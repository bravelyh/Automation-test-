r"""Demo: configure both PSUs on bench_8.

Run:  py -3.14 scripts\demo\psu.py
"""
from __future__ import annotations

from instruments.bench import Bench


bench = Bench()

psu = bench.psu_high_power
psu.open()
psu.set_voltage(14.4)
psu.set_current(1.0)
psu.enable(True)
psu.close()

psu = bench.psu_4ch
psu.open()
psu.set_voltage(12.0, channel=1); psu.set_current(2.0, channel=1); psu.enable(True, channel=1)
psu.set_voltage(14.4, channel=2); psu.set_current(0.5, channel=2); psu.enable(True, channel=2)
psu.set_voltage(3.3,  channel=4); psu.set_current(0.5, channel=4); psu.enable(True, channel=4)
psu.close()
