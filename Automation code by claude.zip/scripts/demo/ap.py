from __future__ import annotations

import sys

from instruments.bench import Bench


def main() -> int:
    bench = Bench()

    # 1. identity ------------------------------------------------------
    print(f"PC ID    : {bench.pc_id}")
    print(f"Bench ID : {bench.bench_id}")
    print(f"AP type  : {bench.ap_type}")

    # 2. build this bench's AP (bench mode) ----------------------------
    ap = bench.ap(mode="bench")          # resolves ap_type internally
    print(f"AP driver: {type(ap).__name__} (mode={ap.mode})")

    # 3. open + configure (base-layer contract) ------------------------
    ap.open()
    try:
        #ap.set_analog_balance_input(channels=2, channel=2, auto_range=False, fixed_range=20.0)
        # high_pass Butterworth/Elliptic -> hpf_frequency (Hz) required;
        # bandwidth applies only when low_pass='AdcPassband' (ignored here).
        #ap.setup_filters(high_pass="Elliptic", low_pass="LpAes17_20k", weighting="wt_None", bandwidth="bw20k", hpf_frequency=20)
        ap.set_digital_generator(waveform = "Sine", level=-36, frequency=100)
        #ap.turn_on_generator()
    finally:
        ap.close()

    return 0


if __name__ == "__main__":
    sys.exit(main())
