r"""Demo: scan this bench — identity + every instrument found on the buses.

Run:  py -3.14 scripts\demo\bench_scan.py
"""
from __future__ import annotations

import sys

from instruments import discovery
from instruments.bench import Bench


def _describe(addr: str, scan: dict) -> str:
    """Human label for a matched address, pulled from the raw scan."""
    for p in scan["com"]:
        if p["address"] == addr:
            return p["description"] or "(no description)"
    for r in scan["visa"]:
        if r["address"] == addr:
            return f"model={r['model'] or '?'}, mfr={r['manufacturer'] or '?'}"
    return "(address not in scan)"


def main() -> int:
    bench = Bench()

    print("=== Bench identity ===")
    print(f"  PC ID    : {bench.pc_id}")
    print(f"  Bench ID : {bench.bench_id}")
    print(f"  AP type  : {bench.ap_type}")

    scan = discovery.scan_all()

    print("\n=== Scanned COM ports ===")
    if scan["com"]:
        for p in scan["com"]:
            desc = p["description"] or "(no description)"
            print(f"  {p['address']:8} {desc}")
    else:
        print("  (none)")

    print("\n=== Scanned VISA resources ===")
    if scan["visa"]:
        for r in scan["visa"]:
            model = r["model"] or "?"
            mfr = r["manufacturer"] or "?"
            print(f"  {r['address']:24} model={model:16} mfr={mfr}")
    else:
        print("  (none)")

    print("\n=== Matched instruments (CATALOG) ===")
    for category in bench.categories():
        try:
            inst = getattr(bench, category)
        except Exception:
            print(f"  {category:16} -> (not found)")
            continue
        addr = getattr(inst, "addr", "?")
        cls = type(inst).__name__
        print(f"  {category:16} -> {cls:18} @ {addr}   {_describe(addr, scan)}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
