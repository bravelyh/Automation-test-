r"""Demo: exercise all three I2X-AAA controls (I2C / I2S / GPIO).

The I2X-AAA is a 3-in-1 bridge over UART. `bench.i2x` auto-discovers it
via its STLink Virtual COM port; open()/close() are no-ops because every
send opens and closes its own connection.

Run:  py -3.14 scripts\demo\i2x.py
"""
from __future__ import annotations

from instruments.bench import Bench


bench = Bench()
i2x = bench.i2x                      # I2X_AAA, resolved by bus scan

# 1. I2C -----------------------------------------------------------------
# Script syntax: 'w DEV REG DATA...' write, 'r DEV REG N' read N bytes,
# 'D<ms>' delay after the previous op. i2c_send returns the parsed reads
# and raises on any per-segment I2C error code.
script = (
    "w E0 03 22\n"       # write 0x22 to reg 0x03 of device 0xE0
    "D100\n"             # wait 100 ms
    "r E0 72 01"          # read 1 byte from reg 0x72
)
results = i2x.i2c_send(script)
print(f"I2C read results: {results}")

# 2. I2S -----------------------------------------------------------------
# Configure the I2S tone generator (keyword-only args).
i2x.i2s_send(
    word_length=24,      # 24 or 32 bits
    sample_rate=48000,   # Hz
    amplitude_dbfs=-6.0, # dBFS, must be <= 0
    frequency=1000,      # Hz
)
print("I2S generator configured")

# 3. GPIO ----------------------------------------------------------------
# Each gpioN is (on: bool, delay_ms: int) or None to leave it unchanged.
i2x.gpio_send(
    gpio1=(True, 0),     # drive GPIO1 high
    gpio3=(False, 50),   # drive GPIO3 low after 50 ms
)
print("GPIO states set")
