r"""Demo: set the loadbox and print each channel's write / read.

Run:  py -3.14 scripts\demo\loadbox.py

Edit MODE / LOAD below (see tools\Loadbox Control for the full GUI):
  MODE 0 = parallel/independent: LOAD is "0/0.5/1/2/3/4/5/6/8/off" (all 4 CH
           the same), or a 4-digit per-channel string like "2234".
  MODE 1 = series: LOAD is an ohm value 0..32 (multiple of 0.5); the 4 CH are
           auto-distributed to sum to it.
  LOAD "off"/"open" opens all 4 CH regardless of MODE.
"""
from __future__ import annotations

from instruments.bench import Bench
from instruments.loadbox.loadbox_SH import (
    LOAD_MAP,
    format_load,
    resolve_mode0,
    resolve_mode1,
)


MODE = 0        # 0 = parallel/independent, 1 = series
LOAD = "6"      # e.g. "4" -> all 4 CH = 4 ohm


bench = Bench()
box = bench.loadbox          # auto-discovered (Prolific USB-Serial)

print(f"Loadbox port: {box.addr}")

# mode/load -> 4 per-channel labels ('1'..'8' / 'off') -> device codes
if str(LOAD).strip().lower() in ("off", "open"):
    labels = ["off"] * 4
elif MODE == 0:
    labels = resolve_mode0(str(LOAD))
else:
    labels = resolve_mode1(str(LOAD))
codes = [LOAD_MAP[k] for k in labels]

print(f"MODE={MODE}  LOAD={LOAD!r}  ->  CH1..CH4={labels}")

results = box.set_load_per_channel(codes, labels)
for r in results:
    print(f'CH{r["ch"]}: load={format_load(r["load"])}, '
          f'write="{r["write"]}", read="{r["read"]}"')
