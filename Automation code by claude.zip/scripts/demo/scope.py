r"""Demo: connect to this bench's oscilloscope and read its ID.

Run:  py -3.14 scripts\demo\scope.py

Two ways to reach the scope:
  * Auto-discovery on GPIB / USB:   scope = bench.scope()
  * Manually over LAN by IP:        scope = bench.scope("10.85.29.232")
    (type only the IP; the TCPIP0::<ip>::inst0::INSTR wrapper is added for you)

If no IP is given and nothing is found on GPIB/USB, bench.scope() raises with
a hint to pass an IP.
"""
from __future__ import annotations

from instruments.bench import Bench


bench = Bench()

# Auto-discover on GPIB/USB. For a LAN scope, pass its IP instead:
# scope = bench.scope("10.85.29.232")
scope = bench.scope()

scope.open()
print("Scope:", scope.get_idn())
# scope.set_timebase(1e-6)          # 1 us/div
# scope.set_channel_scale(1, 0.5)   # CH1 500 mV/div
scope.close()
