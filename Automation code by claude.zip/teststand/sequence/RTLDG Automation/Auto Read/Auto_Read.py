r"""Auto Read — RTLDG periodic-read tool (manual GUI + TestStand interface).

One file, two ways to run:

  * Manual (double-click `Run Auto Read.bat`, or run this file with no args):
    the full interactive GUI — configure a read script by hand, Start/Stop,
    live plot. No auto-start, no auto-close.

  * TestStand (call `auto_read(...)` via the Python Adapter): pops the same
    GUI, auto-loads a config from device+test-name, enables only the CH-
    specific curves, auto-starts, and saves raw/plot on completion.

TestStand interface
-------------------
    auto_read(device_name, test_name, ch, export_dir, test_number,
              load="", config_root="") -> str

    Blocks (runs the live GUI) until the read completes, then returns a
    summary string. Raises RuntimeError on any failure.

    Arguments (device_name/test_name/export_dir/config_root are strings;
    ch, test_number, load are numeric):
        Module   : Auto_Read.py
        Function : auto_read

    Config auto-selected from (config-root defaults to `config/` next to
    this file):
        <config-root>\<device>\Re.json      (test-name contains 'SLOL')
        <config-root>\<device>\Offset.json  (test-name contains 'S2P' or 'S2G')

    Curves enabled by test-name + CH:
        contains OUTP  -> ch<CH> P <suffix>
        contains OUTM  -> ch<CH> N <suffix>
        both           -> both curves
    <suffix> is 'Re' for SLOL, 'offset' for S2P/S2G.

    Saves (only enabled curves; the header/legend labels the P/N side).
    A numeric `load` gets the 'ohm' unit appended, matching Summary Test:
        <export-dir>\raw data\test<N>[_<load>ohm].txt
        <export-dir>\plot\test<N>[_<load>ohm].png
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Imports (union of the manual GUI + TS-wrapper needs)
# ---------------------------------------------------------------------------
import argparse

import json
import os
import queue
import re
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from serial.tools import list_ports


# ---------------------------------------------------------------------------
# I2C bridge — the I2X-AAA driver from the shared instruments library
# (importable anywhere via setup_env.bat; bundled by PyInstaller when frozen)
# ---------------------------------------------------------------------------
from instruments.i2x.i2x_aaa import I2X_AAA


# ---------------------------------------------------------------------------
# COM port detection
# ---------------------------------------------------------------------------
def detect_stlink_port() -> str | None:
    try:
        for port in list_ports.comports():
            desc = (port.description or "").lower()
            if "stlink" in desc and "virtual com" in desc:
                return port.device
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Script parsing - find the first read command
# ---------------------------------------------------------------------------
_READ_RE = re.compile(
    r"^\s*R\s+([0-9A-Fa-f]+)\s+([0-9A-Fa-f]+)\s+(\d+)\s*$",
    re.IGNORECASE,
)


def _split_inline_comment(line: str) -> tuple[str, str]:
    """Split into (code, comment). Comment excludes the leading '#'."""
    idx = line.find("#")
    if idx < 0:
        return line, ""
    return line[:idx], line[idx + 1:].strip()


def _strip_inline_comment(line: str) -> str:
    """Drop everything from '#' onward (inline comment)."""
    return _split_inline_comment(line)[0]


def clean_script(script: str) -> str:
    """Remove inline '#' comments. Case is normalized downstream by
    I2X_AAA.i2c_send (which upper-cases each line)."""
    return "\n".join(_strip_inline_comment(ln) for ln in script.splitlines())


MAX_READS = 8


def find_all_reads(script: str, limit: int = MAX_READS):
    """Return list of dicts, one per 'R ...' line in script order (up to
    `limit`). Each dict has: line_index, dev_hex, reg_hex, count, label.
    label = inline '# comment' text if present, else 'reg{N}' by position."""
    out = []
    for i, raw in enumerate(script.splitlines()):
        code, comment = _split_inline_comment(raw)
        line = code.strip()
        if not line or not line[0].isalnum():
            continue
        m = _READ_RE.match(line)
        if not m:
            continue
        idx = len(out) + 1
        label = comment if comment else f"reg{idx}"
        out.append({
            "line_index": i,
            "dev_hex": m.group(1).upper(),
            "reg_hex": m.group(2).upper(),
            "count": int(m.group(3)),
            "label": label,
        })
        if len(out) >= limit:
            break
    return out


def bytes_to_value_be(byte_list: list[int], signed: bool,
                      effective_bits: int | None = None) -> int:
    """Combine byte list into a single integer (first byte = MSB).

    If effective_bits is given and < 8*len(byte_list), the high padding bits
    are masked off before signed interpretation, so the sign bit is taken
    from bit (effective_bits-1) instead of the MSB of the read bytes.
    Use this for registers where only the low N bits carry data and the
    high bits are unused (e.g., read 4 bytes but data is 24-bit)."""
    v = 0
    for b in byte_list:
        v = (v << 8) | (b & 0xFF)
    total = 8 * len(byte_list)
    bits = effective_bits if effective_bits is not None else total
    if bits < total:
        v &= (1 << bits) - 1
    if signed:
        sign_bit = 1 << (bits - 1)
        if v & sign_bit:
            v -= 1 << bits
    return v


# ---------------------------------------------------------------------------
# Pure-tkinter line plot with embedded X-axis mode dropdown
# ---------------------------------------------------------------------------
class LinePlot(tk.Frame):
    PAD_L = 64
    PAD_R = 14
    PAD_T = 12
    PAD_B = 40
    GRID_COLOR = "#e6e6e6"
    AXIS_COLOR = "#444444"
    LINE_COLOR = "#0066cc"
    BG_COLOR = "#ffffff"
    SCROLL_WINDOW_S = 30.0

    def __init__(self, parent: tk.Widget):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, bg=self.BG_COLOR, highlightthickness=1,
                                highlightbackground="#888888")
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self.redraw())

        self._times: list[float] = []
        # series: list of {"label": str, "color": str, "values": [float],
        #                  "enabled": bool}
        self._series: list[dict] = []
        self._mode = "Auto-fit"

        # X-axis mode dropdown embedded on the canvas, just below the X-axis
        self._mode_btn = ttk.Menubutton(self.canvas, text="Time (s) ▾",
                                        style="XAxis.TMenubutton")
        try:
            ttk.Style().configure("XAxis.TMenubutton",
                                  font=("Segoe UI", 8), padding=0)
        except Exception:
            pass
        m = tk.Menu(self._mode_btn, tearoff=0)
        m.add_command(label="Auto-fit",
                      command=lambda: self._set_mode("Auto-fit"))
        m.add_command(label="Scroll (30 s)",
                      command=lambda: self._set_mode("Scroll"))
        self._mode_btn.config(menu=m)
        self._mode_btn_id = self.canvas.create_window(
            0, 0, window=self._mode_btn, anchor="n")

    # ---- public API
    def set_data(self, times, series):
        """`series` = list of dicts with keys label, color, values, enabled."""
        self._times = times
        self._series = series

    def clear(self):
        self._times = []
        self._series = []
        self.redraw()

    @property
    def mode(self) -> str:
        return self._mode

    def _set_mode(self, mode: str):
        self._mode = mode
        self._mode_btn.config(text=f"Time (s) | {mode} ▾")
        self.redraw()

    # ---- math helpers
    def _xrange(self):
        if not self._times:
            return 0.0, 1.0
        if self._mode == "Scroll":
            x_max = self._times[-1]
            x_min = max(0.0, x_max - self.SCROLL_WINDOW_S)
            if x_max - x_min < 1e-6:
                x_max = x_min + 1e-3
            return x_min, x_max
        return 0.0, max(self._times[-1], 1e-3)

    def _visible_indices(self, x_min, _x_max):
        for i, t in enumerate(self._times):
            if t >= x_min:
                return i, len(self._times)
        return len(self._times), len(self._times)

    def _yrange(self, lo, hi):
        if lo >= hi:
            return 0.0, 1.0
        vmin = None
        vmax = None
        for s in self._series:
            if not s.get("enabled", True):
                continue
            vals = s.get("values") or []
            seg = vals[lo:hi]
            if not seg:
                continue
            smin = min(seg); smax = max(seg)
            vmin = smin if vmin is None else min(vmin, smin)
            vmax = smax if vmax is None else max(vmax, smax)
        if vmin is None:
            return 0.0, 1.0
        if vmax - vmin < 1e-9:
            pad = max(1.0, abs(vmax) * 0.1)
            return vmin - pad, vmax + pad
        pad = (vmax - vmin) * 0.1
        return vmin - pad, vmax + pad

    @staticmethod
    def _nice_ticks(lo, hi, target=6):
        if hi <= lo:
            return [lo]
        import math
        span = hi - lo
        raw = span / max(1, target)
        exp = math.floor(math.log10(raw)) if raw > 0 else 0
        base = 10 ** exp
        step = base
        for m in (1, 2, 2.5, 5, 10):
            step = m * base
            if step >= raw:
                break
        start = math.floor(lo / step) * step
        ticks = []
        v = start
        for _ in range(200):
            if v > hi + step * 0.5:
                break
            if v >= lo - step * 0.5:
                ticks.append(v)
            v += step
        return ticks

    @staticmethod
    def _fmt_num(v):
        av = abs(v)
        if av >= 1e6 or (av != 0 and av < 1e-3):
            return f"{v:.2e}"
        if av >= 1000:
            return f"{v:.0f}"
        if av >= 1:
            s = f"{v:.2f}"
            return s.rstrip("0").rstrip(".") if "." in s else s
        s = f"{v:.3f}"
        return s.rstrip("0").rstrip(".") if "." in s else s

    # ---- draw
    def redraw(self):
        c = self.canvas
        # delete only data items, keep the embedded button
        c.delete("plot")
        w = c.winfo_width()
        h = c.winfo_height()
        if w < 50 or h < 50:
            return

        plot_l = self.PAD_L
        plot_r = w - self.PAD_R
        plot_t = self.PAD_T
        plot_b = h - self.PAD_B
        plot_w = max(1, plot_r - plot_l)
        plot_h = max(1, plot_b - plot_t)

        x_min, x_max = self._xrange()
        lo, hi = self._visible_indices(x_min, x_max)
        y_min, y_max = self._yrange(lo, hi)

        def sx(t):
            return plot_l + (t - x_min) / (x_max - x_min) * plot_w

        def sy(v):
            return plot_b - (v - y_min) / (y_max - y_min) * plot_h

        c.create_rectangle(plot_l, plot_t, plot_r, plot_b,
                           fill=self.BG_COLOR, outline=self.AXIS_COLOR,
                           tags="plot")

        for yt in self._nice_ticks(y_min, y_max, 6):
            y = sy(yt)
            if plot_t <= y <= plot_b:
                c.create_line(plot_l + 1, y, plot_r, y,
                              fill=self.GRID_COLOR, tags="plot")
                c.create_text(plot_l - 6, y, text=self._fmt_num(yt),
                              anchor="e", font=("Segoe UI", 8), tags="plot")

        for xt in self._nice_ticks(x_min, x_max, 6):
            x = sx(xt)
            if plot_l <= x <= plot_r:
                c.create_line(x, plot_t, x, plot_b - 1,
                              fill=self.GRID_COLOR, tags="plot")
                c.create_text(x, plot_b + 4, text=self._fmt_num(xt),
                              anchor="n", font=("Segoe UI", 8), tags="plot")

        # Y axis title
        c.create_text(14, (plot_t + plot_b) / 2,
                      text="Value", anchor="center", angle=90,
                      font=("Segoe UI", 9), tags="plot")

        # X-axis dropdown button at bottom center of plot
        self.canvas.coords(self._mode_btn_id,
                           (plot_l + plot_r) / 2, plot_b + 16)

        # Data lines - one per enabled series
        enabled = [s for s in self._series if s.get("enabled", True)]
        for s in enabled:
            vals = s.get("values") or []
            color = s.get("color", self.LINE_COLOR)
            n = min(hi, len(vals))
            if n - lo >= 2:
                pts = []
                for i in range(lo, n):
                    pts.extend((sx(self._times[i]), sy(vals[i])))
                c.create_line(*pts, fill=color, width=2,
                              smooth=False, tags="plot")
            elif n - lo == 1:
                x = sx(self._times[lo]); y = sy(vals[lo])
                c.create_oval(x - 3, y - 3, x + 3, y + 3,
                              fill=color, outline=color, tags="plot")


# ---------------------------------------------------------------------------
# Worker thread
# ---------------------------------------------------------------------------
class ReadWorker(threading.Thread):
    def __init__(self, stm32: I2X_AAA, script: str, reads: list[dict],
                 count: int, interval_s: float, signed: bool,
                 effective_bits_setting: str,
                 sample_queue: queue.Queue, stop_event: threading.Event):
        """`reads` is the list from find_all_reads(). `effective_bits_setting`
        is the raw UI value: 'auto' means per-read count*8; otherwise the
        parsed int applies to every read."""
        super().__init__(daemon=True)
        self.stm32 = stm32
        self.script = script
        self.reads = reads
        self.count = count
        self.interval_s = interval_s
        self.signed = signed
        self.eb_setting = effective_bits_setting
        self.q = sample_queue
        self.stop_event = stop_event

    MAX_CONSEC_FAILS = 10

    def _effective_bits_for(self, byte_count: int) -> int:
        s = (self.eb_setting or "").strip().lower()
        if s in ("", "auto"):
            return byte_count * 8
        return int(s)

    def run(self):
        if not self.reads:
            self.q.put(("error", "Script has no read command"))
            return

        t0 = time.perf_counter()
        i = 0
        consec_fails = 0
        try:
            while not self.stop_event.is_set() and i < self.count:
                target = t0 + i * self.interval_s
                while not self.stop_event.is_set():
                    remaining = target - time.perf_counter()
                    if remaining <= 0:
                        break
                    time.sleep(min(remaining, 0.005))
                if self.stop_event.is_set():
                    break

                t_send = time.perf_counter() - t0
                # Try once; if the firmware silently drops the command
                # (partial UART frame → bytes_nums != UART_LEN → return),
                # a quick retry usually succeeds. Only warn if the retry
                # also fails.
                results = None
                first_exc = None
                for attempt in range(2):
                    try:
                        results = self.stm32.i2c_send(self.script)
                        break
                    except Exception as exc:
                        if first_exc is None:
                            first_exc = exc
                        if attempt == 0:
                            # Brief pause lets the firmware finish any
                            # in-flight response and re-arm its UART RX.
                            time.sleep(0.02)
                if results is None:
                    consec_fails += 1
                    self.q.put(("warn",
                                f"Read failed at point {i + 1} "
                                f"(2 attempts): {first_exc}"))
                    if consec_fails >= self.MAX_CONSEC_FAILS:
                        self.q.put(("error",
                                    f"Aborting after {consec_fails} "
                                    "consecutive failures"))
                        return
                    i += 1
                    continue
                if first_exc is not None:
                    # First attempt failed, retry succeeded - log as info.
                    self.q.put(("warn",
                                f"Recovered at point {i + 1} after retry "
                                f"({first_exc})"))

                if not results or len(results) < len(self.reads):
                    self.q.put(("error",
                                f"Expected {len(self.reads)} read blocks, "
                                f"got {len(results) if results else 0} "
                                f"at point {i + 1}"))
                    return

                # Parse every read block into a raw int
                per_read = []
                bad = False
                for k, block in enumerate(results[:len(self.reads)]):
                    if not block:
                        self.q.put(("error",
                                    f"Empty read block #{k + 1} at "
                                    f"point {i + 1}"))
                        return
                    byte_list = []
                    for entry in block:
                        try:
                            byte_list.append(int(entry[4:6], 16))
                        except Exception:
                            self.q.put(("error",
                                        f"Bad data {entry!r} in read #{k + 1} "
                                        f"at point {i + 1}"))
                            bad = True
                            break
                    if bad:
                        return
                    eb = self._effective_bits_for(len(byte_list))
                    raw = bytes_to_value_be(byte_list, self.signed, eb)
                    per_read.append((byte_list, raw))

                self.q.put(("sample", i, t_send, per_read))
                consec_fails = 0
                i += 1

            self.q.put(("done", i))
        except Exception as exc:
            self.q.put(("error", f"Worker crashed: {exc}"))


# ---------------------------------------------------------------------------
# Main GUI
# ---------------------------------------------------------------------------
class AutoReadGUI:
    REDRAW_MS = 80
    PALETTE = [
        "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
        "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
    ]

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Auto Read")
        self.stm32: I2X_AAA | None = None
        self.port_name: str | None = None

        self.times: list[float] = []
        # self.reads: list of dicts per read line, populated on Start:
        #   {"label", "reg_hex", "count", "color", "raws", "enabled_var"}
        self.reads: list[dict] = []
        self.sample_q: queue.Queue = queue.Queue()
        self.stop_event = threading.Event()
        self.worker: ReadWorker | None = None
        self._target_count = 0
        self._dirty = False
        self._run_signed = False  # frozen at run start, used for save filenames

        # Remember last-used export folder / filename so the dialog can
        # pre-fill them on the next open (session-only).
        self._last_export_folder: str = ""
        self._last_export_name: str = ""
        # Remember last Save/Load Config path (session-only).
        self._last_config_path: str = ""

        # Tk vars
        self.com_var = tk.StringVar(value="(scanning...)")
        self.points_var = tk.StringVar(value="1000")
        self.interval_var = tk.StringVar(value="50")
        self.signed_var = tk.BooleanVar(value=False)
        self.effective_bits_var = tk.StringVar(value="auto")
        self.a_var = tk.StringVar(value="1")
        self.b_var = tk.StringVar(value="0")
        self.live_var = tk.StringVar(value="-")
        self.min_var = tk.StringVar(value="-")
        self.max_var = tk.StringVar(value="-")
        self.mean_var = tk.StringVar(value="-")
        self.variation_var = tk.StringVar(value="-")
        self.stats_pick_var = tk.StringVar(value="")

        # cached coefficients (only re-parsed when entries change)
        self._a = 1.0
        self._b = 0.0
        self.a_var.trace_add("write", lambda *_: self._on_coef_change())
        self.b_var.trace_add("write", lambda *_: self._on_coef_change())

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(100, self._scan_port)
        self.root.after(50, self._drain_queue)
        self.root.after(self.REDRAW_MS, self._tick_redraw)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=8)
        outer.grid(sticky="nsew")
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        # Layout: 2 columns. Left fixed, right (graph) expands.
        outer.grid_columnconfigure(0, weight=0)
        outer.grid_columnconfigure(1, weight=1)
        outer.grid_rowconfigure(1, weight=1)

        # Row 0 — Connection (STLink scan left, Config buttons right)
        cf = ttk.LabelFrame(outer, text="Connection", padding=6)
        cf.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        ttk.Label(cf, text="STLink:").grid(row=0, column=0, sticky="w")
        self.com_lbl = ttk.Label(cf, textvariable=self.com_var,
                                 foreground="#cc0000", width=22)
        self.com_lbl.grid(row=0, column=1, padx=4, sticky="w")
        self.conn_btn = ttk.Button(cf, text="Rescan",
                                   command=self._scan_port, width=10)
        self.conn_btn.grid(row=0, column=2, padx=4)
        # Spacer pushes config buttons to the far right
        cf.grid_columnconfigure(3, weight=1)
        ttk.Button(cf, text="Save Cfg", command=self._save_config,
                   width=10).grid(row=0, column=4, padx=2)
        ttk.Button(cf, text="Load Cfg", command=self._load_config,
                   width=10).grid(row=0, column=5, padx=2)

        # Row 1 col 0 — left column: settings on top, script below
        left = ttk.Frame(outer)
        left.grid(row=1, column=0, rowspan=2, sticky="nsew", padx=(0, 8))

        sf = ttk.LabelFrame(left, text="Settings", padding=6)
        sf.grid(row=0, column=0, sticky="new")

        r = 0
        ttk.Label(sf, text="Number of points:").grid(row=r, column=0, sticky="w")
        ttk.Entry(sf, textvariable=self.points_var, width=10).grid(
            row=r, column=1, sticky="w", padx=4, pady=2); r += 1

        ttk.Label(sf, text="Interval (ms):").grid(row=r, column=0, sticky="w")
        ttk.Entry(sf, textvariable=self.interval_var, width=10).grid(
            row=r, column=1, sticky="w", padx=4, pady=2); r += 1

        ttk.Label(sf, text="Signed:").grid(row=r, column=0, sticky="w")
        ttk.Checkbutton(sf, variable=self.signed_var).grid(
            row=r, column=1, sticky="w", padx=4, pady=2); r += 1

        ttk.Label(sf, text="Effective bits:").grid(row=r, column=0, sticky="w")
        ttk.Combobox(sf, textvariable=self.effective_bits_var, width=8,
                     values=("auto", "8", "16", "24", "32"),
                     state="readonly").grid(
            row=r, column=1, sticky="w", padx=4, pady=2); r += 1

        ttk.Separator(sf, orient="horizontal").grid(
            row=r, column=0, columnspan=2, sticky="ew", pady=4); r += 1

        ttk.Label(sf, text="Value conversion:  val = a · raw + b",
                  font=("Segoe UI", 9, "italic"),
                  foreground="#555555").grid(
            row=r, column=0, columnspan=2, sticky="w"); r += 1

        ttk.Label(sf, text="a:").grid(row=r, column=0, sticky="w")
        ttk.Entry(sf, textvariable=self.a_var, width=10).grid(
            row=r, column=1, sticky="w", padx=4, pady=2); r += 1

        ttk.Label(sf, text="b:").grid(row=r, column=0, sticky="w")
        ttk.Entry(sf, textvariable=self.b_var, width=10).grid(
            row=r, column=1, sticky="w", padx=4, pady=2); r += 1

        ttk.Label(sf,
                  text="count → 1=8b, 2=16b, 3=24b, 4=32b\n"
                       "First byte read = high byte\n"
                       "Effective bits: auto = count×8.\n"
                       "Set lower if high bits are padding\n"
                       "(e.g. read 4 B, data is 24-bit → 24).",
                  foreground="grey", font=("Segoe UI", 8),
                  justify="left").grid(
            row=r, column=0, columnspan=2, sticky="w", pady=(6, 0))

        # Script frame below settings (narrower)
        scf = ttk.LabelFrame(left, text="Script", padding=6)
        scf.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        left.grid_rowconfigure(1, weight=1)

        sb = ttk.Scrollbar(scf, orient="vertical")
        sb.grid(row=0, column=1, sticky="ns")
        self.script_text = tk.Text(scf, height=10, width=22,
                                   font=("Consolas", 10), wrap="none",
                                   yscrollcommand=sb.set)
        self.script_text.grid(row=0, column=0, sticky="nsew")
        sb.config(command=self.script_text.yview)
        scf.grid_rowconfigure(0, weight=1)
        scf.grid_columnconfigure(0, weight=1)
        self.script_text.insert(
            "1.0",
            "w e0 00 00\n"
            "w e0 7f 00\n"
            "r e0 d1 02\n",
        )

        bf = ttk.Frame(scf)
        bf.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self.start_btn = ttk.Button(bf, text="Start", command=self._start, width=8)
        self.start_btn.grid(row=0, column=0, padx=2)
        self.stop_btn = ttk.Button(bf, text="Stop", command=self._stop,
                                   width=8, state="disabled")
        self.stop_btn.grid(row=0, column=1, padx=2)
        ttk.Button(bf, text="Clear", command=self._clear_plot,
                   width=8).grid(row=0, column=2, padx=2)

        # Row 1 col 1 — Graph (expanding, larger). Live read info sits
        # inside the Graph frame just above the canvas.
        gf = ttk.LabelFrame(outer, text="Graph", padding=4)
        gf.grid(row=1, column=1, sticky="nsew")
        ttk.Label(gf, textvariable=self.live_var,
                  font=("Consolas", 10), foreground="#0066cc",
                  anchor="w", wraplength=1, justify="left").pack(
            fill="x", padx=2, pady=(0, 2))
        # Attach a resize handler so the live-read label wraps to the
        # current width instead of stretching the window.
        self._live_lbl = gf.pack_slaves()[-1]
        self._live_lbl.bind("<Configure>",
                            lambda e: self._live_lbl.config(
                                wraplength=max(1, e.width - 4)))

        content = ttk.Frame(gf)
        content.pack(fill="both", expand=True)
        self.plot = LinePlot(content)
        self.plot.pack(side="left", fill="both", expand=True)

        # Right-side legend/checkbox column - populated on Start
        self.legend_frame = ttk.LabelFrame(content, text="Series", padding=4)
        self.legend_frame.pack(side="right", fill="y", padx=(6, 0))
        self._legend_placeholder = ttk.Label(
            self.legend_frame, text="(none)",
            foreground="#888", font=("Segoe UI", 9))
        self._legend_placeholder.pack(anchor="w", padx=2, pady=2)

        # Row 2 col 1 — Statistics (right, under Graph). Each value gets a
        # 14-char field so 10-digit numbers fit, with generous gaps between.
        rf = ttk.LabelFrame(outer, text="Statistics", padding=6)
        rf.grid(row=2, column=1, sticky="ew", pady=(6, 0))
        L_FONT = ("Segoe UI", 9, "bold")
        V_FONT = ("Consolas", 10, "bold")
        STAT_GAP = 28
        col = 0

        ttk.Label(rf, text="Series:", font=L_FONT).grid(
            row=0, column=col, sticky="e", padx=(0, 4)); col += 1
        self.stats_combo = ttk.Combobox(
            rf, textvariable=self.stats_pick_var, width=16,
            state="readonly", values=())
        self.stats_combo.grid(row=0, column=col, sticky="w",
                              padx=(0, STAT_GAP)); col += 1
        self.stats_combo.bind(
            "<<ComboboxSelected>>", lambda _e: self._update_stats())

        def _stat(label, var, width):
            nonlocal col
            ttk.Label(rf, text=label, font=L_FONT).grid(
                row=0, column=col, sticky="e", padx=(0, 4)); col += 1
            ttk.Label(rf, textvariable=var, font=V_FONT,
                      width=width, anchor="w",
                      foreground="#003366").grid(
                row=0, column=col, sticky="w", padx=(0, STAT_GAP)); col += 1

        _stat("Min:",       self.min_var,       14)
        _stat("Max:",       self.max_var,       14)
        _stat("Mean:",      self.mean_var,      14)
        _stat("Variation:", self.variation_var, 36)
        ttk.Button(rf, text="Export...", command=self._export, width=12).grid(
            row=0, column=col, sticky="w", padx=(8, 0))

        # Row 3 — Log (full width, taller)
        lf = ttk.LabelFrame(outer, text="Log", padding=4)
        lf.grid(row=3, column=0, columnspan=2, sticky="nsew", pady=(6, 0))
        outer.grid_rowconfigure(3, weight=0, minsize=180)
        self.log_text = tk.Text(lf, height=10, font=("Consolas", 9),
                                state="disabled", wrap="word")
        sb2 = ttk.Scrollbar(lf, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb2.set)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        sb2.grid(row=0, column=1, sticky="ns")
        lf.grid_rowconfigure(0, weight=1)
        lf.grid_columnconfigure(0, weight=1)

    # ------------------------------------------------------------- helpers
    def log(self, msg: str):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", msg + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _on_coef_change(self):
        try:
            self._a = float(self.a_var.get())
        except Exception:
            pass
        try:
            self._b = float(self.b_var.get())
        except Exception:
            pass
        self._dirty = True
        self._update_stats()

    def _computed_for(self, read: dict) -> list[float]:
        a, b = self._a, self._b
        return [a * r + b for r in read["raws"]]

    def _series_for_plot(self) -> list[dict]:
        return [{
            "label": r["label"],
            "color": r["color"],
            "values": self._computed_for(r),
            "enabled": bool(r["enabled_var"].get()),
        } for r in self.reads]

    def _enabled_reads(self) -> list[dict]:
        return [r for r in self.reads if bool(r["enabled_var"].get())]

    def _rebuild_legend(self):
        """Rebuild the right-side checkbox column from self.reads."""
        for w in self.legend_frame.winfo_children():
            w.destroy()
        if not self.reads:
            self._legend_placeholder = ttk.Label(
                self.legend_frame, text="(none)",
                foreground="#888", font=("Segoe UI", 9))
            self._legend_placeholder.pack(anchor="w", padx=2, pady=2)
            return
        for r in self.reads:
            row = ttk.Frame(self.legend_frame)
            row.pack(anchor="w", padx=2, pady=1, fill="x")
            swatch = tk.Label(row, text="  ", bg=r["color"],
                              width=2, relief="solid", bd=1)
            swatch.pack(side="left", padx=(0, 4))
            ttk.Checkbutton(row, text=r["label"],
                            variable=r["enabled_var"],
                            command=self._on_enabled_toggle).pack(
                side="left", anchor="w")

    def _on_enabled_toggle(self):
        self._dirty = True
        self._update_stats()

    def _refresh_stats_combo(self):
        labels = [r["label"] for r in self.reads]
        self.stats_combo.config(values=labels)
        cur = self.stats_pick_var.get()
        if cur not in labels:
            self.stats_pick_var.set(labels[0] if labels else "")

    # ------------------------------------------------------------- connect
    def _scan_port(self):
        """Scan for STLink port without holding it open."""
        port = detect_stlink_port()
        if not port:
            self.port_name = None
            self.com_var.set("No STLink found")
            self.com_lbl.config(foreground="#cc0000")
            self.log("[ERR] No STLink Virtual COM port detected")
            return
        self.port_name = port
        self.com_var.set(f"{port} connected")
        self.com_lbl.config(foreground="#007700")
        self.log(f"[OK] Detected {port} (port released, opens on Run)")

    # ------------------------------------------------------------- config
    CONFIG_VERSION = 1
    CONFIG_EXT = ".json"

    def _collect_config(self) -> dict:
        return {
            "version": self.CONFIG_VERSION,
            "script": self.script_text.get("1.0", "end-1c"),
            "points": self.points_var.get(),
            "interval_ms": self.interval_var.get(),
            "signed": bool(self.signed_var.get()),
            "effective_bits": self.effective_bits_var.get(),
            "a": self.a_var.get(),
            "b": self.b_var.get(),
        }

    def _apply_config(self, cfg: dict):
        # Tolerate missing keys — fall back to current value for each field.
        if "script" in cfg:
            self.script_text.delete("1.0", "end")
            self.script_text.insert("1.0", str(cfg["script"]))
        if "points" in cfg:
            self.points_var.set(str(cfg["points"]))
        if "interval_ms" in cfg:
            self.interval_var.set(str(cfg["interval_ms"]))
        if "signed" in cfg:
            self.signed_var.set(bool(cfg["signed"]))
        if "effective_bits" in cfg:
            self.effective_bits_var.set(str(cfg["effective_bits"]))
        if "a" in cfg:
            self.a_var.set(str(cfg["a"]))
        if "b" in cfg:
            self.b_var.set(str(cfg["b"]))

    def _save_config(self):
        initial_dir, initial_file = "", "auto_read_config" + self.CONFIG_EXT
        if self._last_config_path:
            initial_dir = os.path.dirname(self._last_config_path)
            initial_file = os.path.basename(self._last_config_path)
        path = filedialog.asksaveasfilename(
            parent=self.root,
            title="Save Config",
            defaultextension=self.CONFIG_EXT,
            filetypes=[("JSON config", "*.json"), ("All files", "*.*")],
            initialdir=initial_dir or os.path.expanduser("~"),
            initialfile=initial_file,
        )
        if not path:
            return
        try:
            cfg = self._collect_config()
            with open(path, "w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=2, ensure_ascii=False)
            self._last_config_path = path
            self.log(f"[OK] Config saved: {path}")
        except Exception as exc:
            messagebox.showerror("Save Failed", str(exc))
            self.log(f"[ERR] Save config: {exc}")

    def _load_config(self):
        initial_dir = (os.path.dirname(self._last_config_path)
                       if self._last_config_path else os.path.expanduser("~"))
        initial_file = (os.path.basename(self._last_config_path)
                        if self._last_config_path else "")
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Load Config",
            filetypes=[("JSON config", "*.json"), ("All files", "*.*")],
            initialdir=initial_dir,
            initialfile=initial_file,
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            if not isinstance(cfg, dict):
                raise ValueError("config file is not a JSON object")
            self._apply_config(cfg)
            self._last_config_path = path
            self.log(f"[OK] Config loaded: {path}")
        except Exception as exc:
            messagebox.showerror("Load Failed", str(exc))
            self.log(f"[ERR] Load config: {exc}")

    def _export(self):
        """Pop a small dialog: pick Plot/Raw + folder + filename, then save."""
        if not self.times or not self.reads:
            messagebox.showinfo("No Data", "Nothing to export yet.")
            return
        enabled = self._enabled_reads()
        if not enabled:
            messagebox.showinfo(
                "No Series Enabled",
                "Check at least one series in the Graph legend before export.")
            return

        dlg = tk.Toplevel(self.root)
        dlg.title("Export")
        dlg.transient(self.root)
        dlg.resizable(False, False)
        dlg.grab_set()

        plot_var = tk.BooleanVar(value=True)
        raw_var = tk.BooleanVar(value=True)
        folder_var = tk.StringVar(value=self._last_export_folder)
        default_name = (self._last_export_name
                        or f"auto_read_{time.strftime('%Y%m%d_%H%M%S')}")
        name_var = tk.StringVar(value=default_name)

        f = ttk.Frame(dlg, padding=10)
        f.pack(fill="both", expand=True)

        ttk.Label(f, text="Items to save:").grid(
            row=0, column=0, columnspan=3, sticky="w")
        ttk.Checkbutton(f, text="Plot (.png)", variable=plot_var).grid(
            row=1, column=0, columnspan=3, sticky="w", pady=2)
        ttk.Checkbutton(f, text="Raw data (.txt)", variable=raw_var).grid(
            row=2, column=0, columnspan=3, sticky="w", pady=2)

        ttk.Label(f, text="Folder:").grid(
            row=3, column=0, sticky="w", pady=(8, 2))
        ttk.Entry(f, textvariable=folder_var, width=44).grid(
            row=3, column=1, sticky="ew", padx=4)

        def browse():
            d = filedialog.askdirectory(
                parent=dlg,
                title="Select folder",
                initialdir=folder_var.get() or os.path.expanduser("~"))
            if d:
                folder_var.set(d)

        ttk.Button(f, text="Browse...", command=browse, width=10).grid(
            row=3, column=2, padx=2)

        ttk.Label(f, text="Filename:").grid(
            row=4, column=0, sticky="w", pady=(2, 2))
        ttk.Entry(f, textvariable=name_var, width=44).grid(
            row=4, column=1, columnspan=2, sticky="ew", padx=4, pady=(2, 2))

        btns = ttk.Frame(f)
        btns.grid(row=5, column=0, columnspan=3, sticky="e", pady=(12, 0))

        def do_save():
            plot_on = plot_var.get()
            raw_on = raw_var.get()
            if not (plot_on or raw_on):
                messagebox.showerror(
                    "Nothing Selected",
                    "Check Plot, Raw data, or both.", parent=dlg)
                return
            folder = folder_var.get().strip()
            if not folder:
                messagebox.showerror(
                    "Missing Folder",
                    "Enter or browse a folder.", parent=dlg)
                return
            if not os.path.isdir(folder):
                messagebox.showerror(
                    "Bad Folder",
                    f"Folder does not exist:\n{folder}", parent=dlg)
                return
            base = name_var.get().strip()
            if not base:
                messagebox.showerror(
                    "Missing Filename",
                    "Enter a filename.", parent=dlg)
                return
            # strip a known extension if the user typed one
            for ext in (".png", ".txt", ".ps", ".csv"):
                if base.lower().endswith(ext):
                    base = base[:-len(ext)]
                    break

            # Remember these for the next Export dialog open.
            self._last_export_folder = folder
            self._last_export_name = base

            # Hide the dialog BEFORE the screen-grab so it isn't captured.
            dlg.withdraw()
            self.root.update_idletasks()
            self.root.update()
            # Brief pause to let the OS repaint the area where the dialog was.
            time.sleep(0.15)
            self.root.update()

            try:
                if raw_on:
                    try:
                        p = self._save_raw_txt(folder, base)
                        self.log(f"[OK] Raw data saved: {p}")
                    except Exception as exc:
                        self.log(f"[ERR] Raw data save failed: {exc}")
                if plot_on:
                    try:
                        p = self._save_plot_image(folder, base)
                        self.log(f"[OK] Plot saved: {p}")
                    except Exception as exc:
                        self.log(f"[ERR] Plot save failed: {exc}")
            finally:
                dlg.destroy()

        ttk.Button(btns, text="Save", command=do_save, width=10).pack(
            side="left", padx=4)
        ttk.Button(btns, text="Cancel", command=dlg.destroy, width=10).pack(
            side="left")
        f.grid_columnconfigure(1, weight=1)
        dlg.update_idletasks()
        # Center over parent
        px = self.root.winfo_rootx() + (self.root.winfo_width() - dlg.winfo_width()) // 2
        py = self.root.winfo_rooty() + (self.root.winfo_height() - dlg.winfo_height()) // 3
        dlg.geometry(f"+{max(0, px)}+{max(0, py)}")

    # ------------------------------------------------------------- start
    def _start(self):
        if not self.port_name:
            messagebox.showwarning("No Port",
                                   "No STLink detected. Click Rescan.")
            return
        if self.worker and self.worker.is_alive():
            return

        try:
            n_points = int(self.points_var.get())
            if n_points < 1:
                raise ValueError("Points must be >= 1")
            interval_ms = float(self.interval_var.get())
            if interval_ms <= 0:
                raise ValueError("Interval must be > 0")
        except Exception as exc:
            messagebox.showerror("Bad Settings", str(exc))
            return

        # validate coefficients explicitly
        try:
            self._a = float(self.a_var.get())
            self._b = float(self.b_var.get())
        except Exception:
            messagebox.showerror("Bad Coefficients",
                                 "a and b must be numbers (default a=1, b=0).")
            return

        raw_script = self.script_text.get("1.0", "end").strip()
        if not raw_script:
            messagebox.showerror("Empty Script", "Enter a script with one R command.")
            return
        # Parse read commands (and their inline-comment labels) from the
        # RAW script before stripping comments; the STM32 firmware gets
        # the cleaned copy.
        reads = find_all_reads(raw_script, limit=MAX_READS)
        script = clean_script(raw_script)
        if not reads:
            messagebox.showerror(
                "No Read",
                "Script must contain at least one read line: "
                "R <dev> <reg> <count> where count is 1..4.")
            return
        for r in reads:
            if r["count"] < 1 or r["count"] > 4:
                messagebox.showerror(
                    "Bad Count",
                    f"Read count {r['count']} for {r['label']} out of range. "
                    "Only 1..4 (8/16/24/32-bit values) are supported.")
                return
        # Warn if the script has more than MAX_READS read lines
        # (extras were dropped by find_all_reads)
        total_read_lines = sum(
            1 for ln in script.splitlines()
            if _READ_RE.match(_strip_inline_comment(ln).strip() or ""))
        if total_read_lines > MAX_READS:
            messagebox.showwarning(
                "Too Many Reads",
                f"Script has {total_read_lines} read lines; only the first "
                f"{MAX_READS} will be used.")

        # Parse Effective bits: "auto" / "" → per-read count*8, else global int
        eb_text = self.effective_bits_var.get().strip().lower()
        if eb_text not in ("", "auto"):
            try:
                eb_val = int(eb_text)
            except Exception:
                messagebox.showerror(
                    "Bad Effective Bits",
                    "Effective bits must be 'auto' or an integer.")
                return
            for r in reads:
                max_bits = r["count"] * 8
                if eb_val < 1 or eb_val > max_bits:
                    messagebox.showerror(
                        "Bad Effective Bits",
                        f"Effective bits {eb_val} exceeds {max_bits} for "
                        f"{r['label']} (count={r['count']}).")
                    return

        # Build the I2C bridge (I2X_AAA opens/closes the port per transaction)
        try:
            self.stm32 = I2X_AAA(self.port_name)
        except Exception as exc:
            self.stm32 = None
            messagebox.showerror("Open Failed",
                                 f"Could not open {self.port_name}:\n{exc}")
            self.log(f"[ERR] Open {self.port_name}: {exc}")
            return

        # Build self.reads (preserve enabled state for labels that already
        # existed in the previous run).
        prev_enabled = {r["label"]: bool(r["enabled_var"].get())
                        for r in self.reads}
        self.reads = []
        for k, r in enumerate(reads):
            enabled = prev_enabled.get(r["label"], True)
            var = tk.BooleanVar(value=enabled)
            var.trace_add("write", lambda *_: self._on_enabled_toggle())
            self.reads.append({
                "label": r["label"],
                "reg_hex": r["reg_hex"],
                "count": r["count"],
                "color": self.PALETTE[k % len(self.PALETTE)],
                "raws": [],
                "enabled_var": var,
            })
        self.times = []
        self.plot.clear()
        self._rebuild_legend()
        self._refresh_stats_combo()
        self._reset_stats()

        reg_summary = ", ".join(
            f"{r['label']}@0x{r['reg_hex']}({r['count']*8}b)" for r in reads)
        self.live_var.set("-")
        self._target_count = n_points
        self._run_signed = self.signed_var.get()
        self.stop_event = threading.Event()
        self.worker = ReadWorker(
            stm32=self.stm32,
            script=script,
            reads=reads,
            count=n_points,
            interval_s=interval_ms / 1000.0,
            signed=self._run_signed,
            effective_bits_setting=self.effective_bits_var.get(),
            sample_queue=self.sample_q,
            stop_event=self.stop_event,
        )
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.log(f"[--] Start: {n_points} points @ {interval_ms} ms, "
                 f"{len(reads)} read(s) [{reg_summary}], "
                 f"signed={self._run_signed}, ebits={self.effective_bits_var.get()}, "
                 f"a={self._a}, b={self._b}")
        self.worker.start()

    def _stop(self):
        if self.worker and self.worker.is_alive():
            self.stop_event.set()
            self.log("[--] Stop requested")

    def _clear_plot(self):
        self.times = []
        for r in self.reads:
            r["raws"] = []
        self.plot.clear()
        self._reset_stats()
        self.live_var.set("-")

    # ---------------------------------------------------------- queue pump
    def _drain_queue(self):
        try:
            error_msg = None
            done_count = None
            while True:
                try:
                    msg = self.sample_q.get_nowait()
                except queue.Empty:
                    break
                kind = msg[0]
                if kind == "sample":
                    _, idx, t_send, per_read = msg
                    self.times.append(t_send)
                    parts = [f"#{idx + 1}/{self._target_count}"]
                    for k, (byte_list, raw) in enumerate(per_read):
                        if k >= len(self.reads):
                            break
                        self.reads[k]["raws"].append(raw)
                        if not self.reads[k]["enabled_var"].get():
                            continue
                        val = self._a * raw + self._b
                        val_str = (f"{val:.4g}" if abs(val) < 1e6
                                   else f"{val:.4e}")
                        hex_str = "".join(f"{b:02X}" for b in byte_list)
                        parts.append(
                            f"{self.reads[k]['label']}=0x{hex_str}→{val_str}")
                    self.live_var.set("  ".join(parts))
                    self._dirty = True
                elif kind == "warn":
                    self.log(f"[WARN] {msg[1]}")
                elif kind == "done":
                    done_count = msg[1]
                elif kind == "error":
                    error_msg = msg[1]
                    break

            if error_msg is not None:
                self.log(f"[ERR] {error_msg}")
                self._finish(error=True)
            elif done_count is not None:
                self.log(f"[OK] Completed {done_count} reads")
                self._finish(error=False)
        finally:
            self.root.after(50, self._drain_queue)

    def _tick_redraw(self):
        if self._dirty:
            self.plot.set_data(self.times, self._series_for_plot())
            self.plot.redraw()
            self._dirty = False
        self.root.after(self.REDRAW_MS, self._tick_redraw)

    # ----------------------------------------------------------- stats
    def _reset_stats(self):
        self.min_var.set("-")
        self.max_var.set("-")
        self.mean_var.set("-")
        self.variation_var.set("-")

    def _update_stats(self):
        label = self.stats_pick_var.get()
        read = next((r for r in self.reads if r["label"] == label), None)
        if read is None or not read["raws"]:
            self._reset_stats()
            return
        comp = self._computed_for(read)
        vmin = min(comp); vmax = max(comp)
        vmean = sum(comp) / len(comp)
        middle = (vmin + vmax) / 2.0
        half = (vmax - vmin) / 2.0
        if abs(middle) > 1e-12:
            pct = abs(half / middle) * 100.0
            variation_str = f"{self._fmt(middle)} ± {self._fmt(half)} ({pct:.2f}%)"
        elif half == 0:
            variation_str = f"{self._fmt(middle)} ± 0 (0.00%)"
        else:
            variation_str = f"{self._fmt(middle)} ± {self._fmt(half)} (n/a)"
        self.min_var.set(self._fmt(vmin))
        self.max_var.set(self._fmt(vmax))
        self.mean_var.set(self._fmt(vmean))
        self.variation_var.set(variation_str)

    @staticmethod
    def _fmt(v: float) -> str:
        if abs(v) >= 1e10 or (v != 0 and abs(v) < 1e-3):
            return f"{v:.4e}"
        if float(v).is_integer():
            return f"{int(v)}"
        return f"{v:.4f}".rstrip("0").rstrip(".")

    def _finish(self, error: bool):
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.plot.set_data(self.times, self._series_for_plot())
        self.plot.redraw()

        # Release the COM port immediately on run end
        if self.stm32 is not None:
            try:
                self.stm32.close()
            except Exception:
                pass
            self.stm32 = None
            self.log(f"[--] Released {self.port_name}")

        n_samples = len(self.times)
        if n_samples:
            self._update_stats()
            self.log(f"[--] {'Stopped' if error else 'Done'}: "
                     f"{n_samples} samples × {len(self.reads)} reads")
        else:
            self._reset_stats()
            self.log(f"[--] {'Stopped' if error else 'Done (no samples)'}")

    def _save_raw_txt(self, folder: str, basename: str) -> str:
        """Tab-separated .txt with one time column plus (raw, value) columns
        for every enabled series. Opens cleanly in Excel, Notepad, etc."""
        path = os.path.join(folder, f"{basename}.txt")
        a, b = self._a, self._b
        enabled = self._enabled_reads()
        headers = ["index", "time_s"]
        for r in enabled:
            headers.append(f"raw_{r['label']}")
            headers.append(f"val_{r['label']}")
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write("\t".join(headers) + "\n")
            n = len(self.times)
            for i in range(n):
                row = [str(i + 1), f"{self.times[i]:.6f}"]
                for r in enabled:
                    if i < len(r["raws"]):
                        raw = r["raws"][i]
                        row.append(str(raw))
                        row.append(f"{a * raw + b}")
                    else:
                        row.append("")
                        row.append("")
                f.write("\t".join(row) + "\n")
        return path

    def _save_plot_image(self, folder: str, basename: str) -> str:
        """Save plot as PNG. Prefers Win32 PrintWindow so overlapping
        windows don't leak into the capture; falls back to ImageGrab,
        then to .ps postscript."""
        canvas = self.plot.canvas
        self.root.update_idletasks()
        self.root.update()
        canvas.update()

        png_path = os.path.join(folder, f"{basename}.png")

        img = self._grab_canvas_printwindow()
        if img is not None:
            img.save(png_path)
            return png_path

        try:
            from PIL import ImageGrab  # type: ignore
            x = canvas.winfo_rootx()
            y = canvas.winfo_rooty()
            w = canvas.winfo_width()
            h = canvas.winfo_height()
            img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
            img.save(png_path)
            return png_path
        except Exception:
            pass

        ps_path = os.path.join(folder, f"{basename}.ps")
        canvas.postscript(file=ps_path, colormode="color")
        return ps_path

    def _grab_canvas_printwindow(self):
        """Capture the tk toplevel via Win32 PrintWindow(PW_RENDERFULLCONTENT)
        and crop to the plot canvas region. Reads from the window's backing
        store, so other windows overlapping the plot area do NOT appear in
        the output. Returns PIL.Image on success, None on any failure
        (non-Windows, missing PIL/ctypes, API error)."""
        if sys.platform != "win32":
            return None
        try:
            import ctypes
            from ctypes import wintypes
            from PIL import Image  # type: ignore
        except Exception:
            return None

        canvas = self.plot.canvas
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32

        # tk's winfo_id() can point at an inner frame; walk up to the
        # outermost top-level HWND for PrintWindow.
        GA_ROOT = 2
        hwnd_inner = canvas.winfo_toplevel().winfo_id()
        hwnd = user32.GetAncestor(hwnd_inner, GA_ROOT) or hwnd_inner

        rect = wintypes.RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return None
        win_w = rect.right - rect.left
        win_h = rect.bottom - rect.top
        if win_w <= 0 or win_h <= 0:
            return None

        hdc_win = user32.GetWindowDC(hwnd)
        if not hdc_win:
            return None
        hdc_mem = gdi32.CreateCompatibleDC(hdc_win)
        hbmp = gdi32.CreateCompatibleBitmap(hdc_win, win_w, win_h)
        old_obj = gdi32.SelectObject(hdc_mem, hbmp)

        img = None
        try:
            PW_RENDERFULLCONTENT = 0x00000002
            if not user32.PrintWindow(hwnd, hdc_mem, PW_RENDERFULLCONTENT):
                return None

            class BITMAPINFOHEADER(ctypes.Structure):
                _fields_ = [
                    ("biSize", wintypes.DWORD),
                    ("biWidth", wintypes.LONG),
                    ("biHeight", wintypes.LONG),
                    ("biPlanes", wintypes.WORD),
                    ("biBitCount", wintypes.WORD),
                    ("biCompression", wintypes.DWORD),
                    ("biSizeImage", wintypes.DWORD),
                    ("biXPelsPerMeter", wintypes.LONG),
                    ("biYPelsPerMeter", wintypes.LONG),
                    ("biClrUsed", wintypes.DWORD),
                    ("biClrImportant", wintypes.DWORD),
                ]

            bmi = BITMAPINFOHEADER()
            bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bmi.biWidth = win_w
            bmi.biHeight = -win_h  # negative → top-down DIB
            bmi.biPlanes = 1
            bmi.biBitCount = 32
            bmi.biCompression = 0  # BI_RGB

            buf = (ctypes.c_ubyte * (win_w * win_h * 4))()
            if not gdi32.GetDIBits(hdc_mem, hbmp, 0, win_h,
                                   buf, ctypes.byref(bmi), 0):
                return None

            img = Image.frombuffer("RGB", (win_w, win_h),
                                   bytes(buf), "raw", "BGRX", 0, 1)
        finally:
            gdi32.SelectObject(hdc_mem, old_obj)
            gdi32.DeleteObject(hbmp)
            gdi32.DeleteDC(hdc_mem)
            user32.ReleaseDC(hwnd, hdc_win)

        if img is None:
            return None

        # Crop to the plot canvas region within the window
        cx = canvas.winfo_rootx() - rect.left
        cy = canvas.winfo_rooty() - rect.top
        cw = canvas.winfo_width()
        ch = canvas.winfo_height()
        if cw <= 0 or ch <= 0:
            return img
        cx = max(0, cx)
        cy = max(0, cy)
        cx2 = min(win_w, cx + cw)
        cy2 = min(win_h, cy + ch)
        if cx2 <= cx or cy2 <= cy:
            return img
        return img.crop((cx, cy, cx2, cy2))

    def _on_close(self):
        if self.worker and self.worker.is_alive():
            self.stop_event.set()
            self.worker.join(timeout=2.0)
        if self.stm32 is not None:
            try:
                self.stm32.close()
            except Exception:
                pass
            self.stm32 = None
        self.root.destroy()




# ==========================================================================
# TestStand wrapper (auto-mode, config lookup, banner, subclass, entry point)
# ==========================================================================
def _default_config_root() -> str:
    """Default config root is the `config/` folder next to this script:
        <this dir>/config/<device>/*.json
    """
    tool_root = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(tool_root, "config")


DEFAULT_CONFIG_ROOT = _default_config_root()


def _resolve_config(device: str, test_name: str,
                    config_root: str) -> tuple[str, str]:
    """Return (config_path, curve_suffix)."""
    tn = test_name.upper()
    if "SLOL" in tn:
        fname, suffix = "Re.json", "Re"
    elif "S2P" in tn or "S2G" in tn:
        fname, suffix = "Offset.json", "offset"
    else:
        raise ValueError(
            f"test-name {test_name!r} contains neither 'SLOL' nor 'S2P/S2G'")
    return os.path.join(config_root, device, fname), suffix


# TestStand may pass ch / test_number / load as native numbers or as strings.
def _norm_ch(v) -> int:
    """Channel as an int. Accepts 1, 1.0, '1', or 'CH1'."""
    if isinstance(v, bool):
        raise ValueError(f"CH {v!r} invalid")
    if isinstance(v, (int, float)):
        return int(v)
    m = re.search(r"\d+", str(v))
    if not m:
        raise ValueError(f"CH {v!r} contains no digit")
    return int(m.group())


def _to_test_number(v) -> int:
    """Test number as an int (filename stem 'test<N>')."""
    try:
        return int(float(v)) if isinstance(v, str) else int(v)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"test_number {v!r} is not numeric") from exc


def _fmt_load(v) -> str:
    """Canonical load string (no unit), or '' if empty/NA. A whole number ->
    integer form ('4'), a fraction -> '4.5'. Tolerates a trailing 'ohm'."""
    if v is None:
        return ""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return str(int(v)) if float(v).is_integer() else f"{v:g}"
    s = str(v).strip()
    if not s or s.upper() == "NA":
        return ""
    if s.lower().endswith("ohm"):
        s = s[:-3].strip()
    try:
        f = float(s)
        return str(int(f)) if f.is_integer() else f"{f:g}"
    except ValueError:
        return s


def _target_labels(test_name: str, ch: int, suffix: str) -> list[str]:
    tn = str(test_name).upper()
    ch_num = int(ch)
    labels = []
    if "OUTP" in tn:
        labels.append(f"ch{ch_num} P {suffix}")
    if "OUTM" in tn:
        labels.append(f"ch{ch_num} N {suffix}")
    if not labels:
        raise ValueError(
            f"test-name {test_name!r} contains neither 'OUTP' nor 'OUTM'")
    return labels


class AutoReadTSGUI(AutoReadGUI):
    """AutoReadGUI subclass invoked by TestStand: resolves a config from
    device/test-name, auto-starts the read, enables only the CH-specific
    curves, saves raw/plot on completion, then exits with a status code."""

    def __init__(self, root: tk.Tk, device: str, test_name: str, ch: int,
                 config_root: str, export_dir: str, test_number: int,
                 load: str = ""):
        self._auto_device = device
        self._auto_test_name = test_name
        self._auto_ch = ch
        self._auto_config_root = config_root
        self._auto_export_dir = export_dir
        self._auto_test_number = test_number
        self._auto_load = load

        # Resolve config path + target labels up-front. Any error is
        # deferred until _auto_init so it can be logged in the GUI.
        try:
            self._auto_config_path, self._auto_suffix = _resolve_config(
                device, test_name, config_root)
            self._auto_target_labels = _target_labels(
                test_name, ch, self._auto_suffix)
            self._auto_early_error = None
        except Exception as exc:
            self._auto_config_path = ""
            self._auto_suffix = ""
            self._auto_target_labels = []
            self._auto_early_error = str(exc)

        # File-name stem: test<N>[_<load>ohm]  (load already a bare number here;
        # append the 'ohm' unit so it matches what Summary Test reads).
        self._auto_stem = f"test{test_number}"
        if load:
            self._auto_stem += f"_{load}ohm"

        self._auto_exit_code = 0
        super().__init__(root)
        self._install_auto_banner()
        root.after(300, self._auto_init)

    # ---------------------------------------------------------------- banner
    def _install_auto_banner(self):
        """Add a colored banner at the top of the window showing the current
        device / test / CH / save folder. Shifts the existing UI down one
        grid row."""
        for child in self.root.grid_slaves(row=0, column=0):
            child.grid_configure(row=1)
        self.root.grid_rowconfigure(0, weight=0)
        self.root.grid_rowconfigure(1, weight=1)

        banner = tk.Frame(self.root, bg="#1e3a5f", padx=12, pady=6)
        banner.grid(row=0, column=0, sticky="ew")

        line1 = "  {0}   CH{1}   Test #{2}   Load: {3}".format(
            self._auto_test_name, self._auto_ch,
            self._auto_test_number, self._auto_load or "(none)")
        tk.Label(banner, text=line1, bg="#1e3a5f", fg="white",
                 font=("Segoe UI", 12, "bold"), anchor="w").pack(
            fill="x", anchor="w")

        line2 = "  Device: {0}   Save: {1}".format(
            self._auto_device, self._auto_export_dir)
        tk.Label(banner, text=line2, bg="#1e3a5f", fg="#c8e0ff",
                 font=("Consolas", 9), anchor="w").pack(
            fill="x", anchor="w")

        self.root.title(
            "Auto Read [TS] - {0} CH{1} test{2}".format(
                self._auto_test_name, self._auto_ch,
                self._auto_test_number))

    # ------------------------------------------------------------------ auto
    def _auto_init(self):
        if self._auto_early_error:
            self.log(f"[ERR] {self._auto_early_error}")
            self._auto_exit_code = 1
            self.root.after(1500, self._auto_close)
            return

        if not os.path.isfile(self._auto_config_path):
            self.log(f"[ERR] Config not found: {self._auto_config_path}")
            self._auto_exit_code = 1
            self.root.after(1500, self._auto_close)
            return

        try:
            with open(self._auto_config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            if not isinstance(cfg, dict):
                raise ValueError("Config file is not a JSON object")
            self._apply_config(cfg)
            self.log(f"[TS] Config loaded: {self._auto_config_path}")
            self.log(
                f"[TS] Target curves: "
                f"{', '.join(self._auto_target_labels)}")
        except Exception as exc:
            self.log(f"[ERR] Failed to load config: {exc}")
            self._auto_exit_code = 1
            self.root.after(1500, self._auto_close)
            return

        self.root.after(200, self._auto_wait_for_port)

    def _auto_wait_for_port(self):
        if self.port_name:
            self.log("[TS] STLink found, starting read...")
            self._start()
            # _start() rebuilt self.reads. Enable only target curves.
            self._auto_apply_enabled_mask()
        else:
            self.log("[TS] Waiting for STLink...")
            self._scan_port()
            self.root.after(1000, self._auto_wait_for_port)

    def _auto_apply_enabled_mask(self):
        """Turn on only the target curves; turn off everything else. The
        worker still reads every register in the script, but only the
        enabled curves are drawn / saved."""
        if not self.reads:
            self.log("[ERR] No reads parsed from config script")
            self._auto_exit_code = 1
            self._stop()
            return
        available = [r["label"] for r in self.reads]
        missing = [lbl for lbl in self._auto_target_labels
                   if lbl not in available]
        if missing:
            self.log(
                f"[ERR] Target label(s) not in config: "
                f"{', '.join(missing)}  "
                f"(available: {', '.join(available)})")
            self._auto_exit_code = 1
            self._stop()
            return
        for r in self.reads:
            wanted = r["label"] in self._auto_target_labels
            if bool(r["enabled_var"].get()) != wanted:
                r["enabled_var"].set(wanted)
        self.log(f"[TS] Enabled: {', '.join(self._auto_target_labels)}")

    def _finish(self, error: bool):
        super()._finish(error)
        if error:
            self._auto_exit_code = 1
            self.root.after(1500, self._auto_close)
        else:
            self._auto_do_export()

    def _auto_do_export(self):
        if not self.times or not self.reads:
            self.log("[ERR] No data to export")
            self._auto_exit_code = 1
            self.root.after(1500, self._auto_close)
            return

        raw_dir = os.path.join(self._auto_export_dir, "raw data")
        plot_dir = os.path.join(self._auto_export_dir, "plot")
        try:
            os.makedirs(raw_dir, exist_ok=True)
            os.makedirs(plot_dir, exist_ok=True)
        except Exception as exc:
            self.log(f"[ERR] Cannot create output folders: {exc}")
            self._auto_exit_code = 1
            self.root.after(1500, self._auto_close)
            return

        try:
            p = self._save_raw_txt(raw_dir, self._auto_stem)
            self.log(f"[TS] Raw data saved: {p}")
        except Exception as exc:
            self.log(f"[ERR] Raw data export failed: {exc}")
            self._auto_exit_code = 1

        # Repaint before screen-grab so the capture is clean.
        self.root.update_idletasks()
        self.root.update()
        time.sleep(0.2)
        self.root.update()
        try:
            p = self._save_plot_image(plot_dir, self._auto_stem)
            self.log(f"[TS] Plot saved: {p}")
        except Exception as exc:
            self.log(f"[ERR] Plot export failed: {exc}")
            self._auto_exit_code = 1

        self.root.after(1500, self._auto_close)

    def _auto_close(self):
        self._on_close()


# ---------------------------------------------------------------------------
def auto_read(device_name, test_name, ch: int, export_dir, test_number: int,
              load: float | str = "", config_root: str = "") -> str:
    """Run one auto read: resolve config from device/test-name, auto-start
    the read, enable only the CH-specific curves, and save raw/plot into
    <export_dir>. Blocks (runs the live GUI) until the read completes, then
    returns a summary string.

    device_name/test_name/export_dir/config_root are strings; ch, test_number
    and load are numeric (TestStand passes them as numbers). A numeric load
    gets the 'ohm' unit appended in the output filenames.

    Raises RuntimeError on any failure (config missing, no reads, export
    failure, worker error, or early window close).

    config_root empty -> use the default (`config/` next to this script).
    """
    ch_num = _norm_ch(ch)
    test_no = _to_test_number(test_number)
    load_str = _fmt_load(load)
    cr = str(config_root).strip()
    config_dir = cr if (cr and cr.upper() != "NA") else _default_config_root()

    root = tk.Tk()
    root.minsize(1180, 840)
    app = AutoReadTSGUI(
        root,
        device=str(device_name),
        test_name=str(test_name),
        ch=ch_num,
        config_root=config_dir,
        export_dir=str(export_dir),
        test_number=test_no,
        load=load_str,
    )
    try:
        root.mainloop()
    except Exception as exc:
        raise RuntimeError(f"mainloop crashed: {exc}") from exc

    if getattr(app, "_auto_exit_code", 0) != 0:
        raise RuntimeError(
            f"auto read failed for device={device_name} test={test_name} "
            f"ch={ch_num} (see the tool log; window may have closed early)")
    return (f"[OK] read complete: device={device_name}, test={test_name}, "
            f"ch={ch_num}, test_number={test_no}"
            + (f", load={load_str}ohm" if load_str else "")
            + f" -> {export_dir}")


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Auto Read TS. "
            "Omit all flags to run as the standard interactive GUI."
        )
    )
    parser.add_argument("--device-name", metavar="NAME",
                        help="Device folder name under the config root "
                             "(e.g. TAS6754)")
    parser.add_argument("--test-name", metavar="NAME",
                        help="Test name; must contain OUTP and/or OUTM, and "
                             "one of SLOL / S2P / S2G "
                             "(e.g. OUTP_SLOL, OUTP&OUTM_S2P)")
    parser.add_argument("--ch", metavar="N",
                        help="Channel number, e.g. 1")
    parser.add_argument("--export-dir", metavar="DIR",
                        help="Root export directory")
    parser.add_argument("--test-number", metavar="N",
                        help="Test number used in output filename stem")
    parser.add_argument("--load", metavar="STRING", default="",
                        help="Optional load tag appended to filename "
                             "(e.g. 1ohm -> <side>_test1_1ohm.txt)")
    parser.add_argument("--config-root", metavar="DIR",
                        default=DEFAULT_CONFIG_ROOT,
                        help=f"Override config root (default: "
                             f"{DEFAULT_CONFIG_ROOT})")
    args = parser.parse_args()

    auto_flags = [args.device_name, args.test_name, args.ch,
                  args.export_dir, args.test_number]
    auto_mode = any(auto_flags)

    if auto_mode:
        missing = [flag for flag, val in [
            ("--device-name", args.device_name),
            ("--test-name",   args.test_name),
            ("--ch",          args.ch),
            ("--export-dir",  args.export_dir),
            ("--test-number", args.test_number),
        ] if not val]
        if missing:
            parser.error(
                f"TS mode requires --device-name, --test-name, --ch, "
                f"--export-dir, --test-number. Missing: "
                f"{', '.join(missing)}"
            )

    if auto_mode:
        try:
            result = auto_read(
                device_name=args.device_name,
                test_name=args.test_name,
                ch=args.ch,
                export_dir=args.export_dir,
                test_number=args.test_number,
                load=args.load,
                config_root=args.config_root,
            )
        except Exception as exc:
            print(f"ERR {exc}", file=sys.stderr, flush=True)
            sys.exit(1)
        print(result, flush=True)
        sys.exit(0)

    # Interactive GUI (no auto flags)
    root = tk.Tk()
    root.minsize(1180, 840)
    AutoReadGUI(root)
    root.mainloop()
    sys.exit(0)


if __name__ == "__main__":
    main()
