@echo off
set "VPYW=C:\Auto Bench\.venv\Scripts\pythonw.exe"
if not exist "%VPYW%" (
    echo .venv not found. Run setup_env.bat at the repo root first.
    pause
    exit /b 1
)
start "" "%VPYW%" "%~dp0Auto_Read.py"
