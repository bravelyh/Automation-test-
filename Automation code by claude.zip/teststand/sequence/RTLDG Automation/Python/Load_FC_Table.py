"""Load FC table — read an RTLDG FC table .xlsx into a usable 2D array.

Self-contained (stdlib only): reads the .xlsx directly with zipfile + xml, so
no openpyxl/pandas dependency and no import of any other project file.

Pipeline:
    load_fc_table(path)  -> read the .xlsx, then process_FC_table(...)  -> 2D array
    process_FC_table(2D) -> expand ';'-separated cells into row combinations,
                            drop blank rows, blank cell -> "NA", renumber col 0
    validate_fc_table(2D)-> sanity string (SLOL vs S2P/S2G, sweep vs single)

The returned 2D array is `[header_row] + data_rows`, every cell a str — the same
shape the downstream Summary/Auto-Read steps consume.
"""
import zipfile
import xml.etree.ElementTree as ET


# ---------------------------------------------------------------------------
# .xlsx reader (stdlib: an .xlsx is a zip of XML parts)
# ---------------------------------------------------------------------------
_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _col_index(cell_ref):
    """'C5' -> 2 (zero-based column index from the letters of a cell ref)."""
    letters = "".join(c for c in cell_ref if c.isalpha())
    n = 0
    for c in letters:
        n = n * 26 + (ord(c.upper()) - 64)
    return n - 1


def _read_xlsx(path):
    """Read the first worksheet of an .xlsx into a rectangular 2D list of str."""
    with zipfile.ZipFile(path) as z:
        names = z.namelist()

        # Shared string table (most text cells reference it by index).
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall(f"{_NS}si"):
                shared.append("".join(t.text or "" for t in si.iter(f"{_NS}t")))

        sheets = sorted(n for n in names
                        if n.startswith("xl/worksheets/sheet") and n.endswith(".xml"))
        if not sheets:
            return []
        root = ET.fromstring(z.read(sheets[0]))

        rows = []
        max_col = -1
        for row_el in root.iter(f"{_NS}row"):
            cells = {}
            for c in row_el.findall(f"{_NS}c"):
                ci = _col_index(c.get("r", "A"))
                t = c.get("t")
                v = c.find(f"{_NS}v")
                if t == "s" and v is not None:                 # shared string
                    val = shared[int(v.text)]
                elif t == "inlineStr":                          # inline string
                    is_el = c.find(f"{_NS}is")
                    val = ("".join(x.text or "" for x in is_el.iter(f"{_NS}t"))
                           if is_el is not None else "")
                elif t == "b" and v is not None:                # boolean
                    val = "TRUE" if v.text == "1" else "FALSE"
                elif v is not None:                             # number / formula str
                    val = v.text
                else:
                    val = ""
                cells[ci] = val
                if ci > max_col:
                    max_col = ci
            rows.append(cells)

        width = max_col + 1
        return [[r.get(i, "") for i in range(width)] for r in rows]


# ---------------------------------------------------------------------------
# Entry point: path -> 2D array
# ---------------------------------------------------------------------------
def load_fc_table(path):
    """Read the FC table .xlsx at `path` and return the processed 2D array
    (`[header] + ';'-expanded, renumbered rows`, every cell a str)."""
    return process_FC_table(_read_xlsx(path))


# ---------------------------------------------------------------------------
# Row-combination expansion + table processing (unchanged)
# ---------------------------------------------------------------------------
def find_combinations_recursive(list_of_lists, index=0, current_combo=None, results=None):
    if current_combo is None:
        current_combo = []
    if results is None:
        results = []
    if index == len(list_of_lists):
        results.append(current_combo)
        return results
    for elem in list_of_lists[index]:
        for item in str(elem).split(";"):
            if item == "":
                continue
            find_combinations_recursive(list_of_lists, index + 1, current_combo + [item], results)
    return results

def process_FC_table(input_data):
    if not input_data:
        return []

    # First row is the header - pass through unchanged.
    header = list(input_data[0])
    data_rows = input_data[1:]

    all_combined_results = []
    for row in data_rows:
        if all(cell is None or str(cell).strip() == "" for cell in row):
            continue

        row_data = []
        for cell in row:
            if cell is None or str(cell).strip() == "":
                row_data.append(["NA"])
            else:
                row_data.append([str(cell)])

        if row_data:
            row_combinations = find_combinations_recursive(row_data)
            all_combined_results.extend(row_combinations)

    # Renumber first column of data rows starting from 1; header untouched.
    for i, combo in enumerate(all_combined_results):
        if combo:
            combo[0] = str(i + 1)

    return [header] + all_combined_results

def validate_fc_table(processed_data):
    if not processed_data:
        return "Invalid FC table input: No data available for validation."

    test_types = set()
    load_types = set()

    # First row is the header (see process_FC_table); skip it.
    for row in processed_data[1:]:
        if len(row) > 1 and row[1]:
            test_name = str(row[1])
            if "SLOL" in test_name:
                test_types.add("SLOL")
            if "S2P" in test_name or "S2G" in test_name:
                test_types.add("S2PG")

        if len(row) > 5 and row[5]:
            load_value = str(row[5])
            if "~" in load_value:
                load_types.add("sweep")
            else:
                load_types.add("single")

    if "SLOL" in test_types and "S2PG" in test_types:
        return "Invalid FC table input: SLOL and S2P/S2G tests cannot coexist."

    if "sweep" in load_types and "single" in load_types:
        return "Invalid FC table input: Sweep load and Single load tests cannot coexist."

    return "Valid FC table input"


# ---------------------------------------------------------------------------
# Debug CLI: dump a table from a path
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("usage: python Load_FC_Table.py <fc_table.xlsx>", file=sys.stderr)
        sys.exit(2)
    table = load_fc_table(sys.argv[1])
    print(f"{len(table)} rows (including header)")
    for r in table:
        print(r)
    print("validate:", validate_fc_table(table))
