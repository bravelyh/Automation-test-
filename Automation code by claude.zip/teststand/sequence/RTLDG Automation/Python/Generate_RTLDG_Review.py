"""Generate RTLDG Review TS

Scans <data-save-folder>/summary/ for *summary*.html files produced by the
RTLDG Summary Test generator, parses their meta+data tables, reads the
matching raw_data/*.txt files (val_ch<N> P/N Re columns), and emits a
single self-contained review file at:

    <data-save-folder>/Test Review.html

The output HTML mirrors the interactive RTLDG_Review.py tool:
  - Test Name dropdown, per-test checkboxes, Combine mode.
  - Series panel with two percentile dropdowns (MAX / P90 / ... / P10 / MIN)
    for the top and bottom lines. Mean is fixed.
  - Percentile lines use worst-case-per-test semantics: for each selected
    test compute the percentile from its raw points, then reduce across
    tests — min-reduce for pct <= 50 (worst-case lower bound), max-reduce
    for pct > 50 (worst-case upper bound). MAX / MIN reduce over summary
    max/min (no raw read).
  - Dynamic condition table centred horizontally under the plot.
  - Hover cursor + multi-lock overlay. The tooltip is centred above the
    load position and the whole box is clickable to toggle lock.

If no raw data is found, PXX options are hidden — only MAX / MIN are
selectable. The report still generates without error.

Entry point (TestStand Python Adapter)
--------------------------------------
    Module   : Generate_RTLDG_Review_TS.py
    Function : generate_review
    Arguments:
        data_save_folder = FileGlobals... (base folder to scan; Test Review.html
                           is written into this same folder)

    generate_review(data_save_folder) -> str
        Returns the written Test Review.html path. Raises FileNotFoundError
        (folder missing / no parseable files) or RuntimeError (write failure).

Standalone / debug CLI:
    py -3.14 "Generate_RTLDG_Review_TS.py" --data-save-folder "<path>"
"""
from __future__ import annotations

import argparse
import html as htmllib
import json
import os
import re
import sys
from collections import defaultdict


# ---------------------------------------------------------------------------
# HTML summary parser (mirrored from RTLDG_Review.py)
# ---------------------------------------------------------------------------
CONDITION_PREFERRED = [
    "Device", "Unit", "CH", "Fin/Music", "Level", "Temp", "Mode",
    "PVDD", "VBAT", "DVDD", "Gain", "FSW", "Modulation",
    "REG1", "REG2", "REG3", "Thermal Stream",
]

_H1_RE       = re.compile(r"<h1>\s*Test\s+(\d+)\s*</h1>", re.I)
_SUBTITLE_RE = re.compile(r'<p class="subtitle">(.*?)</p>', re.I | re.DOTALL)
_META_RE     = re.compile(
    r'<div>\s*<span class="key">([^<]+?):\s*</span>([^<]*)</div>', re.I)
_ROW_RE      = re.compile(
    r"<tr>\s*"
    r"<td class='num'>\s*([-\d.]+)\s*</td>\s*"
    r"<td class='num'>\s*([-\d.]+)\s*</td>\s*"
    r"<td class='num'>\s*([-\d.]+)\s*</td>\s*"
    r"<td class='num'>\s*([-\d.]+)\s*</td>\s*"
    r"<td class='num'>\s*([-\d.]+)\s*</td>\s*"
    r"<td[^>]*>",
    re.I,
)
_SUBTITLE_LEFT_RE = re.compile(r"^(CH\d+)\s+(.+?)$", re.I)


def _derive_polarity(test_name):
    name = (test_name or "").upper()
    has_p = "OUTP" in name
    has_n = "OUTM" in name
    if has_p and not has_n:
        return "P"
    if has_n and not has_p:
        return "N"
    return None


def parse_summary_html(path):
    """Return (test_no, test_name, polarity, condition, rows) or None."""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            content = fh.read()
    except Exception:
        return None

    m = _H1_RE.search(content)
    test_no = m.group(1) if m else ""

    condition = {}
    test_name = ""

    m = _SUBTITLE_RE.search(content)
    if m:
        subtitle = htmllib.unescape(m.group(1)).strip()
        left, sep, right = subtitle.partition("·")
        left = left.strip()
        right = right.strip()

        sm = _SUBTITLE_LEFT_RE.match(left)
        if sm:
            condition["CH"] = sm.group(1).upper()
            test_name = sm.group(2).strip()
        else:
            test_name = left

        if right:
            rm = re.match(r"^(.+?)\s*/\s*Unit\s+(.+)$", right, re.I)
            if rm:
                condition["Device"] = rm.group(1).strip()
                condition["Unit"] = rm.group(2).strip()
            else:
                condition["Device"] = right

    for key, val in _META_RE.findall(content):
        key = key.strip()
        val = htmllib.unescape(val.strip())
        condition[key] = val

    rows = []
    for row in _ROW_RE.finditer(content):
        try:
            rows.append((
                float(row.group(1)),
                float(row.group(2)),
                float(row.group(3)),
                float(row.group(4)),
            ))
        except ValueError:
            continue

    if not rows or not test_name:
        return None
    return test_no, test_name, _derive_polarity(test_name), condition, rows


# ---------------------------------------------------------------------------
# Raw data locator + loader (mirrored from RTLDG_Review.py)
# ---------------------------------------------------------------------------
def _find_raw_folder(summary_path):
    d = os.path.dirname(summary_path)
    seen = set()
    while d and d not in seen:
        seen.add(d)
        try:
            for name in os.listdir(d):
                if name.lower() == "raw data":
                    p = os.path.join(d, name)
                    if os.path.isdir(p):
                        return p
        except Exception:
            pass
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return None


def _load_raw_column(raw_path, ch_num, polarity):
    try:
        with open(raw_path, "r", encoding="utf-8", errors="ignore") as fh:
            header = fh.readline()
            cols = [c.strip() for c in header.rstrip("\r\n").split("\t")]
            pattern = re.compile(
                rf"^val[_\s]*ch\s*{ch_num}\s+{polarity}\s+Re$", re.I)
            target_idx = None
            for i, c in enumerate(cols):
                if pattern.match(c):
                    target_idx = i
                    break
            if target_idx is None:
                return None
            vals = []
            for line in fh:
                parts = line.rstrip("\r\n").split("\t")
                if target_idx >= len(parts):
                    continue
                try:
                    vals.append(float(parts[target_idx]))
                except ValueError:
                    continue
            vals.sort()
            return vals
    except Exception:
        return None


def _load_str_for_filename(load):
    try:
        f = float(load)
    except (TypeError, ValueError):
        return str(load)
    if f.is_integer():
        return str(int(f))
    return str(f)


def _load_raw_for_record(raw_folder, test_no, ch_str, polarity, loads):
    """Return {load: sorted_list_of_values} for every load whose raw file
    exists and yields a valid column. Empty dict if the record is missing
    any required piece."""
    out = {}
    if not (raw_folder and polarity and ch_str and test_no):
        return out
    m = re.match(r"CH(\d+)", ch_str, re.I)
    if not m:
        return out
    ch_num = m.group(1)
    for load in loads:
        load_str = _load_str_for_filename(load)
        candidates = [
            f"test{test_no}_{load_str}ohm.txt",
            f"test{test_no}_{load_str}Ohm.txt",
            f"test{test_no}_{load_str}OHM.txt",
        ]
        path = None
        for name in candidates:
            p = os.path.join(raw_folder, name)
            if os.path.isfile(p):
                path = p
                break
        if path is None:
            try:
                want = f"test{test_no}_{load_str}ohm.txt".lower()
                for name in os.listdir(raw_folder):
                    if name.lower() == want:
                        path = os.path.join(raw_folder, name)
                        break
            except Exception:
                pass
        if path is None:
            continue
        vals = _load_raw_column(path, ch_num, polarity)
        if vals:
            # Key format matches how JS serialises the load numerically:
            # integer -> "1", non-integer -> "1.5". This keeps the JSON
            # lookup on the browser side trivial.
            out[load_str] = vals
    return out


# ---------------------------------------------------------------------------
# Build the review payload
# ---------------------------------------------------------------------------
def build_review_data(root_folder):
    """Walk root_folder recursively for *summary*.html and pair each with
    its sibling raw data (walking up to locate a 'raw data/' folder).
    Returns the JSON-serialisable payload consumed by the HTML template."""
    groups = defaultdict(list)
    seen_keys = []
    summary_dirs = set()
    raw_dirs = set()

    # Subdirs excluded from the scan — these are user-maintained archives /
    # rechecks that would otherwise get merged into the main report and
    # collide on test_no with the main dataset.
    EXCLUDE_DIRS = {"recheck", "backup", "archive", "old"}

    files = []
    for root, dirs, fnames in os.walk(root_folder):
        dirs[:] = [d for d in dirs if d.lower() not in EXCLUDE_DIRS]
        for fn in fnames:
            if fn.lower().endswith(".html") and "summary" in fn.lower():
                files.append(os.path.join(root, fn))
    files.sort()

    any_raw = False
    for f in files:
        res = parse_summary_html(f)
        if not res:
            print(f"[WARN] Skipped (parse failed): {f}", file=sys.stderr)
            continue
        test_no, test_name, polarity, cond, rows = res
        summary_dirs.add(os.path.dirname(f))

        stem = os.path.splitext(os.path.basename(f))[0]
        ch = cond.get("CH", "")

        for k in cond.keys():
            if k not in seen_keys:
                seen_keys.append(k)

        raw_folder = _find_raw_folder(f)
        if raw_folder:
            raw_dirs.add(raw_folder)

        loads = [r[0] for r in rows]
        raw_points = _load_raw_for_record(
            raw_folder, test_no, ch, polarity, loads)
        if raw_points:
            any_raw = True

        groups[test_name].append({
            "test_no":    test_no,
            "ch":         ch,
            "stem":       stem,
            "label":      "",
            "condition":  cond,
            "polarity":   polarity or "",
            "data":       sorted(rows, key=lambda r: r[0]),
            "raw_points": raw_points,
        })

    if not groups:
        return None

    for records in groups.values():
        counts = defaultdict(int)
        for r in records:
            counts[r["test_no"]] += 1
        has_dup = any(c > 1 for c in counts.values())
        for r in records:
            base = f"test{r['test_no']}" if r["test_no"] else "test?"
            r["label"] = (f"{base} {r['ch']}"
                          if has_dup and r["ch"]
                          else base)
        records.sort(key=lambda r: (
            int(r["test_no"]) if r["test_no"].isdigit() else 10**9,
            r["ch"] or "",
        ))

    ordered_conditions = ([k for k in CONDITION_PREFERRED if k in seen_keys]
                           + [k for k in seen_keys
                              if k not in CONDITION_PREFERRED])

    return {
        "groups":          dict(groups),
        "condition_order": ordered_conditions,
        "summary_dirs":    sorted(summary_dirs),
        "raw_dirs":        sorted(raw_dirs),
        "has_raw":         any_raw,
    }


# ---------------------------------------------------------------------------
# Self-contained HTML template
# ---------------------------------------------------------------------------
HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Test Review</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Tahoma, sans-serif; margin: 12px;
         color: #222; background: #f5f7fa; }
  h1 { color: #1e3a5f; margin: 0 0 8px 0; font-size: 18px; }

  .top-bar { display: flex; align-items: center; gap: 14px;
             padding: 8px 12px; background: #fff; border: 1px solid #d0d7e0;
             border-radius: 4px; margin-bottom: 6px; flex-wrap: wrap; }
  .top-bar label { font-size: 13px; }
  .top-bar select { font-size: 13px; padding: 2px 6px; min-width: 130px; }
  .top-bar button { font-size: 13px; padding: 4px 10px;
                    background: #eef1f6; border: 1px solid #b0bccb;
                    border-radius: 3px; cursor: pointer; }
  .top-bar button:hover { background: #dde3ec; }

  .status-bar { display: flex; gap: 16px; padding: 4px 12px 8px;
                font-size: 11.5px; color: #555; flex-wrap: wrap; }
  .status-bar .lbl { color: #333; font-weight: 600; }

  .main-row { display: flex; gap: 8px; align-items: stretch; }
  .plot-col { flex: 1; display: flex; flex-direction: column; gap: 8px;
              min-width: 0; }
  .right-col { width: 120px; display: flex; flex-direction: column; gap: 6px; }

  .plot-container { position: relative; flex: 1;
                    background: #fff; border: 1px solid #d0d7e0;
                    border-radius: 4px; padding: 6px; }
  .plot-container svg { display: block; width: 100%; height: auto; }

  .series-panel { background: #fff; border: 1px solid #d0d7e0;
                  border-radius: 4px; padding: 6px 8px; }
  .series-panel h3 { margin: 0 0 6px 0; font-size: 12px;
                     color: #1e3a5f; font-weight: 600; }
  .series-row { display: flex; align-items: center; gap: 6px;
                padding: 3px 0; }
  .line-swatch { display: inline-block; width: 24px; height: 3px;
                 border-radius: 1px; flex-shrink: 0; }
  .pct-cb { font-size: 11px; padding: 1px 3px; width: 90px; }
  .pct-cb:disabled { opacity: 0.5; }

  .tests-panel { background: #fff; border: 1px solid #d0d7e0;
                 border-radius: 4px; padding: 6px 4px;
                 display: flex; flex-direction: column; gap: 2px;
                 overflow-y: auto; flex: 1; min-height: 100px; }
  .tests-panel h3 { margin: 0 0 4px 4px; font-size: 12px;
                    color: #1e3a5f; font-weight: 600; }
  .tests-panel label { display: block; padding: 3px 6px; cursor: pointer;
                       font-size: 12.5px; font-weight: 500; }
  .tests-panel label:hover { background: #eef1f6; border-radius: 3px; }
  .tests-panel input[type=checkbox] { margin-right: 5px; vertical-align: -2px; }

  .table-wrap { background: #fff; border: 1px solid #d0d7e0;
                border-radius: 4px; padding: 6px;
                display: flex; flex-direction: column; align-items: center; }
  .table-wrap h3 { margin: 0 0 4px 0; font-size: 12px;
                   color: #1e3a5f; font-weight: 600; align-self: flex-start; }
  .cond-scroll { max-width: 100%; max-height: 260px; overflow: auto; }
  table.cond { border-collapse: collapse; font-size: 12px;
               border: 1px solid #b0bccb; table-layout: auto;
               margin: 0 auto; }
  table.cond th { background: #1e3a5f; color: #fff; padding: 5px 8px;
                  font-weight: 600; border: 1px solid #17304a;
                  text-align: center; white-space: nowrap; }
  table.cond td { padding: 4px 8px; border: 1px solid #d5dde5;
                  text-align: center; white-space: nowrap; }
  table.cond tr:nth-child(even) td { background: #f9fafc; }

  .overlay { position: absolute; left: 0; top: 0; width: 100%; height: 100%;
             pointer-events: none; }
  /* Tooltip: centred over the load line, whole thing is clickable to
     toggle lock. Bottom line is coloured to hint interactivity. */
  .hover-info { position: absolute; background: #ffffe0;
                border: 1px solid #666; border-radius: 4px;
                padding: 5px 10px 4px;
                font-family: Consolas, monospace;
                font-size: 11px; line-height: 1.35; color: #222;
                pointer-events: auto; cursor: pointer; z-index: 20;
                box-shadow: 0 1px 3px rgba(0,0,0,0.12);
                user-select: none; text-align: center;
                transform: translate(-50%, -100%); }
  .hover-info.locked { background: #fff8dc; }
  .hover-info .row { white-space: pre; }
  .hover-info .sep { border-top: 1px solid #aaa;
                     margin: 4px 0 3px; height: 0; }
  .hover-info .lock-line { color: #1e63c9; font-weight: bold;
                           text-decoration: underline; }
  .hover-info.locked .lock-line { color: #c62828; }
</style>
</head>
<body>

<h1>Test Review</h1>

<div class="top-bar">
  <label>Test Name:
    <select id="group-cb"></select>
  </label>
  <label id="pvdd-label" style="display:none">PVDD:
    <select id="pvdd-cb"></select>
  </label>
  <label><input type="checkbox" id="combine-cb"> Combine</label>
  <button id="select-all">Select All</button>
  <button id="clear-all">Clear All</button>
</div>

<div class="status-bar">
  <span><span class="lbl">summary:</span> <span id="summary-path">-</span></span>
  <span><span class="lbl">raw data:</span> <span id="raw-path">-</span></span>
</div>

<div class="main-row">
  <div class="plot-col">
    <div class="plot-container" id="plot-container">
      <svg id="plot" viewBox="0 0 1000 560" preserveAspectRatio="xMinYMin meet">
        <!-- populated dynamically -->
      </svg>
      <div class="overlay" id="overlay"></div>
    </div>

    <div class="table-wrap">
      <h3>Test Conditions</h3>
      <div class="cond-scroll">
        <table class="cond" id="cond-table"></table>
      </div>
    </div>
  </div>

  <div class="right-col">
    <div class="series-panel">
      <h3>Series</h3>
      <div class="series-row">
        <span class="line-swatch" style="background:#c62828"></span>
        <select id="top-cb" class="pct-cb"></select>
      </div>
      <div class="series-row">
        <span class="line-swatch" style="background:#2e7d32"></span>
        <span>Mean</span>
      </div>
      <div class="series-row">
        <span class="line-swatch" style="background:#1e63c9"></span>
        <select id="bot-cb" class="pct-cb"></select>
      </div>
    </div>

    <div class="tests-panel">
      <h3>Tests</h3>
      <div id="checkbox-list"></div>
    </div>
  </div>
</div>

<script>
// ============================================================
// DATA (embedded at generation time)
// ============================================================
const REVIEW_DATA = /*__REVIEW_DATA__*/;

// ============================================================
// PLOT CONFIG — symmetric horizontal padding so the plot's
// centreline aligns with the condition table below it.
// ============================================================
const SVG_W = 1000, SVG_H = 560;
const PAD = { left: 60, right: 60, top: 30, bottom: 55 };
const PLOT_W = SVG_W - PAD.left - PAD.right;
const PLOT_H = SVG_H - PAD.top - PAD.bottom;

const TOP_COLOR  = "#c62828";
const MEAN_COLOR = "#2e7d32";
const BOT_COLOR  = "#1e63c9";

// Top (red, max-reduce) shows upper-tail stats; Bottom (blue, min-reduce)
// shows lower-tail stats. Reducer is determined by dropdown position, not
// by the percentile value — see seriesForLoad().
const TOP_OPTIONS = ["MAX", "P90", "P80", "P70", "P60", "P50"];
const BOT_OPTIONS = ["MIN", "P10", "P20", "P30", "P40", "P50"];

// Test names matching this pattern get a per-PVDD filter dropdown so
// mixed-PVDD combines are impossible. Hidden for other test types (SLOL).
const PVDD_FILTER_TEST_RE = /S2[PG]/i;

const SVGNS = "http://www.w3.org/2000/svg";
const svg = document.getElementById("plot");
const overlay = document.getElementById("overlay");
const plotContainer = document.getElementById("plot-container");

let currentGroup = null;
let checkedStems = new Set();
let combineMode = false;
let combineAgg = null;   // {load: {top, mean, bot}} — hover source
let hoverBox = null;
let lockedBoxes = [];
let xScale, yScale;
let topLabel = "MAX", botLabel = "MIN";

const TAB20 = [
  "#1f77b4", "#aec7e8", "#ff7f0e", "#ffbb78",
  "#2ca02c", "#98df8a", "#d62728", "#ff9896",
  "#9467bd", "#c5b0d5", "#8c564b", "#c49c94",
  "#e377c2", "#f7b6d2", "#7f7f7f", "#c7c7c7",
  "#bcbd22", "#dbdb8d", "#17becf", "#9edae5"
];

// ============================================================
// INIT
// ============================================================
function init() {
  // Status: summary/raw paths
  document.getElementById("summary-path").textContent =
    (REVIEW_DATA.summary_dirs || []).join(" ; ") || "-";
  const rawDirs = REVIEW_DATA.raw_dirs || [];
  const rawPath = document.getElementById("raw-path");
  if (rawDirs.length) {
    rawPath.textContent = rawDirs.join(" ; ");
    rawPath.style.color = "";
  } else {
    rawPath.textContent = "not found (PXX unavailable)";
    rawPath.style.color = "#a05000";
  }

  // Group dropdown
  const groups = Object.keys(REVIEW_DATA.groups).sort();
  const cb = document.getElementById("group-cb");
  cb.innerHTML = groups.map(g =>
    `<option value="${escAttr(g)}">${escHtml(g)}</option>`).join("");
  cb.addEventListener("change", onGroupChange);

  // Combine toggle
  document.getElementById("combine-cb").addEventListener("change", e => {
    combineMode = e.target.checked;
    syncSeriesState();
    redraw();
  });

  // Percentile dropdowns
  const topCb = document.getElementById("top-cb");
  const botCb = document.getElementById("bot-cb");
  populatePctOptions();
  topCb.value = "MAX";
  botCb.value = "MIN";
  topCb.addEventListener("change", () => { topLabel = topCb.value; redraw(); });
  botCb.addEventListener("change", () => { botLabel = botCb.value; redraw(); });
  syncSeriesState();

  document.getElementById("pvdd-cb").addEventListener("change", () => {
    rebuildTestList();
    rebuildConditionTable();
    redraw();
  });

  document.getElementById("select-all").addEventListener("click",
    () => setAllChecks(true));
  document.getElementById("clear-all").addEventListener("click",
    () => setAllChecks(false));

  // Listen on the whole plot-container (svg + overlay/tooltip children)
  // so moving from the SVG onto the tooltip DIV doesn't count as "left".
  plotContainer.addEventListener("mousemove", onHover);
  plotContainer.addEventListener("mouseleave", onLeave);

  if (groups.length) {
    cb.value = groups[0];
    onGroupChange();
  }
}

// MAX / MIN are already directional, so they display without a side tag.
// Only PXX gets the "(max)" / "(min)" suffix.
function pctDisplay(label, sideLbl) {
  return (label === "MAX" || label === "MIN") ? label : `${label}(${sideLbl})`;
}

function populatePctOptions() {
  const hasRaw = !!REVIEW_DATA.has_raw;
  const topOpts = hasRaw ? TOP_OPTIONS : ["MAX"];
  const botOpts = hasRaw ? BOT_OPTIONS : ["MIN"];

  function fill(cbId, opts, sideLbl) {
    const cb = document.getElementById(cbId);
    const prev = cb.value;
    cb.innerHTML = opts.map(o =>
      `<option value="${o}">${pctDisplay(o, sideLbl)}</option>`).join("");
    if (opts.includes(prev)) cb.value = prev;
  }
  fill("top-cb", topOpts, "max");
  fill("bot-cb", botOpts, "min");
}

function syncSeriesState() {
  const topCb = document.getElementById("top-cb");
  const botCb = document.getElementById("bot-cb");
  const enabled = combineMode;
  topCb.disabled = !enabled;
  botCb.disabled = !enabled;
}

function isPvddFilteredGroup(name) {
  return PVDD_FILTER_TEST_RE.test(name || "");
}

function updatePvddUI() {
  const label = document.getElementById("pvdd-label");
  const cb = document.getElementById("pvdd-cb");
  if (!isPvddFilteredGroup(currentGroup)) {
    label.style.display = "none";
    cb.innerHTML = "";
    return;
  }
  const recs = REVIEW_DATA.groups[currentGroup] || [];
  const seen = new Set();
  const values = [];
  for (const r of recs) {
    const v = r.condition && r.condition.PVDD;
    if (v == null || v === "" || seen.has(v)) continue;
    seen.add(v);
    values.push(v);
  }
  values.sort((a, b) => {
    const na = Number(a), nb = Number(b);
    if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb;
    return String(a).localeCompare(String(b));
  });
  const prev = cb.value;
  cb.innerHTML = values.map(v =>
    `<option value="${escAttr(v)}">${escHtml(v)}</option>`).join("");
  if (values.includes(prev)) cb.value = prev;
  label.style.display = "";
}

function currentPvddFilter() {
  if (!isPvddFilteredGroup(currentGroup)) return null;
  return document.getElementById("pvdd-cb").value || null;
}

function activeRecords() {
  const recs = REVIEW_DATA.groups[currentGroup] || [];
  const p = currentPvddFilter();
  if (p == null) return recs;
  return recs.filter(r => r.condition && r.condition.PVDD === p);
}

function rebuildTestList() {
  const list = document.getElementById("checkbox-list");
  list.innerHTML = "";
  for (const rec of activeRecords()) {
    const lbl = document.createElement("label");
    const checked = checkedStems.has(rec.stem) ? "checked" : "";
    lbl.innerHTML =
      `<input type="checkbox" data-stem="${escAttr(rec.stem)}" ${checked}>` +
      escHtml(rec.label);
    lbl.querySelector("input").addEventListener("change", e => {
      const stem = e.target.dataset.stem;
      if (e.target.checked) checkedStems.add(stem);
      else                  checkedStems.delete(stem);
      redraw();
    });
    list.appendChild(lbl);
  }
}

function onGroupChange() {
  currentGroup = document.getElementById("group-cb").value;
  updatePvddUI();
  const recs = REVIEW_DATA.groups[currentGroup] || [];
  checkedStems = new Set(recs.map(r => r.stem));
  rebuildTestList();
  rebuildConditionTable();
  redraw();
}

function setAllChecks(val) {
  const activeStems = activeRecords().map(r => r.stem);
  for (const s of activeStems) {
    if (val) checkedStems.add(s);
    else     checkedStems.delete(s);
  }
  document.querySelectorAll("#checkbox-list input[type=checkbox]")
    .forEach(b => { b.checked = val; });
  redraw();
}

function rebuildConditionTable() {
  const recs = activeRecords();
  const cols = REVIEW_DATA.condition_order || [];
  let html = "<thead><tr><th>Test File</th>";
  for (const c of cols) html += `<th>${escHtml(c)}</th>`;
  html += "</tr></thead><tbody>";
  for (const rec of recs) {
    html += `<tr><td>${escHtml(rec.stem)}</td>`;
    for (const c of cols) {
      const v = (rec.condition && rec.condition[c] != null)
        ? rec.condition[c] : "";
      html += `<td>${escHtml(String(v))}</td>`;
    }
    html += "</tr>";
  }
  html += "</tbody>";
  document.getElementById("cond-table").innerHTML = html;
}

// ============================================================
// PERCENTILE HELPERS
// ============================================================
function pctValue(label) {
  if (label === "MAX") return 100;
  if (label === "MIN") return 0;
  return Number(label.slice(1));
}

function percentileSorted(sortedArr, pct) {
  if (!sortedArr || !sortedArr.length) return NaN;
  if (pct <= 0)   return sortedArr[0];
  if (pct >= 100) return sortedArr[sortedArr.length - 1];
  const n = sortedArr.length;
  const k = (n - 1) * pct / 100;
  const f = Math.floor(k);
  const c = Math.min(f + 1, n - 1);
  if (f === c) return sortedArr[f];
  return sortedArr[f] + (sortedArr[c] - sortedArr[f]) * (k - f);
}

function seriesForLoad(recs, load, pct, side) {
  // Reducer is decided by dropdown position:
  //   side="top" -> max-reduce across tests (worst-case upper bound)
  //   side="bot" -> min-reduce across tests (worst-case lower bound)
  // Example use cases:
  //   OL report (guarantee 90% points > threshold in worst test):
  //     bot = P10  -> min of per-test P10
  //   SL report (guarantee 90% points < threshold in worst test):
  //     top = P90  -> max of per-test P90
  // Returns {value, src} where src is the label of the contributing test.
  const useMax = side === "top";
  const entries = [];

  if (pct >= 100) {
    // MAX = per-test summary max (no raw data needed)
    for (const r of recs) {
      for (const [l, , mx] of r.data) {
        if (l === load) entries.push({ v: mx, rec: r });
      }
    }
  } else if (pct <= 0) {
    // MIN = per-test summary min
    for (const r of recs) {
      for (const [l, mn] of r.data) {
        if (l === load) entries.push({ v: mn, rec: r });
      }
    }
  } else {
    // PXX = per-test percentile from raw data
    const key = String(load);
    const keyInt = Number.isInteger(load) ? String(load) : null;
    for (const r of recs) {
      const rp = r.raw_points || {};
      let vals = rp[key];
      if (!vals && keyInt) vals = rp[keyInt];
      if (!vals) {
        // JSON keys came from Python str(float): "1.0" vs "1" — try both.
        const alt = load.toString();
        vals = rp[alt];
      }
      if (vals && vals.length) {
        // vals is already sorted at build time.
        entries.push({ v: percentileSorted(vals, pct), rec: r });
      }
    }
    if (!entries.length) {
      // Fall back to summary bounds if no raw data for this load
      for (const r of recs) {
        for (const [l, mn, mx] of r.data) {
          if (l === load) {
            entries.push({ v: useMax ? mx : mn, rec: r });
          }
        }
      }
    }
  }

  if (!entries.length) return { value: NaN, src: "" };

  let best = entries[0];
  for (let i = 1; i < entries.length; i++) {
    if (useMax ? entries[i].v > best.v : entries[i].v < best.v) {
      best = entries[i];
    }
  }
  return { value: best.v, src: best.rec.label || "" };
}

// ============================================================
// PLOT
// ============================================================
function selectedRecords() {
  return activeRecords().filter(r => checkedStems.has(r.stem));
}

function redraw() {
  clearAllBoxes();
  svg.innerHTML = "";
  combineAgg = null;

  const recs = selectedRecords();
  if (!recs.length) {
    drawEmpty(`${currentGroup || ""} - no tests selected`);
    return;
  }

  if (combineMode) drawCombine(recs);
  else             drawIndividual(recs);
}

function drawEmpty(msg) {
  drawAxesFrame(0, 1, 0, 1);
  const t = svgEl("text", {
    x: SVG_W / 2, y: SVG_H / 2, "text-anchor": "middle",
    "font-family": "Segoe UI, sans-serif", "font-size": 14, fill: "#777"
  });
  t.textContent = msg;
  svg.appendChild(t);
}

function drawCombine(recs) {
  const loadSet = new Set();
  const meansAgg = {};
  for (const rec of recs) {
    for (const [l, , , m] of rec.data) {
      loadSet.add(l);
      if (!meansAgg[l]) meansAgg[l] = [];
      meansAgg[l].push(m);
    }
  }
  const loads = [...loadSet].sort((a, b) => a - b);
  const topPct = pctValue(topLabel);
  const botPct = pctValue(botLabel);
  const tops = loads.map(l => seriesForLoad(recs, l, topPct, "top"));
  const bots = loads.map(l => seriesForLoad(recs, l, botPct, "bot"));
  const means = loads.map(l =>
    meansAgg[l].reduce((a, b) => a + b, 0) / meansAgg[l].length);

  const topsV = tops.map(t => t.value);
  const botsV = bots.map(t => t.value);
  const ys = topsV.concat(botsV).concat(means).filter(v => Number.isFinite(v));
  const xExt = [Math.min(...loads), Math.max(...loads)];
  const yExt = [Math.min(...ys),    Math.max(...ys)];
  makeScales(xExt, yExt);
  drawAxesFrame(xExt[0], xExt[1], yExt[0], yExt[1]);
  drawTitle(`${currentGroup} - Combined (${recs.length} tests)`);

  drawPolyline(loads, topsV,  TOP_COLOR,  1.8, "-");
  drawPolyline(loads, means,  MEAN_COLOR, 1.8, "-");
  drawPolyline(loads, botsV,  BOT_COLOR,  1.8, "-");
  drawDots(loads, topsV,  TOP_COLOR);
  drawDots(loads, means,  MEAN_COLOR);
  drawDots(loads, botsV,  BOT_COLOR);
  // Legend is rendered by the Series panel outside the SVG.

  combineAgg = {};
  loads.forEach((l, i) => combineAgg[l] = {
    top: tops[i].value, topSrc: tops[i].src,
    mean: means[i],
    bot: bots[i].value, botSrc: bots[i].src,
  });
}

function drawIndividual(recs) {
  const allLoads = [], allY = [];
  for (const rec of recs) {
    for (const [l, mn, mx, m] of rec.data) {
      allLoads.push(l);
      allY.push(mn, mx, m);
    }
  }
  const xExt = [Math.min(...allLoads), Math.max(...allLoads)];
  const yExt = [Math.min(...allY),    Math.max(...allY)];
  makeScales(xExt, yExt);
  drawAxesFrame(xExt[0], xExt[1], yExt[0], yExt[1]);
  drawTitle(`${currentGroup} - ${recs.length} tests  ` +
            `(solid=mean, dashed=max, dotted=min)`);

  const legend = [];
  recs.forEach((rec, i) => {
    const color = TAB20[i % TAB20.length];
    const loads = rec.data.map(d => d[0]);
    const mins  = rec.data.map(d => d[1]);
    const maxs  = rec.data.map(d => d[2]);
    const means = rec.data.map(d => d[3]);
    drawPolyline(loads, maxs,  color, 1.0, "5,3", 0.7);
    drawPolyline(loads, mins,  color, 1.0, "1,3", 0.7);
    drawPolyline(loads, means, color, 1.4, "-",   1.0);
    legend.push([rec.label, color]);
  });
  if (recs.length <= 25) drawLegend(legend);
}

function makeScales(xExt, yExt) {
  const [x0, x1] = xExt;
  const dx = x1 - x0 || 1;
  const [y0, y1] = yExt;
  const yPad = (y1 - y0) * 0.05 || 1;
  const yLo = y0 - yPad, yHi = y1 + yPad;
  const dy = yHi - yLo || 1;
  xScale = x => PAD.left + ((x - x0) / dx) * PLOT_W;
  yScale = y => PAD.top + PLOT_H - ((y - yLo) / dy) * PLOT_H;
  xScale.inverse = px => x0 + ((px - PAD.left) / PLOT_W) * dx;
  xScale.extent  = xExt;
  yScale.extent  = [yLo, yHi];
}

function drawAxesFrame(x0, x1, y0, y1) {
  svg.appendChild(svgEl("rect", {
    x: PAD.left, y: PAD.top, width: PLOT_W, height: PLOT_H,
    fill: "#fff", stroke: "#b0bccb"
  }));
  const yTicks = niceTicks(y0, y1, 6);
  for (const yt of yTicks) {
    const py = yScale(yt);
    svg.appendChild(svgEl("line", {
      x1: PAD.left, y1: py, x2: SVG_W - PAD.right, y2: py,
      stroke: "#e0e6ee", "stroke-width": 1
    }));
    const t = svgEl("text", {
      x: PAD.left - 6, y: py, "text-anchor": "end",
      "dominant-baseline": "middle",
      "font-family": "Segoe UI, sans-serif", "font-size": 11, fill: "#444"
    });
    t.textContent = fmtNum(yt);
    svg.appendChild(t);
  }
  const xTicks = niceTicks(x0, x1, 7);
  for (const xt of xTicks) {
    const px = xScale(xt);
    svg.appendChild(svgEl("line", {
      x1: px, y1: PAD.top, x2: px, y2: SVG_H - PAD.bottom,
      stroke: "#e0e6ee", "stroke-width": 1
    }));
    const t = svgEl("text", {
      x: px, y: SVG_H - PAD.bottom + 16, "text-anchor": "middle",
      "font-family": "Segoe UI, sans-serif", "font-size": 11, fill: "#444"
    });
    t.textContent = fmtNum(xt);
    svg.appendChild(t);
  }
  const xlab = svgEl("text", {
    x: PAD.left + PLOT_W / 2, y: SVG_H - 10, "text-anchor": "middle",
    "font-family": "Segoe UI, sans-serif", "font-size": 12, fill: "#222"
  });
  xlab.textContent = "Load (ohm)";
  svg.appendChild(xlab);
  const ylab = svgEl("text", {
    x: 16, y: PAD.top + PLOT_H / 2, "text-anchor": "middle",
    "font-family": "Segoe UI, sans-serif", "font-size": 12, fill: "#222",
    transform: `rotate(-90 16 ${PAD.top + PLOT_H / 2})`
  });
  ylab.textContent = "Reading";
  svg.appendChild(ylab);
}

function drawTitle(text) {
  const t = svgEl("text", {
    x: SVG_W / 2, y: 18, "text-anchor": "middle",
    "font-family": "Segoe UI, sans-serif", "font-size": 13,
    "font-weight": 600, fill: "#1e3a5f"
  });
  t.textContent = text;
  svg.appendChild(t);
}

function drawPolyline(xs, ys, color, width, dash, alpha = 1) {
  const pts = xs.map((x, i) => `${xScale(x)},${yScale(ys[i])}`).join(" ");
  const attrs = {
    points: pts, fill: "none", stroke: color,
    "stroke-width": width, opacity: alpha
  };
  if (dash && dash !== "-") attrs["stroke-dasharray"] = dash;
  svg.appendChild(svgEl("polyline", attrs));
}

function drawDots(xs, ys, color) {
  for (let i = 0; i < xs.length; i++) {
    if (!Number.isFinite(ys[i])) continue;
    svg.appendChild(svgEl("circle", {
      cx: xScale(xs[i]), cy: yScale(ys[i]), r: 3.2,
      fill: color, stroke: "#fff", "stroke-width": 1
    }));
  }
}

function drawLegend(entries) {
  const boxW = 130, rowH = 16;
  const boxH = entries.length * rowH + 10;
  const x = SVG_W - PAD.right - boxW - 6;
  const y = PAD.top + 6;
  svg.appendChild(svgEl("rect", {
    x, y, width: boxW, height: boxH,
    fill: "#fff", stroke: "#b0bccb", opacity: 0.95
  }));
  entries.forEach(([label, color], i) => {
    const cy = y + 12 + i * rowH;
    svg.appendChild(svgEl("line", {
      x1: x + 8, y1: cy, x2: x + 26, y2: cy,
      stroke: color, "stroke-width": 2.4
    }));
    svg.appendChild(svgEl("circle", {
      cx: x + 17, cy, r: 3, fill: color, stroke: "#fff",
      "stroke-width": 1
    }));
    const t = svgEl("text", {
      x: x + 32, y: cy, "dominant-baseline": "middle",
      "font-family": "Segoe UI, sans-serif", "font-size": 11, fill: "#222"
    });
    t.textContent = label;
    svg.appendChild(t);
  });
}

// ============================================================
// HOVER + LOCK
// ============================================================
function clearAllBoxes() {
  if (hoverBox) { hoverBox.remove(); hoverBox = null; }
  for (const b of lockedBoxes) b.remove();
  lockedBoxes = [];
}

function onHover(e) {
  if (!combineAgg) return;

  // If the cursor is currently over any hover-info tooltip (transient or
  // locked), keep the existing hoverBox untouched — the user is heading
  // for the 'lock' region. Without this the tooltip vanishes the instant
  // the cursor crosses its boundary.
  if (e.target && e.target.closest && e.target.closest(".hover-info")) {
    return;
  }

  const rect = svg.getBoundingClientRect();
  const svgX = ((e.clientX - rect.left) / rect.width) * SVG_W;
  const svgY = ((e.clientY - rect.top)  / rect.height) * SVG_H;

  if (svgX < PAD.left || svgX > SVG_W - PAD.right ||
      svgY < PAD.top  || svgY > SVG_H - PAD.bottom) {
    if (hoverBox) { hoverBox.remove(); hoverBox = null; }
    return;
  }

  const loadHover = xScale.inverse(svgX);
  const loads = Object.keys(combineAgg).map(Number);
  const nearest = loads.reduce((prev, curr) =>
    Math.abs(curr - loadHover) < Math.abs(prev - loadHover) ? curr : prev);

  const lockedLoads = new Set(lockedBoxes.map(b => b.load));
  if (lockedLoads.has(nearest)) {
    if (hoverBox) { hoverBox.remove(); hoverBox = null; }
    return;
  }
  if (hoverBox && hoverBox.load === nearest) return;
  if (hoverBox) hoverBox.remove();
  hoverBox = createBox(nearest, combineAgg[nearest], false, () => {
    if (!hoverBox) return;
    hoverBox.setLocked(true);
    lockedBoxes.push(hoverBox);
    hoverBox = null;
  });
}

function onLeave(e) {
  // The cursor left the plot-container. If it entered a tooltip DIV
  // that visually extends above the container (translate(-50%,-100%))
  // it's technically leaving the container box but still a descendant
  // event target — keep the hoverBox in that case.
  const to = e && e.relatedTarget;
  if (to && to.closest && to.closest(".hover-info")) return;
  if (hoverBox) { hoverBox.remove(); hoverBox = null; }
}

function createBox(load, data, locked, onLockClick) {
  // SVG artists: vertical dashed line + 3 marker dots at top/mean/bot
  const g = svgEl("g", {});
  const xPx = xScale(load);
  g.appendChild(svgEl("line", {
    x1: xPx, y1: PAD.top, x2: xPx, y2: SVG_H - PAD.bottom,
    stroke: "#333", "stroke-width": 0.9, "stroke-dasharray": "4,3",
    opacity: 0.85
  }));
  for (const [val, color] of [[data.top,  TOP_COLOR],
                              [data.mean, MEAN_COLOR],
                              [data.bot,  BOT_COLOR]]) {
    if (!Number.isFinite(val)) continue;
    g.appendChild(svgEl("circle", {
      cx: xPx, cy: yScale(val), r: 5, fill: color,
      stroke: "#fff", "stroke-width": 1.2
    }));
  }
  svg.appendChild(g);

  // HTML overlay: single tooltip, centred over the load line, above the
  // top data point. CSS `translate(-50%, -100%)` on .hover-info anchors
  // the bottom-centre of the tooltip at the (left, top) we set below.
  const rect = svg.getBoundingClientRect();
  const contRect = overlay.getBoundingClientRect();
  const sx = rect.width  / SVG_W;
  const sy = rect.height / SVG_H;
  const cxCss = (xPx * sx) + (rect.left - contRect.left);
  // Anchor at the SVG-y of the topmost of the three (data.top / data.bot
  // — whichever is smaller in CSS px, since y-axis inverts). Use the
  // visual top marker so the tooltip always sits above every dot.
  const yTopVal = data.top;
  const yBotVal = data.bot;
  const yTopCss = (yScale(yTopVal) * sy) + (rect.top - contRect.top);
  const yBotCss = (yScale(yBotVal) * sy) + (rect.top - contRect.top);
  const anchorCss = Math.min(yTopCss, yBotCss) - 10;

  const topSrcTxt = data.topSrc ? ` [${escHtml(data.topSrc)}]` : "";
  const botSrcTxt = data.botSrc ? ` [${escHtml(data.botSrc)}]` : "";
  const topDisp = pctDisplay(topLabel, "max");
  const botDisp = pctDisplay(botLabel, "min");
  const infoDiv = document.createElement("div");
  infoDiv.className = "hover-info" + (locked ? " locked" : "");
  infoDiv.innerHTML =
    `<div class="row">Load=${fmtNum(load)}</div>` +
    `<div class="row">${escHtml(topDisp)}=${fmtNum(data.top)}${topSrcTxt}</div>` +
    `<div class="row">Mean=${fmtNum(data.mean)}</div>` +
    `<div class="row">${escHtml(botDisp)}=${fmtNum(data.bot)}${botSrcTxt}</div>` +
    `<div class="sep"></div>` +
    `<div class="lock-line">${locked ? "unlock" : "lock"}</div>`;
  infoDiv.style.left = cxCss + "px";
  infoDiv.style.top  = anchorCss + "px";
  overlay.appendChild(infoDiv);

  const box = {
    load, data, locked,
    svgGroup: g, infoDiv,
    remove() { g.remove(); infoDiv.remove(); },
    setLocked(l) {
      this.locked = l;
      infoDiv.classList.toggle("locked", l);
      const lockLine = infoDiv.querySelector(".lock-line");
      if (lockLine) lockLine.textContent = l ? "unlock" : "lock";
    },
  };

  infoDiv.addEventListener("click", () => {
    if (box.locked) {
      lockedBoxes = lockedBoxes.filter(b => b !== box);
      box.remove();
    } else if (onLockClick) {
      onLockClick();
    }
  });

  return box;
}

// ============================================================
// HELPERS
// ============================================================
function svgEl(tag, attrs) {
  const el = document.createElementNS(SVGNS, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  return el;
}

function niceTicks(lo, hi, count) {
  if (lo === hi) return [lo];
  const range = hi - lo;
  const step0 = range / count;
  const mag = Math.pow(10, Math.floor(Math.log10(step0)));
  const norm = step0 / mag;
  let step;
  if      (norm < 1.5) step = 1 * mag;
  else if (norm < 3)   step = 2 * mag;
  else if (norm < 7)   step = 5 * mag;
  else                 step = 10 * mag;
  const start = Math.ceil(lo / step) * step;
  const ticks = [];
  for (let v = start; v <= hi + 1e-9; v += step) ticks.push(v);
  return ticks;
}

function fmtNum(v) {
  if (Number.isInteger(v)) return String(v);
  if (Math.abs(v) >= 100)  return v.toFixed(0);
  if (Math.abs(v) >= 10)   return v.toFixed(1);
  return v.toFixed(2);
}

function escHtml(s) {
  return String(s).replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));
}

function escAttr(s) { return escHtml(s); }

// ============================================================
init();
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def generate_review(data_save_folder):
    """Build Test Review.html and return its path.

    Accepts either a folder that CONTAINS a summary/ subdirectory, or the
    summary/ folder itself. Also accepts an arbitrary folder — we
    recursively scan for *summary*.html regardless.

    Raises FileNotFoundError if the folder is missing or has no parseable
    *summary*.html files, RuntimeError on write failure.
    """
    folder = str(data_save_folder).strip().strip('"')
    if not os.path.isdir(folder):
        raise FileNotFoundError(f"folder not found: {folder}")

    data = build_review_data(folder)
    if not data:
        raise FileNotFoundError(
            f"no parseable *summary*.html files under {folder}")

    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    html = HTML_TEMPLATE.replace("/*__REVIEW_DATA__*/", payload)

    out_path = os.path.join(folder, "Test Review.html")
    try:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(html)
    except Exception as exc:
        raise RuntimeError(f"writing {out_path}: {exc}") from exc

    n_groups = len(data["groups"])
    n_tests = sum(len(v) for v in data["groups"].values())
    raw_status = "with raw data" if data.get("has_raw") else "summary-only"
    print(f"[OK] Test Review.html written -> {out_path}", file=sys.stderr)
    print(f"     {n_groups} test-name group(s), {n_tests} test(s), {raw_status}",
          file=sys.stderr)
    return out_path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Generate a self-contained Test Review.html from a "
                    "folder of *summary*.html and raw data/*.txt files.")
    parser.add_argument("--data-save-folder", required=True, metavar="DIR",
        dest="data_save_folder",
        help="Base folder to scan. May be the parent of summary/ and "
             "raw data/, or the summary/ folder itself. Test Review.html "
             "is written into this same folder.")
    args = parser.parse_args()

    try:
        out_path = generate_review(args.data_save_folder)
    except Exception as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 2
    print(out_path, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
