"""Summary Test - build HTML summary reports from Auto_Read raw data.

Companion to `Load FC table.py`. Takes the process_FC_table output plus a
few per-test inputs, reads every per-load raw file produced by
Auto_Read_TS.exe, computes min/max/mean/variation, and writes one or more
HTML summary reports into <save_path>\\summary\\.

Raw file layout expected (produced by Auto_Read_TS.exe):
    <save_path>\\raw data\\test<N>_<load><unit>.txt

Summary output layout:
    - Single val_* column in raw file:
        <save_path>\\summary\\test<N>_summary.html
        (Test Name column = FC test name as-is)

    - Multiple val_* columns (must be distinguishable):
        <save_path>\\summary\\test<N>_<suffix>_summary.html
        where <suffix> is one of:
            CH<n>              (only channel detected)
            OUT{P|M}           (only side detected)
            CH<n>_OUT{P|M}     (both detected)
        Test Name column = "<FC test name>_<suffix>"
"""
import math
import os
import re


# ---------------------------------------------------------------------------
# FC table column names. The FC table passed to generate_summary MUST include
# a header row as row 0; column indices are resolved by matching these names
# (case-insensitive, whitespace-trimmed) against the header row.
# ---------------------------------------------------------------------------
FC_HEADER_ALIASES = {
    "test_no":     ["test no.", "test no", "test number", "test_no"],
    "test_name":   ["test name", "test_name"],
    "fin":         ["fin", "fin/music", "music"],
    "level":       ["level"],
    "temp":        ["temp", "temperature"],
    "load":        ["load"],
    "pvdd":        ["pvdd"],
    "vbat":        ["vbat"],
    "dvdd":        ["dvdd"],
    "gain":        ["gain"],
    "fsw":         ["fsw"],
    "modulation":  ["modulation"],
    "reg1":        ["reg1"],
    "reg2":        ["reg2"],
    "reg3":        ["reg3"],
    "mode":        ["mode"],
}


def _build_col_index(header_row):
    """Return {friendly_name: column_index} by matching header cells against
    FC_HEADER_ALIASES. Raise ValueError if any required column is missing."""
    norm = [str(c).strip().lower() if c is not None else ""
            for c in header_row]
    idx = {}
    for key, aliases in FC_HEADER_ALIASES.items():
        for alias in aliases:
            if alias in norm:
                idx[key] = norm.index(alias)
                break
    missing = [k for k in FC_HEADER_ALIASES if k not in idx]
    if missing:
        raise ValueError(
            "FC table header missing columns: {0}. Got header: {1}".format(
                missing, header_row))
    return idx


# ---------------------------------------------------------------------------
# Label parsing — labels come from fixed Re.json / Offset.json script
# comments in the form 'ch<N> {P|N} <suffix>' (e.g. 'ch1 P Re').
# ---------------------------------------------------------------------------
_LABEL_RE = re.compile(r"^\s*ch\s*([1-4])\s+([PN])\b", re.IGNORECASE)


def _side_specific_test_name(base, side):
    """Rewrite a combined FC test name to the side-specific form.

    Only rewrites when `base` contains BOTH 'OUTP' and 'OUTM' tokens — i.e.
    the FC row was written as a combined test like 'OUTP_SLOL&OUTM_SLOL'.
    In that case, when we emit the OUTP report we want the subtest title to
    say 'OUTP_SLOL' (and the OUTM report to say 'OUTM_SLOL'), so the two
    can be told apart in the RTLDG Review tool.

    Supported base name patterns:
      'OUTP_SLOL&OUTM_SLOL'  -> pick 'OUTP_SLOL' or 'OUTM_SLOL'
      'OUTP_S2P&OUTM_S2P'    -> pick 'OUTP_S2P'  or 'OUTM_S2P'
      'OUTP&OUTM_SLOL'       -> synthesize 'OUTP_SLOL' or 'OUTM_SLOL'
    Anything else (single-side name, unrecognized shape) is returned as-is.
    """
    if side not in ("OUTP", "OUTM"):
        return base
    if "OUTP" not in base or "OUTM" not in base:
        return base
    m = re.search(r"\b" + side + r"_\w+", base)
    if m:
        return m.group(0)
    m = re.search(r"\bOUT[PM]&OUT[PM]_(\w+)", base)
    if m:
        return "{0}_{1}".format(side, m.group(1))
    return base


def _derive_subtest_layout(labels):
    """Return list of (label, file_suffix, ch_prefix) tuples - one per
    subtest to emit.
        file_suffix - appended to the output filename to distinguish OUTP
                      from OUTM reports (empty for single-column).
        ch_prefix   - prepended to the subtest name shown in the report
                      title (e.g. 'CH1'); empty if channel can't be parsed.
    Single column -> [(label, "", ch_prefix_or_empty)].
    Multi-column  -> file_suffix = 'CH<n>_OUT{P|M}', ch_prefix = 'CH<n>'."""
    if len(labels) == 1:
        m = _LABEL_RE.match(str(labels[0]))
        ch_prefix = "CH{0}".format(m.group(1)) if m else ""
        return [(labels[0], "", ch_prefix)]

    seen, out = set(), []
    for lb in labels:
        m = _LABEL_RE.match(str(lb))
        if not m:
            raise ValueError(
                "Label {0!r} does not match 'ch<N> {{P|N}} ...' "
                "format".format(lb))
        ch = m.group(1)
        side = "P" if m.group(2).upper() == "P" else "M"
        if (ch, side) in seen:
            raise ValueError(
                "Duplicate CH{0}_OUT{1} in labels".format(ch, side))
        seen.add((ch, side))
        out.append((lb,
                    "CH{0}_OUT{1}".format(ch, side),
                    "CH{0}".format(ch)))
    return out


# ---------------------------------------------------------------------------
# Load expansion / stats / FC lookup
# ---------------------------------------------------------------------------
def _expand_load(load_str):
    """Expand a Load cell into a list of individual load values (as strings).
    By the time we get here, process_FC_table has already split any ';'
    lists, so only two shapes remain:
        'a~b'  -> integer sweep a..b inclusive.
        single -> [value].
    """
    s = str(load_str).strip()
    if not s or s.upper() == "NA":
        return [s]
    if "~" in s:
        lo_s, hi_s = s.split("~", 1)
        try:
            lo, hi = int(lo_s), int(hi_s)
            step = 1 if lo <= hi else -1
            return [str(v) for v in range(lo, hi + step, step)]
        except ValueError:
            return [s]
    return [s]


def _scan_val_columns(txt_path):
    """Parse an Auto_Read raw data file. Return list of (label, [floats]).
    Preserves the on-disk column order."""
    with open(txt_path, "r", encoding="utf-8") as f:
        header = f.readline().rstrip("\r\n").split("\t")
        val_cols = [(i, h[4:]) for i, h in enumerate(header)
                    if h.startswith("val_")]
        if not val_cols:
            return []
        buckets = [(idx, label, []) for idx, label in val_cols]
        for line in f:
            parts = line.rstrip("\r\n").split("\t")
            for idx, _label, vals in buckets:
                if idx >= len(parts):
                    continue
                cell = parts[idx].strip()
                if not cell:
                    continue
                try:
                    vals.append(float(cell))
                except ValueError:
                    continue
        return [(label, vals) for _idx, label, vals in buckets]


def _stats(vals):
    """Return (min, max, mean, variation%) rounded to int.
    variation% = (max - min) / mean * 100."""
    if not vals:
        return 0, 0, 0, 0
    vmin = min(vals)
    vmax = max(vals)
    vmean = sum(vals) / len(vals)
    if abs(vmean) > 1e-12:
        var = abs((vmax - vmin) / vmean) * 100.0
    else:
        var = 0.0
    return int(round(vmin)), int(round(vmax)), int(round(vmean)), int(round(var))


def _find_fc_row(data_rows, test_no_col, test_number):
    """Return the data row whose Test No. equals `test_number`. `data_rows`
    must exclude the header row."""
    target = int(test_number)
    for r in data_rows:
        if not r:
            continue
        try:
            if int(str(r[test_no_col]).strip()) == target:
                return r
        except (ValueError, IndexError):
            continue
    raise ValueError("Test No. {0} not found in FC table".format(test_number))


def _norm_thermal(v):
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    return str(v).strip().upper()


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------
def _esc(v):
    """HTML-escape any value (converted via str())."""
    s = "" if v is None else str(v)
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;")
             .replace('"', "&quot;"))


_HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Test {test_no} - {subtest}</title>
<style>
body {{ font-family:'Segoe UI',sans-serif; margin:20px; color:#222; }}
h1 {{ color:#1e3a5f; margin:0 0 4px 0; font-size:22px; }}
.subtitle {{ color:#666; margin:0 0 16px 0; font-size:14px; }}
.meta {{ background:#f5f7fa; border:1px solid #d0d7e0; border-radius:4px;
        padding:12px 16px; margin:12px 0 18px 0;
        display:grid; grid-template-columns:repeat(4,1fr); gap:6px 24px;
        font-size:13px; }}
.meta .key {{ color:#666; font-weight:600; margin-right:6px; }}
table {{ border-collapse:collapse; width:100%; font-size:13px;
        border:1px solid #b0bccb; table-layout:fixed; }}
col.c-load    {{ width:80px; }}
col.c-min     {{ width:90px; }}
col.c-max     {{ width:90px; }}
col.c-mean    {{ width:90px; }}
col.c-var     {{ width:110px; }}
col.c-status  {{ width:auto; }}
th {{ background:#1e3a5f; color:#fff; padding:8px 10px; font-weight:600;
     border:1px solid #17304a; text-align:right; }}
th.left {{ text-align:left; }}
td {{ padding:6px 10px; border:1px solid #d5dde5;
     white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }}
tr:nth-child(even) td {{ background:#f9fafc; }}
.num {{ text-align:right; font-family:Consolas,monospace;
       font-variant-numeric:tabular-nums; }}
.chart-wrap {{ margin-top:24px; }}
.chart-wrap svg {{ width:100%; height:auto; max-width:900px;
                  border:1px solid #b0bccb; background:#fff; display:block; }}
</style>
</head>
<body>
<h1>Test {test_no}</h1>
<p class="subtitle">{subtest} &middot; {device_name} / Unit {device_unit}</p>
<div class="meta">
<div><span class="key">Fin/Music:</span>{fin}</div>
<div><span class="key">Level:</span>{level}</div>
<div><span class="key">Temp:</span>{temp}</div>
<div><span class="key">Mode:</span>{mode}</div>
<div><span class="key">PVDD:</span>{pvdd}</div>
<div><span class="key">VBAT:</span>{vbat}</div>
<div><span class="key">DVDD:</span>{dvdd}</div>
<div><span class="key">Gain:</span>{gain}</div>
<div><span class="key">FSW:</span>{fsw}</div>
<div><span class="key">Modulation:</span>{modulation}</div>
<div><span class="key">REG1:</span>{reg1}</div>
<div><span class="key">REG2:</span>{reg2}</div>
<div><span class="key">REG3:</span>{reg3}</div>
<div><span class="key">Thermal Stream:</span>{thermal_stream}</div>
</div>
<table>
<colgroup>
<col class="c-load"><col class="c-min"><col class="c-max">
<col class="c-mean"><col class="c-var"><col class="c-status">
</colgroup>
<thead><tr>
<th>Load</th><th>Min</th><th>Max</th><th>Mean</th>
<th>Variation(%)</th><th class="left">Device Status</th>
</tr></thead>
<tbody>
{rows}
</tbody>
</table>
<div class="chart-wrap">{chart}</div>
</body>
</html>
"""


def _nice_ticks(lo, hi, target=6):
    """Return (ticks, start, end) covering [lo, hi] with 'nice' step size."""
    if hi <= lo:
        hi = lo + 1
    raw = (hi - lo) / max(1, target)
    mag = 10 ** int(round(math.log10(raw))) if raw > 0 else 1
    step = mag
    for m in (1, 2, 2.5, 5, 10):
        step = m * mag
        if (hi - lo) / step <= target * 1.5:
            break
    start = math.floor(lo / step) * step
    end = math.ceil(hi / step) * step
    ticks = []
    v = start
    while v <= end + step * 0.5:
        ticks.append(v)
        v += step
    return ticks, start, end


def _fmt_tick(v):
    """Format a tick value: integer if whole, else 1 decimal."""
    if abs(v - round(v)) < 1e-9:
        return str(int(round(v)))
    return "{0:.1f}".format(v)


def _render_chart_svg(subtest, table_rows):
    """Line chart: x=Load, y=Reading. Three series: Min / Mean / Max.
    No cursors, just the lines + markers + axes + legend."""
    xs, mins, maxs, means = [], [], [], []
    for r in table_rows:
        try:
            x = float(r["load"])
        except (TypeError, ValueError):
            continue
        xs.append(x)
        mins.append(float(r["vmin"]))
        maxs.append(float(r["vmax"]))
        means.append(float(r["vmean"]))

    if len(xs) < 1:
        return ""

    # Sort by x so lines don't zig-zag if the FC table order isn't ascending.
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    xs = [xs[i] for i in order]
    mins = [mins[i] for i in order]
    maxs = [maxs[i] for i in order]
    means = [means[i] for i in order]

    # Canvas. No title, so top padding is small.
    W, H = 900, 420
    pad_l, pad_r, pad_t, pad_b = 70, 30, 20, 55
    plot_w = W - pad_l - pad_r
    plot_h = H - pad_t - pad_b

    x_lo, x_hi = min(xs), max(xs)
    y_lo = min(min(mins), min(means), min(maxs))
    y_hi = max(max(mins), max(means), max(maxs))
    if x_hi == x_lo:
        x_lo -= 0.5
        x_hi += 0.5
    if y_hi == y_lo:
        y_lo -= 1
        y_hi += 1

    x_ticks, x_start, x_end = _nice_ticks(x_lo, x_hi)
    y_ticks, y_start, y_end = _nice_ticks(y_lo, y_hi)

    def sx(v):
        return pad_l + (v - x_start) / (x_end - x_start) * plot_w

    def sy(v):
        return pad_t + (y_end - v) / (y_end - y_start) * plot_h

    parts = ['<svg xmlns="http://www.w3.org/2000/svg" '
             'viewBox="0 0 {0} {1}">'.format(W, H)]

    # Plot area background.
    parts.append(
        '<rect x="{0}" y="{1}" width="{2}" height="{3}" '
        'fill="#ffffff" stroke="#b0bccb"/>'.format(
            pad_l, pad_t, plot_w, plot_h))

    # Grid + axis ticks.
    for t in y_ticks:
        y = sy(t)
        parts.append(
            '<line x1="{0}" y1="{1}" x2="{2}" y2="{1}" '
            'stroke="#e0e6ee" stroke-width="1"/>'.format(
                pad_l, y, pad_l + plot_w))
        parts.append(
            '<text x="{0}" y="{1}" font-family="Segoe UI,sans-serif" '
            'font-size="11" fill="#444" text-anchor="end" '
            'dominant-baseline="middle">{2}</text>'.format(
                pad_l - 6, y, _fmt_tick(t)))

    for t in x_ticks:
        x = sx(t)
        parts.append(
            '<line x1="{0}" y1="{1}" x2="{0}" y2="{2}" '
            'stroke="#e0e6ee" stroke-width="1"/>'.format(x, pad_t, pad_t + plot_h))
        parts.append(
            '<text x="{0}" y="{1}" font-family="Segoe UI,sans-serif" '
            'font-size="11" fill="#444" text-anchor="middle">{2}</text>'.format(
                x, pad_t + plot_h + 16, _fmt_tick(t)))

    # Axis labels.
    parts.append(
        '<text x="{0}" y="{1}" font-family="Segoe UI,sans-serif" '
        'font-size="12" fill="#222" text-anchor="middle">Load (Ohm)</text>'
        .format(pad_l + plot_w / 2, H - 15))
    parts.append(
        '<text transform="translate({0},{1}) rotate(-90)" '
        'font-family="Segoe UI,sans-serif" font-size="12" fill="#222" '
        'text-anchor="middle">Reading</text>'.format(
            18, pad_t + plot_h / 2))

    # Series - one polyline + circle markers each.
    series = [
        ("Min",  mins,  "#22a06b"),
        ("Mean", means, "#c62828"),
        ("Max",  maxs,  "#1e63c9"),
    ]
    for name, ys, color in series:
        pts = " ".join("{0:.1f},{1:.1f}".format(sx(xs[i]), sy(ys[i]))
                       for i in range(len(xs)))
        parts.append(
            '<polyline points="{0}" fill="none" stroke="{1}" '
            'stroke-width="1.8"/>'.format(pts, color))
        for i in range(len(xs)):
            parts.append(
                '<circle cx="{0:.1f}" cy="{1:.1f}" r="3.2" '
                'fill="{2}" stroke="#fff" stroke-width="1"/>'.format(
                    sx(xs[i]), sy(ys[i]), color))

    # Legend - top-left inside the plot.
    lx = pad_l + 8
    ly = pad_t + 8
    parts.append(
        '<rect x="{0}" y="{1}" width="88" height="60" '
        'fill="#ffffff" stroke="#b0bccb" opacity="0.95"/>'.format(lx, ly))
    for i, (name, _y, color) in enumerate(series):
        cy = ly + 14 + i * 16
        parts.append(
            '<line x1="{0}" y1="{1}" x2="{2}" y2="{1}" stroke="{3}" '
            'stroke-width="2.4"/>'.format(lx + 8, cy, lx + 26, color))
        parts.append(
            '<circle cx="{0}" cy="{1}" r="3" fill="{2}" stroke="#fff" '
            'stroke-width="1"/>'.format(lx + 17, cy, color))
        parts.append(
            '<text x="{0}" y="{1}" font-family="Segoe UI,sans-serif" '
            'font-size="11" fill="#222" '
            'dominant-baseline="middle">{2}</text>'.format(lx + 32, cy, name))

    parts.append('</svg>')
    return "".join(parts)


def _render_html(meta, table_rows):
    row_html_parts = []
    for r in table_rows:
        row_html_parts.append(
            "<tr>"
            "<td class='num'>{0}</td>"
            "<td class='num'>{1}</td>"
            "<td class='num'>{2}</td>"
            "<td class='num'>{3}</td>"
            "<td class='num'>{4}</td>"
            "<td>{5}</td>"
            "</tr>".format(
                _esc(r["load"]),
                _esc(r["vmin"]),
                _esc(r["vmax"]),
                _esc(r["vmean"]),
                _esc(r["var"]),
                _esc(r["status"]),
            ))
    return _HTML_TEMPLATE.format(
        test_no=_esc(meta["test_no"]),
        subtest=_esc(meta["subtest"]),
        device_name=_esc(meta["device_name"]),
        device_unit=_esc(meta["device_unit"]),
        fin=_esc(meta["fin"]),
        level=_esc(meta["level"]),
        temp=_esc(meta["temp"]),
        mode=_esc(meta["mode"]),
        pvdd=_esc(meta["pvdd"]),
        vbat=_esc(meta["vbat"]),
        dvdd=_esc(meta["dvdd"]),
        gain=_esc(meta["gain"]),
        fsw=_esc(meta["fsw"]),
        modulation=_esc(meta["modulation"]),
        reg1=_esc(meta["reg1"]),
        reg2=_esc(meta["reg2"]),
        reg3=_esc(meta["reg3"]),
        thermal_stream=_esc(meta["thermal_stream"]),
        rows="\n".join(row_html_parts),
        chart=_render_chart_svg(meta["subtest"], table_rows),
    )


# ---------------------------------------------------------------------------
# Main API
# ---------------------------------------------------------------------------
def generate_summary(save_path,
                     full_fc_table,
                     test_number,
                     device_name,
                     device_unit,
                     thermal_stream_use,
                     device_status):
    """Build one or more HTML summaries under <save_path>\\summary\\.

    Single val_* column in raw data -> 1 file:
        test<N>_summary.html
    Multiple val_* columns -> one file per detected subtest:
        test<N>_<suffix>_summary.html
        (suffix derived from CH1..4 and P/M info in script comments)

    Args:
        save_path: folder containing the 'raw data' subfolder.
        full_fc_table: rows including a header row as index 0. Columns are
            resolved by header name (see FC_HEADER_ALIASES), so column
            order is flexible.
        test_number: FC row's Test No. to summarize (int or str).
        device_name: e.g. 'TAS6754'.
        device_unit: e.g. '1'.
        thermal_stream_use: bool or 'TRUE'/'FALSE'.
        device_status: list of status strings, one per load value.
            Missing/empty entries are preserved as blanks — read_status
            can be flaky and we'd rather emit an empty cell than raise.

    Returns:
        List of absolute paths to the written HTML files.
    """
    if not full_fc_table or len(full_fc_table) < 2:
        raise ValueError(
            "full_fc_table must contain a header row plus at least one data "
            "row (got {0} rows)".format(len(full_fc_table) if full_fc_table
                                          else 0))
    col = _build_col_index(full_fc_table[0])
    data_rows = full_fc_table[1:]
    fc_row = _find_fc_row(data_rows, col["test_no"], test_number)
    loads = _expand_load(fc_row[col["load"]])

    # Normalize None -> "" so missing slots render as blank cells instead
    # of blowing up. read_status can be unstable; a blank status is fine.
    device_status = [("" if s is None else str(s)) for s in device_status]

    # Align to loads length: pad short arrays with "", truncate long ones
    # (LabVIEW may pre-allocate more slots than needed).
    if len(device_status) < len(loads):
        device_status = device_status + [""] * (len(loads) - len(device_status))
    else:
        device_status = device_status[:len(loads)]

    ts_str = _norm_thermal(thermal_stream_use)
    raw_dir = os.path.join(save_path, "raw data")
    summary_dir = os.path.join(save_path, "summary")
    os.makedirs(summary_dir, exist_ok=True)

    # Determine subtest layout from the first raw file that exists.
    layout = None
    for load in loads:
        rf = os.path.join(raw_dir, "test{0}_{1}ohm.txt".format(
            test_number, load))
        if os.path.exists(rf):
            cols = _scan_val_columns(rf)
            if cols:
                labels = [lb for lb, _v in cols]
                layout = _derive_subtest_layout(labels)
                break
    if layout is None:
        raise ValueError(
            "No readable raw data file for test {0} in {1}".format(
                test_number, raw_dir))

    base_test_name = str(fc_row[col["test_name"]])
    written = []

    for label, suffix, ch_prefix in layout:
        # Collect per-load rows for this subtest.
        table_rows = []
        for load, status in zip(loads, device_status):
            rf = os.path.join(raw_dir, "test{0}_{1}ohm.txt".format(
                test_number, load))
            vmin = vmax = vmean = var = 0
            if os.path.exists(rf):
                try:
                    cols = _scan_val_columns(rf)
                    match = [v for lb, v in cols if lb == label]
                    if match and match[0]:
                        vmin, vmax, vmean, var = _stats(match[0])
                    else:
                        print("[WARN] Column '{0}' missing/empty in {1}".format(
                            label, rf))
                except Exception as exc:
                    print("[WARN] Failed to parse {0}: {1}".format(rf, exc))
            else:
                print("[WARN] Raw file missing: {0}".format(rf))

            table_rows.append({
                "load": load,
                "vmin": vmin, "vmax": vmax, "vmean": vmean, "var": var,
                "status": status,
            })

        # When the FC row is a combined test (e.g. 'OUTP_SLOL&OUTM_SLOL'),
        # rewrite the test name to just the side we're emitting so the OUTP
        # and OUTM reports are distinguishable in RTLDG Review.
        if "_OUTP" in suffix:
            side_test_name = _side_specific_test_name(base_test_name, "OUTP")
        elif "_OUTM" in suffix:
            side_test_name = _side_specific_test_name(base_test_name, "OUTM")
        else:
            side_test_name = base_test_name

        # Subtest name shown in the report: 'CH<n> <base>' (channel prefix
        # only — the side is encoded in side_test_name / filename).
        if ch_prefix:
            subtest_name = "{0} {1}".format(ch_prefix, side_test_name)
        else:
            subtest_name = side_test_name
        # Filename keeps the side suffix so OUTP/OUTM reports don't collide.
        if suffix:
            fname = "test{0}_{1}_summary.html".format(test_number, suffix)
        else:
            fname = "test{0}_summary.html".format(test_number)
        out_path = os.path.join(summary_dir, fname)

        meta = {
            "test_no": test_number,
            "subtest": subtest_name,
            "device_name": device_name,
            "device_unit": device_unit,
            "fin":            fc_row[col["fin"]],
            "level":          fc_row[col["level"]],
            "temp":           fc_row[col["temp"]],
            "mode":           fc_row[col["mode"]],
            "pvdd":           fc_row[col["pvdd"]],
            "vbat":           fc_row[col["vbat"]],
            "dvdd":           fc_row[col["dvdd"]],
            "gain":           fc_row[col["gain"]],
            "fsw":            fc_row[col["fsw"]],
            "modulation":     fc_row[col["modulation"]],
            "reg1":           fc_row[col["reg1"]],
            "reg2":           fc_row[col["reg2"]],
            "reg3":           fc_row[col["reg3"]],
            "thermal_stream": ts_str,
        }

        with open(out_path, "w", encoding="utf-8") as f:
            f.write(_render_html(meta, table_rows))
        written.append(out_path)

    return written
