"""Index_One_Row — pull one FC-table row into a ForcingConditions container.

Given the processed FC table (2D array, header row 0) and a test number, find
that row and return a tuple shaped EXACTLY like the TestStand
`FileGlobals.ForcingConditions` container. Bind this step's return value to
that container: TestStand fills the fields positionally, so the tuple order
below MUST match the container's field order.

Mapping is by COLUMN NAME (case-insensitive), not position -- the FC table and
the container have different column sets/orders (the container has CH/FS which
the FC table may lack; the FC table has Test No./Test Script which the
container lacks). A field with no matching FC column gets a type default:
Number -> 0.0, String -> "".

Types matter: the container's Number fields (Temp, CH, PVDD, VBAT, DVDD, Gain)
are returned as float; every other field is returned as str. This is what
lets the tuple slot cleanly into the mixed-type container.

Entry point
-----------
    index_one_row(fc_table, test_number) -> tuple   # 19-tuple, container order
"""

# Container field order + FC-header aliases + type. THE ORDER IS THE CONTRACT:
# it must match FileGlobals.ForcingConditions field-for-field.
#   "num" -> TestStand Number (returned as float)
#   "str" -> TestStand String (returned as str)
FIELDS = [
    ("TestName",    ["test name", "test_name", "testname"],           "str"),
    ("Fin",         ["fin", "fin/music", "music"],                    "str"),
    ("Level",       ["level"],                                        "str"),
    ("Temp",        ["temp", "temperature"],                          "num"),
    ("Load",        ["load"],                                         "str"),
    ("CH",          ["ch", "channel"],                                "num"),
    ("PVDD",        ["pvdd"],                                         "num"),
    ("VBAT",        ["vbat"],                                         "num"),
    ("DVDD",        ["dvdd"],                                         "num"),
    ("Gain",        ["gain"],                                         "num"),
    ("FSW",         ["fsw"],                                          "str"),
    ("Modulation",  ["modulation"],                                   "str"),
    ("FS",          ["fs"],                                           "str"),
    ("REG1",        ["reg1"],                                         "str"),
    ("REG2",        ["reg2"],                                         "str"),
    ("REG3",        ["reg3"],                                         "str"),
    ("Mode",        ["mode"],                                         "str"),
    ("MusicPath",   ["music path", "musicpath", "music_path"],        "str"),
    ("ExtraScript", ["extra script", "extrascript", "extra_script"],  "str"),
]

_TEST_NO_ALIASES = ["test no.", "test no", "test number", "test_no", "testno"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _norm_header(header_row):
    """Header cells -> lowercased, trimmed strings."""
    return [str(c).strip().lower() if c is not None else "" for c in header_row]


def _col_for(norm_header, aliases):
    """First column index whose header matches one of `aliases`, else None."""
    for a in aliases:
        if a in norm_header:
            return norm_header.index(a)
    return None


def _to_num(v) -> float:
    """FC cell -> float. Empty / NA / non-numeric -> 0.0."""
    if v is None:
        return 0.0
    if isinstance(v, bool):
        return float(v)
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if not s or s.upper() == "NA":
        return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def _to_str(v) -> str:
    """FC cell -> str. None -> ''. (NA is kept as-is; downstream treats it.)"""
    return "" if v is None else str(v).strip()


def _find_row(fc_table, test_number):
    """Return the data row whose Test No. equals `test_number`."""
    norm = _norm_header(fc_table[0])
    tn_col = _col_for(norm, _TEST_NO_ALIASES)
    if tn_col is None:
        tn_col = 0                      # process_FC_table renumbers column 0
    try:
        target = int(float(test_number))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"test_number {test_number!r} is not numeric") from exc
    for row in fc_table[1:]:
        try:
            if int(float(str(row[tn_col]).strip())) == target:
                return row
        except (ValueError, IndexError):
            continue
    raise ValueError(f"Test No. {test_number} not found in FC table")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def index_one_row(fc_table, test_number):
    """Return the ForcingConditions tuple for `test_number`.

    The tuple is in container field order (see FIELDS); Number fields are
    floats, String fields are strs. Bind the step's return value to
    FileGlobals.ForcingConditions. Raises ValueError on bad input / missing row.
    """
    if not fc_table or len(fc_table) < 2:
        raise ValueError(
            "fc_table must have a header row plus at least one data row")

    norm = _norm_header(fc_table[0])
    row = _find_row(fc_table, test_number)

    out = []
    for _name, aliases, typ in FIELDS:
        col = _col_for(norm, aliases)
        raw = row[col] if (col is not None and col < len(row)) else ""
        out.append(_to_num(raw) if typ == "num" else _to_str(raw))
    return tuple(out)


# ---------------------------------------------------------------------------
# Debug CLI: load an FC .xlsx (via Load_FC_Table.py) and dump one row
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys, os, importlib.util
    if len(sys.argv) < 3:
        print('usage: python "Index_One_Row.py" <fc_table.xlsx> <test_number>',
              file=sys.stderr)
        sys.exit(2)
    here = os.path.dirname(os.path.abspath(__file__))
    spec = importlib.util.spec_from_file_location(
        "load_fc", os.path.join(here, "Load_FC_Table.py"))
    load_fc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(load_fc)

    table = load_fc.load_fc_table(sys.argv[1])
    values = index_one_row(table, sys.argv[2])
    print(f"ForcingConditions for Test No. {sys.argv[2]}:")
    for (name, _aliases, typ), val in zip(FIELDS, values):
        print(f"  {name:12} ({typ:3}) = {val!r}")
