"""Relay Config — drive the 3 GPIO relays on the I2X-AAA board (TestStand Python Adapter).

RTLDG-specific test step (Reading vs Load S2P/S2G sweep): it lives with the
RTLDG Automation sequence rather than in the shared setup/ tree. It combines
two orthogonal knobs into 3 GPIO states on the board:

  test_name  Which relay configuration to select. One of:
               OUTP_S2P  OUTP_S2G  OUTM_S2P  OUTM_S2G
             First half sets Side (GPIO2/B): OUTM=ON, OUTP=OFF
             Second half sets Short Type (GPIO1/A): S2G=ON, S2P=OFF

  short_en   Short Enable (GPIO3/C). Native bool, or a string (case-insensitive):
               True/enable/on/1   -> ON
               False/disable/off/0 -> OFF

All hardware talk goes through the i2x abstraction layer
(`I2X_AAA.gpio_send`) — the board is auto-discovered via the shared `Bench`
facade (STLink VCP). Delay per GPIO is fixed at 10 ms.

Entry point
-----------
    relay_control(test_name, short_en, port="") -> str

Returns a one-line summary. Raises ValueError on bad input, RuntimeError on
relay / discovery failure.

TestStand Python Adapter
------------------------
    Module   : Relay_Control.py
    Function : relay_control
    Arguments:
        test_name = FileGlobals.ForcingConditions.RelayConfig
        short_en  = FileGlobals.ForcingConditions.ShortEnable
        port      = FileGlobals.Instruments.I2X_Port   (optional override)

Standalone / debug CLI:
    .venv\\Scripts\\python.exe "Relay_Control.py" --test-name OUTP_S2P --short-en true
"""
from __future__ import annotations

import argparse
import sys
import traceback


TEST_NAMES   = ("OUTP_S2P", "OUTP_S2G", "OUTM_S2P", "OUTM_S2G")
ENABLE_TRUE  = {"true", "enable", "on", "1"}
ENABLE_FALSE = {"false", "disable", "off", "0"}
DELAY_MS     = 10   # per-GPIO delay is fixed


def parse_test_name(name: str) -> tuple[bool, bool]:
    """Return (short_s2g, side_outm) — the on-state booleans for A / B GPIOs."""
    name = str(name).strip()
    if name not in TEST_NAMES:
        raise ValueError(
            f"test_name '{name}' invalid. Must be one of: {', '.join(TEST_NAMES)}")
    side, short = name.split("_")
    return (short == "S2G"), (side == "OUTM")


def parse_short_en(v) -> bool:
    """Accept a native bool/number, or a string (True/enable/on/1 vs
    False/disable/off/0). TestStand may pass any of these."""
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    s = str(v).strip().lower()
    if s in ENABLE_TRUE:
        return True
    if s in ENABLE_FALSE:
        return False
    raise ValueError(
        f"short_en '{v}' invalid. Accepts (case-insensitive): "
        f"True/enable/on/1 or False/disable/off/0")


def _resolve_i2x(port):
    """Return the bench's I2X_AAA instance. Empty/NA port -> auto-discover."""
    from instruments.bench import Bench, CATALOG
    if port is not None and str(port).strip() and str(port).strip().upper() != "NA":
        entries = CATALOG.get("i2x", [])
        if not entries:
            raise RuntimeError("CATALOG['i2x'] is empty")
        return entries[0]["class"](str(port).strip())
    return Bench().i2x


# ---------------------------------------------------------------------------
# Python Adapter entry point
# ---------------------------------------------------------------------------
def relay_control(test_name: str, short_en, port: str = "") -> str:
    """Drive the 3 GPIO relays on the I2X-AAA board. Returns a one-line summary.

    Raises ValueError on bad input, RuntimeError on relay / discovery failure.
    """
    # gpio1=A (Short Type), gpio2=B (Side), gpio3=C (Short Enable)
    a_on, b_on = parse_test_name(test_name)   # raises ValueError
    c_on = parse_short_en(short_en)           # raises ValueError

    side  = "OUTM"   if b_on else "OUTP"
    short = "S2G"    if a_on else "S2P"
    enab  = "enable" if c_on else "disable"

    # -------- resolve the board (auto-discover or port override) --------
    try:
        board = _resolve_i2x(port)
    except Exception as exc:
        raise RuntimeError(
            f"auto-discover I2X board failed: {exc}. Pass port to override.") from exc

    # -------- send via the i2x abstraction's GPIO subsystem -------------
    try:
        board.gpio_send(
            gpio1=(a_on, DELAY_MS),
            gpio2=(b_on, DELAY_MS),
            gpio3=(c_on, DELAY_MS),
        )
    except Exception as exc:
        raise RuntimeError(
            f"relay command failed: {exc}\n{traceback.format_exc()}") from exc

    return (f"[OK] Relay set: Side={side}, Short Type={short}, "
            f"Enable={enab} (via {board.addr})")


# ---------------------------------------------------------------------------
# Standalone / debug CLI shim
# ---------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(
        description="Drive 3-GPIO relay via the I2X-AAA board.")
    parser.add_argument("--test-name", required=True, dest="test_name", metavar="NAME",
        help=f"One of: {', '.join(TEST_NAMES)}. First half = Side "
             "(OUTM=on/OUTP=off), second half = Short Type (S2G=on/S2P=off).")
    parser.add_argument("--short-en", required=True, dest="short_en", metavar="VALUE",
        help="Short Enable. True/enable/on/1 or False/disable/off/0 (case-insensitive).")
    parser.add_argument("--port", default="", metavar="COMx",
        help="Force COM port (default: auto-discover STLink VCP via Bench).")
    args = parser.parse_args()

    try:
        result = relay_control(args.test_name, args.short_en, port=args.port)
    except ValueError as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 2
    except Exception as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 1
    print(result, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
