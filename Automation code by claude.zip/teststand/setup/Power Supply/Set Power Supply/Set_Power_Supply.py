"""Set Power Supply — headless PSU setup step (TestStand Python Adapter).

Programs the bench's supply rails from four float inputs. Instruments are
auto-discovered via the Bench facade; every rail is driven only through the
PSU abstraction layer (set_voltage / set_current).

Rail -> instrument / channel mapping (auto, by what the bench has)
------------------------------------------------------------------
  PVDD voltage + current -> high-power supply (single channel)  — bench.psu_high_power
  VBAT voltage           -> 4-channel supply, CH2               — bench.psu_4ch (ch=2)
  DVDD voltage           -> 4-channel supply, CH4 on a GW Instek
                            GPP-4323 (CH1 on a generic 4-CH)     — bench.psu_4ch

Entry point
-----------
    set_power_supply(pvdd_voltage="", pvdd_current="",
                     vbat_voltage="", dvdd_voltage="") -> str

All four inputs are floats. Empty / whitespace / "NA" leaves that setting
untouched; if all are empty the function is a no-op (no hardware touched).
A non-empty voltage — even 0 — sets that rail's level and automatically turns
its output ON (PVDD current alone does not turn anything on).

Returns a one-line summary of what was applied. Raises ValueError on bad
input, RuntimeError on hardware / discovery failure.

TestStand Python Adapter
------------------------
    Module   : Set_Power_Supply.py
    Function : set_power_supply
    Arguments (map each to the matching FileGlobals; empty = untouched):
        pvdd_voltage = FileGlobals.PSU.PVDD_V
        pvdd_current = FileGlobals.PSU.PVDD_I
        vbat_voltage = FileGlobals.PSU.VBAT_V
        dvdd_voltage = FileGlobals.PSU.DVDD_V

Standalone / debug CLI:
    .venv\\Scripts\\python.exe "Set_Power_Supply.py" --pvdd-voltage 14.4 --pvdd-current 1 --vbat-voltage 12 --dvdd-voltage 3.3
"""
from __future__ import annotations

import argparse
import sys

from instruments.bench import Bench


# ---------------------------------------------------------------------------
# Rail -> channel mapping
# ---------------------------------------------------------------------------
def resolve_dvdd_channel(psu_4ch_driver) -> int:
    """DVDD is CH4 on a GW Instek GPP-4323, CH1 on a generic 4-CH supply."""
    if type(psu_4ch_driver).__name__ == "GwinstekGPP4323":
        return 4
    return 1


# ---------------------------------------------------------------------------
# Input parsing helpers
# ---------------------------------------------------------------------------
def _is_empty(v) -> bool:
    """True for None, '', whitespace, or 'NA' (case-insensitive). A native
    number is a concrete value, never empty."""
    if v is None:
        return True
    if isinstance(v, str):
        t = v.strip()
        return not t or t.upper() == "NA"
    return False


def _parse_opt_float(v, name: str):
    """Return float(v), or None if empty/NA. Raises ValueError if non-numeric."""
    if _is_empty(v):
        return None
    if isinstance(v, bool):
        raise ValueError(f"{name} '{v}' is not numeric")
    try:
        return float(v)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} '{v}' is not numeric") from exc


# ---------------------------------------------------------------------------
# Python Adapter entry point
# ---------------------------------------------------------------------------
def set_power_supply(pvdd_voltage: float | str = "", pvdd_current: float | str = "",
                     vbat_voltage: float | str = "", dvdd_voltage: float | str = "") -> str:
    """Program PVDD (V+I), VBAT (V), DVDD (V) on the current bench.

    Empty / whitespace / "NA" leaves that setting untouched. Returns a one-line
    summary. Raises ValueError on bad input, RuntimeError on hardware/discovery
    failure.
    """
    pv = _parse_opt_float(pvdd_voltage, "pvdd_voltage")
    pi = _parse_opt_float(pvdd_current, "pvdd_current")
    vv = _parse_opt_float(vbat_voltage, "vbat_voltage")
    dv = _parse_opt_float(dvdd_voltage, "dvdd_voltage")

    need_hp  = pv is not None or pi is not None
    need_4ch = vv is not None or dv is not None
    if not (need_hp or need_4ch):
        return "OK no-op (all inputs empty)"

    bench = Bench()
    applied: list[str] = []
    hp = ch4 = None
    try:
        # -------- PVDD -> high-power supply (V + I) --------------------
        if need_hp:
            try:
                hp = bench.psu_high_power
            except Exception as exc:
                raise RuntimeError(f"PVDD needs psu_high_power: {exc}") from exc
            hp.open()
            if pv is not None:
                hp.set_voltage(pv)
                applied.append(f"PVDD.V={pv}")
            if pi is not None:
                hp.set_current(pi)
                applied.append(f"PVDD.I={pi}")
            if pv is not None:              # voltage set (even 0) -> turn on
                hp.enable(True)
                applied.append("PVDD.On")

        # -------- VBAT (CH2) + DVDD (CH4) -> 4-channel supply ----------
        if need_4ch:
            try:
                ch4 = bench.psu_4ch
            except Exception as exc:
                raise RuntimeError(f"VBAT/DVDD need psu_4ch: {exc}") from exc
            ch4.open()
            if vv is not None:
                ch4.set_voltage(vv, channel=2)
                ch4.enable(True, channel=2)          # voltage set -> turn on
                applied.append(f"VBAT.V={vv}(ch2,On)")
            if dv is not None:
                dch = resolve_dvdd_channel(ch4)
                ch4.set_voltage(dv, channel=dch)
                ch4.enable(True, channel=dch)         # voltage set -> turn on
                applied.append(f"DVDD.V={dv}(ch{dch},On)")
    except Exception as exc:
        if isinstance(exc, (ValueError, RuntimeError)):
            raise
        raise RuntimeError(f"failed to set power supply: {exc}") from exc
    finally:
        for drv in (hp, ch4):
            if drv is not None:
                try:
                    drv.close()
                except Exception:
                    pass

    return f"[OK] {' '.join(applied)}"


# ---------------------------------------------------------------------------
# Standalone / debug CLI shim
# ---------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(
        description="Program PVDD (V+I), VBAT (V), DVDD (V) on the current bench.")
    parser.add_argument("--pvdd-voltage", default="", metavar="V", dest="pvdd_voltage",
        help="PVDD voltage (V). Empty/NA -> don't touch.")
    parser.add_argument("--pvdd-current", default="", metavar="A", dest="pvdd_current",
        help="PVDD current limit (A). Empty/NA -> don't touch.")
    parser.add_argument("--vbat-voltage", default="", metavar="V", dest="vbat_voltage",
        help="VBAT voltage (V), 4-CH CH2. Empty/NA -> don't touch.")
    parser.add_argument("--dvdd-voltage", default="", metavar="V", dest="dvdd_voltage",
        help="DVDD voltage (V), 4-CH CH4 (GPP-4323). Empty/NA -> don't touch.")
    args = parser.parse_args()

    try:
        result = set_power_supply(
            pvdd_voltage=args.pvdd_voltage, pvdd_current=args.pvdd_current,
            vbat_voltage=args.vbat_voltage, dvdd_voltage=args.dvdd_voltage)
    except ValueError as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 2
    except Exception as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 1
    print(result, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
