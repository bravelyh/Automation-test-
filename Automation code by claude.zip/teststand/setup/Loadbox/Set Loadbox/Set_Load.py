"""Loadbox setup step — set the 4-CH resistive loadbox (TestStand Python Adapter).

Sets the bench's 4-channel resistive loadbox. All device I/O goes through the
abstraction layer: this step resolves the loadbox via the Bench facade
(`Bench().loadbox`, or a port override) and drives it with the single
`loadbox.set_load_per_channel(codes, labels)` call declared in LoadboxBase.

The load -> per-channel-code resolution (mode 0 / mode 1, series distribution)
is pure setup-layer logic; it reuses the driver module's stateless helpers
(LOAD_MAP, resolve_mode0/1) which perform no I/O.

Entry point
-----------
    set_load(load, load_range="", port="") -> str

load        (number, or the string 'off'/'open')
    * ""/"NA"              (any case)  -> no-op: the loadbox is left untouched.
    * "off" / "open"       (any case)  -> all 4 CH open. load_range ignored.
    * Mode-0 uniform       one of {0, 0.5, 1, 2, 3, 4, 5, 6, 8}
                           -> all 4 CH set to the same value. (load_range=0)
    * Mode-0 per-channel   a 4-digit value, each digit in {1,2,3,4,5,6,8},
                           e.g. 2234 -> CH1=2, CH2=2, CH3=3, CH4=4. (load_range=0)
    * Mode-1 series        ohm 0..32, multiple of 0.5 (e.g. 10) -> 4 CH
                           auto-distributed to sum to this value. (load_range=1)
    A whole number is normalised to its integer form (3.0 -> "3"), so it
    matches the load table; a fraction is kept (0.5 -> "0.5").

load_range  (number 0 or 1)
    0 = parallel/independent (uniform or per-channel).
    1 = series (auto-distribute).
    Required unless load is "off" / "open" (then ignored).

port        (string, optional)
    Force COM port. Empty / "NA" -> auto-discover via Bench().loadbox
    (Prolific USB-Serial).

Returns one summary line per channel plus a responded-count line. Raises
ValueError on bad input, RuntimeError on serial / discovery failure.

TestStand Python Adapter
------------------------
    Module   : Set_Load.py
    Function : set_load
    Arguments:
        load       = FileGlobals.ForcingConditions.Load
        load_range = FileGlobals.ForcingConditions.LoadRange
        port       = FileGlobals.Instruments.Loadbox_Port   (optional override)

Standalone / debug CLI:
    .venv\\Scripts\\python.exe "Set_Load.py" --load 3 --load-range 0
    .venv\\Scripts\\python.exe "Set_Load.py" --load off
"""
from __future__ import annotations

import argparse
import sys
import traceback

from instruments.loadbox.loadbox_SH import (
    LOAD_MAP,
    format_load,
    resolve_mode0,
    resolve_mode1,
)


# ---------------------------------------------------------------------------
# Input parsing helpers
# ---------------------------------------------------------------------------
def _is_empty(v) -> bool:
    """True for None, '', whitespace, or 'NA' (case-insensitive). A number is
    a concrete value, never empty. TestStand may pass native numbers/strings."""
    if v is None:
        return True
    if isinstance(v, str):
        t = v.strip()
        return not t or t.upper() == "NA"
    return False


def _norm_num(v) -> str:
    """Normalise a numeric-or-string input to a canonical string:
    a whole number -> integer form (3.0 -> '3'), a fraction -> '0.5',
    a string -> stripped as-is (so 'off'/'open' pass through)."""
    if v is None:
        return ""
    if isinstance(v, bool):        # guard: a bool is not a load value
        return str(v)
    if isinstance(v, str):
        return v.strip()
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return f"{v:g}" if isinstance(v, float) else str(v)


# ---------------------------------------------------------------------------
# Loadbox resolution (abstraction layer only)
# ---------------------------------------------------------------------------
def _resolve_loadbox(port):
    """Return the bench's loadbox driver instance (a LoadboxBase).

    A non-empty `port` instantiates the CATALOG's loadbox class at that address
    (skips discovery); otherwise Bench() auto-discovers it.
    """
    from instruments.bench import Bench, CATALOG
    if not _is_empty(port):
        entries = CATALOG.get("loadbox", [])
        if not entries:
            raise RuntimeError("CATALOG['loadbox'] is empty")
        return entries[0]["class"](str(port).strip())
    return Bench().loadbox


# ---------------------------------------------------------------------------
# Python Adapter entry point
# ---------------------------------------------------------------------------
def set_load(load: float | str, load_range: float | str = "", port: str = "") -> str:
    """Set the loadbox load on all 4 channels via the abstraction layer.

    Empty / "NA" load leaves the loadbox untouched (no-op). Returns one line
    per channel plus a responded-count line. Raises ValueError on bad input,
    RuntimeError on serial / discovery failure.
    """
    load_s = _norm_num(load)

    # -------- empty / NA -> no-op (leave the loadbox untouched) ----------
    if _is_empty(load_s):
        return "OK no-op (load empty)"

    # -------- resolve load + load_range into 4 per-channel labels --------
    # 'off'/'open' (any case) -> every CH open, regardless of load_range.
    if load_s.lower() in ("off", "open"):
        labels = ["off"] * 4
    else:
        lr = _norm_num(load_range)
        if lr not in ("0", "1"):
            raise ValueError(
                f"load_range must be 0 or 1 (got {load_range!r}); "
                "optional only when load is 'off' / 'open'.")
        # resolve_mode0/1 raise ValueError on bad load values
        labels = resolve_mode0(load_s) if lr == "0" else resolve_mode1(load_s)

    codes = [LOAD_MAP[k] for k in labels]

    # -------- resolve the loadbox (auto-discover or port override) -------
    try:
        loadbox = _resolve_loadbox(port)
    except Exception as exc:
        raise RuntimeError(
            f"could not resolve the loadbox: {exc}. Pass port to override.") from exc

    # -------- apply via the abstraction, then close ----------------------
    try:
        results = loadbox.set_load_per_channel(codes, labels)
    except Exception as exc:
        raise RuntimeError(
            f"failed to set load: {exc}\n{traceback.format_exc()}") from exc
    finally:
        try:
            loadbox.close()
        except Exception:
            pass

    lines = [
        f'CH{r["ch"]}: load={format_load(r["load"])}, '
        f'write="{r["write"]}", read="{r["read"]}"'
        for r in results
    ]
    responded = sum(1 for r in results if r["read"])
    lines.append(f"[OK] Done. {responded}/4 channels responded.")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Standalone / debug CLI shim
# ---------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(
        description="Set loadbox load on 4 channels via the abstraction layer.")
    parser.add_argument("--load", required=True, metavar="VALUE",
        help="Mode 0: single value (0/0.5/1/2/3/4/5/6/8) or 4-digit "
             "per-channel value. Mode 1: 0..32 ohm, multiple of 0.5. "
             "Special: 'off'/'open' (any case) -> all 4 CH off.")
    parser.add_argument("--load-range", default="", metavar="{0,1}",
        dest="load_range",
        help="0 = parallel/independent. 1 = series. Not required for 'off'/'open'.")
    parser.add_argument("--port", default="", metavar="COMx",
        help="Force COM port (default: auto-detect Prolific USB-Serial).")
    args = parser.parse_args()

    try:
        result = set_load(args.load, load_range=args.load_range, port=args.port)
    except ValueError as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 2
    except Exception as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 1
    print(result, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
