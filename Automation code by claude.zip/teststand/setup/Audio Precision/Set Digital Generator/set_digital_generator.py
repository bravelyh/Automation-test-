r"""Set Digital Generator — Audio Precision generator setup (TestStand Python Adapter).

This setup step wraps the AP abstraction layer. It instantiates this bench's
Audio Precision analyzer through the Bench facade — `Bench().ap("bench")`,
which resolves the bench's `ap_type` to the APx555 or AP2722 driver — opens it,
and applies the settings with a single `ap_base.set_digital_generator(...)` call.

Only that one abstraction-layer call talks to the instrument; this module does
no raw APx API access. The wrapping (interpreting `fin`, gating on `new_fin`)
lives entirely here, in the setup layer.

Entry point
-----------
    set_digital_generator(fin: str = "", level: str = "",
                          music_path: str = "", turn_on: bool | None = None,
                          new_fin: bool = True) -> str

How each input maps onto `ap_base.set_digital_generator`:

    fin        numeric (e.g. "1000")  -> waveform="Sine", frequency=<fin>
               non-numeric (e.g.       -> waveform="music" (play a file); the
               "PinkNoise")               file is `music_path`
    level      number (e.g. "-20")    -> level (dBFS), forwarded as-is
    music_path path                   -> music_path, but ONLY in music mode
                                         (a Sine tone never receives it)
    turn_on    true|false             -> turn_on (output on/off now)
    new_fin    false                  -> amplitude-only fast path: keep the
                                         currently-loaded tone/file untouched —
                                         waveform, frequency and music loading
                                         are all skipped, only level (and
                                         turn_on, if given) are forwarded.
               true (default)         -> apply the fin-derived waveform too.

Empty ("", whitespace, or "NA" case-insensitive) means "don't touch". If
nothing remains to apply, the function returns a no-op message without
connecting to APx.

Returns a one-line summary of what was forwarded. Raises ValueError on bad
input, RuntimeError on connection / apply failure.

TestStand Python Adapter
------------------------
    Module   : set_digital_generator.py
    Function : set_digital_generator
    Arguments (map each to the matching FileGlobals string; empty = untouched):
        fin        = FileGlobals.APGen.Fin
        level      = FileGlobals.APGen.Level
        music_path = FileGlobals.APGen.MusicPath
        turn_on    = FileGlobals.APGen.TurnOn
        new_fin    = FileGlobals.APGen.NewFin
    (APx has no address override — the driver connects via its own DLL, and
    Bench() picks the driver from this bench's ap_type.)

Standalone / debug CLI:
    .venv\Scripts\python.exe "set_digital_generator.py" --fin 1000 --level -20 --turn-on true
"""
from __future__ import annotations

import argparse
import sys

from instruments.bench import Bench


# ---------------------------------------------------------------------------
# Input parsing helpers
# ---------------------------------------------------------------------------
# TestStand's Python Adapter passes each argument as a native Python value —
# a str, a number, or a bool — depending on how the step parameter is typed
# (e.g. turn_on/new_fin often arrive as real bools, level as a real number).
# These helpers accept any of those; they never assume the value is a str.
def _is_empty(v) -> bool:
    if v is None:
        return True
    if isinstance(v, str):
        t = v.strip()
        return not t or t.upper() == "NA"
    return False  # a number or bool is a concrete value, never "empty"


def _try_float(v):
    """Return float(v), or None if v is not numeric (used to classify `fin`)."""
    if isinstance(v, bool):
        return None  # a bool is not a frequency
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _parse_float(v, name: str) -> float:
    if isinstance(v, bool):
        raise ValueError(f"{name} '{v}' is not numeric")
    try:
        return float(v)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} '{v}' is not numeric") from exc


def _parse_bool(v, name: str) -> bool:
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    s = str(v).strip().lower()
    if s in ("true", "1", "yes", "on"):
        return True
    if s in ("false", "0", "no", "off"):
        return False
    raise ValueError(f"{name} '{v}' must be true|false")


# ---------------------------------------------------------------------------
# Python Adapter entry point
# ---------------------------------------------------------------------------
def set_digital_generator(fin: str = "", level: str = "",
                          music_path: str = "", turn_on: bool | None = None,
                          new_fin: bool = True) -> str:
    """Interpret the setup-layer inputs and apply them via the AP abstraction.

    Empty / whitespace / "NA" leaves that setting untouched. Returns a one-line
    summary. Raises ValueError on bad input, RuntimeError on connection / apply
    failure.
    """
    new_fin_bool = _parse_bool(new_fin, "new_fin") if not _is_empty(new_fin) else True

    # -------- build the abstraction-layer kwargs -----------------------
    kwargs: dict[str, object] = {}
    summary: list[str] = []

    # level (amplitude) and turn_on (output on/off) are independent of new_fin.
    if not _is_empty(level):
        kwargs["level"] = _parse_float(level, "level")
        summary.append(f"level={kwargs['level']}dBFS")
    if not _is_empty(turn_on):
        kwargs["turn_on"] = _parse_bool(turn_on, "turn_on")
        summary.append(f"turn_on={kwargs['turn_on']}")

    # fin-derived waveform/frequency/music: applied only when new_fin is true.
    # new_fin=false is the amplitude-only fast path — reuse the current tone or
    # loaded file, so none of these are sent.
    if new_fin_bool and not _is_empty(fin):
        freq = _try_float(fin)
        if freq is not None:
            # numeric fin -> sine tone at that frequency (music_path not sent).
            kwargs["waveform"] = "Sine"
            kwargs["frequency"] = freq
            summary.append(f"waveform=Sine frequency={freq}Hz")
        else:
            # non-numeric fin -> music mode; music_path is the file to play.
            kwargs["waveform"] = "music"
            summary.append("waveform=music")
            if not _is_empty(music_path):
                kwargs["music_path"] = str(music_path).strip()
                summary.append(f"music_path={kwargs['music_path']}")

    if not kwargs:
        return "OK no-op (nothing to apply)"

    # -------- resolve this bench's AP, open, apply, close --------------
    try:
        ap = Bench().ap("bench")
    except Exception as exc:
        raise RuntimeError(f"failed to resolve the AP for this bench: {exc}") from exc

    try:
        ap.open()
    except Exception as exc:
        raise RuntimeError(f"failed to connect to APx500: {exc}") from exc

    try:
        ap.set_digital_generator(**kwargs)
    except Exception as exc:
        raise RuntimeError(f"set_digital_generator failed: {exc}") from exc
    finally:
        try:
            ap.close()
        except Exception:
            pass

    return f"OK {' '.join(summary)}"


# ---------------------------------------------------------------------------
# Standalone / debug CLI shim
# ---------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(
        description="Audio Precision digital generator setup. Every input is "
                    "optional; the non-empty ones are interpreted and applied "
                    "through the AP abstraction layer's set_digital_generator.")
    parser.add_argument("--fin", default="", metavar="FREQ_OR_NAME",
        help="Numeric -> sine frequency in Hz. Non-numeric -> music mode "
             "(play --music-path). Empty/NA -> untouched.")
    parser.add_argument("--level", default="", metavar="dBFS",
        help="Generator level in dBFS. Empty/NA -> untouched.")
    parser.add_argument("--music-path", default="", metavar="PATH", dest="music_path",
        help="Waveform file to play; only used in music mode. Empty/NA -> untouched.")
    parser.add_argument("--turn-on", default="", metavar="BOOL", dest="turn_on",
        help="Turn the output on/off now. Empty/NA -> untouched.")
    parser.add_argument("--new-fin", default="true", metavar="BOOL", dest="new_fin",
        help="true (default) -> apply the fin-derived waveform/frequency/music. "
             "false -> amplitude-only fast path: keep the current tone/file, "
             "forward only level (and turn_on, if given).")
    args = parser.parse_args()

    try:
        result = set_digital_generator(
            fin=args.fin, level=args.level, music_path=args.music_path,
            turn_on=args.turn_on, new_fin=args.new_fin)
    except ValueError as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 2
    except Exception as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 1
    print(result, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
