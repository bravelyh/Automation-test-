"""Set Temp — thermal chamber setup step with live GUI (TestStand Python Adapter).

Auto-driver. Reuses the same Tk + matplotlib GUI as the manual Thermal
Stream Control tool: settings applied on launch, live plot of Air/DUT vs
setpoint, in-range countdown, then closes when the chamber signals TECR
bit 0 (at-temp + soak complete).

Entry point
-----------
    set_temp(temp, accuracy, soak, mode="", sensor="", keep_flow=True, port="") -> str

temp/accuracy/soak are numeric (required). mode is "air" or "dut", sensor is
"t" or "k" (both case-insensitive strings); empty/"NA" leaves the chamber's
current setting unchanged. keep_flow is the FINAL flow state: flow is always ON
during control, then True (default) keeps it on / False turns it off once soak
completes. All instrument control goes through the ATS710 abstraction methods.

Blocks (runs the live GUI) until the chamber reaches temperature + soak,
then returns a summary string. Raises ValueError on bad input, RuntimeError if
the window is closed early / the connection is lost / apply or mode-sensor
fails, or on auto-discover failure.

Address discovery:
    * `port` non-empty  -> use it directly.
    * `port` empty / omitted -> auto-discover via `Bench().thermal.addr`.

TestStand Python Adapter
------------------------
    Module   : Set_Temp.py
    Function : set_temp
    Arguments:
        temp      = FileGlobals.ForcingConditions.Temperature
        accuracy  = FileGlobals.ForcingConditions.TempAccuracy
        soak      = FileGlobals.ForcingConditions.SoakSec
        mode      = FileGlobals.ForcingConditions.ThermalMode    (optional)
        sensor    = FileGlobals.ForcingConditions.ThermalSensor  (optional)
        keep_flow = FileGlobals.ForcingConditions.KeepFlow       (optional; default on)
        port      = FileGlobals.Instruments.Thermal_Port         (optional override)

Standalone / debug CLI:
    py -3.14 "Set_Temp.py" --temp 25 --accuracy 1 --soak 30 --mode DUT --sensor K
"""
from __future__ import annotations

import argparse
import sys
import time
import tkinter as tk
from datetime import datetime
from tkinter import messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure                                    # noqa: E402
from matplotlib.lines import Line2D                                     # noqa: E402
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg         # noqa: E402

from instruments.thermal.ats_710 import ATS710 as Thermal_Stream


DEFAULTS = {
    "gpib":      "GPIB0::9::INSTR",
    "setpoint":  25.0,
    "soak":      30,
    "accuracy":  1.0,
    "ramp":      0,
    "flow_rate": 10,
    "mode":      "DUT",
    "sensor":    "K",
}

MODE_MAP   = {"Air": 0, "DUT": 1, "Air+DUT": 2}
SENSOR_MAP = {"NON": 0, "T": 1, "K": 2}


# mode / sensor are plain string inputs (TestStand-friendly), case-insensitive.
# Allowed input (lowercased) -> MODE_MAP / SENSOR_MAP key.
_MODE_ALLOWED   = {"air": "Air", "dut": "DUT"}
_SENSOR_ALLOWED = {"t": "T", "k": "K"}


def _is_empty(v) -> bool:
    """True for None, '', whitespace, or 'NA' (case-insensitive)."""
    if v is None:
        return True
    if isinstance(v, str):
        t = v.strip()
        return not t or t.upper() == "NA"
    return False


def _parse_mode(v):
    """Return the MODE_MAP key ('Air' or 'DUT'), or None if empty/NA."""
    if _is_empty(v):
        return None
    s = str(v).strip().lower()
    if s in _MODE_ALLOWED:
        return _MODE_ALLOWED[s]
    raise ValueError(f"mode '{v}' invalid. Must be 'air' or 'dut' (case-insensitive).")


def _parse_sensor(v):
    """Return the SENSOR_MAP key ('T' or 'K'), or None if empty/NA."""
    if _is_empty(v):
        return None
    s = str(v).strip().lower()
    if s in _SENSOR_ALLOWED:
        return _SENSOR_ALLOWED[s]
    raise ValueError(f"sensor '{v}' invalid. Must be 't' or 'k' (case-insensitive).")


def _parse_keep_flow(v) -> bool:
    """Final flow state after the step. Empty/NA -> True (keep flow on).

    TestStand may pass a native bool/number or a string.
    """
    if _is_empty(v):
        return True
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    s = str(v).strip().lower()
    if s in ("true", "1", "yes", "on", "keep"):
        return True
    if s in ("false", "0", "no", "off"):
        return False
    raise ValueError(f"keep_flow '{v}' must be true/false")

POLL_MS      = 1000       # monitor tick interval
MAX_POINTS   = 7200       # 2 h at 1 Hz
VISA_TIMEOUT_MS = 5000    # per-query timeout
COOL_REQUIRED_BELOW = 15  # °C - warn if setpoint below this and compressor off

BANNER_BG   = "#1e3a5f"
BANNER_FG   = "white"
BANNER_FG_2 = "#c8e0ff"


# ═══════════════════════════════════════════════════════════════════════
#  ThermalStreamControl — copied verbatim from
#  tools/Thermal Stream Control/Thermal_Stream_Control.py
#  (kept in sync manually — this is the same class the manual GUI uses).
# ═══════════════════════════════════════════════════════════════════════
class ThermalStreamControl:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Thermal Stream Control - TS700 V3.1")
        self.ts: "Thermal_Stream | None" = None
        self.monitoring = False
        self._monitor_after_id = None
        self.t_data:   list[float] = []
        self.air_data: list[float] = []
        self.dut_data: list[float] = []
        self.start_time: float | None = None
        self._cached_setp = None
        self._cached_acc  = None
        self._cached_soak = None
        self._holding_start_time: float | None = None
        self._dead_queries: set[str] = set()

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(200, self._check_device)

    # =================================================================== UI
    def _build_ui(self):
        top = ttk.Frame(self.root, padding=(10, 8))
        top.grid(row=0, column=0, sticky="ew")
        self.top_frame = top
        ttk.Label(top, text="GPIB Address:").grid(row=0, column=0, padx=(0, 4))
        self.gpib_var = tk.StringVar(value=DEFAULTS["gpib"])
        ttk.Entry(top, textvariable=self.gpib_var, width=24).grid(
            row=0, column=1, padx=(0, 4))
        ttk.Button(top, text="Check Device",
                   command=self._check_device, width=12).grid(
            row=0, column=2, padx=4)
        self.idn_var = tk.StringVar(value="(checking...)")
        ttk.Label(top, textvariable=self.idn_var, foreground="#666",
                  font=("Segoe UI", 9, "italic")).grid(
            row=0, column=3, padx=(8, 0), sticky="w")

        mid = ttk.Frame(self.root, padding=(10, 0))
        mid.grid(row=1, column=0, sticky="nsew")
        self.mid_frame = mid
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)
        mid.grid_columnconfigure(1, weight=1)
        mid.grid_rowconfigure(0, weight=1)

        self._build_settings(mid)
        self._build_monitor(mid)
        self._build_manual_controls()
        self._build_log()

    def _build_settings(self, parent):
        f = ttk.LabelFrame(parent, text="Settings", padding=10)
        f.grid(row=0, column=0, sticky="nsw", padx=(0, 8))
        self.settings_frame = f
        row = 0

        def add_entry(label, key, unit="", width=10):
            nonlocal row
            ttk.Label(f, text=label).grid(row=row, column=0, sticky="w", pady=3)
            var = tk.StringVar(value=str(DEFAULTS[key]))
            ttk.Entry(f, textvariable=var, width=width).grid(
                row=row, column=1, padx=4, pady=3, sticky="w")
            if unit:
                ttk.Label(f, text=unit, foreground="#666").grid(
                    row=row, column=2, sticky="w")
            row += 1
            return var

        self.setpoint_var  = add_entry("Setpoint:",           "setpoint",  "°C")
        self.soak_var      = add_entry("Soak time:",          "soak",      "s")
        self.accuracy_var  = add_entry("Accuracy (window):",  "accuracy",  "°C")
        self.ramp_var      = add_entry("Ramp:",               "ramp",      "°C/min (0=fastest)")
        self.flow_rate_var = add_entry("Flow rate:",          "flow_rate", "SCFM (4-18)")

        self.mode_var   = tk.StringVar(value=DEFAULTS["mode"])
        self.sensor_var = tk.StringVar(value=DEFAULTS["sensor"])
        self.cool_var   = tk.StringVar(value="?")

        ttk.Separator(f, orient="horizontal").grid(
            row=row, column=0, columnspan=3, sticky="ew", pady=10)
        row += 1

        s = ttk.Style()
        s.configure("Big.TButton",  font=("Segoe UI", 11, "bold"))
        s.configure("Stop.TButton", font=("Segoe UI", 10, "bold"),
                    foreground="#c62828")

        self.set_btn = ttk.Button(
            f, text="Set", command=self._set_all_and_run,
            width=26, style="Big.TButton")
        self.set_btn.grid(row=row, column=0, columnspan=3, pady=4, sticky="ew")
        row += 1

        self.stop_btn = ttk.Button(
            f, text="Abort", command=self._abort,
            width=26, style="Stop.TButton", state="disabled")
        self.stop_btn.grid(row=row, column=0, columnspan=3, pady=4, sticky="ew")

    def _build_monitor(self, parent):
        f = ttk.LabelFrame(parent, text="Monitor", padding=8)
        f.grid(row=0, column=1, sticky="nsew")
        self.monitor_frame = f
        f.grid_rowconfigure(0, weight=1)
        f.grid_columnconfigure(0, weight=1)

        self.fig = Figure(figsize=(7.5, 4.4), dpi=90)
        self.ax = self.fig.add_subplot(111)
        self._init_plot()
        self.canvas = FigureCanvasTkAgg(self.fig, master=f)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew",
                                         pady=(0, 6))

        status = ttk.Frame(f)
        status.grid(row=1, column=0, sticky="ew", pady=4)

        col1 = ttk.Frame(status)
        col2 = ttk.Frame(status)
        col3 = ttk.Frame(status)
        col1.pack(side="left", padx=(4, 20), anchor="n")
        col2.pack(side="left", padx=(0, 20), anchor="n")
        col3.pack(side="left",              anchor="n")

        self.air_val     = tk.StringVar(value="--")
        self.dut_val     = tk.StringVar(value="--")
        self.set_val     = tk.StringVar(value="--")
        self.tecr_val    = tk.StringVar(value="--")
        self.range_val   = tk.StringVar(value="--")
        self.elapsed_val = tk.StringVar(value="00:00:00")
        self.timeout_val = tk.StringVar(value="--")
        self.err_val     = tk.StringVar(value="--")
        self.state_val   = tk.StringVar(value="idle")

        def add_row(parent, row, label, var, color="#222",
                    lbl_w=10, val_w=14):
            lbl = tk.Label(parent, text=label, foreground="#666",
                           width=lbl_w, anchor="w",
                           font=("Consolas", 10))
            lbl.grid(row=row, column=0, sticky="w", padx=(0, 6), pady=1)
            val = tk.Label(parent, textvariable=var, foreground=color,
                           anchor="w", width=val_w,
                           font=("Consolas", 10, "bold"))
            val.grid(row=row, column=1, sticky="w", pady=1)
            return val

        LW1, LW2, LW3 = 7, 10, 9

        add_row(col1, 0, "Air:",      self.air_val,     "#1e63c9", lbl_w=LW1)
        add_row(col1, 1, "TECR:",     self.tecr_val,               lbl_w=LW1)
        add_row(col1, 2, "Error:",    self.err_val,                lbl_w=LW1)

        add_row(col2, 0, "DUT:",      self.dut_val,     "#c62828", lbl_w=LW2)
        self.range_lbl = add_row(col2, 1, "In-Range:", self.range_val,
                                  lbl_w=LW2)
        add_row(col2, 2, "State:",    self.state_val,   "#1e3a5f", lbl_w=LW2)

        add_row(col3, 0, "Set:",      self.set_val,     "#444",    lbl_w=LW3)
        add_row(col3, 1, "Elapsed:",  self.elapsed_val,            lbl_w=LW3)
        add_row(col3, 2, "Timeout:",  self.timeout_val, "#1e3a5f", lbl_w=LW3)

    def _init_plot(self):
        self.ax.clear()
        self.ax.set_xlabel("Elapsed (s)")
        self.ax.set_ylabel("Temperature (°C)")
        self.ax.grid(True, alpha=0.3)
        (self.air_line,) = self.ax.plot(
            [], [], color="#1e63c9", label="Air", linewidth=1.6)
        (self.dut_line,) = self.ax.plot(
            [], [], color="#c62828", label="DUT", linewidth=1.6)
        self.set_line = self.ax.axhline(
            y=0, color="#444", linestyle="--", linewidth=1.2)
        self.set_line.set_visible(False)
        setpoint_proxy = Line2D([0], [0], color="#444", linestyle="--",
                                linewidth=1.2, label="Setpoint")
        self.band = None
        self.ax.legend(handles=[self.air_line, self.dut_line, setpoint_proxy],
                       loc="upper right", fontsize=9)
        self.fig.tight_layout()

    def _build_manual_controls(self):
        f = ttk.LabelFrame(self.root, text="Manual Controls", padding=8)
        f.grid(row=2, column=0, sticky="ew", padx=10, pady=(4, 0))
        self.manual_frame = f

        ttk.Label(f, text="Mode:", font=("Segoe UI", 9, "bold")).grid(
            row=0, column=0, sticky="e", padx=(0, 6))
        mf = ttk.Frame(f)
        mf.grid(row=0, column=1, sticky="w", padx=(0, 20))
        self.mode_btns: dict[str, tk.Button] = {}
        for i, m in enumerate(("Air", "DUT", "Air+DUT")):
            b = tk.Button(mf, text=m, width=9,
                          command=lambda x=m: self._set_mode(x))
            b.grid(row=0, column=i, padx=2)
            self.mode_btns[m] = b

        ttk.Label(f, text="Sensor:", font=("Segoe UI", 9, "bold")).grid(
            row=0, column=2, sticky="e", padx=(0, 6))
        sf = ttk.Frame(f)
        sf.grid(row=0, column=3, sticky="w", padx=(0, 20))
        self.sensor_btns: dict[str, tk.Button] = {}
        for i, s in enumerate(("NON", "T", "K")):
            b = tk.Button(sf, text=s, width=6,
                          command=lambda x=s: self._set_sensor(x))
            b.grid(row=0, column=i, padx=2)
            self.sensor_btns[s] = b

        self.flow_btn = tk.Button(f, text="Flow: ?", width=14,
                                  command=self._toggle_flow)
        self.flow_btn.grid(row=0, column=4, padx=6)
        self.cool_btn = tk.Button(f, text="Compressor: ?", width=16,
                                  command=self._toggle_cool)
        self.cool_btn.grid(row=0, column=5, padx=6)
        self.head_btn = tk.Button(f, text="Head: ?", width=12,
                                  command=self._toggle_head)
        self.head_btn.grid(row=0, column=6, padx=6)

        self._paint_mode_buttons(None)
        self._paint_sensor_buttons(None)
        self._paint_toggle(self.flow_btn, "Flow", None)
        self._paint_toggle(self.cool_btn, "Compressor", None)
        self._paint_toggle(self.head_btn, "Head", None)

    def _paint_mode_buttons(self, active_name):
        for name, btn in self.mode_btns.items():
            if name == active_name:
                btn.configure(relief="sunken", bg="#1e63c9",
                              fg="white", font=("Segoe UI", 9, "bold"))
            else:
                btn.configure(relief="raised", bg="SystemButtonFace",
                              fg="black", font=("Segoe UI", 9))

    def _paint_sensor_buttons(self, active_name):
        for name, btn in self.sensor_btns.items():
            if name == active_name:
                btn.configure(relief="sunken", bg="#1e63c9",
                              fg="white", font=("Segoe UI", 9, "bold"))
            else:
                btn.configure(relief="raised", bg="SystemButtonFace",
                              fg="black", font=("Segoe UI", 9))

    def _paint_toggle(self, btn: tk.Button, label: str, state):
        if state is None:
            btn.configure(text=f"{label}: ?", bg="SystemButtonFace",
                          fg="black", relief="raised")
            return
        if label == "Head":
            on_word, off_word = "DOWN", "UP"
        else:
            on_word, off_word = "ON", "OFF"
        if state:
            btn.configure(text=f"{label}: {on_word}",
                          bg="#4caf50", fg="white", relief="sunken",
                          font=("Segoe UI", 9, "bold"))
        else:
            btn.configure(text=f"{label}: {off_word}",
                          bg="SystemButtonFace", fg="black",
                          relief="raised", font=("Segoe UI", 9))

    def _refresh_manual_states(self):
        if self.ts is None:
            return
        try:
            mode   = int(self.ts.get_dut_mode())
            sensor = int(self.ts.get_dut_sensor())
            flow   = int(self.ts.get_flow())
            cool   = int(self.ts.get_cool())
            head   = int(self.ts.get_head())
            mode_name   = next((k for k, v in MODE_MAP.items()   if v == mode),   None)
            sensor_name = next((k for k, v in SENSOR_MAP.items() if v == sensor), None)
            if mode_name:
                self.mode_var.set(mode_name)
                self._paint_mode_buttons(mode_name)
            if sensor_name:
                self.sensor_var.set(sensor_name)
                self._paint_sensor_buttons(sensor_name)
            self._paint_toggle(self.flow_btn, "Flow",       bool(flow))
            self._paint_toggle(self.cool_btn, "Compressor", bool(cool))
            self._paint_toggle(self.head_btn, "Head",       bool(head))
            self.cool_var.set("ON" if cool else "OFF")
        except Exception as exc:
            self.log(f"[WARN] state refresh failed: {exc}")

    def _ensure_flow_off(self):
        try:
            if bool(int(self.ts.get_flow())):
                self.ts.flow_off()
                self.log("[OK] Flow OFF (auto, required for Mode/Sensor)")
            self._paint_toggle(
                self.flow_btn, "Flow", bool(int(self.ts.get_flow())))
        except Exception as exc:
            self.log(f"[WARN] flow-off precheck failed: {exc}")

    def _set_mode(self, name: str):
        if not self._ensure_connected():
            return
        if name in ("DUT", "Air+DUT") and self.sensor_var.get() == "NON":
            messagebox.showerror(
                "Sensor Required",
                f"Mode '{name}' needs a DUT thermocouple.\n"
                "Set Sensor to T or K first, then switch Mode.")
            return
        try:
            self._ensure_flow_off()
            self.ts.set_dut_mode(MODE_MAP[name])
            self.mode_var.set(name)
            self._paint_mode_buttons(name)
            self.log(f"[OK] Mode -> {name}")
        except Exception as exc:
            messagebox.showerror("Set Mode", str(exc))
            self.log(f"[ERR] Set mode failed: {exc}")

    def _set_sensor(self, name: str):
        if not self._ensure_connected():
            return
        if name == "NON" and self.mode_var.get() in ("DUT", "Air+DUT"):
            messagebox.showerror(
                "Sensor Required",
                f"Mode '{self.mode_var.get()}' needs a DUT thermocouple.\n"
                "Switch Mode to Air first, then set Sensor to NON.")
            return
        try:
            self._ensure_flow_off()
            self.ts.set_dut_sensor(SENSOR_MAP[name])
            self.sensor_var.set(name)
            self._paint_sensor_buttons(name)
            self.log(f"[OK] Sensor -> {name}")
        except Exception as exc:
            messagebox.showerror("Set Sensor", str(exc))
            self.log(f"[ERR] Set sensor failed: {exc}")

    def _toggle_flow(self):
        if not self._ensure_connected():
            return
        try:
            was_on = bool(int(self.ts.get_flow()))
            if was_on:
                if self.monitoring:
                    self._stop_monitor("flow turned off by user")
                self.ts.flow_off()
                self.log("[OK] Flow OFF")
                self._paint_toggle(self.flow_btn, "Flow", False)
            else:
                self.ts.flow_on()
                self.log("[OK] Flow ON")
                self._paint_toggle(self.flow_btn, "Flow", True)
        except Exception as exc:
            messagebox.showerror("Toggle Flow", str(exc))
            self.log(f"[ERR] Toggle flow failed: {exc}")

    def _toggle_cool(self):
        if not self._ensure_connected():
            return
        try:
            was_on = bool(int(self.ts.get_cool()))
            if was_on:
                self.ts.cool_off()
                self.log("[OK] Compressor OFF")
                self._paint_toggle(self.cool_btn, "Compressor", False)
                self.cool_var.set("OFF")
            else:
                self.ts.cool_on()
                self.log("[OK] Compressor ON")
                self._paint_toggle(self.cool_btn, "Compressor", True)
                self.cool_var.set("ON")
        except Exception as exc:
            messagebox.showerror("Toggle Compressor", str(exc))
            self.log(f"[ERR] Toggle compressor failed: {exc}")

    def _toggle_head(self):
        if not self._ensure_connected():
            return
        try:
            was_down = bool(int(self.ts.get_head()))
            if was_down:
                self.ts.head_up()
                self.log("[OK] Head UP")
                self._paint_toggle(self.head_btn, "Head", False)
            else:
                self.ts.head_down()
                self.log("[OK] Head DOWN")
                self._paint_toggle(self.head_btn, "Head", True)
        except Exception as exc:
            messagebox.showerror("Toggle Head", str(exc))
            self.log(f"[ERR] Toggle head failed: {exc}")

    def _ensure_connected(self) -> bool:
        if self.ts is None:
            if not self._connect():
                return False
            self._refresh_manual_states()
        return True

    def _build_log(self):
        f = ttk.LabelFrame(self.root, text="Log", padding=(6, 4))
        f.grid(row=3, column=0, sticky="nsew", padx=10, pady=(4, 8))
        self.log_frame = f
        f.grid_rowconfigure(0, weight=1)
        f.grid_columnconfigure(0, weight=1)
        self.log_text = tk.Text(f, height=7, wrap="word",
                                font=("Consolas", 9), state="disabled")
        self.log_text.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(f, orient="vertical",
                           command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb.set)
        sb.grid(row=0, column=1, sticky="ns")

    def log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_text.configure(state="normal")
        self.log_text.insert("end", f"[{ts}] {msg}\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _connect(self) -> bool:
        if self.ts is not None:
            return True
        addr = self.gpib_var.get().strip()
        if not addr:
            messagebox.showwarning("Missing", "Enter a GPIB address.")
            return False
        try:
            self.ts = Thermal_Stream(addr)
            try:
                self.ts.my_ins.timeout = VISA_TIMEOUT_MS
                self.ts.my_ins.query_delay = 0.05
                self.ts.my_ins.clear()
            except Exception:
                pass
            self.ts.set_remote()
            idn = self.ts.get_idn()
            self.idn_var.set(idn)
            self._dead_queries.clear()
            self._preblacklist_by_model(idn)
            self.log(f"[OK] Connected: {addr} -> {idn}")
            return True
        except Exception as exc:
            self.ts = None
            self.idn_var.set(f"({addr} not detected)")
            messagebox.showerror("Connect Error", str(exc))
            self.log(f"[ERR] Connect failed: {exc}")
            return False

    def _preblacklist_by_model(self, idn: str):
        u = (idn or "").upper()
        if "ATS-71" in u or "ATS-81" in u:
            self._dead_queries.add("ERROR?")
            self.log("[--] Model does not support ERROR?  - skipped.")

    def _disconnect(self):
        if self.ts is None:
            return
        try:
            self.ts.set_local()
        except Exception:
            pass
        try:
            self.ts.my_ins.close()
        except Exception:
            pass
        self.ts = None
        self.log("[--] Disconnected")

    def _check_device(self):
        addr = self.gpib_var.get().strip()
        if not addr:
            self.idn_var.set("(no address)")
            return
        keep_open = self.ts is not None
        if not keep_open:
            if not self._connect():
                return
        try:
            self._refresh_manual_states()
        finally:
            if not keep_open:
                self._disconnect()

    def _set_all_and_run(self):
        try:
            setp      = float(self.setpoint_var.get())
            soak      = int(self.soak_var.get())
            acc       = float(self.accuracy_var.get())
            ramp      = int(self.ramp_var.get())
            flow_rate = int(self.flow_rate_var.get())
        except Exception as exc:
            messagebox.showerror("Bad Input", f"Cannot parse settings: {exc}")
            return

        if not self._ensure_connected():
            return

        self.state_val.set("applying...")
        self.set_btn.configure(state="disabled")
        self.root.update_idletasks()

        try:
            self.ts.set_soak(soak)
            self.ts.set_accuracy(acc)
            self.ts.set_ramp(ramp)
            self.ts.set_flow_rate(flow_rate)
            self.ts.set_setpoint(setp)

            self.ts.flow_on()
            self.log("[OK] Flow ON (auto)")
            self._sync_flow_button()

            self._cached_setp = setp
            self._cached_acc  = acc
            self._cached_soak = soak
            self._holding_start_time = None
            self.timeout_val.set(f"{soak} s")

            self.log(
                f"[OK] Applied: setpoint={setp} °C, soak={soak} s, "
                f"acc={acc} °C, ramp={ramp}, flow_rate={flow_rate}")
        except Exception as exc:
            self.set_btn.configure(state="normal")
            self.state_val.set("apply failed")
            messagebox.showerror("Apply Error", str(exc))
            self.log(f"[ERR] Apply failed: {exc}")
            return

        self._start_monitor()

    def _abort(self):
        if self.monitoring:
            self._stop_monitor("aborted by user")
        if self.ts is not None:
            try:
                self.ts.flow_off()
                self.log("[OK] Flow OFF (auto on abort)")
                self._sync_flow_button()
            except Exception as exc:
                self.log(f"[WARN] flow-off on abort failed: {exc}")
        self._disconnect()
        self.state_val.set("aborted")
        self.timeout_val.set("--")
        self._holding_start_time = None
        self.set_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")

    def _sync_flow_button(self):
        time.sleep(0.1)
        try:
            is_on = bool(int(self.ts.get_flow()))
        except Exception as exc:
            self.log(f"[WARN] flow readback failed: {exc}")
            return
        self._paint_toggle(self.flow_btn, "Flow", is_on)

    def _start_monitor(self):
        if self.ts is None or self.monitoring:
            return
        self.monitoring = True
        self.start_time = time.time()
        self.t_data.clear()
        self.air_data.clear()
        self.dut_data.clear()
        self.set_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.state_val.set("ramping")
        self.log("[--] Monitor started")
        self._monitor_tick()

    def _stop_monitor(self, reason: str = ""):
        if not self.monitoring:
            return
        self.monitoring = False
        if self._monitor_after_id is not None:
            try:
                self.root.after_cancel(self._monitor_after_id)
            except Exception:
                pass
            self._monitor_after_id = None
        self.set_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        if reason:
            self.log(f"[--] Monitor stopped ({reason})")
        else:
            self.log("[--] Monitor stopped")

    def _monitor_tick(self):
        if not self.monitoring:
            return

        setp = self._cached_setp
        acc  = self._cached_acc
        elapsed = time.time() - self.start_time

        def _q(name, fn, default):
            if name in self._dead_queries:
                return default
            try:
                return fn()
            except Exception as exc:
                self.log(
                    f"[WARN] {name} failed: {exc}. "
                    f"Skipping this query for the rest of the session.")
                self._dead_queries.add(name)
                try:
                    self.ts.my_ins.clear()
                except Exception:
                    pass
                return default

        air_raw  = _q("TMPA?",  self.ts.get_air_temp, None)
        dut_raw  = _q("TMPD?",  self.ts.get_dut_temp, None)
        tecr_raw = _q("TECR?",  self.ts.get_TECR,     None)
        err_raw  = _q("ERROR?", self.ts.get_error,    None)

        air  = float(air_raw)  if air_raw  is not None else (
            self.air_data[-1]  if self.air_data  else float("nan"))
        dut  = float(dut_raw)  if dut_raw  is not None else (
            self.dut_data[-1]  if self.dut_data  else float("nan"))
        tecr = int(tecr_raw)   if tecr_raw is not None else 0
        err  = int(err_raw)    if err_raw  is not None else 0

        self.t_data.append(elapsed)
        self.air_data.append(air)
        self.dut_data.append(dut)
        if len(self.t_data) > MAX_POINTS:
            self.t_data = self.t_data[-MAX_POINTS:]
            self.air_data = self.air_data[-MAX_POINTS:]
            self.dut_data = self.dut_data[-MAX_POINTS:]

        self.air_val.set(f"{air:.2f} °C")
        self.dut_val.set(f"{dut:.2f} °C")
        self.set_val.set(f"{setp:.2f} °C")
        self.tecr_val.set(f"0x{tecr:04X}")
        ctrl_temp = dut if self.mode_var.get() == "DUT" else air
        in_range = abs(ctrl_temp - setp) <= acc
        self.range_val.set("True" if in_range else "False")
        self.range_lbl.configure(
            foreground="#2e7d32" if in_range else "#c62828")
        h, rem = divmod(int(elapsed), 3600)
        m, s = divmod(rem, 60)
        self.elapsed_val.set(f"{h:02d}:{m:02d}:{s:02d}")
        self.err_val.set("OK" if err == 0 else f"{err} (0x{err:04X})")

        now = time.time()
        soak = self._cached_soak or 0
        if in_range:
            if self._holding_start_time is None:
                self._holding_start_time = now
                self.state_val.set("holding")
                self.log(f"[--] In-range: holding for {soak} s")
            remaining = max(0.0, soak - (now - self._holding_start_time))
            self.timeout_val.set(f"{remaining:.0f} s")
        else:
            if self._holding_start_time is not None:
                self._holding_start_time = None
                self.log("[--] Drifted out of range — back to ramping, "
                         f"timeout reset to {soak} s")
            self.state_val.set("ramping")
            self.timeout_val.set(f"{soak} s")

        self.air_line.set_data(self.t_data, self.air_data)
        self.dut_line.set_data(self.t_data, self.dut_data)
        self.set_line.set_ydata([setp, setp])
        self.set_line.set_visible(True)
        if self.band is not None:
            self.band.remove()
        self.band = self.ax.axhspan(setp - acc, setp + acc,
                                    color="#4caf50", alpha=0.10)
        self.ax.relim()
        self.ax.autoscale_view()
        self.canvas.draw_idle()

        if tecr & 1:
            self.log(
                f"[OK] TECR bit 0 set (at-temp + soak complete). "
                f"Air={air:.2f}, DUT={dut:.2f}, Set={setp:.2f}, "
                f"elapsed={self.elapsed_val.get()}")
            self._stop_monitor("at-temp + soak complete")
            self._disconnect()
            self.state_val.set("done")
            self.timeout_val.set("0 s")
            return

        self._monitor_after_id = self.root.after(POLL_MS, self._monitor_tick)

    def _on_close(self):
        self._stop_monitor()
        self._disconnect()
        self.root.destroy()


# ═══════════════════════════════════════════════════════════════════════
#  SetTemp — auto-driven TS setup step
# ═══════════════════════════════════════════════════════════════════════
class SetTemp(ThermalStreamControl):
    """Replaces the manual widgets with a blue banner showing the CLI
    inputs + live Mode/Sensor/Compressor. Auto-invokes 'Set' on launch,
    exits with code 0 when the chamber signals TECR bit 0."""

    def __init__(self, root: tk.Tk, gpib: str, setpoint: float,
                 soak: int, accuracy: float, mode=None, sensor=None,
                 keep_flow: bool = True):
        self._auto_gpib      = gpib
        self._auto_setpoint  = setpoint
        self._auto_soak      = soak
        self._auto_accuracy  = accuracy
        self._auto_mode      = mode        # 'Air'/'DUT' or None (None -> unchanged)
        self._auto_sensor    = sensor      # 'T'/'K' or None
        self._auto_keep_flow = keep_flow   # final flow state after soak
        # Default 1 (failure). Success path flips it to 0 on TECR done.
        self._auto_exit_code = 1

        super().__init__(root)

        self._hide_extra_widgets()
        self._install_auto_banner()

        # Push CLI values into the base class's StringVars so _set_all_and_run
        # picks them up unchanged.
        self.gpib_var.set(gpib)
        self.setpoint_var.set(str(setpoint))
        self.soak_var.set(str(soak))
        self.accuracy_var.set(str(accuracy))

        # Kick off Set after mainloop paints the banner.
        root.after(400, self._auto_start)

    def _hide_extra_widgets(self):
        """Remove the top bar, settings panel, manual controls, and log
        frame so only the Monitor plot remains visible."""
        for w in (self.top_frame, self.settings_frame,
                  self.manual_frame, self.log_frame):
            try:
                w.grid_remove()
            except Exception:
                pass

    def _install_auto_banner(self):
        """Shift every existing widget down by one grid row and paint a
        blue banner on row 0 showing the CLI inputs + live status."""
        for child in self.root.grid_slaves():
            info = child.grid_info()
            if not info:
                continue
            try:
                cur_row = int(info.get("row", 0))
                child.grid_configure(row=cur_row + 1)
            except Exception:
                pass

        # After shifting: banner=row 0, hidden top_frame=row 1,
        # mid_frame (Monitor)=row 2, hidden manual/log=rows 3/4.
        # Base class set row 1 weight=1 -- now points at the hidden top_frame,
        # producing an empty weighted gap. Reweight so the Monitor row expands.
        for r in (0, 1, 3, 4):
            self.root.grid_rowconfigure(r, weight=0)
        self.root.grid_rowconfigure(2, weight=1)

        banner = tk.Frame(self.root, bg=BANNER_BG, padx=12, pady=8)
        banner.grid(row=0, column=0, sticky="ew")

        def lbl(parent, text=None, var=None, bold=False, dim=False,
                size=10, width=None):
            kw = dict(bg=BANNER_BG,
                      fg=(BANNER_FG_2 if dim else BANNER_FG),
                      font=("Consolas", size, "bold" if bold else "normal"))
            if width is not None:
                kw["width"] = width
                kw["anchor"] = "w"
            if var is not None:
                return tk.Label(parent, textvariable=var, **kw)
            return tk.Label(parent, text=text, **kw)

        # Line 1: static inputs (Segoe UI, larger, bold)
        line1 = ("  Setpoint: {:.2f} °C    Soak: {} s    Accuracy: ±{:.2f} °C"
                 "    Keep flow: {}").format(
            self._auto_setpoint, self._auto_soak, self._auto_accuracy,
            "ON" if self._auto_keep_flow else "OFF (off after soak)")
        tk.Label(banner, text=line1, bg=BANNER_BG, fg=BANNER_FG,
                 font=("Segoe UI", 12, "bold"), anchor="w").pack(
            fill="x", anchor="w")

        # Line 2: GPIB + live Mode / Sensor / Compressor
        row2 = tk.Frame(banner, bg=BANNER_BG)
        row2.pack(fill="x", anchor="w", pady=(4, 0))
        lbl(row2, text=f"  GPIB: {self._auto_gpib}    |    ", dim=True).pack(side="left")
        lbl(row2, text="Mode: ",       dim=True, bold=True).pack(side="left")
        lbl(row2, var=self.mode_var,   bold=True, width=8).pack(side="left")
        lbl(row2, text="Sensor: ",     dim=True, bold=True).pack(side="left")
        lbl(row2, var=self.sensor_var, bold=True, width=5).pack(side="left")
        lbl(row2, text="Compressor: ", dim=True, bold=True).pack(side="left")
        lbl(row2, var=self.cool_var,   bold=True, width=5).pack(side="left")

        self.root.title(
            f"Set Temp - {self._auto_setpoint} °C / soak {self._auto_soak}s")

    def _auto_start(self):
        """Apply mode/sensor (if requested) first, then the base Set-All run.

        Mode/Sensor can only be changed with flow OFF; _set_all_and_run turns
        flow back ON before ramping, so ordering is: flow off -> mode/sensor ->
        temp settings -> flow on -> monitor.
        """
        if not self._ensure_connected():
            self.state_val.set("connect failed")
            self.root.after(1500, self._safe_close)
            return
        try:
            self._apply_mode_sensor()
        except Exception as exc:
            self.state_val.set("mode/sensor failed")
            self.log(f"[ERR] mode/sensor apply failed: {exc}")
            self._auto_exit_code = 1
            self.root.after(1500, self._safe_close)
            return
        self._set_all_and_run()

    def _apply_mode_sensor(self):
        """Set the DUT sensor then the DUT mode via the ATS710 abstraction.

        Only touches what was requested (None -> leave unchanged). Flow must be
        OFF to change either. Mode DUT / Air+DUT requires a DUT thermocouple
        (sensor T or K); a bare NON sensor under those modes is rejected.
        """
        want_mode   = self._auto_mode      # 'Air'/'DUT' or None
        want_sensor = self._auto_sensor    # 'T'/'K' or None
        if want_mode is None and want_sensor is None:
            return

        ts = self.ts
        # Flow must be off to change mode/sensor.
        try:
            if bool(int(ts.get_flow())):
                ts.flow_off()
                self.log("[OK] Flow OFF (auto, required for mode/sensor)")
        except Exception as exc:
            self.log(f"[WARN] flow-off precheck failed: {exc}")

        # Effective mode/sensor after this apply (requested value, else current).
        cur_mode   = int(ts.get_dut_mode())
        cur_sensor = int(ts.get_dut_sensor())
        eff_mode   = MODE_MAP[want_mode]     if want_mode   else cur_mode
        eff_sensor = SENSOR_MAP[want_sensor] if want_sensor else cur_sensor
        if eff_mode in (MODE_MAP["DUT"], MODE_MAP["Air+DUT"]) and \
                eff_sensor == SENSOR_MAP["NON"]:
            raise ValueError(
                "Mode DUT / Air+DUT needs a DUT thermocouple (sensor T or K), "
                "not NON.")

        # Sensor first (so a DUT mode always has a valid sensor), then mode.
        if want_sensor is not None:
            ts.set_dut_sensor(SENSOR_MAP[want_sensor])
            self.sensor_var.set(want_sensor)
            self._paint_sensor_buttons(want_sensor)
            self.log(f"[OK] Sensor -> {want_sensor}")
        if want_mode is not None:
            ts.set_dut_mode(MODE_MAP[want_mode])
            self.mode_var.set(want_mode)
            self._paint_mode_buttons(want_mode)
            self.log(f"[OK] Mode -> {want_mode}")

    def _stop_monitor(self, reason: str = ""):
        # keep_flow=False: turn flow off at the very end (after soak complete).
        if (reason == "at-temp + soak complete" and not self._auto_keep_flow
                and self.ts is not None):
            try:
                self.ts.flow_off()
                self.log("[OK] Flow OFF (keep_flow=False, after soak)")
            except Exception as exc:
                self.log(f"[WARN] final flow-off failed: {exc}")
        super()._stop_monitor(reason)
        if reason == "at-temp + soak complete":
            self._auto_exit_code = 0
            self.log("[TS] Soak complete — exit 0 in 1.5 s")
            self.root.after(1500, self._safe_close)

    def _safe_close(self):
        try:
            self._on_close()
        except Exception:
            try:
                self.root.destroy()
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════════════════
#  Entry point
# ═══════════════════════════════════════════════════════════════════════
def _resolve_port(port_arg: str) -> str:
    """`--port` non-empty -> return it. Else auto-discover thermal via Bench."""
    if port_arg and port_arg.strip() and port_arg.strip().upper() != "NA":
        return port_arg.strip()
    from instruments.bench import Bench
    return Bench().thermal.addr


# ═══════════════════════════════════════════════════════════════════════
#  Python Adapter entry point
# ═══════════════════════════════════════════════════════════════════════
def set_temp(temp, accuracy, soak, mode="", sensor="", keep_flow=True,
             port: str = "") -> str:
    """Drive the chamber to `temp`, soak `soak` s within ±`accuracy` °C, with a
    live GUI. Optionally set the DUT mode/sensor first. Blocks until at-temp +
    soak complete, then returns a summary string.

    temp/accuracy/soak : numeric (required).
    mode               : "Air" | "DUT" | "Air+DUT". Empty/NA -> leave unchanged.
    sensor             : "NON" | "T" | "K".         Empty/NA -> leave unchanged.
    keep_flow          : final flow state AFTER the step. Flow is always ON
                         during control; True (default) leaves it on, False
                         turns it off once soak completes.
    port               : VISA address override. Empty/NA -> auto-discover.

    Raises ValueError on bad input, RuntimeError on auto-discover failure,
    connection loss, apply failure, or early window close.
    """
    try:
        setpoint = float(temp)
        accuracy_f = float(accuracy)
        soak_i = int(float(soak))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"temp/accuracy/soak must be numeric: {exc}") from exc

    mode_key   = _parse_mode(mode)          # 'Air'/'DUT' or None; raises on bad value
    sensor_key = _parse_sensor(sensor)      # 'T'/'K' or None; raises on bad value
    keep_flow_b = _parse_keep_flow(keep_flow)

    try:
        addr = _resolve_port(str(port))
    except Exception as exc:
        raise RuntimeError(
            f"auto-discover thermal failed: {exc}. Pass port to override.") from exc

    root = tk.Tk()
    root.minsize(1100, 700)
    app = SetTemp(root, addr, setpoint, soak_i, accuracy_f,
                  mode=mode_key, sensor=sensor_key, keep_flow=keep_flow_b)
    try:
        root.mainloop()
    except Exception as exc:
        raise RuntimeError(f"mainloop crashed: {exc}") from exc

    if app._auto_exit_code != 0:
        raise RuntimeError(
            "chamber did not reach at-temp + soak complete "
            "(window closed early / connection lost / apply/mode-sensor failure)")
    return (f"[OK] at-temp + soak complete: temp={setpoint}C, accuracy=±{accuracy_f}C, "
            f"soak={soak_i}s, mode={mode_key or 'unchanged'}, "
            f"sensor={sensor_key or 'unchanged'}, keep_flow={keep_flow_b}")


# ═══════════════════════════════════════════════════════════════════════
#  Standalone / debug CLI shim
# ═══════════════════════════════════════════════════════════════════════
def main() -> int:
    parser = argparse.ArgumentParser(
        description="Drive the thermal chamber to a setpoint and soak, "
                    "with a live GUI (banner + plot).")
    parser.add_argument("--temp", type=float, required=True, metavar="C",
        help="Target temperature in °C")
    parser.add_argument("--accuracy", type=float, required=True, metavar="C",
        help="Accuracy window in ±°C")
    parser.add_argument("--soak", type=int, required=True, metavar="SEC",
        help="Soak time in seconds")
    parser.add_argument("--mode", default="", metavar="MODE",
        help="air | dut (case-insensitive). Empty/NA -> leave unchanged.")
    parser.add_argument("--sensor", default="", metavar="SENSOR",
        help="t | k (case-insensitive). Empty/NA -> leave unchanged.")
    parser.add_argument("--keep-flow", default="", metavar="BOOL", dest="keep_flow",
        help="Flow state after soak. true (default) -> keep on; false -> off.")
    parser.add_argument("--port", default="", metavar="ADDR",
        help='VISA address override, e.g. "GPIB0::9::INSTR". '
             "Default: auto-discover via Bench().thermal.")
    args = parser.parse_args()

    try:
        result = set_temp(args.temp, args.accuracy, args.soak,
                          mode=args.mode, sensor=args.sensor,
                          keep_flow=args.keep_flow, port=args.port)
    except ValueError as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 2
    except Exception as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 1
    print(result, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
