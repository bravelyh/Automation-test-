r"""I2C setup steps — one module, four TestStand Python-Adapter entry points.

Consolidates the former four I2C steps (Run Script, Check Status, Clear Fault,
Config FC) into a single file. Every device transaction goes through the i2x
abstraction layer's `I2X_AAA.i2c_send(script)` — this module builds the I2C
script strings (the setup-layer wrapping) but never touches the serial port
itself.

The DUT's I2C address and its register maps are auto-loaded from
`C:\MPAA Validation\Projects\<device_name>\...`.

Entry points
------------
    run_script(script, device_name, port="")        -> str
    check_status(device_name, port="")              -> list[str]
    clear_fault(device_name, port="")               -> str
    set_reg_FC(fc_string, device_name, port="")     -> list[str]

Argument order is "payload first": the step-specific input (script / fc_string)
comes first, then device_name, then the optional port. `port` empty / "NA"
auto-discovers the STLink Virtual COM port via Bench(). `check_status` and
`set_reg_FC` return data (active statuses / config records); the other two
return a one-line summary. Per-command diagnostics go to stderr.

Raises FileNotFoundError / ValueError on missing/invalid config, RuntimeError
on port / communication failure.

TestStand Python Adapter
------------------------
    Module : I2C.py
    | Function     | Arguments (in order)                                       |
    |--------------|------------------------------------------------------------|
    | run_script   | script=FileGlobals.ForcingConditions.ExtraScript,          |
    |              | device_name=FileGlobals.DeviceLogInfo.DUT_Name, port       |
    | check_status | device_name=FileGlobals.DeviceLogInfo.DUT_Name, port       |
    |              |   -> returns list[str] of active statuses                  |
    | clear_fault  | device_name=FileGlobals.DeviceLogInfo.DUT_Name, port       |
    | set_reg_FC   | fc_string=FileGlobals.ForcingConditions.FC_String,         |
    |              | device_name=FileGlobals.DeviceLogInfo.DUT_Name, port       |
    |              |   -> returns list[str] of config records                   |
    port = FileGlobals.Instruments.I2X_Port  (optional override; empty = auto)

Standalone / debug CLI (subcommand per entry point):
    .venv\Scripts\python.exe "I2C.py" run_script  --script "w E0 03 22" --device-name TAS6754
    .venv\Scripts\python.exe "I2C.py" check_status --device-name TAS6754
    .venv\Scripts\python.exe "I2C.py" clear_fault  --device-name TAS6754
    .venv\Scripts\python.exe "I2C.py" set_reg_FC   --fc-string "MUTE_ON,SPK_EN" --device-name TAS6754
"""
from __future__ import annotations

import argparse
import configparser
import os
import sys
import time


INI_ROOT = r"C:\MPAA Validation\Projects"


# ===========================================================================
# Shared helpers — input parsing, device address, instrument resolution
# ===========================================================================
def _is_empty(v) -> bool:
    """True for None, '', whitespace, or 'NA' (case-insensitive)."""
    if v is None:
        return True
    if isinstance(v, str):
        t = v.strip()
        return not t or t.upper() == "NA"
    return False


def _load_device_addr(device_name: str) -> str:
    """Return the DUT I2C address as an uppercase 2-hex-digit string (e.g. 'E0').

    Reads 'IC Address*' from
    C:\\MPAA Validation\\Projects\\<name>\\<name> Default Setting.ini.
    Raises FileNotFoundError / ValueError on failure.
    """
    name = str(device_name).strip()
    path = os.path.join(INI_ROOT, name, f"{name} Default Setting.ini")
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Default Setting.ini not found: {path}")
    cfg = configparser.RawConfigParser()
    cfg.optionxform = str
    cfg.read(path, encoding="utf-8")
    for section in cfg.sections():
        if "IC Address*" in cfg[section]:
            try:
                val = float(cfg[section]["IC Address*"].strip().strip("\"'"))
                return f"{int(val):02X}"
            except Exception:
                pass
    raise ValueError(f"IC Address* not found in: {path}")


def _resolve_i2x(port):
    """Return the bench's I2X_AAA instance. Empty/NA port -> auto-discover."""
    from instruments.bench import Bench, CATALOG
    if not _is_empty(port):
        entries = CATALOG.get("i2x", [])
        if not entries:
            raise RuntimeError("CATALOG['i2x'] is empty")
        return entries[0]["class"](str(port).strip())
    return Bench().i2x


def _log(msg: str) -> None:
    print(msg, file=sys.stderr)


# ===========================================================================
# Low-level register I/O — all via the abstraction's i2c_send()
# ===========================================================================
def _read_reg_byte(i2x, dev_hex: str, reg_hex: str) -> int:
    """Read one byte from a register. Returns the byte value."""
    results = i2x.i2c_send(f"R {dev_hex} {reg_hex} 1")
    if not (results and results[0]):
        raise RuntimeError(f"No data for reg 0x{reg_hex}")
    return int(results[0][0][4:6], 16)


def _rmw(i2x, dev_hex: str, reg_hex: str,
         start_bit: int, length: int, value: int) -> tuple[int, int]:
    """Read-modify-write a bit field. Returns (old_byte, new_byte)."""
    current = _read_reg_byte(i2x, dev_hex, reg_hex)
    mask = (1 << length) - 1
    new_val = (current & ~(mask << start_bit)) | ((value & mask) << start_bit)
    i2x.i2c_send(f"W {dev_hex} {reg_hex} {new_val:02X}")
    return current, new_val


def _switch_page(i2x, dev_hex: str, page: int) -> None:
    """Emit the standard 3-write page-select sequence."""
    i2x.i2c_send(
        f"w {dev_hex} 00 00\nw {dev_hex} 7f 00\nw {dev_hex} 00 {page:02X}")


# ===========================================================================
# run_script — protocol wrapping + executor
# ===========================================================================
def _convert_script(script: str, dev_hex: str) -> str:
    """Convert X/D shorthand to standard w/r commands."""
    dev_hex = dev_hex.lower()
    out: list[str] = []
    for raw_line in script.split("\n"):
        cut = len(raw_line)
        for i, ch in enumerate(raw_line):
            if not (ch.isalnum() or ch.isspace()):
                cut = i
                break
        line = raw_line[:cut].strip()
        if not line or not line[0].isalnum():
            out.append(line)
            continue
        upper = line.upper()
        if upper.startswith("X"):
            parts = line.split()
            if len(parts) >= 2:
                line = f"w {dev_hex} {parts[0][1:]} {' '.join(parts[1:])}"
        elif upper.startswith("D"):
            parts = line.split()
            if len(parts) >= 2:
                line = f"r {dev_hex} {parts[0][1:]} {parts[1]}"
        out.append(line)
    return "\n".join(out)


def _execute_script(i2x, dev_hex: str, script: str) -> str:
    """Execute a converted script line by line. Returns a one-line summary."""
    converted = _convert_script(script.strip(), dev_hex)
    cmd_num = 0
    for line in converted.split("\n"):
        line = line.strip()
        if not line or not line[0].isalnum():
            continue
        cmd_num += 1

        # Bare delay: D<digits>
        if line.upper().startswith("D") and len(line) > 1 and line[1:].isdigit():
            delay_ms = int(line[1:])
            time.sleep(delay_ms / 1000.0)
            _log(f"[{cmd_num}] delay {delay_ms}ms")
            continue

        results = i2x.i2c_send(line)
        parts = line.split()
        upper = parts[0].upper() if parts else ""
        if upper == "R":
            dev = parts[1] if len(parts) > 1 else "??"
            reg = parts[2] if len(parts) > 2 else "??"
            _log(f"[{cmd_num}] r {dev} {reg} read successful")
            if results and results[0]:
                _log(f"    data: {' '.join(f'{int(r[4:6],16):02X}' for r in results[0])}")
        elif upper == "W":
            dev = parts[1] if len(parts) > 1 else "??"
            reg = parts[2] if len(parts) > 2 else "??"
            val = parts[3] if len(parts) > 3 else "??"
            _log(f"[{cmd_num}] w {dev} {reg} {val} write successful")
        else:
            _log(f"[{cmd_num}] {line} ok")

    summary = f"[OK] Script complete ({cmd_num} cmd(s))"
    _log(summary)
    return summary


# ===========================================================================
# check_status — status register map parsing + reader
# ===========================================================================
def _parse_status_register_map(file_path: str) -> list[dict]:
    """Tab-separated, header row skipped. Columns: reg_addr, bits, value, status."""
    registers: list[dict] = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if line_no == 1:
                continue
            line = line.strip()
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) < 4:
                continue
            try:
                registers.append({
                    "reg_addr": parts[0].strip(),
                    "bits":     parts[1].strip(),
                    "value":    int(parts[2].strip()),
                    "status":   parts[3].strip(),
                })
            except (ValueError, IndexError):
                continue
    return registers


def _read_active_status(i2x, dev_hex: str, device_name: str) -> list[str]:
    """Return the list of active status strings for the device."""
    name = str(device_name).strip()
    status_map_path = os.path.join(
        INI_ROOT, name, f"{name} Status Register Map.txt")
    if not os.path.isfile(status_map_path):
        raise FileNotFoundError(f"Status register map not found: {status_map_path}")

    registers = _parse_status_register_map(status_map_path)
    if not registers:
        raise ValueError(f"No entries parsed from: {status_map_path}")

    # Page select to 0
    try:
        i2x.i2c_send(f"w {dev_hex} 00 00\nw {dev_hex} 7f 00")
    except Exception as exc:
        _log(f"[WARN] page switch failed: {exc}")

    # Read each unique register once
    reg_cache: dict[int, int] = {}
    for item in registers:
        reg_int = int(item["reg_addr"].strip(), 16)
        if reg_int not in reg_cache:
            reg_cache[reg_int] = _read_reg_byte(i2x, dev_hex, f"{reg_int:02X}")

    # Collect active statuses
    active: list[str] = []
    for item in registers:
        reg_int  = int(item["reg_addr"].strip(), 16)
        bits_str = item["bits"]
        expected = item["value"]
        byte_val = reg_cache.get(reg_int, 0)

        if "," in bits_str:
            bit_list = [int(b.strip()) for b in bits_str.split(",")]
        else:
            bit_list = [int(bits_str)]

        if len(bit_list) > 1:
            high, low = max(bit_list), min(bit_list)
            extracted = (byte_val >> low) & ((1 << (high - low + 1)) - 1)
        else:
            extracted = (byte_val >> bit_list[0]) & 1

        if extracted == expected:
            active.append(item["status"])

    return active


# ===========================================================================
# set_reg_FC — FC register map parsing + configure loop
# ===========================================================================
class _FCMapEntry:
    __slots__ = ('name', 'page1', 'reg1', 'start1', 'len1', 'val1',
                 'has_part2', 'page2', 'reg2', 'start2', 'len2', 'val2')

    def __init__(self, name, page1, reg1, start1, len1, val1,
                 has_part2=False, page2=0, reg2=0, start2=0, len2=0, val2=0):
        self.name = name
        self.page1 = page1
        self.reg1 = reg1
        self.start1 = start1
        self.len1 = len1
        self.val1 = val1
        self.has_part2 = has_part2
        self.page2 = page2
        self.reg2 = reg2
        self.start2 = start2
        self.len2 = len2
        self.val2 = val2


def _parse_bin_literal(s: str) -> int:
    """Parse a '2bXXXX' style literal -> int. The prefix digit is ignored."""
    s = s.strip()
    idx = s.lower().find('b')
    if idx < 0:
        raise ValueError(f"Not a binary literal: {s!r}")
    return int(s[idx + 1:], 2)


def _parse_fc_register_map(file_path: str) -> list[_FCMapEntry]:
    """Parse an FC Register Map .txt file. Tolerates tab/space-separated rows;
    skips malformed rows."""
    entries: list[_FCMapEntry] = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line_no, line in enumerate(f, 1):
            if line_no == 1:
                continue
            line = line.rstrip("\r\n")
            if not line.strip():
                continue
            if '\t' in line:
                parts = [p.strip() for p in line.split('\t') if p.strip() != '']
            else:
                parts = line.split()
            if len(parts) < 6:
                continue
            try:
                name = parts[0]
                page1 = int(parts[1])
                reg1 = int(parts[2], 16)
                start1 = int(parts[3])
                len1 = int(parts[4])
                val1 = _parse_bin_literal(parts[5])
                has_p2 = (len(parts) >= 12 and parts[6].lower() == 'yes')
                if has_p2:
                    entries.append(_FCMapEntry(
                        name, page1, reg1, start1, len1, val1, True,
                        int(parts[7]), int(parts[8], 16), int(parts[9]),
                        int(parts[10]), _parse_bin_literal(parts[11])))
                else:
                    entries.append(_FCMapEntry(name, page1, reg1, start1, len1, val1))
            except Exception:
                continue
    return entries


def _configure_fc(i2x, dev_hex: str, fc_map: list[_FCMapEntry],
                  names: list[str]) -> list[str]:
    """Configure each named FC. Silently skip names not in the map.
    Returns one string per successfully-configured FC."""
    by_name = {e.name: e for e in fc_map}
    current_page: int | None = None

    def _ensure_page(p: int) -> None:
        nonlocal current_page
        if current_page != p:
            _switch_page(i2x, dev_hex, p)
            current_page = p

    records: list[str] = []
    for raw_name in names:
        name = raw_name.strip()
        if not name:
            continue
        entry = by_name.get(name)
        if entry is None:
            _log(f"[SKIP] {name}: not in FC map")
            continue
        try:
            _ensure_page(entry.page1)
            reg_hex = f"{entry.reg1:02X}"
            high1 = entry.start1 + entry.len1 - 1
            old, new = _rmw(i2x, dev_hex, reg_hex,
                            entry.start1, entry.len1, entry.val1)
            records.append(
                f"{name}: P{entry.page1} 0x{reg_hex}[{high1}:{entry.start1}]"
                f"={entry.val1} (0x{old:02X} -> 0x{new:02X})")

            if entry.has_part2:
                _ensure_page(entry.page2)
                reg_hex2 = f"{entry.reg2:02X}"
                high2 = entry.start2 + entry.len2 - 1
                old2, new2 = _rmw(i2x, dev_hex, reg_hex2,
                                  entry.start2, entry.len2, entry.val2)
                records.append(
                    f"{name} (part2): P{entry.page2} 0x{reg_hex2}"
                    f"[{high2}:{entry.start2}]={entry.val2} "
                    f"(0x{old2:02X} -> 0x{new2:02X})")
        except Exception as exc:
            _log(f"[ERR] {name}: {exc}")

    _log(f"[OK] {len(records)} setting(s) configured")
    return records


# ===========================================================================
# Python Adapter entry points
# ===========================================================================
def run_script(script: str = "", device_name: str = "", port: str = "") -> str:
    """Run an I2C script on the device. Empty/NA script -> no-op.

    Returns a one-line summary. Raises FileNotFoundError / ValueError on bad
    config, RuntimeError on port / communication failure.
    """
    if _is_empty(script):
        return "[OK] Empty script, nothing to do"

    dev_hex = _load_device_addr(device_name)
    i2x = _resolve_i2x(port)
    try:
        return _execute_script(i2x, dev_hex, str(script))
    finally:
        try:
            i2x.close()
        except Exception:
            pass


def check_status(device_name: str = "", port: str = "") -> list[str]:
    """Return the list of active status strings (empty list = no faults)."""
    dev_hex = _load_device_addr(device_name)
    i2x = _resolve_i2x(port)
    try:
        return _read_active_status(i2x, dev_hex, device_name)
    finally:
        try:
            i2x.close()
        except Exception:
            pass


def clear_fault(device_name: str = "", port: str = "") -> str:
    """Run the fixed clear-fault sequence. Returns a one-line summary."""
    dev_hex = _load_device_addr(device_name)
    i2x = _resolve_i2x(port)
    try:
        # Page select first
        try:
            i2x.i2c_send(f"w {dev_hex} 00 00\nw {dev_hex} 7f 00")
        except Exception as exc:
            _log(f"[WARN] page switch failed: {exc}")
        for idx, cmd in enumerate(
                (f"w {dev_hex} 00 00", f"w {dev_hex} 7f 00", f"w {dev_hex} 01 08"), 1):
            i2x.i2c_send(cmd)
            _log(f"[{idx}] {cmd} write successful")
        _log("[OK] Clear fault complete")
        return "[OK] Clear fault complete"
    finally:
        try:
            i2x.close()
        except Exception:
            pass


def set_reg_FC(fc_string: str = "", device_name: str = "", port: str = "") -> list[str]:
    """Configure the FC settings named in `fc_string`. Empty/NA -> no-op ([]).

    Returns one string per successfully-configured FC. Names not in the FC map
    are silently skipped.
    """
    if _is_empty(fc_string):
        return []

    dev_hex = _load_device_addr(device_name)
    name = str(device_name).strip()
    fc_map_path = os.path.join(INI_ROOT, name, f"{name} FC Register Map.txt")
    if not os.path.isfile(fc_map_path):
        raise FileNotFoundError(f"FC Register Map not found: {fc_map_path}")
    fc_map = _parse_fc_register_map(fc_map_path)
    names = str(fc_string).split(",")

    i2x = _resolve_i2x(port)
    try:
        return _configure_fc(i2x, dev_hex, fc_map, names)
    finally:
        try:
            i2x.close()
        except Exception:
            pass


# ===========================================================================
# Standalone / debug CLI shim (one subcommand per entry point)
# ===========================================================================
def main() -> int:
    parser = argparse.ArgumentParser(description="I2C setup steps over STM32 STLink.")
    sub = parser.add_subparsers(dest="action", required=True)

    def _add_common(p):
        p.add_argument("--device-name", required=True, metavar="NAME", dest="device_name",
            help=r"Project name under C:\MPAA Validation\Projects\<NAME>")
        p.add_argument("--port", default="", metavar="COMx",
            help="Force a specific STLink COM port (default: auto-detect).")

    p_run = sub.add_parser("run_script", help="Run an I2C script.")
    p_run.add_argument("--script", default="", metavar="TEXT", help="Inline script. Empty = no-op.")
    _add_common(p_run)

    p_status = sub.add_parser("check_status", help="Read active statuses.")
    _add_common(p_status)

    p_clear = sub.add_parser("clear_fault", help="Run the clear-fault sequence.")
    _add_common(p_clear)

    p_fc = sub.add_parser("set_reg_FC", help="Configure a batch of FC settings.")
    p_fc.add_argument("--fc-string", default="", metavar="LIST", dest="fc_string",
        help='Comma-separated FC names. Names not in the FC map are skipped.')
    _add_common(p_fc)

    args = parser.parse_args()
    try:
        if args.action == "run_script":
            print(run_script(args.script, args.device_name, args.port), flush=True)
        elif args.action == "check_status":
            for line in check_status(args.device_name, args.port):
                print(line, flush=True)
        elif args.action == "clear_fault":
            print(clear_fault(args.device_name, args.port), flush=True)
        elif args.action == "set_reg_FC":
            for line in set_reg_FC(args.fc_string, args.device_name, args.port):
                print(line, flush=True)
    except (FileNotFoundError, ValueError) as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 2
    except Exception as exc:
        print(f"ERR {exc}", file=sys.stderr, flush=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
