@echo off
setlocal
cd /d "%~dp0"

REM --- TI corporate network requires a proxy to reach pypi.org ---------------
set "PIP_PROXY=http://webproxy.ext.ti.com:80"

echo ============================================================
echo  Auto Bench -- virtual environment setup (.venv)
echo ============================================================

REM --- 1. Require Python 3.14 64-bit (the base for the venv) -----------------
py -3.14 -c "import sys; assert sys.maxsize > 2**32, '64-bit required'" 2>nul
if errorlevel 1 (
    echo [!] ERROR: py -3.14 ^(64-bit^) not found. Install Python 3.14 64-bit.
    pause
    exit /b 1
)
py -3.14 -c "import sys; print('  Base Python:', sys.executable, sys.version.split()[0])"

REM --- 2. Create the .venv if it does not exist -----------------------------
REM .venv is per-machine and git-ignored. Each bench builds its own from the
REM pinned line below, so multiple users share the repo with no env conflicts.
if not exist ".venv\Scripts\python.exe" (
    echo.
    echo Creating virtual environment in .venv ...
    py -3.14 -m venv .venv
    if errorlevel 1 (
        echo [!] ERROR: failed to create .venv
        pause
        exit /b 1
    )
) else (
    echo.
    echo Reusing existing .venv
)

REM --- 3. Upgrade pip inside the venv ---------------------------------------
echo.
echo Upgrading pip...
.venv\Scripts\python.exe -m pip install --upgrade pip --quiet

REM --- 4. Sync dependencies: scan the repo's imports, install any missing --
REM No hardcoded package list. A generated helper walks every .py, collects
REM the third-party top-level imports, and pip-installs whatever the venv is
REM missing. Add a feature that imports a new package and the next setup_env
REM run installs it -- THIS FILE NEVER NEEDS EDITING for a new dependency.
REM   * Same-name packages (matplotlib, openpyxl, ...) are zero-config.
REM   * Import-name != pip-name (serial->pyserial, clr->pythonnet, PIL->pillow,
REM     pyvisa->PyVISA) and non-pip/DLL imports (AudioPrecision, System) are
REM     handled by the NAME_MAP / IGNORE tables in the helper below -- the only
REM     place to touch, and only for those rare cases.
REM (Build-only tools like PyInstaller are NOT installed here -- only people who
REM build a tools/ exe need it, so tools/<tool>/build.bat installs it on demand.)
REM Versions are NOT pinned: a missing package installs at its latest release.
REM Like step 6, the helper is generated to a temp .py, run with the venv
REM interpreter, then deleted (front-loaded redirection keeps it byte-exact).
set "ROOT=%~dp0"
echo.
echo Syncing dependencies (scanning imports)...
set "DEPSYNC=%TEMP%\ab_dep_sync.py"
if exist "%DEPSYNC%" del "%DEPSYNC%"
>>"%DEPSYNC%" echo(import ast, os, sys, subprocess
>>"%DEPSYNC%" echo(from importlib import metadata
>>"%DEPSYNC%" echo(root = os.environ["ROOT"].rstrip("\\")
>>"%DEPSYNC%" echo(LOCAL = "instruments"
>>"%DEPSYNC%" echo(SKIP = {".git", "__pycache__", ".vscode", ".idea", "build", "dist", ".venv"}
>>"%DEPSYNC%" echo(NAME_MAP = {"serial": "pyserial", "clr": "pythonnet", "PIL": "pillow", "pyvisa": "PyVISA"}
>>"%DEPSYNC%" echo(IGNORE = {"AudioPrecision", "System"}
>>"%DEPSYNC%" echo(found = set()
>>"%DEPSYNC%" echo(for dp, dns, fns in os.walk(root):
>>"%DEPSYNC%" echo(    dns[:] = [d for d in dns if d not in SKIP]
>>"%DEPSYNC%" echo(    for f in fns:
>>"%DEPSYNC%" echo(        if not f.endswith(".py"):
>>"%DEPSYNC%" echo(            continue
>>"%DEPSYNC%" echo(        try:
>>"%DEPSYNC%" echo(            tree = ast.parse(open(os.path.join(dp, f), encoding="utf-8").read())
>>"%DEPSYNC%" echo(        except Exception:
>>"%DEPSYNC%" echo(            continue
>>"%DEPSYNC%" echo(        for n in ast.walk(tree):
>>"%DEPSYNC%" echo(            if isinstance(n, ast.Import):
>>"%DEPSYNC%" echo(                for a in n.names:
>>"%DEPSYNC%" echo(                    found.add(a.name.split(".")[0])
>>"%DEPSYNC%" echo(            elif isinstance(n, ast.ImportFrom):
>>"%DEPSYNC%" echo(                if n.level == 0 and n.module:
>>"%DEPSYNC%" echo(                    found.add(n.module.split(".")[0])
>>"%DEPSYNC%" echo(stdlib = sys.stdlib_module_names
>>"%DEPSYNC%" echo(dist_map = metadata.packages_distributions()
>>"%DEPSYNC%" echo(need = []
>>"%DEPSYNC%" echo(for name in sorted(found):
>>"%DEPSYNC%" echo(    if name in stdlib or name == LOCAL or name in IGNORE:
>>"%DEPSYNC%" echo(        continue
>>"%DEPSYNC%" echo(    if name in dist_map:
>>"%DEPSYNC%" echo(        continue
>>"%DEPSYNC%" echo(    need.append(NAME_MAP.get(name, name))
>>"%DEPSYNC%" echo(need = sorted(set(need))
>>"%DEPSYNC%" echo(if need:
>>"%DEPSYNC%" echo(    print("  Installing missing deps: " + ", ".join(need))
>>"%DEPSYNC%" echo(    subprocess.check_call([sys.executable, "-m", "pip", "install"] + need)
>>"%DEPSYNC%" echo(else:
>>"%DEPSYNC%" echo(    print("  All dependencies already satisfied.")
.venv\Scripts\python.exe "%DEPSYNC%"
if errorlevel 1 (
    echo [!] ERROR: dependency sync failed.
    del "%DEPSYNC%"
    pause
    exit /b 1
)
del "%DEPSYNC%"

REM --- 5. Make `instruments` importable inside the .venv --------------------
REM Write a .pth into the venv's site-packages that adds THIS repo root to
REM sys.path, so scripts run by the venv interpreter can `import instruments`
REM with no path bootstrap. Re-run this script if the repo folder ever moves
REM (it rewrites the .pth to the new location).
echo.
echo Registering 'instruments' on the venv path...
set "ROOT=%~dp0"
.venv\Scripts\python.exe -c "import sysconfig, os; p = sysconfig.get_paths()['purelib']; open(os.path.join(p, 'auto_bench.pth'), 'w').write(os.environ['ROOT'].rstrip(os.sep) + '\n'); print('  ->', os.path.join(p, 'auto_bench.pth'))"
if errorlevel 1 (
    echo [!] ERROR: failed to register the path.
    pause
    exit /b 1
)

REM --- 6. If .vscode exists, point Code Runner at the venv (python key only)-
REM .vscode is per-user and git-ignored; this NEVER creates the folder. If it
REM is present, ensure code-runner.executorMap has a "python" entry that runs
REM THIS repo's .venv interpreter -- touching only that one language key and
REM leaving every other language (e.g. java) and every other setting intact.
REM
REM To keep the repo to a single setup file, the patch (a targeted text splice
REM that preserves comments/formatting) is written to a temp .py on the fly,
REM run with the venv interpreter, then deleted -- no helper script in the repo.
REM Two cmd-echo hazards are sidestepped so the generated .py is byte-exact:
REM   * regexes are assembled from chr() codes, so no ^ / | / \ ever lands on a
REM     line whose carets cmd's echo would eat;
REM   * redirection is front-loaded (>>file echo ...), so a line ending in a
REM     digit is not swallowed as a stream handle (e.g. "+ 1>>" -> fd 1).
if not exist ".vscode" goto :vscode_done
echo.
echo Configuring Code Runner ^(python entry^) to use the .venv ...
set "ROOT=%~dp0"
set "PATCH=%TEMP%\ab_patch_vscode.py"
if exist "%PATCH%" del "%PATCH%"
>>"%PATCH%" echo(import os, re, json, sys
>>"%PATCH%" echo(root = os.environ["ROOT"].rstrip("\\")
>>"%PATCH%" echo(vscode = os.path.join(root, ".vscode")
>>"%PATCH%" echo(settings = os.path.join(vscode, "settings.json")
>>"%PATCH%" echo(pypath = os.path.join(root, ".venv", "Scripts", "python.exe")
>>"%PATCH%" echo(pyentry = json.dumps("python") + ": " + json.dumps('"' + pypath + '" -u')
>>"%PATCH%" echo(newmap = json.dumps("code-runner.executorMap") + ": {" + pyentry + "}"
>>"%PATCH%" echo(q = chr(34)
>>"%PATCH%" echo(bs = chr(92)
>>"%PATCH%" echo(cf = chr(94)
>>"%PATCH%" echo(pipe = chr(124)
>>"%PATCH%" echo(MAP = re.compile(q + "code-runner" + bs + ".executorMap" + q + bs + "s*:" + bs + "s*" + bs + "{[" + cf + "{}]*" + bs + "}")
>>"%PATCH%" echo(PYK = re.compile(q + "python" + q + bs + "s*:" + bs + "s*" + q + "(?:[" + cf + q + bs + bs + "]" + pipe + bs + bs + ".)*" + q)
>>"%PATCH%" echo(def fix(m):
>>"%PATCH%" echo(    obj = m.group(0)
>>"%PATCH%" echo(    i = obj.find("{") + 1
>>"%PATCH%" echo(    return PYK.sub(lambda _x: pyentry, obj) if PYK.search(obj) else obj[:i] + pyentry + ", " + obj[i:]
>>"%PATCH%" echo(if not os.path.isdir(vscode):
>>"%PATCH%" echo(    print("  .vscode not present -- skipping Code Runner config.")
>>"%PATCH%" echo(    sys.exit()
>>"%PATCH%" echo(if not os.path.exists(settings):
>>"%PATCH%" echo(    open(settings, "w", encoding="utf-8").write("{\n    " + newmap + "\n}\n")
>>"%PATCH%" echo(    print("  created settings.json with code-runner.executorMap python entry")
>>"%PATCH%" echo(    sys.exit()
>>"%PATCH%" echo(text = open(settings, encoding="utf-8").read()
>>"%PATCH%" echo(if MAP.search(text):
>>"%PATCH%" echo(    new = MAP.sub(fix, text)
>>"%PATCH%" echo(elif text.find("{") != -1:
>>"%PATCH%" echo(    i = text.find("{") + 1
>>"%PATCH%" echo(    new = text[:i] + "\n    " + newmap + "," + text[i:]
>>"%PATCH%" echo(else:
>>"%PATCH%" echo(    new = text
>>"%PATCH%" echo(if new == text:
>>"%PATCH%" echo(    print("  code-runner.executorMap python entry already up to date -- no change.")
>>"%PATCH%" echo(else:
>>"%PATCH%" echo(    open(settings, "w", encoding="utf-8").write(new)
>>"%PATCH%" echo(    print("  set code-runner.executorMap python entry -> .venv interpreter")
.venv\Scripts\python.exe "%PATCH%"
del "%PATCH%"
:vscode_done

echo.
echo ============================================================
echo  Done. The .venv has the pinned deps, and 'instruments'
echo  imports inside it. Point the TestStand Python Adapter to:
echo    C:\Auto Bench\.venv\Scripts\python.exe
echo ============================================================
pause
