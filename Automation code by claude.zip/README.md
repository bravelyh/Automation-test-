# Auto Bench

Lab automation library: Python 3.14 (64-bit) + TestStand (Python Adapter).
PyInstaller is optional — only for building standalone `tools/` exes for
machines without Python.

## Layout

```
Auto Bench/
├─ .claude/
│  └─ skills/         Claude Code skills (project-scoped helpers)
│
├─ instruments/       hardware abstraction — auto-discovery + drivers
│  ├─ bench.py        Bench facade + CATALOG + BENCH_REGISTRY (single source of truth)
│  ├─ discovery.py    scanner: PC ID (hostname) + COM + VISA, module-level cached
│  │
│  │   Per category, <cat>_base.py is the ONLY public interface — an abstract
│  │   class declaring the method contract (no I/O). The "..." files are the
│  │   concrete drivers: one per model, holding the real comms code
│  │   (SCPI / .NET API / serial) and the function bodies.
│  │
│  ├─ psu/
│  │  ├─ psu_base.py             public interface
│  │  └─ ...                     model drivers (high power supply or 4ch power supply)
│  ├─ dmm/
│  │  ├─ dmm_base.py             public interface
│  │  └─ ...                     model drivers
│  ├─ thermal/
│  │  ├─ thermal_base.py         public interface
│  │  └─ ...                     model drivers  (Shanghai site or Dallas site)
│  ├─ scope/
│  │  ├─ scope_base.py           public interface
│  │  └─ ...                     model drivers
│  ├─ loadbox/                   
│  │  ├─ loadbox_base.py         public interface
│  │  └─ loadbox_SH.py           Shanghai site loadbox driver (Prolific USB-Serial transport)
│  ├─ ap/                        Audio Precision (software-controlled; built via bench.ap())
│  │  ├─ ap_base.py              public interface
│  │  ├─ apx555.py               bench mode + sequence mode
│  │  └─ ap2722.py               bench mode only
│  └─ i2x/                       I2X-AAA bridge (I2C / I2S / GPIO over UART)
│     ├─ i2x_aaa.py              VISA write and Read
│     ├─ i2c_encoder.py          convert scripts to command
│     ├─ i2s_encoder.py          convert audio format to command
│     └─ gpio_encoder.py         convert gpio sequence to command
│
├─ tools/             manual bench GUIs — each folder is self-contained
│  │                  Each tool folder holds (plus its build output):
│  │                    <Tool>.py         GUI source
│  │                    Run <Tool>.bat    launch from source (needs the .venv)
│  │                    build.bat         build a standalone one-file exe on demand
│  │                    dist/<Tool>.exe   build output: ONE exe, git-ignored (not tracked)
│  ├─ I2C Tool/
│  ├─ Loadbox Control/
│  ├─ Power Supply Control/
│  └─ Thermal Stream Control/
│
├─ teststand/
│  ├─ setup/          reusable TS setup steps — Python-Adapter modules (no build)
│  └─ sequence/       TestStand .seq files that reference the above
│     └─ <seq>/tests/ TS test steps — Python modules, run only within their sequence
│
├─ scripts/
│  └─ demo/           runnable demos to validate bench scan and each instrument drivers
│                     
├─ docs/                         data & manuals (not code)
│  ├─ instrument manuals/         SCPI / .NET API manuals (psu, ap, ...)
│  ├─ bench loadbox mapping/     per-bench measured loadbox resistance tables
│  └─ projects/                  per-device I2C configs (I2C Tool device-name lookup)
│
├─ setup_env.bat      one-time setup: build .venv + auto-install imported deps + register instruments
├─ .venv/             per-machine virtual environment (git-ignored, built by setup_env.bat)
├─ README.md
└─ .gitignore
```

## Environment

Two hard rules, enforced on every bench — the whole setup depends on them:

1. **Python 3.14 (64-bit) is the base Python.** `py -3.14` must resolve to it;
   `setup_env.bat` builds the `.venv` from it.
2. **The repo lives at `C:\Auto Bench`.** Same fixed path on every machine, so
   the venv is always at `C:\Auto Bench\.venv` — identical on every bench.

**A per-machine virtual environment lives at `.venv` (repo root).** `.venv` is
**git-ignored — never committed.** Each machine builds its own by running
`setup_env.bat`, which derives the dependency list from the code itself — it
scans every `.py` for third-party imports and installs whatever the venv is
missing. There is no hardcoded package list to maintain, so multiple users
share the repo without touching `setup_env.bat`.

### What `setup_env.bat` does

1. Verifies Python 3.14 (64-bit) is present.
2. Creates `.venv` from it if missing (reuses it otherwise).
3. Upgrades pip, then **syncs dependencies**: scans every `.py` in the repo for
   third-party imports and installs any the `.venv` is missing (latest release;
   not version-pinned). No hardcoded package list.
4. Writes `.venv\Lib\site-packages\auto_bench.pth = C:\Auto Bench`, making
   `instruments` importable by the venv interpreter with no path bootstrap.
5. **If (and only if) a `.vscode\` folder already exists**, points the VS Code
   Code Runner extension's Run button at the venv (see below). It never creates
   `.vscode\`; if the folder is absent the step is silently skipped.

### VS Code Code Runner (optional, step 5)

`.vscode\` is per-user — VS Code (its Python extension) creates it the first
time you open the folder or run a `.py`. It is **not** committed. When it is
present, `setup_env.bat` edits `.vscode\settings.json` so Code Runner's Run
button uses this repo's interpreter, so `import instruments` works from Run with
no per-user setup:

```jsonc
"code-runner.executorMap": { "python": "\"C:\\Auto Bench\\.venv\\Scripts\\python.exe\" -u" }
```

The edit is deliberately surgical: it sets **only** the `python` entry of
`code-runner.executorMap`. Every other language (e.g. `java`), every other
setting, and all comments/formatting are left byte-for-byte intact — an existing
`python` entry is rewritten, a missing one is added, and nothing else is
touched. There is no separate helper script: the patch is a small Python program
generated into a temp file at run time, executed by the venv interpreter, and
deleted.

### When to run it

- **New bench / fresh clone** — builds the `.venv` (first-time setup above).
- **After `git pull` brought in code that imports a new package** — re-run
  `setup_env.bat` and the import scan installs it.

### Adding a dependency (developer)

Just `import` it in your code and commit. The next `setup_env.bat` run on any
bench scans the imports and installs it — **`setup_env.bat` itself needs no
edit.** Two rare exceptions, handled by small tables inside `setup_env.bat`'s
sync helper:

- **Import name ≠ pip name** (e.g. `import serial` → `pyserial`, `clr` →
  `pythonnet`, `PIL` → `pillow`): add the mapping to `NAME_MAP`.
- **Imported but not a pip package** (DLL/.NET-provided, e.g. `AudioPrecision`,
  `System`): add it to `IGNORE` so the sync doesn't try to install it.

Dependencies are installed at their latest release (not version-pinned). To
hold a specific version, install it into the `.venv` by hand
(`.venv\Scripts\python.exe -m pip install <pkg>==<ver>`) — the sync only ever
adds missing packages, it never changes an already-installed one.

## Usage

```python
from instruments.bench import Bench
bench = Bench()                          # auto: hostname + bus scan on 1st access
bench.psu_high_power.open()
bench.psu_high_power.set_voltage(12.0)   # e.g. Chroma 62012P
bench.psu_4ch.set_current(0.5, channel=1) # e.g. GW Instek GPP-4323
bench.dmm.measure_dc_voltage()           # e.g. Keysight 34461A
bench.i2x.i2c_send("w E0 03 22\nr E0 05 1")
```

## Auto-discovery

`Bench()` never uses hardcoded addresses. On first attribute access:
1. `discovery.scan_all()` enumerates every COM port and every VISA resource,
   probing each VISA resource for its `*IDN?` reply.
2. `CATALOG` in `instruments/bench.py` maps each category to a keyword
   (COM description substring or VISA IDN model substring).
3. First match wins → driver instantiated with the discovered address.

Change a USB port, swap a GPIB slot, move an instrument between benches
— no code edits needed. Only new hardware models require a CATALOG entry.

## Bench identity (PC ID → bench id → AP type → load calibration)

Some facts can't be read off a bus — which physical bench a machine *is*,
which Audio Precision analyzer it drives, and the real resistance of that
bench's loadbox. These come from the machine's identity, not its hardware.

1. `discovery.scan_all()` also returns `pc_id` — the machine's hostname
   (e.g. `DT4CE210CTM1`).
2. `BENCH_REGISTRY` in `instruments/bench.py` maps each PC ID to a
   `bench_id` + `ap_type` (e.g. `DT4CE210CTM1` → bench `8`, `APx555`).
3. `bench_id` selects the loadbox calibration file
   `docs/bench loadbox mapping/Bench_#<id>_Loadbox_Value.txt`
   — the *actual measured* resistance per channel, used for calculations
   (e.g. power) instead of the nominal commanded load.

```python
bench = Bench()
bench.pc_id                       # 'DT4CE210CTM1'
bench.bench_id                    # '8'
bench.ap_type                     # 'APx555'  -> pick the AP interface to call
bench.loadbox_values()           # {'1': [1.055, ...], ..., '8': [...]}  ohms
bench.loadbox_resistance(["3","8","1","2"])  # real ohms for CH1..CH4 -> power calc
```

Add a bench: run `hostname` on it and append one row to `BENCH_REGISTRY`,
pointing at a `bench_id` that has a matching loadbox calibration file.

### Typical test flow

1. Scan identity + buses: `pc_id` + COM + VISA.
2. Match hardware via CATALOG; confirm `ap_type` and `bench_id` via
   BENCH_REGISTRY.
3. If the test uses audio, drive the AP through the interface for `ap_type`.
4. If it computes power/current, resolve the real load resistance for this
   bench with `loadbox_resistance(...)` and calculate from measured ohms.

## Bench tools (manual GUIs)

`tools/` holds standalone GUI utilities for driving the bench by hand
(I2C, loadbox, thermal stream, power supply). Each tool is self-contained
in its own folder and builds independently — no shared spec, no shared
`_internal/`.

Two ways to run a tool:

1. **With the `.venv` built (the normal case).** Double-click
   `Run <Tool>.bat` — it launches the `.py` via the repo's
   `.venv\Scripts\pythonw.exe`. No build step, and it always runs the current
   source. (Run `setup_env.bat` once first to create the `.venv`.)
2. **On a machine without Python.** Run `build.bat` inside the tool's
   folder to produce a standalone exe at `dist/<Tool>.exe`, then copy that
   single exe to the target machine — it needs no Python. (`build.bat` uses the
   repo `.venv`, so run `setup_env.bat` first.)

`build.bat` builds **one-file** (`--onefile`): the whole tool collapses
into a single `dist/<Tool>.exe` with no `_internal/` folder, and all temp
artifacts (`build/`, `__pycache__`, the generated `.spec`) are cleaned up
automatically.

`dist/` is **git-ignored — built exes are never committed.** A fresh clone
has the `.py` and both `.bat` files but no exe; anyone who needs an exe
builds it on demand.

## TestStand integration

Configure the TestStand Python Adapter once per machine, pointing at the
repo's virtual-environment interpreter:
```
C:\Auto Bench\.venv\Scripts\python.exe
```
This path is identical on every bench (the repo is fixed at `C:\Auto Bench`),
so the adapter no longer depends on where each user installed Python. Run
`setup_env.bat` first to build the `.venv`.

Everything TestStand calls is a **Python module invoked via the Python
Adapter** — no exes, no `Call Executable`, no build step. Edit a `.py` and
the next run picks it up.

Sequence structure:
- **`teststand/sequence/<seq>/*.seq`** — TestStand sequence files. Steps
  call the setup modules in `teststand/setup/` and the Python modules in
  that sequence's own `tests/` subfolder, both through the Python Adapter.
- **`teststand/setup/`** — reusable setup steps, shared across sequences.
  Each is a module exposing one entry function (e.g. `Set_Power_Supply.py`
  → `set_power_supply(...)`). The function returns its result (TestStand
  captures the return value) and raises on failure (TestStand reports the
  step as failed with the traceback). Each file's docstring lists its
  module/function/argument mapping.
- **`teststand/sequence/<seq>/tests/`** — per-test Python modules, also
  called via the Python Adapter. Each test lives under the sequence it runs
  in; tests are never run standalone.

Every setup/test module can also be run directly for debugging
(`.venv\Scripts\python.exe "Set_Power_Supply.py" --pvdd-voltage 12`) — each
keeps a thin CLI shim around its entry function.

Migrating a step from the old exe model, and the full step→module→function
mapping, are documented in **`teststand/README.md`**.

## Claude Code skills

Project-scoped skills live under `.claude/skills/`. They ship with the
repo so anyone cloning gets the same helpers.
