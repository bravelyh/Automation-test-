# OscViewer

A desktop oscilloscope waveform viewer for Tektronix `.wfm` files, built for audio amplifier (TAS6584/6684/6884) validation work.  
Single-file Python application (~1800 lines) — everything lives in `oscviewer.py`.

---

## Requirements

```
Python  3.10+  (3.12 / 3.14 recommended)
PyQt5   5.15+
pyqtgraph 0.14+
numpy   1.24+
scipy   1.10+
pandas  (optional, for CSV loading)
```

Install all at once:

```bash
pip install PyQt5 pyqtgraph scipy numpy pandas
```

---

## Launch

```bash
python oscviewer.py
# or double-click OscViewer.bat  (no console window)
```

Load files from the command line:

```bash
python oscviewer.py CH1_Yellow_1.25GSa_s.wfm CH2_Cyan_1.25GSa_s.wfm
```

The GUI opens empty — it does not connect to anything on launch, so it never
blocks the window from showing up. Use the toolbar's **Reload Scope** button
to pull the live waveform from this bench's oscilloscope once the window is
up (see **Live Oscilloscope** below).

---

## Supported File Formats

| Format | Description |
|---|---|
| `.wfm` | Tektronix WFM v3 (`:WFM#003`, little-endian, output of SCPI `CURVE` command) |
| `.csv` | First column = time, subsequent columns = channel voltages |
| `.txt` | Same as CSV |

**Filename convention** (channel name / color / sample rate parsed automatically):

```
CH1_Yellow_1.25GSa_s.wfm   →  CH1, yellow, 1.25 GSa/s
CH3_Red_250MSa_s.wfm       →  CH3, red, 250 MSa/s
```

Recognized color keywords: `yellow cyan red green blue magenta orange white pink purple`

---

## UI Layout

```
┌──────────┬─────────────────────────────────────────┐
│ Channels │        Waveform area (Stacked/Overlay)   │
│ (left)   │                                         │
├──────────┴─────────────────────────────────────────┤
│              Measurements (bottom card bar)         │
└─────────────────────────────────────────────────────┘
```

---

## Mouse Interactions

| Action | Effect |
|---|---|
| Drag & drop files | Load waveforms (multiple files at once) |
| Shift + scroll wheel | Zoom X axis (time) |
| Ctrl + scroll wheel | Zoom Y axis (voltage) |
| Left drag | Pan X + Y |
| Shift + left drag | Rubber-band → zoom X only; Y auto-fits to full data range |
| Ctrl + left drag | Rubber-band → zoom Y only; X stays at current range |
| Left double-click | Auto Scale (fit to full data) |
| Right click | Context menu |

---

## Right-Click Menu

- **Add Measurement** → select channel → select metric → adds card to bottom panel
- **Phase** → select two channels, computes phase difference (FFT method)
- **Cursor Snap** (Overlay mode) → choose which channel cursors snap to, or Free
- **Switch to Stacked / Overlay** → toggle display mode
- **Enable / Disable Cursors** → toggle cursors
- **Zoom In / Zoom Out** → X axis ×2 / ÷2
- **Auto Scale All** → fit all channels to full data range
- **Clear All** → remove all channels

---

## Display Modes

### Stacked (default)
Each channel has its own independent Y-axis; X-axes are linked. Best when channels have very different voltage ranges (e.g. CH1/CH2 at ±12 V and CH3/CH4 at ±60 mV).

### Overlay
All channels share the same X/Y axes with raw voltage values overlaid.

---

## Cursors

When enabled, each channel in Stacked mode gets its own independent cursor pair:

- **T1/T2** (blue dashed): vertical cursors — show T and V in real time while dragging; snap to nearest sample on release
- **H1/H2** (orange dashed): horizontal cursors — show voltage value
- **Delta readout** (top-right of each plot): live ΔT / f = 1/ΔT / ΔV

---

## Measurement Cards

Added via right-click → **Add Measurement**. Each card shows a live value for one channel metric.

Available metrics:  
`Vmax` `Vmin` `Vpp` `Vmean` `Vrms` `Vac-rms` `Freq` `Period` `Rise` `Fall` `Duty%` `Overshoot` `Undershoot` `Phase`

Values update automatically when the view is panned or zoomed (computed on visible window only).

---

## FFT Window

Open via toolbar **FFT** button. Separate window.

- Computed on the currently visible time window, capped at 65536 points (stride subsampling)
- **Follow view**: auto-refreshes when the main waveform view pans/zooms
- **Cursor** checkbox: draggable vertical cursor showing frequency and magnitude
- Right-click (cursor active) → **Set cursor frequency…**: type a frequency to jump to (e.g. `480 kHz`, `2.1 MHz`)
- Shift / Ctrl + drag to zoom X / Y independently (same as main window)

---

## Digital Filter

Toolbar **Filter** button. Opens a dialog with a live frequency response preview.

| Parameter | Description |
|---|---|
| Type | Butterworth / Chebyshev I / FIR (window) |
| Response | LP / HP / BP / BS |
| Order | Filter order 1–10 |
| fc1 | Cutoff frequency — accepts `480k`, `480kHz`, `1.25MHz` etc. |
| fc2 | Upper bound (BP / BS only) |

The right panel shows the frequency response in real time as parameters change.  
A red dashed line marks −3 dB. A draggable cursor reads frequency and magnitude.  
X-axis is centered on fc1 (passband + rolloff visible). Y-axis clamped to −80 dB to +5 dB.

---

## Live Oscilloscope

OscViewer can pull waveforms straight from this bench's scope, through the
Auto Bench instrument abstraction layer (`Bench().scope()` +
`ScopeBase.save_waveform_files`) — no raw SCPI ever leaves this file.

| When | What happens |
|---|---|
| Toolbar **Reload Scope** (F5) | Clears all channels and captures fresh from the scope, on a background thread so the window stays responsive while the GPIB transfer runs |
| Toolbar **Save WFM** | Prompts for a folder, then saves the scope's currently displayed channels there as native `.wfm` files (`CH<n>_<color>_<rate>.wfm`) — does not touch what's shown in the viewer |

Nothing connects automatically on launch — the GPIB/USB session opens on the
first Reload / Save WFM click and is kept open for later ones. If no scope is
found on the bench (or it's unreachable), the error shows in a dialog instead
of blocking the UI.

---

## Math Channels

Toolbar **Math** button. Supports arbitrary expression evaluation:

```
CH1 + CH2       addition
CH1 - CH2       subtraction
CH1 * CH2       multiplication
abs(CH1)        absolute value
diff(CH1)       differentiation  (numpy.gradient)
integ(CH1)      integration      (cumulative sum)
CH1 / 2         scalar operation
```

Click a channel name button to insert it at the cursor position in the expression field.

---

## Code Structure (`oscviewer.py`)

```
Channel              Data model (dataclass) — t, v arrays + metadata
load_file            File loader entry point (.wfm / .csv)
_parse_wfm_v3        Tektronix WFM v3 binary parser
                     Key offsets: dt@488, t0@496, n_pts@504, curve_start@838

MEAS_FUNCS           Dict of measurement functions (all auto-measure metrics)
MeasCard             Single measurement card widget
MeasurementPanel     Bottom measurement panel

_RightClickViewBox   Custom ViewBox — all mouse interaction logic lives here
_ChannelPlot         Single-channel PlotWidget for Stacked mode
_OverlayPlot         Shared PlotWidget for Overlay mode
WaveformWidget       Main waveform area (QWidget + QSplitter)
  _decimate          Min-max downsampling: 5M pts → 4000 pts, peaks preserved

_CursorPair          Cursor pair for one channel (T1/T2 + H1/H2 + delta label)
CursorManager        Manages all cursor pairs across sub-plots

ChannelPanel         Left channel list (visibility / color / rename / delete)
FFTWindow            FFT spectrum window
FreqEdit             Frequency input widget (auto kHz/MHz display + flexible parsing)
FilterDialog         Digital filter dialog (with live frequency response preview)
MathDialog           Math channel dialog
MainWindow           Main application window
```

---

## WFM Parser Notes

Tektronix WFM v3 (MDO/DPO/TBS series, saved via SCPI `CURVE` command):

```
Byte order flag    offset   0 : 0x0F0F = little-endian
Curve buffer start offset  16 : 838 (fixed)
Voltage scale      offset 168 : ymult  (V per ADC count)
Voltage offset     offset 176 : yoff   (V)
Data type          offset 240 : 7 = int8, 0 = int16
Time step (dt)     offset 488 : seconds per sample
Time origin (t0)   offset 496 : seconds
Point count        offset 504 : n_pts
Raw ADC data       byte   838 : n_pts × itemsize bytes

Voltage conversion: v = yoff + ymult × raw_adc
```

---

## Performance Notes

- **Downsampling**: 5M points → 4000 points. On every pan/zoom, data is sliced to the visible time range first, then decimated — zooming in actually gets faster.
- **FFT**: visible window + stride subsampling to ≤65536 points, ~18 ms per refresh.
- **autoRange**: `sigRangeChanged` is disconnected before calling `setRange`, then manually reconnected, to prevent the feedback loop that causes UI freeze when zoomed far out.

---

## Known Limitations

- Only Tektronix WFM v3 (`:WFM#003`) is supported
- Live scope support is capture-only (reload, save) — no remote
  trigger/timebase/channel-scale control from this viewer
- No XY mode, persistence display, or protocol decoding
