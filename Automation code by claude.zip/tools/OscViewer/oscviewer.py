# -*- coding: utf-8 -*-
"""Oscilloscope Waveform Viewer — single-file edition."""

# ── stdlib / third-party imports ──────────────────────────────────────────────
import csv
import io
import os
import re
import struct
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import pyqtgraph as pg
from scipy import signal as sig

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from instruments.bench import Bench

from PyQt5.QtCore import Qt, QEvent, QObject, QThread, QTimer, pyqtSignal
from PyQt5.QtGui import QBrush, QColor, QCursor, QFont, QKeySequence
from PyQt5.QtWidgets import (
    QAction, QApplication, QCheckBox, QColorDialog, QComboBox,
    QDialog, QDockWidget, QDoubleSpinBox, QFileDialog, QFormLayout,
    QFrame, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMainWindow, QMenu, QMessageBox, QProgressBar, QPushButton,
    QScrollArea, QSpinBox, QSplitter, QStatusBar, QToolBar, QVBoxLayout,
    QWidget,
)

pg.setConfigOptions(antialias=False, useOpenGL=False)


# ═══════════════════════════════════════════════════════════════════════════════
# WFM PARSER
# ═══════════════════════════════════════════════════════════════════════════════

_COLOR_MAP = {
    "yellow": (255, 255, 0), "cyan":  (0, 220, 255), "red":    (255, 70, 70),
    "green":  (0, 230, 100), "blue":  (80, 140, 255), "magenta":(255, 0, 255),
    "orange": (255, 160, 0), "white": (220, 220, 220), "pink":  (255, 150, 180),
    "purple": (180, 80, 255),
}
_DEFAULT_COLORS = [
    (255, 255, 0), (0, 220, 255), (255, 70, 70),
    (0, 230, 100), (255, 160, 0), (180, 80, 255),
]
CHANNEL_COLORS = _DEFAULT_COLORS

_SA_RE = re.compile(r'(\d+(?:\.\d+)?)\s*([KMGT]?)Sa[_/]?s', re.IGNORECASE)
_CH_RE = re.compile(r'\b(CH\d+|MATH\d*|REF\d*)\b', re.IGNORECASE)
_PREFIX = {'K': 1e3, 'M': 1e6, 'G': 1e9, 'T': 1e12, '': 1.0}

_DTYPE_MAP = {
    0: (np.int16, 2), 1: (np.int32, 4), 2: (np.uint32, 4), 3: (np.uint64, 8),
    4: (np.float32, 4), 5: (np.float64, 8), 6: (np.uint8, 1), 7: (np.int8, 1),
}


@dataclass
class Channel:
    name: str
    t: np.ndarray
    v: np.ndarray
    unit_t: str = "s"
    unit_v: str = "V"
    color: tuple = (255, 255, 0)
    visible: bool = True
    is_math: bool = False
    is_filter: bool = False   # produced by apply_filter (a filtered channel)
    source_file: str = ""
    sample_rate: float = 0.0
    from_scope: bool = False

    @property
    def dt(self) -> float:
        if self.sample_rate > 0:
            return 1.0 / self.sample_rate
        return float(self.t[1] - self.t[0]) if len(self.t) > 1 else 0.0


def _parse_filename(path: str) -> Tuple[str, tuple, float]:
    stem  = Path(path).stem
    parts = re.split(r'[_\-\s]+', stem)
    name  = "CH1"
    for p in parts:
        m = _CH_RE.match(p)
        if m: name = m.group(1).upper(); break
    color = _DEFAULT_COLORS[0]
    for p in parts:
        c = _COLOR_MAP.get(p.lower())
        if c: color = c; break
    sr = 0.0
    m = _SA_RE.search(stem)
    if m:
        sr = float(m.group(1)) * _PREFIX.get(m.group(2).upper() if m.group(2) else '', 1.0)
    return name, color, sr


def _parse_wfm_v3(data: bytes, path: str) -> Channel:
    if len(data) < 840:
        raise ValueError(f"File too short ({len(data)} B)")
    e = '<' if struct.unpack_from('>H', data, 0)[0] == 0x0F0F else '>'
    u4 = lambda off: struct.unpack_from(e + 'I', data, off)[0]
    d8 = lambda off: struct.unpack_from(e + 'd', data, off)[0]
    curve_off = u4(16); ymult = d8(168); yoff_v = d8(176)
    data_type = u4(240); dt = d8(488); t0 = d8(496); n_pts = u4(504)
    dtype, itemsize = _DTYPE_MAP.get(data_type, (np.int8, 1))
    avail = (len(data) - curve_off) // itemsize
    if n_pts == 0 or n_pts > avail: n_pts = avail
    raw = np.frombuffer(data[curve_off: curve_off + n_pts * itemsize], dtype=dtype)
    if e == '>': raw = raw.byteswap()
    name, color, sr_fname = _parse_filename(path)
    return Channel(name=name, t=t0 + dt * np.arange(n_pts),
                   v=yoff_v + ymult * raw.astype(np.float64),
                   color=color, source_file=path,
                   sample_rate=(1.0 / dt) if dt > 0 else sr_fname)


def load_wfm(path: str) -> List[Channel]:
    with open(path, 'rb') as f:
        data = f.read()
    if b'WFM' not in data[2:10]:
        raise ValueError(f"Not a Tektronix WFM file")
    return [_parse_wfm_v3(data, path)]


def capture_live_channels(scope) -> List[Channel]:
    """Grab every currently displayed channel from an already-open `scope`.

    Goes through the abstraction layer only: `ScopeBase.save_waveform_files`
    (native wfm export) to pull the data, then the same `load_wfm` parser
    used for files on disk. Does NOT open or close the connection — the
    caller owns that (MainWindow opens fresh and closes right after, for
    every single Reload; the GPIB/USB session is never held open between
    clicks).
    """
    with tempfile.TemporaryDirectory(prefix="oscviewer_") as tmp:
        paths = scope.save_waveform_files(tmp)
        channels: List[Channel] = []
        for p in paths:
            for ch in load_wfm(p):
                ch.from_scope = True
                channels.append(ch)
        return channels


def load_file(path: str) -> List[Channel]:
    p = Path(path)
    if p.suffix.lower() == '.wfm':
        return load_wfm(path)
    elif p.suffix.lower() in ('.csv', '.txt'):
        import pandas as pd
        df = pd.read_csv(path, header=None, skiprows=1)
        t = df.iloc[:, 0].values.astype(float)
        _, _, sr = _parse_filename(path)
        sr_i = sr if sr > 0 else (1.0 / (t[1] - t[0]) if len(t) > 1 else 0.0)
        return [Channel(name=f"CH{i}", t=t, v=df.iloc[:, i].values.astype(float),
                        color=_DEFAULT_COLORS[(i-1) % len(_DEFAULT_COLORS)],
                        source_file=path, sample_rate=sr_i)
                for i in range(1, df.shape[1])]
    raise ValueError(f"Unsupported file type: {p.suffix}")


# ═══════════════════════════════════════════════════════════════════════════════
# MEASUREMENT PANEL
# ═══════════════════════════════════════════════════════════════════════════════

def _zero_crossings_freq(t, v):
    mean = np.mean(v)
    idx = np.where(np.diff(((v - mean) > 0).astype(int)) > 0)[0]
    return (1.0 / np.mean(np.diff(t[idx]))) if len(idx) >= 2 else None

def _rise_time(t, v):
    vmin, vmax = np.min(v), np.max(v)
    span = vmax - vmin
    if span < 1e-12: return None
    lo, hi = vmin + 0.1*span, vmin + 0.9*span
    rising = np.where(np.diff((v >= lo).astype(int)) > 0)[0]
    if not len(rising): return None
    cross = np.where(v[rising[0]:] >= hi)[0]
    return float(t[rising[0] + cross[0]] - t[rising[0]]) if len(cross) else None

def _fall_time(t, v):
    vmin, vmax = np.min(v), np.max(v)
    span = vmax - vmin
    if span < 1e-12: return None
    lo, hi = vmin + 0.1*span, vmin + 0.9*span
    falling = np.where(np.diff((v <= hi).astype(int)) > 0)[0]
    if not len(falling): return None
    cross = np.where(v[falling[0]:] <= lo)[0]
    return float(t[falling[0] + cross[0]] - t[falling[0]]) if len(cross) else None

def _duty_cycle(t, v):
    above = (v > np.mean(v)).astype(int)
    return 100.0 * above.sum() / len(above) if len(above) else None

def _high_low_levels(v):
    """Estimate steady-state high/low using histogram top/bottom 20%."""
    vmin, vmax = float(np.min(v)), float(np.max(v))
    vpp = vmax - vmin
    if vpp < 1e-12: return None, None
    v_high = float(np.mean(v[v > vmin + 0.8 * vpp]))
    v_low  = float(np.mean(v[v < vmin + 0.2 * vpp]))
    return v_high, v_low

def _overshoot(t, v):
    v_high, _ = _high_low_levels(v)
    if v_high is None: return None
    vpp = float(np.max(v) - np.min(v))
    val = (float(np.max(v)) - v_high) / vpp * 100
    return max(0.0, val)

def _undershoot(t, v):
    _, v_low = _high_low_levels(v)
    if v_low is None: return None
    vpp = float(np.max(v) - np.min(v))
    val = (v_low - float(np.min(v))) / vpp * 100
    return max(0.0, val)

def compute_phase_deg(ch_a, ch_b, t_start=None, t_stop=None):
    ta, va, tb, vb = ch_a.t, ch_a.v, ch_b.t, ch_b.v
    if t_start is not None:
        ma = (ta >= t_start) & (ta <= t_stop)
        mb = (tb >= t_start) & (tb <= t_stop)
        if ma.sum() > 4 and mb.sum() > 4:
            ta, va, tb, vb = ta[ma], va[ma], tb[mb], vb[mb]
    vb_r = np.interp(ta, tb, vb)
    va_n = va - va.mean(); vb_n = vb_r - vb_r.mean()
    if np.std(va_n) * np.std(vb_n) < 1e-12: return None
    fa = np.fft.rfft(va_n); fb = np.fft.rfft(vb_n)
    idx = np.argmax(np.abs(fa[1:])) + 1
    return float(np.degrees(np.angle(fb[idx]) - np.angle(fa[idx])) % 360)

MEAS_FUNCS = {
    "Vmax":    lambda t, v: float(np.max(v)),
    "Vmin":    lambda t, v: float(np.min(v)),
    "Vpp":     lambda t, v: float(np.max(v) - np.min(v)),
    "Vmean":   lambda t, v: float(np.mean(v)),
    "Vrms":    lambda t, v: float(np.sqrt(np.mean(v**2))),
    "Vac-rms": lambda t, v: float(np.std(v)),
    "Freq":    lambda t, v: _zero_crossings_freq(t, v),
    "Period":  lambda t, v: (1.0 / _zero_crossings_freq(t, v)) if _zero_crossings_freq(t, v) else None,
    "Rise":    lambda t, v: _rise_time(t, v),
    "Fall":    lambda t, v: _fall_time(t, v),
    "Duty%":      lambda t, v: _duty_cycle(t, v),
    "Overshoot":  lambda t, v: _overshoot(t, v),
    "Undershoot": lambda t, v: _undershoot(t, v),
}
MEAS_UNITS = {
    "Vmax":"V","Vmin":"V","Vpp":"V","Vmean":"V","Vrms":"V","Vac-rms":"V",
    "Freq":"Hz","Period":"s","Rise":"s","Fall":"s","Duty%":"%",
    "Overshoot":"%","Undershoot":"%",
}

def _fmt_meas(val, unit):
    if val is None: return "—"
    if unit == "Hz":
        if abs(val) >= 1e9:  return f"{val/1e9:.4f} GHz"
        if abs(val) >= 1e6:  return f"{val/1e6:.4f} MHz"
        if abs(val) >= 1e3:  return f"{val/1e3:.4f} kHz"
        return f"{val:.4f} Hz"
    if unit == "s":
        at = abs(val)
        if at >= 1:    return f"{val:.4f} s"
        if at >= 1e-3: return f"{val*1e3:.4f} ms"
        if at >= 1e-6: return f"{val*1e6:.4f} µs"
        if at >= 1e-9: return f"{val*1e9:.4f} ns"
        return f"{val*1e12:.4f} ps"
    if unit in ("%", "°"): return f"{val:.2f}{unit}"
    return f"{val:.4f} {unit}".strip()


class MeasCard(QFrame):
    removed = pyqtSignal(object)

    def __init__(self, ch_name, color_rgb, meas_name, parent=None):
        super().__init__(parent)
        self.ch_name = ch_name; self.meas_name = meas_name
        self._unit = MEAS_UNITS.get(meas_name, "")
        r, g, b = color_rgb
        self.setFrameShape(QFrame.StyledPanel)
        self.setFixedSize(130, 64)
        self.setStyleSheet(f"MeasCard{{background:#2a2a2a;border:1px solid rgb({r},{g},{b});border-radius:5px;}}")
        layout = QVBoxLayout(self); layout.setContentsMargins(6, 4, 6, 4); layout.setSpacing(2)
        hdr = QHBoxLayout(); hdr.setSpacing(2)
        lbl = QLabel(f"{ch_name}  {meas_name}")
        lbl.setStyleSheet(f"color:rgb({r},{g},{b});font-size:10px;")
        hdr.addWidget(lbl); hdr.addStretch()
        btn = QPushButton("×"); btn.setFixedSize(16, 16)
        btn.setStyleSheet("QPushButton{background:transparent;color:#888;border:none;font-size:12px;}QPushButton:hover{color:#fff;}")
        btn.clicked.connect(lambda: self.removed.emit(self))
        hdr.addWidget(btn); layout.addLayout(hdr)
        self._val = QLabel("—")
        f = QFont(); f.setPointSize(13); f.setBold(True)
        self._val.setFont(f); self._val.setAlignment(Qt.AlignCenter)
        self._val.setStyleSheet("color:#e8e8e8;"); layout.addWidget(self._val)

    def refresh(self, channels, t0=None, t1=None):
        if self.ch_name.startswith("PHASE:"):
            _, rn, tn = self.ch_name.split(":")
            ca = next((c for c in channels if c.name == rn), None)
            cb = next((c for c in channels if c.name == tn), None)
            if ca is None or cb is None: self._val.setText("—"); return
            try: self._val.setText(_fmt_meas(compute_phase_deg(ca, cb, t0, t1), "°"))
            except Exception: self._val.setText("err")
            return
        ch = next((c for c in channels if c.name == self.ch_name), None)
        if ch is None or not ch.visible: self._val.setText("—"); return
        t, v = ch.t, ch.v
        if t0 is not None:
            mask = (t >= t0) & (t <= t1)
            if mask.sum() > 2: t, v = t[mask], v[mask]
        try: self._val.setText(_fmt_meas(MEAS_FUNCS[self.meas_name](t, v), self._unit))
        except Exception: self._val.setText("err")


class MeasurementPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._cards = []; self._channels = []
        self.setFixedHeight(84)
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        self._cont = QWidget()
        self._box  = QHBoxLayout(self._cont)
        self._box.setContentsMargins(4, 4, 4, 4); self._box.setSpacing(6)
        self._box.addStretch(); self._scroll.setWidget(self._cont)
        outer = QHBoxLayout(self); outer.setContentsMargins(4, 0, 4, 0); outer.setSpacing(0)
        outer.addWidget(self._scroll)

    def set_channels(self, channels):
        self._channels = channels
        names = {c.name for c in channels}
        for card in list(self._cards):
            if card.ch_name not in names and not card.ch_name.startswith("PHASE:"):
                self._remove_card(card)

    def add_card(self, ch_name, meas_name):
        if ch_name.startswith("PHASE:"):
            _, rn, _ = ch_name.split(":")
            ch = next((c for c in self._channels if c.name == rn), None)
            color = ch.color if ch else (180, 180, 180)
            card = MeasCard(ch_name, color, "Phase")
        else:
            ch = next((c for c in self._channels if c.name == ch_name), None)
            if ch is None: return
            card = MeasCard(ch.name, ch.color, meas_name)
        card.removed.connect(self._remove_card)
        self._cards.append(card)
        self._box.insertWidget(self._box.count() - 1, card)
        self.update_values()

    def _remove_card(self, card):
        self._cards.remove(card); self._box.removeWidget(card); card.deleteLater()

    def update(self, channels, t0=None, t1=None):
        self._channels = channels; self.update_values(t0, t1)

    def update_values(self, t0=None, t1=None):
        for card in self._cards: card.refresh(self._channels, t0, t1)


# ═══════════════════════════════════════════════════════════════════════════════
# WAVEFORM WIDGET
# ═══════════════════════════════════════════════════════════════════════════════

MAX_RENDER_PTS = 4000
OVERLAY = 'overlay'
STACKED = 'stacked'


def _decimate(t, v, max_pts=MAX_RENDER_PTS):
    """Min-max decimation for stacked mode: preserves peaks, shows full envelope."""
    n = len(t)
    if n <= max_pts: return t, v
    buckets = max_pts // 2; factor = n // buckets; trim = factor * buckets
    t_r = t[:trim].reshape(buckets, factor); v_r = v[:trim].reshape(buckets, factor)
    t_out = np.empty(buckets * 2, dtype=t.dtype); v_out = np.empty(buckets * 2, dtype=v.dtype)
    t_out[0::2] = t_r[:, 0]; t_out[1::2] = t_r[:, 0]
    v_out[0::2] = v_r.min(axis=1); v_out[1::2] = v_r.max(axis=1)
    return t_out, v_out


def _decimate_line(t, v, max_pts=MAX_RENDER_PTS):
    """Simple stride decimation for overlay mode: thin lines, no fill effect."""
    n = len(t)
    if n <= max_pts: return t, v
    stride = n // max_pts
    return t[::stride], v[::stride]


class _RightClickViewBox(pg.ViewBox):
    sigRightClicked  = pyqtSignal()
    sigDoubleClicked = pyqtSignal()
    sigXZoomRect     = pyqtSignal(float, float)   # Shift+drag → x0, x1; Y 拉满
    sigYZoomRect     = pyqtSignal(float, float)   # Ctrl+drag  → y0, y1; X 拉满

    # ── click ────────────────────────────────────────────────────────────────
    def mouseClickEvent(self, ev):
        if ev.button() == Qt.RightButton:
            ev.accept(); self.sigRightClicked.emit()
        elif ev.double() and ev.button() == Qt.LeftButton:
            ev.accept(); self.sigDoubleClicked.emit()
        else:
            super().mouseClickEvent(ev)

    # ── scroll wheel ─────────────────────────────────────────────────────────
    def wheelEvent(self, ev, axis=None):
        mods = ev.modifiers()
        if mods & Qt.ControlModifier:
            super().wheelEvent(ev, axis=1)    # Ctrl+滚轮 → Y 轴缩放
        elif mods & Qt.ShiftModifier:
            super().wheelEvent(ev, axis=0)    # Shift+滚轮 → X 轴缩放
        else:
            ev.accept()                       # 裸滚轮 → 禁用

    # ── rubber band (full-height for X zoom, full-width for Y zoom) ──────────
    def updateScaleBox(self, p1, p2):
        mode = getattr(self, '_drag_mode', 'pan')
        if mode == 'x_zoom':
            sb = self.sceneBoundingRect()
            p1 = pg.Point(p1.x(), sb.top())
            p2 = pg.Point(p2.x(), sb.bottom())
        elif mode == 'y_zoom':
            sb = self.sceneBoundingRect()
            p1 = pg.Point(sb.left(),  p1.y())
            p2 = pg.Point(sb.right(), p2.y())
        super().updateScaleBox(p1, p2)

    # ── drag ─────────────────────────────────────────────────────────────────
    def mouseDragEvent(self, ev, axis=None):
        if ev.button() == Qt.RightButton:
            ev.ignore(); return

        if ev.button() == Qt.LeftButton:
            if ev.isStart():
                mods = ev.modifiers()
                if mods & Qt.ShiftModifier:
                    self._drag_mode = 'x_zoom'   # Shift → X 框选，Y 拉满
                elif mods & Qt.ControlModifier:
                    self._drag_mode = 'y_zoom'   # Ctrl  → Y 框选，X 拉满
                else:
                    self._drag_mode = 'pan'

            mode = getattr(self, '_drag_mode', 'pan')

            if mode in ('x_zoom', 'y_zoom'):
                ev.accept()
                if ev.isFinish():
                    self._drag_mode = 'pan'
                    try: self.rbScaleBox.hide()
                    except Exception: pass
                    from PyQt5.QtCore import QRectF
                    ax = QRectF(pg.Point(ev.buttonDownPos(ev.button())),
                                pg.Point(ev.pos()))
                    ax = self.childGroup.mapRectFromParent(ax)
                    if mode == 'x_zoom' and ax.width() > 1e-15:
                        self.sigXZoomRect.emit(float(ax.left()), float(ax.right()))
                    elif mode == 'y_zoom' and ax.height() > 1e-15:
                        y0 = float(min(ax.top(), ax.bottom()))
                        y1 = float(max(ax.top(), ax.bottom()))
                        self.sigYZoomRect.emit(y0, y1)
                else:
                    self.updateScaleBox(ev.buttonDownPos(), ev.pos())
            else:
                if ev.isFinish(): self._drag_mode = 'pan'
                super().mouseDragEvent(ev, axis=None)   # pan both axes
        else:
            super().mouseDragEvent(ev, axis=axis)


class _ChannelPlot(pg.PlotWidget):
    def __init__(self, ch, master_vb=None):
        vb = _RightClickViewBox()
        super().__init__(background='#111111', viewBox=vb)
        self.ch = ch; r, g, b = ch.color
        self.setLabel('left', ch.name, units='V', color=f'#{r:02x}{g:02x}{b:02x}', size='10pt')
        self.showGrid(x=True, y=True, alpha=0.2); self.setMinimumHeight(80)
        if master_vb: self.getViewBox().setXLink(master_vb)
        self.getAxis('bottom').setStyle(showValues=False); self.getAxis('bottom').setLabel('')
        self._curve = self.plot([], [], pen=pg.mkPen(color=(r, g, b), width=1), name=ch.name)

    def update_data(self, t0, t1):
        t, v = self.ch.t, self.ch.v; margin = max((t1-t0)*0.05, 1e-9)
        lo = np.searchsorted(t, t0-margin); hi = np.searchsorted(t, t1+margin)
        tv, vv = t[lo:hi], v[lo:hi]
        if len(tv) == 0: tv, vv = t, v
        self._curve.setData(*_decimate(tv, vv))

    def auto_scale_y(self): self.enableAutoRange(axis='y')
    @property
    def vb(self): return self.getViewBox()


class _OverlayPlot(pg.PlotWidget):
    def __init__(self):
        vb = _RightClickViewBox()
        super().__init__(background='#111111', viewBox=vb)
        self.showGrid(x=True, y=True, alpha=0.25)
        self.setLabel('bottom', 'Time', units='s')
        self.setLabel('left', 'Voltage', units='V')
        self.addLegend(offset=(10, 10))
        self._curves    = {}
        self._ch_order  = []    # ordered list of channel names for slot assignment

    def set_channels(self, channels):
        for curve in self._curves.values():
            try: self.removeItem(curve)
            except Exception: pass
        self._curves.clear()
        try:
            if self.plotItem.legend is not None:
                self.plotItem.legend.scene().removeItem(self.plotItem.legend)
                self.plotItem.legend = None
        except Exception: pass
        self.addLegend(offset=(10, 10))
        for ch in channels:
            r, g, b = ch.color
            self._curves[ch.name] = self.plot([], [], pen=pg.mkPen(color=(r,g,b), width=1), name=ch.name)
        self.setLabel('left', 'Voltage', units='V')

    def update_data(self, channels, t0, t1):
        for ch in channels:
            if ch.name not in self._curves: continue
            t, v = ch.t, ch.v; margin = max((t1-t0)*0.05, 1e-9)
            lo = np.searchsorted(t, t0-margin); hi = np.searchsorted(t, t1+margin)
            tv, vv = t[lo:hi], v[lo:hi]
            if len(tv) == 0: tv, vv = t, v
            self._curves[ch.name].setData(*_decimate(tv, vv))

    @property
    def vb(self): return self.getViewBox()


_MENU_STYLE = """
    QMenu{background:#2d2d2d;color:#e0e0e0;border:1px solid #555;}
    QMenu::item{padding:4px 20px 4px 8px;}
    QMenu::item:selected{background:#505050;}
    QMenu::separator{height:1px;background:#444;margin:2px 4px;}
"""


class WaveformWidget(QWidget):
    view_changed              = pyqtSignal()
    channel_clicked           = pyqtSignal(str)
    add_measurement_requested = pyqtSignal(str, str)
    cursor_snap_requested     = pyqtSignal(str)
    cursor_toggle_requested   = pyqtSignal()
    clear_requested           = pyqtSignal()
    _cursor_active            = False   # kept in sync by MainWindow

    def __init__(self, parent=None):
        super().__init__(parent)
        self._channels = []; self._sub_plots = []; self._overlay = None
        self._mode = STACKED; self._updating = False; self._master_vb = None
        self._splitter = QSplitter(Qt.Vertical)
        self._splitter.setHandleWidth(2)
        self._splitter.setStyleSheet("QSplitter::handle{background:#333;}")
        lay = QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        lay.addWidget(self._splitter)

    def set_mode(self, mode):
        self._mode = mode; self._rebuild_plots()

    def toggle_mode(self):
        self.set_mode(OVERLAY if self._mode == STACKED else STACKED); return self._mode

    @property
    def mode(self): return self._mode

    def set_channels(self, channels):
        self._channels = channels; self._rebuild_plots()

    def refresh(self): self._rebuild_plots()

    def get_view_range(self):
        f = self._first_plot()
        return (f.viewRange()[0][0], f.viewRange()[0][1]) if f else (0.0, 1.0)

    def autoRange(self):
        """One-shot range fit, range-change signal disconnected during execution."""
        visible = [ch for ch in self._channels if ch.visible and len(ch.t) > 0]
        if not visible or not self._master_vb: return

        # Disconnect to prevent sigRangeChanged → _update_data → setData feedback loop
        try:
            self._master_vb.sigRangeChanged.disconnect(self._on_range_changed)
        except Exception:
            pass

        try:
            x0 = float(min(ch.t.min() for ch in visible))
            x1 = float(max(ch.t.max() for ch in visible))
            pad_x = (x1 - x0) * 0.02

            if self._mode == STACKED and self._sub_plots:
                self._master_vb.setXRange(x0 - pad_x, x1 + pad_x, padding=0)
                for sp in self._sub_plots:
                    vmin = float(sp.ch.v.min())
                    vmax = float(sp.ch.v.max())
                    pad_y = (vmax - vmin) * 0.08 if vmax > vmin else 1.0
                    sp.getViewBox().setYRange(vmin - pad_y, vmax + pad_y, padding=0)

            elif self._overlay:
                y0 = float(min(ch.v.min() for ch in visible))
                y1 = float(max(ch.v.max() for ch in visible))
                pad_y = (y1 - y0) * 0.08 if y1 > y0 else 1.0
                self._overlay.getViewBox().setRange(
                    xRange=(x0 - pad_x, x1 + pad_x),
                    yRange=(y0 - pad_y, y1 + pad_y),
                    padding=0, disableAutoRange=True)
        finally:
            # Reconnect, then manually update data once for the new range
            self._master_vb.sigRangeChanged.connect(self._on_range_changed)

        self._update_data()
        self.view_changed.emit()

    def zoom_x(self, factor):
        """factor < 1 = zoom in, factor > 1 = zoom out."""
        if not self._master_vb: return
        vr = self._master_vb.viewRange()
        x0, x1 = vr[0]
        cx = (x0 + x1) / 2
        hw = (x1 - x0) / 2 * factor
        self._master_vb.setXRange(cx - hw, cx + hw, padding=0)

    def addItem(self, item):
        for sp in self._sub_plots:
            try: sp.addItem(item, ignoreBounds=True)
            except Exception: pass
        if self._overlay:
            try: self._overlay.addItem(item, ignoreBounds=True)
            except Exception: pass

    def removeItem(self, item):
        for sp in self._sub_plots:
            try: sp.removeItem(item)
            except Exception: pass
        if self._overlay:
            try: self._overlay.removeItem(item)
            except Exception: pass

    def viewRange(self):
        f = self._first_plot(); return f.viewRange() if f else [[0,1],[0,1]]

    # ── zoom helpers (called by ViewBox signals) ──────────────────────────────

    def _with_range_blocked(self, fn):
        """Execute fn() with sigRangeChanged disconnected, then update once."""
        try:
            self._master_vb.sigRangeChanged.disconnect(self._on_range_changed)
        except Exception: pass
        try:
            fn()
        finally:
            self._master_vb.sigRangeChanged.connect(self._on_range_changed)
        self._update_data(); self.view_changed.emit()

    def _do_x_zoom(self, x0, x1):
        """Shift+drag: zoom X to [x0,x1], Y → full data range per channel."""
        visible = [ch for ch in self._channels if ch.visible]
        def _set():
            self._master_vb.setXRange(x0, x1, padding=0)
            if self._mode == STACKED:
                for sp in self._sub_plots:
                    vmin, vmax = float(sp.ch.v.min()), float(sp.ch.v.max())
                    pad = (vmax - vmin) * 0.08 if vmax > vmin else 1.0
                    sp.getViewBox().setYRange(vmin - pad, vmax + pad, padding=0)
            elif self._overlay and visible:
                y0 = float(min(ch.v.min() for ch in visible))
                y1 = float(max(ch.v.max() for ch in visible))
                pad = (y1 - y0) * 0.08 if y1 > y0 else 1.0
                self._overlay.getViewBox().setYRange(y0 - pad, y1 + pad, padding=0)
        self._with_range_blocked(_set)

    def _do_y_zoom(self, sub_plot, y0, y1):
        """Ctrl+drag: zoom Y to [y0,y1], X stays at current view range."""
        def _set():
            pad = (y1 - y0) * 0.08 if y1 > y0 else 1.0
            if sub_plot is not None:
                sub_plot.getViewBox().setYRange(y0 - pad, y1 + pad, padding=0)
            elif self._overlay:
                self._overlay.getViewBox().setYRange(y0 - pad, y1 + pad, padding=0)
        self._with_range_blocked(_set)

    def _first_plot(self):
        if self._mode == STACKED and self._sub_plots: return self._sub_plots[0]
        if self._mode == OVERLAY and self._overlay:   return self._overlay
        return None

    def _clear_plots(self):
        while self._splitter.count():
            w = self._splitter.widget(0); w.setParent(None); w.deleteLater()
        self._sub_plots.clear(); self._overlay = None; self._master_vb = None

    def _rebuild_plots(self):
        self._clear_plots()
        visible = [ch for ch in self._channels if ch.visible]
        if not visible: return
        if self._mode == OVERLAY: self._build_overlay(visible)
        else: self._build_stacked(visible)
        self._update_data()
        QTimer.singleShot(0, self.autoRange)   # defer: allow render cycle before fitting

    def _build_stacked(self, visible):
        for i, ch in enumerate(visible):
            sp = _ChannelPlot(ch, master_vb=self._master_vb)
            if i == 0:
                self._master_vb = sp.vb
                self._master_vb.sigRangeChanged.connect(self._on_range_changed)
            if i == len(visible) - 1:
                sp.getAxis('bottom').setStyle(showValues=True)
                sp.setLabel('bottom', 'Time', units='s')
            sp.vb.sigRightClicked.connect(lambda ch=ch: self._show_context_menu(ch.name))
            sp.vb.sigDoubleClicked.connect(self.autoRange)
            sp.vb.sigXZoomRect.connect(self._do_x_zoom)
            sp.vb.sigYZoomRect.connect(lambda y0, y1, s=sp: self._do_y_zoom(s, y0, y1))
            self._splitter.addWidget(sp); self._sub_plots.append(sp)
        h = max(1, self._splitter.height())
        self._splitter.setSizes([h // len(visible)] * len(visible))

    def _build_overlay(self, visible):
        self._overlay = _OverlayPlot(); self._overlay.set_channels(visible)
        self._master_vb = self._overlay.vb
        self._master_vb.sigRangeChanged.connect(self._on_range_changed)
        self._overlay.vb.sigRightClicked.connect(lambda: self._show_context_menu(None))
        self._overlay.vb.sigDoubleClicked.connect(self.autoRange)
        self._overlay.vb.sigXZoomRect.connect(self._do_x_zoom)
        self._overlay.vb.sigYZoomRect.connect(lambda y0, y1: self._do_y_zoom(None, y0, y1))
        self._splitter.addWidget(self._overlay)

    def _on_range_changed(self): self._update_data(); self.view_changed.emit()

    def _update_data(self):
        if self._updating: return
        self._updating = True
        try:
            t0, t1 = self.get_view_range()
            if self._mode == STACKED:
                for sp in self._sub_plots: sp.update_data(t0, t1)
            elif self._overlay:
                self._overlay.update_data(self._channels, t0, t1)
        finally: self._updating = False

    def _show_context_menu(self, clicked_ch_name=None):
        menu = QMenu(); menu.setStyleSheet(_MENU_STYLE)
        visible = [ch for ch in self._channels if ch.visible]
        if visible:
            mm = menu.addMenu("Add Measurement"); mm.setStyleSheet(_MENU_STYLE)
            for ch in visible:
                cs = mm.addMenu(ch.name); cs.setStyleSheet(_MENU_STYLE)
                for meas in MEAS_FUNCS:
                    a = QAction(meas, cs)
                    a.triggered.connect(lambda c, cn=ch.name, mn=meas: self.add_measurement_requested.emit(cn, mn))
                    cs.addAction(a)
            if len(visible) >= 2:
                pm = menu.addMenu("Phase"); pm.setStyleSheet(_MENU_STYLE)
                for ref in visible:
                    for tgt in visible:
                        if ref.name == tgt.name: continue
                        a = QAction(f"{tgt.name} vs {ref.name}", pm)
                        a.triggered.connect(lambda c, r=ref.name, t=tgt.name:
                            self.add_measurement_requested.emit(f"PHASE:{r}:{t}", "Phase"))
                        pm.addAction(a)
            menu.addSeparator()
        if self._mode == OVERLAY and visible:
            # Cursor snap submenu
            sm = menu.addMenu("Cursor Snap"); sm.setStyleSheet(_MENU_STYLE)
            nsnap = QAction("No snap (free)", sm)
            nsnap.triggered.connect(lambda: self.cursor_snap_requested.emit(""))
            sm.addAction(nsnap)
            for ch in visible:
                a = QAction(f"Snap to {ch.name}", sm)
                a.triggered.connect(lambda c, n=ch.name: self.cursor_snap_requested.emit(n))
                sm.addAction(a)
            menu.addSeparator()
        ml = "Switch to Stacked" if self._mode == OVERLAY else "Switch to Overlay"
        ma = QAction(ml, menu); ma.triggered.connect(self.toggle_mode); menu.addAction(ma)
        menu.addSeparator()

        # Cursor toggle
        cur_lbl = "Disable Cursors" if self._cursor_active else "Enable Cursors"
        ca = QAction(cur_lbl, menu); ca.triggered.connect(self.cursor_toggle_requested); menu.addAction(ca)
        menu.addSeparator()

        # Zoom
        zi = QAction("Zoom In  (+)", menu);  zi.triggered.connect(lambda: self.zoom_x(0.5));  menu.addAction(zi)
        zo = QAction("Zoom Out (-)", menu);  zo.triggered.connect(lambda: self.zoom_x(2.0));  menu.addAction(zo)
        menu.addSeparator()

        # Auto scale
        aa = QAction("Auto Scale All", menu); aa.triggered.connect(self.autoRange); menu.addAction(aa)
        if clicked_ch_name and self._mode == STACKED:
            sp = next((s for s in self._sub_plots if s.ch.name == clicked_ch_name), None)
            if sp:
                a = QAction(f"Auto Scale  {clicked_ch_name}", menu)
                a.triggered.connect(sp.auto_scale_y); menu.addAction(a)
        menu.addSeparator()

        # Clear
        cla = QAction("Clear All", menu); cla.triggered.connect(self.clear_requested); menu.addAction(cla)
        menu.exec_(QCursor.pos())


# ═══════════════════════════════════════════════════════════════════════════════
# CURSOR MANAGER
# ═══════════════════════════════════════════════════════════════════════════════

def _fmt_t(t):
    at = abs(t)
    if at == 0:    return "0 s"
    if at >= 1:    return f"{t:.6f} s"
    if at >= 1e-3: return f"{t*1e3:.4f} ms"
    if at >= 1e-6: return f"{t*1e6:.4f} µs"
    return f"{t*1e9:.3f} ns"

def _fmt_f(f):
    if f is None or not np.isfinite(f): return "—"
    af = abs(f)
    if af >= 1e9: return f"{f/1e9:.4f} GHz"
    if af >= 1e6: return f"{f/1e6:.4f} MHz"
    if af >= 1e3: return f"{f/1e3:.4f} kHz"
    return f"{f:.4f} Hz"

def _fmt_v_cur(v):
    return f"{v*1e3:.4f} mV" if 0 < abs(v) < 0.1 else f"{v:.4f} V"

def _parse_freq_str(s):
    """Parse '480 kHz', '1.25MHz', '625000000', etc. → Hz float. Returns None on error."""
    import re
    m = re.match(r'^\s*([\d.]+)\s*(g|m|k|hz)?\s*(?:hz)?\s*$', s.strip(), re.IGNORECASE)
    if not m: return None
    val = float(m.group(1))
    unit = (m.group(2) or '').lower()
    mult = {'g': 1e9, 'm': 1e6, 'k': 1e3, 'hz': 1, '': 1}.get(unit, 1)
    return val * mult

def _nearest(t_axis, v_axis, x):
    idx = int(np.clip(np.searchsorted(t_axis, x), 0, len(t_axis)-1))
    if idx > 0 and abs(t_axis[idx-1]-x) < abs(t_axis[idx]-x): idx -= 1
    return float(t_axis[idx]), float(v_axis[idx])


class _CursorPair:
    PEN_V = pg.mkPen(color=(160,200,255), width=1, style=2)
    PEN_H = pg.mkPen(color=(255,200,140), width=1, style=2)
    DOT   = {'size':9, 'pen':pg.mkPen('w'), 'brush':pg.mkBrush(255,255,255,220)}

    def __init__(self, plot, channel):
        self.plot = plot; self.ch = channel; self._t1 = self._t2 = None
        self._v1 = pg.InfiniteLine(angle=90, movable=True, pen=self.PEN_V,
                                   label='T1', labelOpts={'position':0.95,'color':'#9cc'})
        self._v2 = pg.InfiniteLine(angle=90, movable=True, pen=self.PEN_V,
                                   label='T2', labelOpts={'position':0.90,'color':'#9cc'})
        self._h1 = pg.InfiniteLine(angle=0, movable=True, pen=self.PEN_H,
                                   label='H1', labelOpts={'position':0.05,'color':'#fca'})
        self._h2 = pg.InfiniteLine(angle=0, movable=True, pen=self.PEN_H,
                                   label='H2', labelOpts={'position':0.05,'color':'#fca'})
        self._dot1 = pg.ScatterPlotItem(**self.DOT); self._dot2 = pg.ScatterPlotItem(**self.DOT)
        _f = (25,25,25,210)
        self._lbl1 = pg.TextItem(anchor=(0,1), color='#cce', fill=_f)
        self._lbl2 = pg.TextItem(anchor=(0,1), color='#cce', fill=_f)
        self._hlbl1= pg.TextItem(anchor=(0,0), color='#fca', fill=_f)
        self._hlbl2= pg.TextItem(anchor=(0,0), color='#fca', fill=_f)
        self._dlbl = pg.TextItem(anchor=(1,0), color='#ffe', fill=(20,20,20,230))
        self._dlbl.setZValue(100)
        for item in (self._v1,self._v2,self._h1,self._h2,self._dot1,self._dot2,
                     self._lbl1,self._lbl2,self._hlbl1,self._hlbl2,self._dlbl):
            item.setZValue(60); plot.addItem(item, ignoreBounds=True)
        self._v1.sigPositionChangeFinished.connect(lambda l: self._snap_v(l,1))
        self._v2.sigPositionChangeFinished.connect(lambda l: self._snap_v(l,2))
        self._v1.sigPositionChanged.connect(lambda l: self._live_v(l,1))
        self._v2.sigPositionChanged.connect(lambda l: self._live_v(l,2))
        self._h1.sigPositionChanged.connect(self._live_h)
        self._h2.sigPositionChanged.connect(self._live_h)
        plot.getViewBox().sigRangeChanged.connect(self._reposition)
        self._place_defaults()

    def _place_defaults(self):
        vr = self.plot.viewRange(); x0,x1=vr[0]; y0,y1=vr[1]
        if self.ch is not None and len(self.ch.t)>1:
            t1,_ = _nearest(self.ch.t,self.ch.v, x0+(x1-x0)*0.3)
            t2,_ = _nearest(self.ch.t,self.ch.v, x0+(x1-x0)*0.7)
        else: t1=x0+(x1-x0)*0.3; t2=x0+(x1-x0)*0.7
        self._v1.setValue(t1); self._v2.setValue(t2); self._t1=t1; self._t2=t2
        self._h1.setValue(y0+(y1-y0)*0.65); self._h2.setValue(y0+(y1-y0)*0.35)
        self._refresh()

    def _snap_v(self, line, idx):
        if self.ch is not None and len(self.ch.t)>1:
            t,_ = _nearest(self.ch.t,self.ch.v,line.value())
            line.blockSignals(True); line.setValue(t); line.blockSignals(False)
        if idx==1: self._t1=line.value()
        else:      self._t2=line.value()
        self._refresh()

    def _live_v(self, line, idx):
        pos = line.value()
        if self.ch is not None and len(self.ch.t)>1: t,v = _nearest(self.ch.t,self.ch.v,pos)
        else: t,v = pos,0.0
        dot = self._dot1 if idx==1 else self._dot2
        lbl = self._lbl1 if idx==1 else self._lbl2
        if self.ch is not None:
            dot.setData([t],[v]); lbl.setPos(pos,v)
            lbl.setText(f"T{'1' if idx==1 else '2'}={_fmt_t(pos)}\nV={_fmt_v_cur(v)}")
        self._refresh_delta()

    def _live_h(self): self._refresh_hlabels(); self._refresh_delta()

    def _refresh(self):
        t1p=self._v1.value(); t2p=self._v2.value()
        if self.ch is not None and len(self.ch.t)>1:
            t1,v1=_nearest(self.ch.t,self.ch.v,t1p); t2,v2=_nearest(self.ch.t,self.ch.v,t2p)
            self._dot1.setData([t1],[v1]); self._dot2.setData([t2],[v2])
            self._lbl1.setPos(t1p,v1); self._lbl1.setText(f"T1={_fmt_t(t1)}\nV={_fmt_v_cur(v1)}")
            self._lbl2.setPos(t2p,v2); self._lbl2.setText(f"T2={_fmt_t(t2)}\nV={_fmt_v_cur(v2)}")
        else:
            self._dot1.setData([],[]); self._dot2.setData([],[])
            self._lbl1.setText(''); self._lbl2.setText('')
        self._refresh_hlabels(); self._refresh_delta()

    def _refresh_hlabels(self):
        vr=self.plot.viewRange(); x0=vr[0][0]
        self._hlbl1.setPos(x0,self._h1.value()); self._hlbl1.setText(f"H1={_fmt_v_cur(self._h1.value())}")
        self._hlbl2.setPos(x0,self._h2.value()); self._hlbl2.setText(f"H2={_fmt_v_cur(self._h2.value())}")

    def _refresh_delta(self):
        dt=self._v2.value()-self._v1.value(); dh=self._h2.value()-self._h1.value()
        freq=(1.0/dt) if dt!=0 else None
        dv_str=""
        if self.ch is not None and len(self.ch.t)>1:
            _,v1=_nearest(self.ch.t,self.ch.v,self._v1.value())
            _,v2=_nearest(self.ch.t,self.ch.v,self._v2.value())
            dv_str=f"ΔV(wave) = {_fmt_v_cur(v2-v1)}\n"
        self._dlbl.setText(f"── Time ──\nΔT = {_fmt_t(dt)}\nf  = {_fmt_f(freq)}\n── Voltage ──\n{dv_str}ΔH = {_fmt_v_cur(dh)}")
        self._reposition()

    def _reposition(self):
        vr=self.plot.viewRange(); self._dlbl.setPos(vr[0][1],vr[1][1])

    def remove(self):
        try: self.plot.getViewBox().sigRangeChanged.disconnect(self._reposition)
        except Exception: pass
        for item in (self._v1,self._v2,self._h1,self._h2,self._dot1,self._dot2,
                     self._lbl1,self._lbl2,self._hlbl1,self._hlbl2,self._dlbl):
            try: self.plot.removeItem(item)
            except Exception: pass

    def set_channel(self, ch): self.ch=ch; self._refresh()


_CURSOR_UNSET = object()


class CursorManager(QObject):
    cursor_changed = pyqtSignal()

    def __init__(self, wave_widget):
        super().__init__()
        self._wave = wave_widget; self._active = False
        self._pairs = []; self.snap_channel_name = _CURSOR_UNSET

    def set_active(self, active):
        self._active = active
        for p in self._pairs: p.remove()
        self._pairs.clear()
        if not active: return
        visible = [ch for ch in self._wave._channels if ch.visible]
        if self._wave.mode == STACKED:
            for sp in self._wave._sub_plots:
                if len(sp.ch.t)>1: self._pairs.append(_CursorPair(sp, sp.ch))
        elif self._wave._overlay and visible:
            if self.snap_channel_name is _CURSOR_UNSET: snap_ch=visible[0]
            elif self.snap_channel_name is None:        snap_ch=None
            else: snap_ch=next((c for c in visible if c.name==self.snap_channel_name), visible[0])
            self._pairs.append(_CursorPair(self._wave._overlay, snap_ch))

    def set_snap_channel(self, ch_name):
        self.snap_channel_name = ch_name
        if self._active: self.set_active(True)

    def update_readout(self):
        for p in self._pairs: p._refresh()

    @property
    def active(self): return self._active


# ═══════════════════════════════════════════════════════════════════════════════
# CHANNEL PANEL
# ═══════════════════════════════════════════════════════════════════════════════

class ChannelPanel(QWidget):
    visibility_changed = pyqtSignal()
    color_changed      = pyqtSignal()
    channel_deleted    = pyqtSignal(object)   # emits Channel object

    def __init__(self, parent=None):
        super().__init__(parent)
        self._channels = []; self.setMaximumWidth(180)
        title = QLabel("Channels"); title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-weight:bold;padding:4px;")
        self._list = QListWidget()
        self._list.setStyleSheet("QListWidget{background:#1a1a1a;}")
        self._list.setContextMenuPolicy(Qt.CustomContextMenu)
        self._list.itemClicked.connect(self._on_click)
        self._list.itemDoubleClicked.connect(self._on_double_click)
        self._list.customContextMenuRequested.connect(self._on_right_click)
        lay = QVBoxLayout(self); lay.setContentsMargins(4,4,4,4)
        lay.addWidget(title); lay.addWidget(self._list)

    def set_channels(self, channels):
        self._channels = channels; self._refresh()

    def _refresh(self):
        self._list.clear()
        for ch in self._channels:
            item = QListWidgetItem()
            item.setText(f"  {'◉' if ch.visible else '○'}  {ch.name}")
            r,g,b = ch.color
            item.setForeground(QBrush(QColor(r,g,b)))
            item.setBackground(QBrush(QColor(30,30,30)))
            self._list.addItem(item)

    def _on_click(self, item):
        idx = self._list.row(item)
        if 0 <= idx < len(self._channels):
            self._channels[idx].visible = not self._channels[idx].visible
            self._refresh(); self.visibility_changed.emit()

    def _on_double_click(self, item):
        self._change_color(self._list.row(item))

    def _on_right_click(self, pos):
        item = self._list.itemAt(pos)
        if item is None: return
        idx = self._list.row(item)
        if not (0 <= idx < len(self._channels)): return
        ch = self._channels[idx]

        menu = QMenu(self); menu.setStyleSheet(_MENU_STYLE)

        rename_a = QAction("Rename…", menu)
        rename_a.triggered.connect(lambda: self._rename(idx))
        menu.addAction(rename_a)

        color_a = QAction("Change color…", menu)
        color_a.triggered.connect(lambda: self._change_color(idx))
        menu.addAction(color_a)

        menu.addSeparator()

        del_a = QAction(f"Delete  {ch.name}", menu)
        del_a.triggered.connect(lambda: self._delete(idx))
        menu.addAction(del_a)

        menu.exec_(self._list.viewport().mapToGlobal(pos))

    def _rename(self, idx):
        from PyQt5.QtWidgets import QInputDialog
        ch = self._channels[idx]
        new_name, ok = QInputDialog.getText(self, "Rename Channel",
                                            "New name:", text=ch.name)
        if ok and new_name.strip():
            ch.name = new_name.strip()
            self._refresh(); self.visibility_changed.emit()

    def _change_color(self, idx):
        if not (0 <= idx < len(self._channels)): return
        ch = self._channels[idx]; r,g,b = ch.color
        nc = QColorDialog.getColor(QColor(r,g,b), self, f"Color: {ch.name}")
        if nc.isValid():
            ch.color = (nc.red(), nc.green(), nc.blue())
            self._refresh(); self.color_changed.emit()

    def _delete(self, idx):
        ch = self._channels[idx]
        self.channel_deleted.emit(ch)


# ═══════════════════════════════════════════════════════════════════════════════
# FFT WINDOW
# ═══════════════════════════════════════════════════════════════════════════════

# Max spectrum points sent to the plot. This is a DISPLAY cap only — the FFT
# itself always runs on the full record (see refresh()), so the frequency axis
# reaches the true Nyquist (fs/2) and there is no aliasing from source
# decimation. Only the drawn curve is thinned, and via min/max so peaks survive.
MAX_PLOT_PTS = 8192
_FFT_WINDOWS = {
    "Hann": np.hanning, "Rectangular": np.ones,
    "Hamming": np.hamming, "Blackman": np.blackman,
}


def _decimate_spectrum(freqs, y, max_pts=MAX_PLOT_PTS):
    """Min/max-decimate an FFT trace for DISPLAY only, preserving peaks.

    Returns (freqs, y) unchanged if already small enough.

    Buckets in LOG-FREQUENCY space, not by array index. The spectrum axis is
    displayed on a log scale, and rfft bins are LINEARLY spaced — so equal-index
    buckets crush the whole low-frequency region (a 1 kHz peak on a 250 MSa/s
    record sits in bin ~20 of 2.5M and would share one 30 kHz-wide bucket with
    everything up to 30 kHz, leaving the decade around it with almost no drawn
    points). Log-frequency buckets give every decade the same point density, so
    a narrow low-frequency peak survives and is actually visible. Within each
    bucket we still emit the min AND max of y (at their true frequencies) so a
    tall narrow peak is never strided away.
    """
    n = len(freqs)
    if n <= max_pts:
        return freqs, y
    buckets = max_pts // 2
    f0 = freqs[0] if freqs[0] > 0 else freqs[1]      # avoid log(0) at DC
    edges = np.logspace(np.log10(f0), np.log10(freqs[-1]), buckets + 1)
    # bucket index of each spectrum point (clip so the last edge is inclusive)
    idx = np.clip(np.searchsorted(edges, freqs, side='right') - 1, 0, buckets - 1)
    f_out = []; y_out = []
    # np.minimum.at / segment reductions: do it vectorized per bucket via sort
    order = np.argsort(idx, kind='stable')
    idx_s = idx[order]; f_s = freqs[order]; y_s = y[order]
    starts = np.searchsorted(idx_s, np.arange(buckets), side='left')
    ends   = np.searchsorted(idx_s, np.arange(buckets), side='right')
    for b in range(buckets):
        s, e = starts[b], ends[b]
        if s == e:
            continue                                  # empty log bucket
        yb = y_s[s:e]; fb = f_s[s:e]
        i_lo = yb.argmin(); i_hi = yb.argmax()
        # emit the two extrema in frequency order (no backward zig-zag on x)
        if fb[i_lo] <= fb[i_hi]:
            f_out += [fb[i_lo], fb[i_hi]]; y_out += [yb[i_lo], yb[i_hi]]
        else:
            f_out += [fb[i_hi], fb[i_lo]]; y_out += [yb[i_hi], yb[i_lo]]
    return np.asarray(f_out, dtype=freqs.dtype), np.asarray(y_out, dtype=y.dtype)


class FFTWindow(QWidget):
    def __init__(self, channels=None, waveform_widget=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("FFT Spectrum"); self.resize(900, 460)
        self._channels = channels or []; self._ww = waveform_widget
        self._spectra  = {}   # ch.name -> (freqs, y) for cursor readout

        # ── toolbar ───────────────────────────────────────────────────────────
        tb = QHBoxLayout()
        tb.addWidget(QLabel("Source:")); self._src = QComboBox(); tb.addWidget(self._src)
        tb.addWidget(QLabel("Window:")); self._win = QComboBox()
        self._win.addItems(list(_FFT_WINDOWS.keys())); tb.addWidget(self._win)
        self._db = QCheckBox("dB"); self._db.setChecked(True); tb.addWidget(self._db)
        self._cur_chk = QCheckBox("Cursor"); self._cur_chk.stateChanged.connect(self._toggle_cursor)
        tb.addWidget(self._cur_chk)
        # Refresh recomputes the FFT for the main waveform's CURRENT view range.
        # The FFT does NOT auto-follow drags/zooms of the main waveform — a full
        # FFT is ~0.2s and doing it every drag frame froze the main plot. Click
        # Refresh to re-sync to the current view.
        btn = QPushButton("Refresh"); btn.clicked.connect(self.refresh)
        btn.setToolTip("Recompute FFT for the main waveform's current view range")
        tb.addWidget(btn)
        save_btn = QPushButton("Save PNG"); save_btn.clicked.connect(self._save_png); tb.addWidget(save_btn)
        self._info = QLabel(""); self._info.setStyleSheet("color:#888;font-size:10px;"); tb.addWidget(self._info)
        tb.addStretch()

        # ── plot — uses same ViewBox as main waveform (same interaction logic) ──
        _fft_vb = _RightClickViewBox()
        self._plot = pg.PlotWidget(background='#111111', viewBox=_fft_vb)
        self._plot.setLabel('bottom', 'Frequency', units='Hz')
        self._plot.setLabel('left', 'Magnitude', units='dB')
        self._plot.showGrid(x=True, y=True, alpha=0.3)
        self._plot.setLogMode(x=True, y=False)
        self._plot.addLegend()
        _fft_vb.sigDoubleClicked.connect(self._plot.autoRange)
        _fft_vb.sigRightClicked.connect(self._on_right_click)
        _fft_vb.sigXZoomRect.connect(self._on_x_zoom)
        _fft_vb.sigYZoomRect.connect(self._on_y_zoom)

        lay = QVBoxLayout(self); lay.addLayout(tb); lay.addWidget(self._plot)

        # ── cursor ────────────────────────────────────────────────────────────
        _pen = pg.mkPen(color=(200, 200, 255), width=1, style=2)
        self._cur_line = pg.InfiniteLine(angle=90, movable=True, pen=_pen)
        # anchor=(0,0): top-left of label at pos → text stays inside plot
        self._cur_lbl  = pg.TextItem(anchor=(0, 0), color='#dde',
                                     fill=(20, 20, 20, 220))
        self._cur_lbl.setZValue(100)
        self._cursor_active = False

        self._src.currentIndexChanged.connect(self.refresh)
        self._win.currentIndexChanged.connect(self.refresh)
        self._db.stateChanged.connect(self.refresh)
        # Live update while dragging
        self._cur_line.sigPositionChanged.connect(self._update_cursor_lbl)
        self._plot.getViewBox().sigRangeChanged.connect(self._reposition_cursor_lbl)
        # NOTE: intentionally NOT connected to waveform_widget.view_changed — the
        # FFT is recomputed only on demand (Refresh button), never on every drag.
        if channels: self.set_channels(channels)

    # ── public ────────────────────────────────────────────────────────────────

    def set_channels(self, channels):
        self._channels = [ch for ch in channels if ch.visible]
        cur = self._src.currentText()
        self._src.blockSignals(True); self._src.clear()
        self._src.addItem("All visible")
        for ch in self._channels: self._src.addItem(ch.name)
        self._src.setCurrentIndex(max(0, self._src.findText(cur)))
        self._src.blockSignals(False); self.refresh()

    def refresh(self):
        self._plot.clear(); self._spectra.clear()
        if not self._channels: return
        t0, t1 = (self._ww.get_view_range() if self._ww else (None, None))
        idx     = self._src.currentIndex()
        targets = self._channels if idx == 0 else [self._channels[idx - 1]]
        win_fn  = _FFT_WINDOWS[self._win.currentText()]; use_db = self._db.isChecked()
        n_raw   = 0
        n_plot  = 0
        for ch in targets:
            t, v = ch.t, ch.v
            if t0 is not None:
                lo = np.searchsorted(t, t0); hi = np.searchsorted(t, t1)
                if hi - lo > 4: t, v = t[lo:hi], v[lo:hi]
            # FFT on the FULL record (no source decimation): the frequency axis
            # reaches the true Nyquist fs/2, and there is no aliasing.
            n     = len(v)
            n_raw = n
            fs    = ch.sample_rate
            w     = win_fn(n); spec = np.fft.rfft(v * w)
            freqs = np.fft.rfftfreq(n, d=1.0 / fs)
            mag   = np.abs(spec) * 2 / np.sum(w)
            y     = 20 * np.log10(np.maximum(mag, 1e-12)) if use_db else mag
            mask  = freqs > 0
            f_full, y_full = freqs[mask], y[mask]
            # Store the FULL spectrum for the cursor (accurate readout), but
            # decimate only what we hand to the plot so drawing stays fast.
            self._spectra[ch.name] = (f_full, y_full)
            f_plot, y_plot = _decimate_spectrum(f_full, y_full)
            n_plot = len(f_plot)
            r, g, b = ch.color
            self._plot.plot(f_plot, y_plot,
                            pen=pg.mkPen(color=(r, g, b), width=1), name=ch.name)

        fmax = (n_raw and ch.sample_rate / 2.0) or 0.0
        info = f"{n_raw:,} pts  |  Nyquist {_fmt_f(fmax)}"
        if n_plot < (n_raw // 2 if n_raw else 0):
            info += f"  |  drawn {n_plot:,} pts"
        if t0 is not None: info += f"  |  window {(t1-t0)*1e3:.3f} ms"
        self._info.setText(info)
        self._plot.setLabel('left', 'Magnitude (dB)' if use_db else 'Magnitude')

        # Re-add cursor items after clear
        if self._cursor_active:
            self._plot.addItem(self._cur_line, ignoreBounds=True)
            self._plot.addItem(self._cur_lbl,  ignoreBounds=True)
            self._update_cursor_lbl()

    # ── zoom (Shift/Ctrl + drag) ──────────────────────────────────────────────

    def _on_x_zoom(self, x0, x1):
        """Shift+drag: zoom X (frequency axis) only, Y unchanged."""
        self._plot.getViewBox().setXRange(x0, x1, padding=0)

    def _on_y_zoom(self, y0, y1):
        """Ctrl+drag: zoom Y (magnitude), X stays at current view range."""
        self._plot.getViewBox().setYRange(y0, y1, padding=0)

    # ── right-click menu ──────────────────────────────────────────────────────

    def _on_right_click(self):
        if not self._cursor_active:
            return
        from PyQt5.QtWidgets import QMenu, QAction, QInputDialog
        menu = QMenu(self)
        menu.setStyleSheet(_MENU_STYLE)

        set_act = QAction("Set cursor frequency…", menu)
        set_act.triggered.connect(self._set_cursor_freq_dialog)
        menu.addAction(set_act)
        menu.exec_(QCursor.pos())

    def _set_cursor_freq_dialog(self):
        from PyQt5.QtWidgets import QInputDialog
        cur_hz = self._log_to_hz(self._cur_line.value())
        freq_str, ok = QInputDialog.getText(
            self, "Set Cursor Frequency",
            "Frequency (Hz, kHz, or MHz):",
            text=_fmt_f(cur_hz)
        )
        if not ok or not freq_str.strip():
            return
        hz = _parse_freq_str(freq_str.strip())
        if hz is not None and hz > 0:
            self._cur_line.setValue(np.log10(hz))
            self._update_cursor_lbl()

    # ── cursor ────────────────────────────────────────────────────────────────

    def _toggle_cursor(self, state):
        self._cursor_active = bool(state)
        if self._cursor_active:
            self._plot.addItem(self._cur_line, ignoreBounds=True)
            self._plot.addItem(self._cur_lbl,  ignoreBounds=True)
            vr = self._plot.viewRange()
            self._cur_line.setValue((vr[0][0] + vr[0][1]) / 2)
            self._update_cursor_lbl()
        else:
            for item in (self._cur_line, self._cur_lbl):
                try: self._plot.removeItem(item)
                except Exception: pass

    def _log_to_hz(self, log_val):
        """Convert ViewBox x-coordinate (log10 space) back to Hz."""
        try: return float(10 ** log_val)
        except Exception: return 1.0

    def _update_cursor_lbl(self):
        if not self._cursor_active or not self._spectra: return
        freq_hz = self._log_to_hz(self._cur_line.value())
        use_db  = self._db.isChecked()
        lines   = []
        for ch_name, (freqs, y) in self._spectra.items():
            if len(freqs) == 0: continue
            idx      = int(np.argmin(np.abs(freqs - freq_hz)))
            f_actual = float(freqs[idx])
            amp      = float(y[idx])
            unit     = " dB" if use_db else ""
            lines.append(f"{ch_name}:  {_fmt_f(f_actual)}  {amp:.2f}{unit}")
        self._cur_lbl.setText('\n'.join(lines) if lines else "")
        self._reposition_cursor_lbl()

    def _reposition_cursor_lbl(self):
        if not self._cursor_active: return
        vr = self._plot.viewRange()
        # Place label just below the top of the Y range, at cursor X
        y_top = vr[1][1] - (vr[1][1] - vr[1][0]) * 0.02
        self._cur_lbl.setPos(self._cur_line.value(), y_top)

    def _save_png(self):
        if not self._spectra:
            QMessageBox.information(self,"No data","Nothing to export — compute an FFT first."); return
        start_dir = getattr(self, "_last_dir", str(Path.home()))
        path,_ = QFileDialog.getSaveFileName(self,"Save FFT PNG",start_dir,"PNG files (*.png)")
        if not path: return
        if not path.lower().endswith(".png"): path += ".png"
        self._last_dir = str(Path(path).parent)
        # Render the FFT plot's own scene at a fixed resolution (independent of
        # the window's current size), same approach as the waveform export.
        try:
            img = _export_plotitem(self._plot.plotItem, 1600)
            ok = img.save(path, "PNG")
        except Exception as e:
            QMessageBox.critical(self,"Export Error",f"Could not export PNG:\n{e}"); return
        if not ok:
            QMessageBox.critical(self,"Export Error",f"Could not write PNG:\n{path}")


# ═══════════════════════════════════════════════════════════════════════════════
# FILTER DIALOG
# ═══════════════════════════════════════════════════════════════════════════════

def apply_filter(channel, ftype, response, order, fc1, fc2=0.0):
    fs = channel.sample_rate; nyq = fs / 2.0
    if fc1 <= 0 or fc1 >= nyq: raise ValueError(f"fc1={fc1:.1f} Hz out of range (0, {nyq:.1f})")
    Wn = [fc1/nyq, fc2/nyq] if response in ('BP','BS') else fc1/nyq
    if response in ('BP','BS') and (fc2 <= fc1 or fc2 >= nyq):
        raise ValueError(f"fc2 must be > fc1 and < {nyq:.1f} Hz")
    btype = {'LP':'low','HP':'high','BP':'bandpass','BS':'bandstop'}[response]
    label = f"{ftype} {response} fc={fc1:.0f}Hz"
    color = CHANNEL_COLORS[hash(label) % len(CHANNEL_COLORS)]
    name  = f"{channel.name}_{response}_{fc1:.0f}Hz"
    if ftype == 'FIR (window)':
        numtaps = order*10+1
        h = (sig.firwin(numtaps,fc1/nyq) if response=='LP' else
             sig.firwin(numtaps,fc1/nyq,pass_zero=False) if response=='HP' else
             sig.firwin(numtaps,[fc1/nyq,fc2/nyq],pass_zero=False) if response=='BP' else
             sig.firwin(numtaps,[fc1/nyq,fc2/nyq]))
        zi=sig.lfilter_zi(h,[1.0])*channel.v[0]; filtered,_=sig.lfilter(h,[1.0],channel.v,zi=zi)
    else:
        sos = (sig.butter(order,Wn,btype=btype,output='sos') if ftype=='Butterworth'
               else sig.cheby1(order,1.0,Wn,btype=btype,output='sos'))
        filtered = sig.sosfiltfilt(sos, channel.v)
    return Channel(name=name,t=channel.t,v=filtered,unit_t=channel.unit_t,unit_v=channel.unit_v,
                   color=color,is_math=True,is_filter=True,sample_rate=channel.sample_rate)


# ── Frequency input widget (auto kHz/MHz display + flexible parsing) ─────────

def _fmt_freq_display(hz: float) -> str:
    """Format Hz value for display: 1000 → '1 kHz', 1250000 → '1.25 MHz'."""
    if hz >= 1e6:
        v = hz / 1e6
        return f"{v:.4g} MHz"
    if hz >= 1e3:
        v = hz / 1e3
        return f"{v:.4g} kHz"
    return f"{hz:.4g} Hz"


class FreqEdit(QLineEdit):
    """QLineEdit that accepts '1000', '1k', '20kHz', '1.25MHz', displays auto-unit."""
    valueChanged = pyqtSignal(float)

    def __init__(self, hz=1000.0, parent=None):
        super().__init__(parent)
        self._hz = float(hz)
        self.setText(_fmt_freq_display(self._hz))
        self.editingFinished.connect(self._parse)
        self.setMinimumWidth(110)

    def value(self) -> float:
        return self._hz

    def setValue(self, hz: float):
        self._hz = float(hz)
        self.setText(_fmt_freq_display(self._hz))

    def _parse(self):
        hz = _parse_freq_str(self.text().strip())
        if hz and hz > 0:
            self._hz = hz
            self.setText(_fmt_freq_display(self._hz))
            self.valueChanged.emit(self._hz)
        else:
            self.setText(_fmt_freq_display(self._hz))   # revert


class FilterDialog(QDialog):
    def __init__(self, channels, parent=None):
        super().__init__(parent)
        # Allow raw AND math channels as filter sources; only exclude channels
        # that are themselves filter outputs (filtering a filtered channel just
        # keeps growing the source list without a clear use case).
        self.channels = [ch for ch in channels if not ch.is_filter]
        self.result_channel = None
        self.setWindowTitle("Digital Filter")
        self.resize(680, 480)

        # ── left panel: parameters ────────────────────────────────────────────
        left = QVBoxLayout()

        src_row = QHBoxLayout()
        src_row.addWidget(QLabel("Source:"))
        self._src = QComboBox()
        for ch in self.channels: self._src.addItem(ch.name)
        src_row.addWidget(self._src); left.addLayout(src_row)

        box = QGroupBox("Filter Parameters"); form = QFormLayout(box)

        self._ftype = QComboBox()
        self._ftype.addItems(["Butterworth", "Chebyshev I", "FIR (window)"])
        form.addRow("Type:", self._ftype)

        self._resp = QComboBox()
        self._resp.addItems(["LP", "HP", "BP", "BS"])
        form.addRow("Response:", self._resp)

        self._order = QSpinBox()
        self._order.setRange(1, 10); self._order.setValue(4)
        form.addRow("Order:", self._order)

        self._fc1 = FreqEdit(1000.0)
        form.addRow("Cutoff (fc1):", self._fc1)

        self._fc2_lbl = QLabel("Upper (fc2):")
        self._fc2 = FreqEdit(10000.0)
        form.addRow(self._fc2_lbl, self._fc2)

        left.addWidget(box)
        left.addStretch()

        btn_row = QHBoxLayout()
        ok = QPushButton("Apply"); ok.clicked.connect(self._ok)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        btn_row.addWidget(ok); btn_row.addWidget(cancel)
        left.addLayout(btn_row)

        # ── right panel: frequency response plot ──────────────────────────────
        self._freq_plot = pg.PlotWidget(background='#111111')
        self._freq_plot.setLabel('bottom', 'Frequency', units='Hz')
        self._freq_plot.setLabel('left', 'Magnitude', units='dB')
        self._freq_plot.showGrid(x=True, y=True, alpha=0.3)
        self._freq_plot.setLogMode(x=True, y=False)
        self._freq_plot.setMinimumWidth(360)

        # Main response curve
        self._freq_curve = self._freq_plot.plot(
            [], [], pen=pg.mkPen(color=(100, 180, 255), width=2))
        # -3 dB reference line
        self._ref3db = pg.InfiniteLine(
            pos=-3, angle=0, movable=False,
            pen=pg.mkPen(color=(255, 80, 80), width=1, style=2))
        self._freq_plot.addItem(self._ref3db)

        # Cursor
        self._cur = pg.InfiniteLine(
            angle=90, movable=True,
            pen=pg.mkPen(color=(200, 200, 255), width=1, style=2))
        self._cur_lbl = pg.TextItem(anchor=(0, 0), color='#dde',
                                    fill=(20, 20, 20, 220))
        self._cur_lbl.setZValue(100)
        self._freq_plot.addItem(self._cur, ignoreBounds=True)
        self._freq_plot.addItem(self._cur_lbl, ignoreBounds=True)
        self._cur.sigPositionChanged.connect(self._upd_cur_lbl)
        self._freq_plot.getViewBox().sigRangeChanged.connect(self._repos_cur_lbl)

        # Store computed response for cursor readout
        self._resp_w = np.array([])
        self._resp_mag = np.array([])

        # ── main layout ───────────────────────────────────────────────────────
        main = QHBoxLayout(self)
        main.addLayout(left, 0)
        main.addWidget(self._freq_plot, 1)

        for w in (self._ftype, self._resp, self._src):
            w.currentIndexChanged.connect(self._upd)
        for w in (self._order,):
            w.valueChanged.connect(self._upd)
        self._fc1.valueChanged.connect(self._upd)
        self._fc2.valueChanged.connect(self._upd)

        self._upd()

    def _upd(self):
        bp = self._resp.currentText() in ('BP', 'BS')
        self._fc2.setVisible(bp); self._fc2_lbl.setVisible(bp)
        self._draw_response()

    def _draw_response(self):
        try:
            ch    = self.channels[self._src.currentIndex()]
            fs    = ch.sample_rate if ch.sample_rate > 0 else 1.25e9
            nyq   = fs / 2.0
            ftype = self._ftype.currentText()
            resp  = self._resp.currentText()
            order = self._order.value()
            fc1   = self._fc1.value()
            fc2   = self._fc2.value()
            if fc1 <= 0 or fc1 >= nyq: raise ValueError()
            Wn    = [fc1/nyq, fc2/nyq] if resp in ('BP','BS') else fc1/nyq
            if resp in ('BP','BS') and (fc2 <= fc1 or fc2 >= nyq): raise ValueError()
            btype = {'LP':'low','HP':'high','BP':'bandpass','BS':'bandstop'}[resp]

            # Log-spaced points over 6 decades centred on fc1
            f_ref = fc1 if resp in ('LP','HP') else (fc1 * fc2) ** 0.5
            f_lo  = max(1.0, f_ref / 1000)
            f_hi  = min(nyq * 0.9999, f_ref * 1000)
            w_pts = np.logspace(np.log10(f_lo), np.log10(f_hi), 3000)

            if ftype == 'FIR (window)':
                numtaps = order * 10 + 1
                if resp == 'LP':   h = sig.firwin(numtaps, fc1/nyq)
                elif resp == 'HP': h = sig.firwin(numtaps, fc1/nyq, pass_zero=False)
                elif resp == 'BP': h = sig.firwin(numtaps, [fc1/nyq, fc2/nyq], pass_zero=False)
                else:              h = sig.firwin(numtaps, [fc1/nyq, fc2/nyq])
                _, H = sig.freqz(h, worN=w_pts, fs=fs)
            else:
                sos = (sig.butter(order, Wn, btype=btype, output='sos')
                       if ftype == 'Butterworth'
                       else sig.cheby1(order, 1.0, Wn, btype=btype, output='sos'))
                _, H = sig.sosfreqz(sos, worN=w_pts, fs=fs)

            freq   = w_pts
            mag_db = np.maximum(20 * np.log10(np.maximum(np.abs(H), 1e-12)), -100.0)

            self._resp_w   = freq
            self._resp_mag = mag_db
            self._freq_curve.setData(freq, mag_db)

            # X range: fc1/100 ~ fc1*100 (通带+滚降+阻带都可见), Y: -80 ~ +5
            x_lo = np.log10(max(freq[0],  fc1 / 100))
            x_hi = np.log10(min(freq[-1], fc1 * 100))
            self._freq_plot.getViewBox().setXRange(x_lo, x_hi, padding=0)
            self._freq_plot.getViewBox().setYRange(-80, 5, padding=0)

            # Cursor at fc1
            self._cur.setValue(np.log10(fc1))
            self._upd_cur_lbl()

        except Exception:
            self._freq_curve.setData([], [])
            self._resp_w = np.array([])
            self._resp_mag = np.array([])

    def _upd_cur_lbl(self):
        if len(self._resp_w) == 0: return
        log_pos = self._cur.value()
        freq_hz = 10 ** log_pos
        idx = int(np.argmin(np.abs(self._resp_w - freq_hz)))
        f_actual = float(self._resp_w[idx])
        amp = float(self._resp_mag[idx])
        self._cur_lbl.setText(f"{_fmt_f(f_actual)}\n{amp:.2f} dB")
        self._repos_cur_lbl()

    def _repos_cur_lbl(self):
        vr = self._freq_plot.viewRange()
        self._cur_lbl.setPos(self._cur.value(), vr[1][1])

    def _ok(self):
        try:
            self.result_channel = apply_filter(
                self.channels[self._src.currentIndex()],
                self._ftype.currentText(), self._resp.currentText(),
                self._order.value(), self._fc1.value(), self._fc2.value())
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Filter Error", str(e))


# ═══════════════════════════════════════════════════════════════════════════════
# MATH DIALOG
# ═══════════════════════════════════════════════════════════════════════════════

_MATH_PRESETS = [
    ("CH1 + CH2","CH1 + CH2"),("CH1 - CH2","CH1 - CH2"),("CH1 * CH2","CH1 * CH2"),
    ("|CH1|","abs(CH1)"),("d/dt CH1","diff(CH1) / diff_t(CH1)"),
    ("∫ CH1 dt","integ(CH1)"),("CH1 / 2","CH1 / 2"),
]


def evaluate_math(expr, channels):
    ns = {"np":np,"abs":np.abs}; ref_ch = None
    for ch in channels:
        ns[ch.name.replace(" ","_")] = ch.v
        if ref_ch is None: ref_ch = ch
    t = ref_ch.t
    ns.update({"diff": np.gradient, "diff_t": lambda a: np.gradient(t),
               "integ": lambda a: np.cumsum(a) * (t[1]-t[0] if len(t)>1 else 1.0)})
    safe = expr
    for ch in channels: safe = safe.replace(ch.name, ch.name.replace(" ","_"))
    result = np.asarray(eval(safe, {"__builtins__":{}}, ns), dtype=np.float64)  # noqa: S307
    if result.shape != t.shape: result=result[:len(t)]; t=t[:len(result)]
    sr = ref_ch.sample_rate if ref_ch.sample_rate>0 else (1.0/(t[1]-t[0]) if len(t)>1 else 0.0)
    return Channel(name=f"MATH({expr[:20]})", t=t, v=result,
                   color=CHANNEL_COLORS[len(channels)%len(CHANNEL_COLORS)], is_math=True, sample_rate=sr)


class MathDialog(QDialog):
    def __init__(self, channels, parent=None):
        super().__init__(parent); self.channels=channels; self.result_channel=None
        self.setWindowTitle("Add Math Channel"); self.setMinimumWidth(420)
        lay = QVBoxLayout(self)

        # Preset
        pr = QHBoxLayout(); pr.addWidget(QLabel("Preset:"))
        self._preset = QComboBox(); self._preset.addItem("— custom —","")
        for lbl,expr in _MATH_PRESETS: self._preset.addItem(lbl,expr)
        self._preset.currentIndexChanged.connect(self._apply_preset)
        pr.addWidget(self._preset); lay.addLayout(pr)

        # Expression
        lay.addWidget(QLabel("Expression:"))
        self._expr = QLineEdit(); self._expr.setPlaceholderText("e.g.  CH1 - CH2")
        lay.addWidget(self._expr)

        # Clickable channel buttons (insert name at cursor position)
        ch_row = QHBoxLayout(); ch_row.addWidget(QLabel("Channels:"))
        for ch in channels:
            r, g, b = ch.color
            btn = QPushButton(ch.name)
            btn.setFixedHeight(24)
            btn.setStyleSheet(
                f"QPushButton{{color:rgb({r},{g},{b});background:#2a2a2a;"
                f"border:1px solid rgb({r},{g},{b});border-radius:3px;padding:0 6px;}}"
                f"QPushButton:hover{{background:#3a3a3a;}}"
            )
            btn.clicked.connect(lambda checked, n=ch.name: self._insert(n))
            ch_row.addWidget(btn)
        ch_row.addStretch()
        lay.addLayout(ch_row)

        br = QHBoxLayout(); ok=QPushButton("Add"); ok.clicked.connect(self._ok)
        cancel=QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        br.addWidget(ok); br.addWidget(cancel); lay.addLayout(br)

    def _insert(self, name):
        """Insert channel name at cursor position in expression editor."""
        pos = self._expr.cursorPosition()
        text = self._expr.text()
        # Add space padding if needed
        before = text[:pos]
        after = text[pos:]
        sep_before = ' ' if before and not before.endswith(' ') else ''
        sep_after  = ' ' if after  and not after.startswith(' ')  else ''
        new_text = before + sep_before + name + sep_after + after
        self._expr.setText(new_text)
        self._expr.setCursorPosition(pos + len(sep_before) + len(name) + len(sep_after))
        self._expr.setFocus()

    def _apply_preset(self, idx):
        expr=self._preset.itemData(idx)
        if expr: self._expr.setText(expr)

    def _ok(self):
        expr=self._expr.text().strip()
        if not expr: return
        try: self.result_channel=evaluate_math(expr,self.channels); self.accept()
        except Exception as e: QMessageBox.critical(self,"Error",f"Math error:\n{e}")


# ═══════════════════════════════════════════════════════════════════════════════
# SCOPE WORKER (background thread — keeps the UI responsive during GPIB I/O)
# ═══════════════════════════════════════════════════════════════════════════════

class _ScopeWorker(QObject):
    """Runs one blocking scope call (reload / save) off the UI thread.

    GPIB transfers of several channels' wfm data take seconds; running them
    on the Qt main thread freezes the whole window (no repaint, no clicks)
    for that entire time. This just moves the blocking call to a QThread and
    reports back via signals — no change to what's actually being called
    (`ScopeBase.save_waveform_files` through `Bench().scope()`, same as
    before), just where it runs.
    """
    done  = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, fn):
        super().__init__()
        self._fn = fn   # zero-arg callable; returns the result to emit via `done`

    def run(self):
        try:
            result = self._fn()
        except Exception as e:
            self.error.emit(str(e))
            return
        self.done.emit(result)


# ═══════════════════════════════════════════════════════════════════════════════
# PNG EXPORT HELPER
# ═══════════════════════════════════════════════════════════════════════════════

def _export_plotitem(plot_item, width: int, height: int = 0) -> "QImage":
    """Render one pyqtgraph plot to a QImage.

    Uses ImageExporter (renders the plot's own scene, independent of its current
    on-screen size). We set ONLY width on the exporter — its width/height are
    aspect-linked, so setting both makes the second assignment re-scale the first
    and the output collapses. If a specific `height` is requested, we let the
    exporter render at the target width (height following the plot's aspect), then
    scale the resulting QImage to exactly width×height. Scaling the final raster
    is reliable and fully decouples the output from the on-screen aspect ratio —
    which is what went wrong before: a wide/short window made every sub-plot
    export very short, so a stacked export looked truncated.
    """
    from PyQt5.QtCore import Qt as _Qt
    import pyqtgraph.exporters as exp
    ex = exp.ImageExporter(plot_item)
    ex.parameters()['width'] = int(width)
    img = ex.export(toBytes=True)             # returns a QImage
    if height and img.height() != int(height):
        img = img.scaled(int(width), int(height),
                         _Qt.IgnoreAspectRatio, _Qt.SmoothTransformation)
    return img


def stack_plots_png(plots, path: str, width: int = 1600,
                    per_plot_height: int = 380, bg="#111111") -> bool:
    """Export a list of pyqtgraph plots stacked vertically into one PNG.

    Every plot is rendered to an identical width×per_plot_height tile (via
    `_export_plotitem`, which post-scales to that exact size), so EVERY channel
    appears complete and at the same height regardless of the on-screen window
    shape — no truncation, no missing sub-plots. Tiles are painted one below the
    next into a single canvas. Returns True on a successful file write.
    """
    from PyQt5.QtGui import QImage, QPainter, QColor
    imgs = [_export_plotitem(p.plotItem, width, per_plot_height) for p in plots]
    if not imgs:
        return False
    total_h = sum(im.height() for im in imgs)
    max_w   = max(im.width() for im in imgs)
    canvas  = QImage(max_w, total_h, QImage.Format_ARGB32)
    canvas.fill(QColor(bg))
    painter = QPainter(canvas)
    y = 0
    for im in imgs:
        painter.drawImage(0, y, im)
        y += im.height()
    painter.end()
    return canvas.save(path, "PNG")


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN WINDOW
# ═══════════════════════════════════════════════════════════════════════════════

_DARK_THEME = """
    QMainWindow,QWidget{background-color:#1e1e1e;color:#e0e0e0;}
    QToolBar{background:#2d2d2d;border:none;spacing:4px;}
    QToolButton{background:#3a3a3a;border-radius:4px;padding:4px 8px;}
    QToolButton:hover{background:#505050;}
    QDockWidget::title{background:#2d2d2d;padding:4px;}
    QTableWidget{background:#1a1a1a;gridline-color:#333;}
    QHeaderView::section{background:#2d2d2d;padding:4px;border:none;}
    QMenuBar{background:#2d2d2d;}QMenuBar::item:selected{background:#505050;}
    QMenu{background:#2d2d2d;}QMenu::item:selected{background:#505050;}
    QDialog{background:#1e1e1e;}
    QGroupBox{border:1px solid #444;margin-top:8px;padding:4px;}
    QGroupBox::title{subcontrol-origin:margin;left:8px;}
    QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit{background:#2d2d2d;border:1px solid #555;padding:2px 4px;}
    QPushButton{background:#3a3a3a;border:1px solid #555;padding:4px 12px;border-radius:3px;}
    QPushButton:hover{background:#505050;}
    QCheckBox{spacing:6px;}
"""


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self._channels = []; self._fft_window = None; self._last_dir = str(Path.home())
        self._scope_thread = None   # kept alive while a background scope job runs
        self._last_scope = None     # (name, addr) of the last scope discovered this session
        self.setWindowTitle("Oscilloscope Viewer"); self.resize(1200, 700)
        self.setStyleSheet(_DARK_THEME); self.setAcceptDrops(True)

        self._wave = WaveformWidget()
        self._wave.view_changed.connect(self._on_view_changed)
        self._wave.channel_clicked.connect(lambda n: self.statusBar().showMessage(f"Selected: {n}", 2000))
        self._wave.add_measurement_requested.connect(lambda cn,mn: self._meas_panel.add_card(cn,mn))
        self._wave.cursor_snap_requested.connect(lambda n: self._cursors.set_snap_channel(n if n else None))
        self._wave.cursor_toggle_requested.connect(self._toggle_cursors_menu)
        self._wave.clear_requested.connect(self._clear)
        self.setCentralWidget(self._wave)

        self._ch_panel = ChannelPanel()
        self._ch_panel.visibility_changed.connect(self._refresh_all)
        self._ch_panel.color_changed.connect(self._refresh_all)
        self._ch_panel.channel_deleted.connect(self._delete_channel)
        ld = QDockWidget("Channels", self); ld.setWidget(self._ch_panel)
        ld.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
        self.addDockWidget(Qt.LeftDockWidgetArea, ld)

        self._meas_panel = MeasurementPanel()
        bd = QDockWidget("Measurements", self); bd.setWidget(self._meas_panel)
        bd.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
        self.addDockWidget(Qt.BottomDockWidgetArea, bd)

        self._cursors = CursorManager(self._wave)
        self._cursors.cursor_changed.connect(lambda: self._cursors.update_readout())
        self._build_toolbar(); self._build_menu(); self.setStatusBar(QStatusBar())
        self._scope_progress = QProgressBar()
        self._scope_progress.setRange(0, 0)   # indeterminate — no per-channel callback from save_waveform_files
        self._scope_progress.setFixedWidth(140)
        self._scope_progress.setTextVisible(False)
        self._scope_progress.setVisible(False)
        self.statusBar().addPermanentWidget(self._scope_progress)
        self._meas_timer = QTimer(); self._meas_timer.setSingleShot(True)
        self._meas_timer.setInterval(200); self._meas_timer.timeout.connect(self._update_meas)

    # ── drag & drop ───────────────────────────────────────────────────────────

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls() and any(
                Path(u.toLocalFile()).suffix.lower() in ('.wfm','.csv','.txt')
                for u in event.mimeData().urls()):
            event.acceptProposedAction()
        else: event.ignore()

    def dropEvent(self, event):
        loaded = []
        for path in (Path(u.toLocalFile()) for u in event.mimeData().urls()):
            if path.suffix.lower() not in ('.wfm','.csv','.txt'): continue
            try:
                new = load_file(str(path)); existing = {ch.name for ch in self._channels}
                for ch in new:
                    base,i = ch.name,2
                    while ch.name in existing: ch.name=f"{base}_{i}"; i+=1
                    existing.add(ch.name)
                self._channels.extend(new); loaded.extend(new)
            except Exception as e: QMessageBox.critical(self,"Load Error",f"Could not load {path.name}:\n{e}")
        if loaded: self._refresh_all(); self.statusBar().showMessage(f"Loaded: {', '.join(c.name for c in loaded)}",3000)
        event.acceptProposedAction()

    # ── toolbar / menu ────────────────────────────────────────────────────────

    def _build_toolbar(self):
        tb = QToolBar("Main", self); tb.setMovable(False); self.addToolBar(tb)
        def act(label, tip, slot, shortcut=None):
            a = QAction(label, self); a.setToolTip(tip); a.triggered.connect(slot)
            if shortcut: a.setShortcut(QKeySequence(shortcut))
            tb.addAction(a); return a
        act("Open","Open .wfm/.csv",self._open_file,"Ctrl+O"); tb.addSeparator()
        self._act_reload = act("Reload Scope","Reload waveforms from the bench oscilloscope",self._reload_from_scope,"F5")
        self._act_save_wfm = act("Save WFM","Save the oscilloscope's currently displayed channels as .wfm files",self._save_wfm_from_scope)
        tb.addSeparator()
        act("Math","Add math channel",self._add_math)
        act("Filter","Apply digital filter",self._add_filter)
        act("FFT","FFT spectrum",self._open_fft,"F")
        tb.addSeparator()
        self._scope_lbl = QLabel("Scope: not connected")
        self._scope_lbl.setStyleSheet("color:#888;padding:0 8px;")
        tb.addWidget(self._scope_lbl)

    def _build_menu(self):
        mb = self.menuBar(); fm = mb.addMenu("File")
        for lbl,sc,slot in [("Open...","Ctrl+O",self._open_file),("Export CSV...",None,self._export_csv),
                             ("Export PNG...",None,self._export_png)]:
            a = QAction(lbl,self)
            if sc: a.setShortcut(sc)
            a.triggered.connect(slot); fm.addAction(a)
        fm.addSeparator(); qa=QAction("Quit",self); qa.setShortcut("Ctrl+Q"); qa.triggered.connect(self.close); fm.addAction(qa)

    # ── actions ───────────────────────────────────────────────────────────────

    def _open_file(self):
        paths,_ = QFileDialog.getOpenFileNames(self,"Open Waveform File",self._last_dir,
                                                "Waveform files (*.wfm *.csv *.txt);;All files (*)")
        for path in paths:
            self._last_dir = str(Path(path).parent)
            try:
                new = load_file(path); existing={ch.name for ch in self._channels}
                for ch in new:
                    base,i=ch.name,2
                    while ch.name in existing: ch.name=f"{base}_{i}"; i+=1
                    existing.add(ch.name)
                self._channels.extend(new)
                self.statusBar().showMessage(f"Loaded: {', '.join(c.name for c in new)}",3000)
            except Exception as e: QMessageBox.critical(self,"Load Error",f"Could not load {Path(path).name}:\n{e}")
        if paths: self._refresh_all()

    def _update_scope_label(self, scope=None):
        """Refresh the toolbar's "Scope: <model> @ <addr>" indicator.

        Same display convention as the Power Supply Control tool
        (`f"{type(driver).__name__}  @  {driver.addr}"`). UI-thread only —
        call from a `done`/`error` handler, never from the worker thread
        directly.

        The connection is never kept open between operations (see module
        docstring on `capture_live_channels`), so after each job the scope
        handle is gone — but the *identity* of the scope on the bus does not
        change. So `scope=None` does NOT mean "unknown": if we have discovered
        a scope this session (`self._last_scope`), we keep showing it, just in
        grey to signal "known, but not currently held open". Only when nothing
        has ever been found do we show "not connected".
        """
        if scope is not None:
            self._last_scope = (type(scope).__name__, scope.addr)
        known = getattr(self, "_last_scope", None)
        if known is not None:
            name, addr = known
            self._scope_lbl.setText(f"Scope: {name}  @  {addr}")
            self._scope_lbl.setToolTip(f"{name} @ {addr}")
            # Green while a handle is live (scope passed in), grey otherwise.
            self._scope_lbl.setStyleSheet(
                f"color:{'#0a4' if scope is not None else '#888'};padding:0 8px;")
        else:
            self._scope_lbl.setText("Scope: not connected")
            self._scope_lbl.setStyleSheet("color:#888;padding:0 8px;")
            self._scope_lbl.setToolTip("")

    def _run_scope_job(self, fn, on_done, busy_msg):
        """Run `fn` (zero-arg, blocking) on a background thread so GPIB I/O
        doesn't freeze the UI. Disables the scope buttons and shows a busy
        progress bar for the duration; `on_done(result)` runs back on the UI
        thread when it finishes. `fn` owns the connection it opens (discover
        + open + do the work + close) — nothing here keeps a scope handle
        alive past this one call.
        """
        self._act_reload.setEnabled(False); self._act_save_wfm.setEnabled(False)
        self.statusBar().showMessage(busy_msg)
        self._scope_progress.setVisible(True)

        thread = QThread(self)
        worker = _ScopeWorker(fn)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)

        def _finish():
            self._act_reload.setEnabled(True); self._act_save_wfm.setEnabled(True)
            self._scope_progress.setVisible(False)
            self._update_scope_label(None)   # connection is always closed by now
            thread.quit()

        def _on_done(result):
            _finish(); on_done(result)

        def _on_error(msg):
            _finish()
            QMessageBox.critical(self,"Scope Error",msg)

        worker.done.connect(_on_done)
        worker.error.connect(_on_error)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        # Keep BOTH thread and worker referenced on self. worker was only a local:
        # after this method returned, Python could GC it mid-run (the reload job
        # blocks ~18s on the GPIB transfer — a long window), and once the worker
        # is collected its done/error signal has no live receiver, so the callback
        # never fires — the reload appears to hang forever with buttons disabled.
        self._scope_thread = thread
        self._scope_worker = worker
        thread.start()

    def _reload_from_scope(self):
        def _job():
            scope = Bench().scope()
            scope.open()
            try:
                return capture_live_channels(scope)
            finally:
                scope.close()
        def _apply(channels):
            self._channels = channels; self._refresh_all()
            self.statusBar().showMessage(f"Reloaded from scope: {', '.join(c.name for c in channels)}",3000)
        self._run_scope_job(_job, _apply, "Reloading from oscilloscope…")

    def _save_wfm_from_scope(self):
        target_dir = QFileDialog.getExistingDirectory(self,"Save WFM Files To",self._last_dir)
        if not target_dir: return
        self._last_dir = target_dir
        def _job():
            scope = Bench().scope()
            scope.open()
            try:
                return scope.save_waveform_files(target_dir)
            finally:
                scope.close()
        def _apply(paths):
            if not paths:
                QMessageBox.information(self,"No data","No channel is currently displayed on the scope."); return
            self.statusBar().showMessage(f"Saved: {', '.join(paths)}",5000)
        self._run_scope_job(_job, _apply, "Saving waveforms from oscilloscope…")

    def _discover_scope_on_launch(self):
        """One-shot GPIB/USB discovery at startup: find the scope, show its
        model/address in the toolbar, then disconnect immediately. Runs on a
        background thread — `Bench().scope()`'s bus scan + `*IDN?` probing
        can take a couple seconds and must not delay the window opening.
        No connection is kept afterward; Reload / Save WFM each open + close
        their own connection when clicked.
        """
        def _job():
            scope = Bench().scope()
            scope.open()
            info = (type(scope).__name__, scope.addr)
            scope.close()
            return info
        def _apply(info):
            name, addr = info
            self._last_scope = (name, addr)   # remember so later ops keep showing it
            self._scope_lbl.setText(f"Scope: {name}  @  {addr}")
            self._scope_lbl.setStyleSheet("color:#0a4;padding:0 8px;")
            self._scope_lbl.setToolTip(f"{name} @ {addr}")
            self.statusBar().showMessage(f"Scope found: {name} @ {addr}", 4000)
        def _on_error(msg):
            # No scope found/reachable. Surface the real reason instead of
            # silently leaving "not connected" — a short red label with the
            # full error on hover, and the full text in the status bar.
            short = (msg or "unknown error").splitlines()[0]
            if len(short) > 60: short = short[:57] + "…"
            self._scope_lbl.setText(f"Scope: {short}")
            self._scope_lbl.setStyleSheet("color:#d44;padding:0 8px;")
            self._scope_lbl.setToolTip(msg or "unknown error")
            self.statusBar().showMessage(f"Scope discovery failed: {msg}", 10000)
        # Show a scanning state so a slow bus scan is not mistaken for failure.
        self._scope_lbl.setText("Scope: scanning…")
        self._scope_lbl.setStyleSheet("color:#cc0;padding:0 8px;")
        thread = QThread(self)
        worker = _ScopeWorker(_job)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.done.connect(lambda r: (_apply(r), thread.quit()))
        worker.error.connect(lambda m: (_on_error(m), thread.quit()))
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        # Keep BOTH the thread and the worker referenced on self. The worker was
        # only a local before, so after this method returned Python could GC it
        # while the QThread was still running — the done/error signal then had no
        # live receiver and the label stayed stuck on "scanning…".
        self._startup_scan_thread = thread
        self._startup_scan_worker = worker
        thread.start()

    def closeEvent(self, event):
        super().closeEvent(event)

    def _toggle_cursors(self, checked):
        self._cursors.set_active(checked)
        self._wave._cursor_active = checked
        if checked: self._cursors.update_readout()

    def _toggle_cursors_menu(self):
        new_state = not self._cursors.active
        self._toggle_cursors(new_state)

    def _add_math(self):
        if not self._channels: QMessageBox.information(self,"No data","Load waveforms first."); return
        dlg = MathDialog(self._channels, self)
        if dlg.exec_() and dlg.result_channel:
            self._channels.append(dlg.result_channel); self._refresh_all()

    def _add_filter(self):
        # Filterable = anything that isn't itself a filter output (raw + math).
        if not [ch for ch in self._channels if not ch.is_filter]:
            QMessageBox.information(self,"No data","Load waveforms first."); return
        dlg = FilterDialog(self._channels, self)
        if dlg.exec_() and dlg.result_channel:
            self._channels.append(dlg.result_channel); self._refresh_all()

    def _open_fft(self):
        if not self._channels: return
        if self._fft_window is None:
            self._fft_window = FFTWindow(self._channels, waveform_widget=self._wave)
        else: self._fft_window.set_channels(self._channels)
        self._fft_window.show(); self._fft_window.raise_()

    def _toggle_mode(self):
        self._wave.toggle_mode()
        if self._cursors.active: self._cursors.set_active(True)

    def _clear(self): self._channels.clear(); self._refresh_all()

    def keyPressEvent(self, event):
        k = event.key()
        if k in (Qt.Key_Plus, Qt.Key_Equal):   self._wave.zoom_x(0.5)
        elif k == Qt.Key_Minus:                 self._wave.zoom_x(2.0)
        else: super().keyPressEvent(event)

    def _delete_channel(self, ch):
        if ch in self._channels:
            self._channels.remove(ch); self._refresh_all()

    def _on_view_changed(self):
        self._meas_timer.start()
        if self._cursors.active: self._cursors.update_readout()

    def _update_meas(self):
        t0,t1 = self._wave.get_view_range()
        self._meas_panel.update(self._channels, t0, t1)

    def _refresh_all(self):
        self._ch_panel.set_channels(self._channels)
        self._wave.set_channels(self._channels)
        self._meas_panel.set_channels(self._channels)
        self._update_meas()
        if self._cursors.active: self._cursors.set_active(True)
        if self._fft_window and self._fft_window.isVisible():
            self._fft_window.set_channels(self._channels)

    def _export_csv(self):
        if not self._channels: return
        path,_ = QFileDialog.getSaveFileName(self,"Export CSV",self._last_dir,"CSV files (*.csv)")
        if not path: return
        with open(path,'w',newline='') as f:
            w = csv.writer(f); w.writerow(['Time']+[ch.name for ch in self._channels])
            for i,ti in enumerate(self._channels[0].t):
                w.writerow([ti]+[ch.v[i] if i<len(ch.v) else '' for ch in self._channels])
        self.statusBar().showMessage(f"Exported: {path}",3000)

    def _export_png(self):
        if not self._wave._first_plot():
            QMessageBox.information(self,"No data","Load or reload waveforms first."); return
        path,_ = QFileDialog.getSaveFileName(self,"Export PNG",self._last_dir,"PNG files (*.png)")
        if not path: return
        if not path.lower().endswith(".png"): path += ".png"
        self._last_dir = str(Path(path).parent)
        # Render each plot via ImageExporter at a fixed resolution and stack them,
        # instead of grabbing the on-screen widget. A screen grab only captured
        # the visible/expanded height, so stacked channels squeezed small in the
        # splitter came out clipped or missing. ImageExporter renders each plot's
        # own scene independently of its on-screen size — every channel complete.
        try:
            if self._wave.mode == STACKED and self._wave._sub_plots:
                ok = stack_plots_png(self._wave._sub_plots, path)
            else:
                img = _export_plotitem(self._wave._first_plot().plotItem, 1600)
                ok = img.save(path, "PNG")
        except Exception as e:
            QMessageBox.critical(self,"Export Error",f"Could not export PNG:\n{e}"); return
        if ok:
            self.statusBar().showMessage(f"Saved: {path}",3000)
        else:
            QMessageBox.critical(self,"Export Error",f"Could not write PNG:\n{path}")


# ═══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("OscViewer"); app.setStyle("Fusion")
    win = MainWindow()
    for path in sys.argv[1:]:
        try:
            for ch in load_file(path): win._channels.append(ch)
        except Exception as e: print(f"Warning: could not load {path}: {e}")
    if win._channels: win._refresh_all()
    # No waveform auto-load on launch — only a background discovery scan so
    # the toolbar can show which scope is on the bus. That scan opens and
    # immediately closes the connection; it never blocks window startup
    # (runs on a thread) and never keeps the GPIB/USB session held open.
    win.show()
    win._discover_scope_on_launch()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
