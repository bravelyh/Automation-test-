"""Loadbox Control GUI

Manual bench GUI for the 4-channel loadbox.

Inputs:
  * Load  -- string, meaning depends on Mode:
              Mode 0, single value  (e.g. '3')   -> uniform, all 4 CH same.
              Mode 0, 4-digit string (e.g. '2234') -> per-channel, CH1..CH4.
              Mode 1, numeric ohm    (e.g. '10') -> series, 4 CH sum to load.
  * Mode  -- 0 = parallel/independent, 1 = series.

Behaviour:
  * COM port auto-scanned on startup (Prolific USB-Serial).
  * 'Set' button connects, writes 4 channels, disconnects (per-op).
  * 4-CH table updates with the load / write cmd / read value after each Set.
  * Read column may be empty for a channel — that's fine, hardware doesn't
    always return a value; the tool doesn't treat empty reads as an error.
"""
from __future__ import annotations

import os
import sys
import tkinter as tk
from tkinter import messagebox, ttk


def _setup_paths():
    # Frozen: _MEIPASS.  Source: this tool folder + repo root (../.. from
    # this tool folder) so `instruments.*` is importable.
    candidates = []
    if getattr(sys, "frozen", False):
        candidates.append(getattr(sys, "_MEIPASS", ""))
    here = os.path.dirname(os.path.abspath(__file__))
    candidates.append(here)
    candidates.append(os.path.abspath(os.path.join(here, "..", "..")))
    for p in candidates:
        if p and p not in sys.path:
            sys.path.insert(0, p)


_setup_paths()
from instruments.loadbox.loadbox_SH import (  # noqa: E402
    LOAD_MAP,
    detect_loadbox_port,
    format_load,
    list_all_ports,
    resolve_mode0,
    resolve_mode1,
    set_load_per_channel,
)


NUM_CH = 4
ROW_BG = ["#ffffff", "#f0f4f8"]


class ChannelRow:
    """One CH row in the results table."""

    def __init__(self, parent: tk.Widget, grid_row: int, ch: int, idx: int):
        bg = ROW_BG[idx % 2]
        self.load_var = tk.StringVar(value="")
        self.write_var = tk.StringVar(value="")
        self.read_var = tk.StringVar(value="")

        def cell(col, var, w, anchor="w"):
            lbl = tk.Label(parent, textvariable=var, width=w,
                           font=("Consolas", 9), bg=bg, anchor=anchor,
                           relief="solid", bd=1)
            lbl.grid(row=grid_row, column=col, padx=1, pady=1, sticky="ew")
            return lbl

        tk.Label(parent, text=f"CH{ch}", width=6, font=("Segoe UI", 9, "bold"),
                 bg=bg, anchor="center", relief="solid", bd=1).grid(
            row=grid_row, column=0, padx=1, pady=1, sticky="ew")
        cell(1, self.load_var, 12, anchor="center")
        cell(2, self.write_var, 12, anchor="center")
        cell(3, self.read_var, 12, anchor="center")

    def clear(self):
        self.load_var.set("")
        self.write_var.set("")
        self.read_var.set("")

    def set(self, load_key: str, write_cmd: str, read_val: str):
        self.load_var.set(format_load(load_key))
        self.write_var.set(write_cmd)
        self.read_var.set(read_val)


class LoadboxGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Loadbox Control")
        self._detected_port: str | None = None
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(100, self.do_scan_ports)

    # ============================================================== UI
    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=10)
        outer.grid(sticky="nsew")
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        # ── Top row: Connection + Set Load side-by-side ──────────────
        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 6))

        # Connection
        cf = ttk.LabelFrame(top, text="Connection", padding=6)
        cf.grid(row=0, column=0, sticky="w", padx=(0, 8))
        ttk.Label(cf, text="Status:").grid(row=0, column=0, sticky="w")
        self.status_var = tk.StringVar(value="Scanning...")
        self.status_lbl = ttk.Label(
            cf, textvariable=self.status_var, foreground="#cc0000", width=22)
        self.status_lbl.grid(row=0, column=1, padx=3)
        ttk.Button(cf, text="Rescan", command=self.do_scan_ports, width=10).grid(
            row=0, column=2, padx=4)

        # Set Load
        sf = ttk.LabelFrame(top, text="Set Load", padding=6)
        sf.grid(row=0, column=1, sticky="w")
        ttk.Label(sf, text="Mode:").grid(row=0, column=0, sticky="w")
        self.mode_var = tk.StringVar(value="0")
        self.mode_combo = ttk.Combobox(
            sf, textvariable=self.mode_var, values=["0", "1"], width=4,
            state="readonly")
        self.mode_combo.grid(row=0, column=1, padx=(3, 12))

        ttk.Label(sf, text="Load:").grid(row=0, column=2, sticky="w")
        self.load_var = tk.StringVar(value="")
        self.load_entry = ttk.Entry(sf, textvariable=self.load_var, width=12)
        self.load_entry.grid(row=0, column=3, padx=3)
        self.load_entry.bind("<Return>", lambda _e: self.do_set())

        ttk.Button(sf, text="Set", command=self.do_set, width=8).grid(
            row=0, column=4, padx=(12, 0))

        # Hint line
        ttk.Label(
            sf, foreground="grey", font=("Segoe UI", 8),
            text="Mode 0: '3' uniform or '2234' per-CH (digits 1-6,8).  "
                 "Mode 1: numeric ohm, 0..32 step 0.5."
        ).grid(row=1, column=0, columnspan=5, sticky="w", pady=(4, 0))

        # ── Channels table ──────────────────────────────────────────
        chf = ttk.LabelFrame(outer, text="Channels", padding=6)
        chf.grid(row=1, column=0, sticky="ew", pady=(0, 6))

        headers = [("CH", 6), ("Load", 12), ("Write", 12), ("Read", 12)]
        for col, (text, w) in enumerate(headers):
            ttk.Label(chf, text=text, width=w, anchor="center",
                      font=("Segoe UI", 9, "bold")).grid(
                row=0, column=col, padx=1, pady=(0, 4), sticky="ew")
        ttk.Separator(chf, orient="horizontal").grid(
            row=1, column=0, columnspan=4, sticky="ew", pady=(0, 2))

        self.ch_rows: list[ChannelRow] = []
        for i in range(NUM_CH):
            self.ch_rows.append(ChannelRow(chf, grid_row=2 + i, ch=i + 1, idx=i))

        # ── Log ─────────────────────────────────────────────────────
        lf = ttk.LabelFrame(outer, text="Log", padding=6)
        lf.grid(row=2, column=0, sticky="nsew")
        outer.grid_rowconfigure(2, weight=1)

        self.log_text = tk.Text(
            lf, height=14, width=72, state="disabled",
            font=("Consolas", 9), wrap="word")
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb.set)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        lf.grid_rowconfigure(0, weight=1)
        lf.grid_columnconfigure(0, weight=1)

        self.log_text.tag_config("ok", foreground="#007700")
        self.log_text.tag_config("err", foreground="#cc0000")
        self.log_text.tag_config("data", foreground="#0066cc",
                                  font=("Consolas", 9, "bold"))

        ttk.Button(outer, text="Clear Log", command=self.clear_log).grid(
            row=3, column=0, sticky="e", pady=(4, 0))

    # ============================================================== helpers
    def log(self, msg: str, tag: str = ""):
        self.log_text.configure(state="normal")
        if tag:
            self.log_text.insert("end", msg + "\n", tag)
        else:
            self.log_text.insert("end", msg + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    # ============================================================== scan
    def do_scan_ports(self):
        """Scan for the Prolific loadbox COM port. Does NOT connect."""
        self.log("[--] Scanning COM ports...")
        for p in list_all_ports():
            self.log(f"    {p['device']}: {p['description']}")

        port = detect_loadbox_port()
        if not port:
            self._detected_port = None
            self.status_var.set("No Loadbox Found")
            self.status_lbl.config(foreground="#cc0000")
            self.log("[ERR] No Prolific USB-Serial port detected", tag="err")
            return

        self._detected_port = port
        self.status_var.set(f"{port} Ready")
        self.status_lbl.config(foreground="#007700")
        self.log(f"[OK] Detected loadbox: {port} (will connect on Set)", tag="ok")

    # ============================================================== set
    def do_set(self):
        """Resolve inputs, connect, write 4 channels, disconnect, update UI."""
        mode = self.mode_var.get().strip()
        load = self.load_var.get().strip()

        if mode not in ("0", "1"):
            messagebox.showwarning("Invalid Mode", "Mode must be 0 or 1.")
            return
        if not load:
            messagebox.showwarning("Missing Load", "Enter a Load value.")
            return

        try:
            if mode == "0":
                labels = resolve_mode0(load)
                self.log(f"[--] Mode 0, load='{load}' -> CH1..CH4={labels}")
            else:
                labels = resolve_mode1(load)
                self.log(f"[--] Mode 1 (series), load='{load}' -> CH1..CH4={labels}")
            codes = [LOAD_MAP[k] for k in labels]
        except ValueError as exc:
            self.log(f"[ERR] {exc}", tag="err")
            messagebox.showerror("Invalid Load", str(exc))
            return

        port = self._detected_port or detect_loadbox_port()
        if not port:
            self.log("[ERR] No loadbox port detected", tag="err")
            messagebox.showwarning(
                "No Loadbox",
                "No Prolific USB-Serial port detected.\nClick Rescan.")
            return
        self._detected_port = port

        try:
            results = set_load_per_channel(port, codes, labels, self.log)
        except Exception as exc:
            self.log(f"[ERR] set failed: {exc}", tag="err")
            messagebox.showerror("Set Failed", str(exc))
            return

        # Update the 4-CH table
        for r, row in zip(results, self.ch_rows):
            row.set(r["load"], r["write"], r["read"])

        responded = sum(1 for r in results if r["read"])
        self.log(f"[OK] Set complete. {responded}/4 channels responded.",
                 tag="ok")

    # ============================================================== close
    def _on_close(self):
        self.root.destroy()


def main():
    root = tk.Tk()
    root.minsize(560, 520)
    LoadboxGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
