r"""Common Trim Manual GUI
Read/write I2C register bits via STM32 UART bridge.

5 global buttons: Read  Write  Export  Save  Reset

INI format (C:\Auto Bench\docs\projects\<Name>\<Name> Trim Config.ini):
  [Section]
  Trim Name = "0x28[7:3]"
  Trim Name = "0x1E[2:0],0x29[3:2]"   ← two fields: Field1=MSB, Field2=LSB

Export format: w <dev_addr> <reg_addr> <full_reg_byte>  (e.g. w e0 03 22)
"""
from __future__ import annotations

import configparser
import os
import re
import sys
import time
import tkinter as tk
from tkinter import messagebox, ttk
from serial.tools import list_ports


# ---------------------------------------------------------------------------
# Path setup
# ---------------------------------------------------------------------------
def _setup_paths():
    # Frozen: _MEIPASS.  Source: this tool folder + repo root (../.. from
    # this tool folder) so `instruments.*` is importable.
    candidates = []
    if getattr(sys, "frozen", False):
        candidates.append(getattr(sys, "_MEIPASS", ""))
    here = os.path.dirname(os.path.abspath(__file__))
    candidates.append(here)
    candidates.append(os.path.abspath(os.path.join(here, "..", "..")))
    for p in candidates:
        if p and p not in sys.path:
            sys.path.insert(0, p)

_setup_paths()
from instruments.i2x.i2x_aaa import I2X_AAA  # noqa: E402


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------
_FIELD_RE = re.compile(
    r"(0x[0-9a-fA-F]+|[0-9a-fA-F]+)\[(\d+)(?::(\d+))?\]", re.I
)


def parse_field_combined(s: str):
    """'0x28[7:3]' or '28[2:0]'  →  (reg_int, high, low).  None if empty."""
    s = s.strip()
    if not s:
        return None
    m = _FIELD_RE.match(s)
    if not m:
        raise ValueError(f"Invalid field '{s}' — expected: 0x28[7:3]")
    reg  = int(m.group(1), 16)
    high = int(m.group(2))
    low  = int(m.group(3)) if m.group(3) is not None else high
    if high < low:
        high, low = low, high
    if high > 7:
        raise ValueError(f"Bit {high} > 7")
    return reg, high, low


def parse_ini_value(v: str):
    """'"0x28[7:3]"' or '"0x1E[2:0],0x29[3:2]"'  →  (f1, f2)."""
    v = v.strip().strip("\"'")
    parts = [p.strip() for p in v.split(",")]
    f1 = parse_field_combined(parts[0]) if parts else None
    f2 = parse_field_combined(parts[1]) if len(parts) >= 2 else None
    return f1, f2


def field_to_ini(reg_int: int, high: int, low: int) -> str:
    bits = f"{high}:{low}" if high != low else str(high)
    return f"0x{reg_int:02X}[{bits}]"


def parse_hex_addr(s: str) -> int:
    s = s.strip()
    return int(s, 0) if s.lower().startswith("0x") else int(s, 16)


def parse_bits(s: str):
    """'2:0' / '[7:4]' / '5'  →  (high, low).  None for empty."""
    s = s.strip().strip("[]")
    if not s:
        return None
    if ":" in s:
        hi, lo = s.split(":", 1)
        high, low = int(hi.strip()), int(lo.strip())
    else:
        high = low = int(s.strip())
    if high < low:
        high, low = low, high
    if high > 7:
        raise ValueError(f"Bit {high} > 7")
    return high, low


def fwidth(high: int, low: int) -> int:
    return high - low + 1


def fmask(width: int) -> int:
    return (1 << width) - 1


# ---------------------------------------------------------------------------
# Status register map parsing
# ---------------------------------------------------------------------------
def parse_status_register_map(file_path: str) -> list[dict]:
    """Parse status register map from txt file.
    Returns list of dicts with keys: reg_addr, bits, value, status"""
    registers = []
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            for line_no, line in enumerate(f, 1):
                if line_no == 1:
                    continue
                line = line.strip()
                if not line:
                    continue
                parts = line.split('\t')
                if len(parts) >= 4:
                    try:
                        reg_addr = parts[0].strip()
                        bits_str = parts[1].strip()
                        value_str = parts[2].strip()
                        status = parts[3].strip()
                        registers.append({
                            'reg_addr': reg_addr,
                            'bits': bits_str,
                            'value': int(value_str),
                            'status': status,
                        })
                    except (ValueError, IndexError):
                        pass
    except Exception:
        pass
    return registers


class FCMapEntry:
    """One row of the FC Register Map. Represents a named register configuration.

    Example: FC_Name '384', page1=0, reg1=0x52, start_bit1=0, length1=2, value1=0
    means: 0x52 bits [1:0] = 00 on page 0.
    If has_part2: the same value is also written to reg2 on page2.
    """
    __slots__ = ('name', 'page1', 'reg1', 'start1', 'len1', 'val1',
                 'has_part2', 'page2', 'reg2', 'start2', 'len2', 'val2')

    def __init__(self, name, page1, reg1, start1, len1, val1,
                 has_part2=False, page2=0, reg2=0, start2=0, len2=0, val2=0):
        self.name = name
        self.page1 = page1
        self.reg1 = reg1
        self.start1 = start1
        self.len1 = len1
        self.val1 = val1
        self.has_part2 = has_part2
        self.page2 = page2
        self.reg2 = reg2
        self.start2 = start2
        self.len2 = len2
        self.val2 = val2


def _parse_bin_literal(s: str) -> int:
    """Parse a '2bXXXX' style literal → int. The prefix digit is ignored."""
    s = s.strip()
    idx = s.lower().find('b')
    if idx < 0:
        raise ValueError(f"Not a binary literal: {s!r}")
    return int(s[idx + 1:], 2)


def parse_fc_register_map(file_path: str) -> list[FCMapEntry]:
    """Parse FC Register Map txt.
    Columns: FC_Name, Page, Reg_part1, StartBit, Length, Reg_Part1_Value,
             Reg_part2_need, Page, Reg_part2, StartBit, Length, Reg_Part2_Value
    Handles both tab-separated (name may contain spaces) and space-separated lines.
    """
    entries: list[FCMapEntry] = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line_no, line in enumerate(f, 1):
            if line_no == 1:
                continue
            line = line.rstrip("\r\n")
            if not line.strip():
                continue
            if '\t' in line:
                parts = [p.strip() for p in line.split('\t')]
                parts = [p for p in parts if p != '']
            else:
                parts = line.split()
            if len(parts) < 6:
                continue
            try:
                name = parts[0]
                page1 = int(parts[1])
                reg1 = int(parts[2], 16)
                start1 = int(parts[3])
                len1 = int(parts[4])
                val1 = _parse_bin_literal(parts[5])
                has_p2 = (len(parts) >= 12 and parts[6].lower() == 'yes')
                if has_p2:
                    page2 = int(parts[7])
                    reg2 = int(parts[8], 16)
                    start2 = int(parts[9])
                    len2 = int(parts[10])
                    val2 = _parse_bin_literal(parts[11])
                    entries.append(FCMapEntry(name, page1, reg1, start1, len1, val1,
                                              True, page2, reg2, start2, len2, val2))
                else:
                    entries.append(FCMapEntry(name, page1, reg1, start1, len1, val1))
            except Exception:
                continue
    return entries


# ---------------------------------------------------------------------------
# COM port detection
# ---------------------------------------------------------------------------
def get_all_ports_info() -> list[dict]:
    """Get all COM ports with details."""
    ports = []
    try:
        for port in list_ports.comports():
            ports.append({
                'device': port.device,
                'description': port.description,
                'manufacturer': port.manufacturer or "",
            })
    except Exception:
        pass
    return ports


def detect_stlink_port() -> str | None:
    """Detect STMicroelectronics STLink Virtual COM port."""
    try:
        for port in list_ports.comports():
            desc = port.description.lower()
            if "stlink" in desc and "virtual com" in desc:
                return port.device
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Low-level I2C helpers
# ---------------------------------------------------------------------------
def _read_reg(board: I2X_AAA, dev_hex: str, reg_hex: str):
    """Returns (byte_value, tx_script, rx_raw)."""
    script  = f"R {dev_hex} {reg_hex} 1"
    results = board.i2c_send(script)
    if not (results and results[0]):
        raise RuntimeError(f"No data for reg 0x{reg_hex}")
    raw = results[0][0]      # 6-char ASCII: dev(2)+reg(2)+data(2)
    return int(raw[4:6], 16), script, raw


def _rmw(board: I2X_AAA, dev_hex: str, reg_hex: str,
         high: int, low: int, value: int):
    """Read-modify-write. Returns (old, new, r_script, w_script, rx_raw)."""
    current, r_script, raw = _read_reg(board, dev_hex, reg_hex)
    mask    = fmask(fwidth(high, low))
    new_val = (current & ~(mask << low)) | ((value & mask) << low)
    w_script = f"W {dev_hex} {reg_hex} {new_val:02X}"
    board.i2c_send(w_script)
    return current, new_val, r_script, w_script, raw


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
NUM_ROWS = 16
ROW_BG   = ["#ffffff", "#f0f4f8"]
# Per-device INI/config files. Live under docs/ in the repo; absolute path per
# the fixed repo location (README rule: the repo is at C:\Auto Bench).
INI_ROOT = r"C:\Auto Bench\docs\projects"


# ---------------------------------------------------------------------------
# Single data row (no per-row buttons)
# ---------------------------------------------------------------------------
class TrimRow:
    def __init__(self, parent: tk.Widget, grid_row: int, idx: int):
        bg = ROW_BG[idx % 2]

        self.name_var   = tk.StringVar()
        self.field_var  = tk.StringVar()  # Combined field input: 0x28[7:3] or 0x1E[2:0],0x29[3:2]
        self.val_var    = tk.StringVar()
        self._bg        = bg
        self._f1        = None
        self._f2        = None

        def e(col, var, w):
            ent = tk.Entry(parent, textvariable=var, width=w,
                           font=("Segoe UI", 9), bg=bg, relief="solid", bd=1)
            ent.grid(row=grid_row, column=col, padx=2, pady=2, sticky="w")
            return ent

        col = 0
        e(col, self.name_var,  27);  col += 1

        # Combined field input (60% of original width)
        self.field_entry = e(col, self.field_var, 21);  col += 1

        # Value field with validation
        self.val_entry = e(col, self.val_var, 8)

        # Real-time validation
        self.field_var.trace_add("write", self._validate_field)
        self.val_var.trace_add("write", self._validate_value)

    def _validate_field(self, *_):
        """Real-time field format validation."""
        field_str = self.field_var.get().strip()
        if not field_str:
            self.field_entry.config(bg="white")
            self._f1 = None
            self._f2 = None
            self._validate_value()
            return

        try:
            f1, f2 = parse_ini_value(f'"{field_str}"')
            if f1 is None:
                self.field_entry.config(bg="#fff8dc")
                self._f1 = None
                self._f2 = None
            else:
                self.field_entry.config(bg="white")
                self._f1 = f1
                self._f2 = f2
        except Exception:
            self.field_entry.config(bg="#ffe6e6")
            self._f1 = None
            self._f2 = None

        self._validate_value()

    def _validate_value(self, *_):
        """Validate value against field bit width."""
        if self._f1 is None:
            self.val_entry.config(bg=self._bg)
            return

        val_str = self.val_var.get().strip()
        if not val_str:
            self.val_entry.config(bg=self._bg)
            return

        try:
            val = int(val_str, 0)
            w1 = fwidth(self._f1[1], self._f1[2])
            w2 = fwidth(self._f2[1], self._f2[2]) if self._f2 else 0
            max_val = fmask(w1 + w2)

            if val < 0 or val > max_val:
                self.val_entry.config(bg="#ffe6e6")
            else:
                self.val_entry.config(bg="white")
        except ValueError:
            self.val_entry.config(bg="#ffe6e6")

    def get_fields(self):
        """Parse field input and return (f1, f2) tuples.
        Each field: (reg_int, high, low). f1=None means empty row."""
        field_str = self.field_var.get().strip()
        if not field_str:
            return None, None
        return parse_ini_value(f'"{field_str}"')

    def load_fields(self, f1, f2):
        """Populate from (reg,high,low) tuples; clear value."""
        parts = []
        if f1:
            parts.append(field_to_ini(f1[0], f1[1], f1[2]))
        if f2:
            parts.append(field_to_ini(f2[0], f2[1], f2[2]))
        self.field_var.set(",".join(parts))
        self.val_var.set("")

    def to_ini_value(self) -> str | None:
        """Build INI value string, e.g. '"0x28[7:3]"' or '"0x1E[2:0],0x29[3:2]"'."""
        field_str = self.field_var.get().strip()
        if not field_str:
            return None
        return f'"{field_str}"'

    def clear_all(self):
        for v in (self.name_var, self.field_var, self.val_var):
            v.set("")
        self.field_entry.config(bg=self._bg)
        self.val_entry.config(bg=self._bg)
        self._f1 = None
        self._f2 = None


# ---------------------------------------------------------------------------
# Quick Setting row (Setting Item + Setting Value)
# ---------------------------------------------------------------------------
class QuickSettingRow:
    """One row of Quick Settings.

    - name_var: Setting Item — user-defined label, no validation.
    - value_var: Setting Value — must match an FC_Name in the FC Register Map.
      Turns red if the current value isn't in the FC map (live validation).
    """

    def __init__(self, parent: tk.Widget, grid_row: int, idx: int,
                 fc_names_getter):
        bg = ROW_BG[idx % 2]
        self._bg = bg
        self._fc_names_getter = fc_names_getter  # callable → set[str] of valid names

        self.name_var  = tk.StringVar()
        self.value_var = tk.StringVar()

        self.name_entry = tk.Entry(
            parent, textvariable=self.name_var, width=18,
            font=("Segoe UI", 9), bg=bg, relief="solid", bd=1)
        self.name_entry.grid(row=grid_row, column=0, padx=2, pady=2, sticky="w")

        self.value_entry = tk.Entry(
            parent, textvariable=self.value_var, width=18,
            font=("Segoe UI", 9), bg=bg, relief="solid", bd=1)
        self.value_entry.grid(row=grid_row, column=1, padx=2, pady=2, sticky="w")

        self.value_var.trace_add("write", self._validate_value)

    def _validate_value(self, *_):
        v = self.value_var.get().strip()
        if not v:
            self.value_entry.config(bg=self._bg)
            return
        fc_names = self._fc_names_getter()
        if not fc_names:
            # FC map not loaded yet — don't flag as invalid
            self.value_entry.config(bg=self._bg)
            return
        if v in fc_names:
            self.value_entry.config(bg="white")
        else:
            self.value_entry.config(bg="#ffe6e6")

    def clear_all(self):
        self.name_var.set("")
        self.value_var.set("")
        self.name_entry.config(bg=self._bg)
        self.value_entry.config(bg=self._bg)


# ---------------------------------------------------------------------------
# Quick Setting ini I/O — [Quick Setting] section of <Name> Default Setting.ini
# ---------------------------------------------------------------------------
QS_SEP = ",   "          # separator used in ini: comma + three spaces
QS_SUFFIX = r"\0D\0A"    # literal trailing sentinel in ini value


def _qs_parse_ini_list(raw: str) -> list[str]:
    """Strip surrounding quotes and trailing \\0D\\0A, split by comma, trim items."""
    if raw is None:
        return []
    s = raw.strip()
    if s.startswith('"') and s.endswith('"'):
        s = s[1:-1]
    if s.endswith(QS_SUFFIX):
        s = s[:-len(QS_SUFFIX)]
    return [item.strip() for item in s.split(',')]


def _qs_build_ini_list(items: list[str]) -> str:
    """Build ini value from a list of items, wrapping in quotes.
    We do NOT append the \\0D\\0A trailing sentinel — that came from another
    tool's writer. Our loader tolerates its presence, so we don't need to emit
    it ourselves.
    """
    body = QS_SEP.join(items)
    return f'"{body}"'


# ---------------------------------------------------------------------------
# Shared configparser factory (preserves key case, raw values)
# ---------------------------------------------------------------------------
def _make_cfg() -> configparser.RawConfigParser:
    cfg = configparser.RawConfigParser()
    cfg.optionxform = str          # preserve key case (e.g. "OUT1P HS OC")
    return cfg


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------
class TrimGUI:
    def __init__(self, root: tk.Tk):
        self.root      = root
        self.root.title("I2C Tool")
        self.board     = None
        self._detected_port: str | None = None
        self._ini_path: str | None = None
        self.script_var = tk.StringVar()
        self._status_registers: list[dict] = []
        self._fc_map: list[FCMapEntry] = []
        self._fc_names: set[str] = set()
        self._qs_default_setting_path: str | None = None
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(100, self.do_scan_ports)

    # ====================================================================== UI
    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=10)
        outer.grid(sticky="nsew")
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        PAD = {"padx": 8, "pady": 4}

        # ── Top bar ───────────────────────────────────────────────────────
        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", **PAD)

        # Connection
        cf = ttk.LabelFrame(top, text="Connection", padding=6)
        cf.grid(row=0, column=0, sticky="w", padx=(0, 8))
        ttk.Label(cf, text="Status:").grid(row=0, column=0, sticky="w")
        self.status_var = tk.StringVar(value="Scanning...")
        self.status_lbl = ttk.Label(
            cf, textvariable=self.status_var, foreground="#cc0000", width=20)
        self.status_lbl.grid(row=0, column=1, padx=3)
        self.conn_btn = ttk.Button(
            cf, text="Rescan", command=self.do_scan_ports, width=10)
        self.conn_btn.grid(row=0, column=2, padx=4)

        # Device (address + name)
        df = ttk.LabelFrame(top, text="Device", padding=6)
        df.grid(row=0, column=1, sticky="w", padx=(0, 8))
        ttk.Label(df, text="Device Name:").grid(row=0, column=0, sticky="w")
        self.device_name_var = tk.StringVar(value="")
        ttk.Entry(df, textvariable=self.device_name_var, width=12).grid(
            row=0, column=1, padx=3)
        ttk.Button(df, text="Load", command=self.do_load, width=6).grid(
            row=0, column=2, padx=3)

        ttk.Label(df, text="I2C Addr:").grid(row=0, column=3, sticky="w", padx=(8, 0))
        self.dev_addr_var = tk.StringVar()
        ttk.Entry(df, textvariable=self.dev_addr_var, width=8).grid(
            row=0, column=4, padx=3)
        ttk.Label(df, text="e.g. E0",
                  foreground="grey").grid(row=0, column=5, padx=3)

        # Trim section + Page
        nf = ttk.LabelFrame(top, text="Trim Section", padding=6)
        nf.grid(row=0, column=2, sticky="w", padx=(0, 8))
        ttk.Label(nf, text="Section:").grid(row=0, column=0, sticky="w")
        self.section_var = tk.StringVar()
        self.section_combo = ttk.Combobox(
            nf, textvariable=self.section_var, width=16, state="normal")
        self.section_combo.grid(row=0, column=1, padx=3)
        self.section_combo.bind("<<ComboboxSelected>>", self._on_section_selected)

        ttk.Label(nf, text="Page:").grid(row=0, column=2, sticky="w", padx=(8, 0))
        self.page_var = tk.StringVar(value="2")
        self.page_combo = ttk.Combobox(
            nf, textvariable=self.page_var, values=["0", "1", "2"], width=5, state="readonly")
        self.page_combo.grid(row=0, column=3, padx=3)

        # ── Middle: Script + Check Status (left) + QT/QS (right) ─────────
        mid = ttk.Frame(outer)
        mid.grid(row=1, column=0, sticky="nsew", padx=8, pady=4)
        outer.grid_columnconfigure(0, weight=1)

        # Right side wrapper: QT/QS panels stacked, each with a mode dropdown
        # embedded in its own LabelFrame border (replaces the plain-text title).
        right_panel = ttk.Frame(mid)
        right_panel.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        mid.grid_columnconfigure(0, weight=1)
        mid.grid_columnconfigure(1, weight=0)

        self.mode_var = tk.StringVar(value="Quick Trim")

        # ── Quick Trim panel ────────────────────────────────────────────
        # The dropdown is a child of right_panel and used as the LabelFrame's
        # labelwidget so it sits on the top-left border in place of a title.
        self._qt_mode_combo = ttk.Combobox(
            right_panel, textvariable=self.mode_var,
            values=["Quick Trim", "Quick Settings"],
            width=15, state="readonly")
        self._qt_mode_combo.bind("<<ComboboxSelected>>", self._on_mode_switch)
        tf = ttk.LabelFrame(right_panel, labelwidget=self._qt_mode_combo, padding=6)
        tf.grid(row=0, column=0, sticky="nsew")
        self.tf = tf

        HDR = [
            ("Trim Name",  27), ("Field", 21), ("Value", 8),
        ]
        for col, (text, w) in enumerate(HDR):
            ttk.Label(tf, text=text, width=w,
                      font=("Segoe UI", 9, "bold"), anchor="w").grid(
                row=0, column=col, padx=2, pady=(0, 2), sticky="w")
        ttk.Separator(tf, orient="horizontal").grid(
            row=1, column=0, columnspan=len(HDR), sticky="ew", pady=2)
        ttk.Label(
            tf,
            text="Format: 0x28[7:3] or 0x1E[2:0],0x29[3:2]  |  "
                 "Invalid field or value turns red",
            foreground="grey", font=("Segoe UI", 8),
        ).grid(row=2, column=0, columnspan=len(HDR),
               sticky="w", padx=2, pady=(0, 4))

        self.trim_rows: list[TrimRow] = []
        for i in range(NUM_ROWS):
            self.trim_rows.append(TrimRow(tf, grid_row=3 + i, idx=i))

        # 5 action buttons at the bottom of Quick Trim
        bf = ttk.Frame(tf)
        bf.grid(row=3 + NUM_ROWS, column=0, columnspan=3, sticky="ew", pady=(12, 0), padx=0)
        for text, cmd in [
            ("Read",   self.do_read),
            ("Write",  self.do_write),
            ("Export", self.do_export),
            ("Save",   self.do_save),
            ("Reset",  self.do_reset),
        ]:
            ttk.Button(bf, text=text, command=cmd, width=10).pack(
                side="left", padx=6, pady=2)

        # ── Quick Settings panel (same cell as Quick Trim, hidden by default) ─
        # Its own labelwidget dropdown, bound to the same StringVar so both
        # combos always show the current mode; only the visible one is clickable.
        self._qs_mode_combo = ttk.Combobox(
            right_panel, textvariable=self.mode_var,
            values=["Quick Trim", "Quick Settings"],
            width=15, state="readonly")
        self._qs_mode_combo.bind("<<ComboboxSelected>>", self._on_mode_switch)
        qsf = ttk.LabelFrame(right_panel, labelwidget=self._qs_mode_combo, padding=6)
        qsf.grid(row=0, column=0, sticky="nsew")
        qsf.grid_remove()
        self.qsf = qsf

        QS_HDR = [
            ("Setting Items",    18),
            ("Setting Values",   18),
            ("Current Settings", 18),
        ]
        for col, (text, w) in enumerate(QS_HDR):
            ttk.Label(qsf, text=text, width=w,
                      font=("Segoe UI", 9, "bold"), anchor="w").grid(
                row=0, column=col, padx=2, pady=(0, 2), sticky="w")
        ttk.Separator(qsf, orient="horizontal").grid(
            row=1, column=0, columnspan=3, sticky="ew", pady=2)
        ttk.Label(
            qsf,
            text="Setting Values must match FC map names  |  "
                 "Invalid name turns red",
            foreground="grey", font=("Segoe UI", 8),
        ).grid(row=2, column=0, columnspan=3,
               sticky="w", padx=2, pady=(0, 4))

        # Column 0/1: Setting Items + Setting Values entries (16 rows)
        self.qs_rows: list[QuickSettingRow] = []
        for i in range(NUM_ROWS):
            self.qs_rows.append(
                QuickSettingRow(qsf, grid_row=3 + i, idx=i,
                                fc_names_getter=lambda: self._fc_names))

        # Column 2: Current Settings text with scrollbar (spans all 16 rows)
        qs_cur_frame = ttk.Frame(qsf)
        qs_cur_frame.grid(row=3, column=2, rowspan=NUM_ROWS,
                          sticky="nsew", padx=2, pady=2)
        qs_cur_sb = ttk.Scrollbar(qs_cur_frame, orient="vertical")
        qs_cur_sb.pack(side="right", fill="y")
        self.qs_current_text = tk.Text(
            qs_cur_frame, width=18, height=NUM_ROWS,
            font=("Consolas", 9), wrap="none",
            state="disabled",
            yscrollcommand=qs_cur_sb.set,
            relief="solid", bd=1)
        self.qs_current_text.pack(side="left", fill="both", expand=True)
        qs_cur_sb.configure(command=self.qs_current_text.yview)

        # 5 buttons at the bottom of Quick Settings
        qs_bf = ttk.Frame(qsf)
        qs_bf.grid(row=3 + NUM_ROWS, column=0, columnspan=3,
                   sticky="ew", pady=(12, 0), padx=0)
        for text, cmd in [
            ("Read",   self.do_read),
            ("Write",  self.do_write),
            ("Export", self.do_export),
            ("Save",   self.do_save),
            ("Reset",  self.do_reset),
        ]:
            ttk.Button(qs_bf, text=text, command=cmd, width=10).pack(
                side="left", padx=6, pady=2)

        # ── Script Panel (left) + Check Status (middle) ─────────────────────
        right_frame = ttk.Frame(mid)
        right_frame.grid(row=0, column=0, sticky="nsew")
        mid.grid_rowconfigure(0, weight=1)
        right_frame.grid_columnconfigure(0, weight=1)
        right_frame.grid_columnconfigure(1, weight=0)

        # Script Execution (60% width)
        sf = ttk.LabelFrame(right_frame, text="Script Execution", padding=6)
        sf.grid(row=0, column=0, sticky="nsew", padx=(0, 4))
        right_frame.grid_rowconfigure(0, weight=1)

        # Script text area with scrollbar
        sf_inner = ttk.Frame(sf)
        sf_inner.pack(fill="both", expand=True, padx=0, pady=0)

        sb = ttk.Scrollbar(sf_inner, orient="vertical")
        sb.pack(side="right", fill="y")

        self.script_text = tk.Text(
            sf_inner, height=18, width=36, state="normal",
            font=("Consolas", 9), wrap="word", yscrollcommand=sb.set)
        self.script_text.pack(side="left", fill="both", expand=True)
        sb.configure(command=self.script_text.yview)

        # Script buttons
        sb_frame = ttk.Frame(sf)
        sb_frame.pack(fill="x", padx=0, pady=(8, 0))
        ttk.Button(sb_frame, text="Run", command=self.do_run_script, width=10).pack(
            side="left", padx=(0, 4))
        ttk.Button(sb_frame, text="Clear", command=self._clear_script, width=10).pack(
            side="left")

        # ── Check Status Panel (right) ─────────────────────────────────────
        csf = ttk.LabelFrame(right_frame, text="Check Status", padding=6)
        csf.grid(row=0, column=1, sticky="nsew")
        right_frame.grid_columnconfigure(1, weight=0)

        # Status list with scrollbar
        cs_inner = ttk.Frame(csf)
        cs_inner.pack(fill="both", expand=True, padx=0, pady=0)

        sb_cs = ttk.Scrollbar(cs_inner, orient="vertical")
        sb_cs.pack(side="right", fill="y")

        self.status_list = tk.Text(
            cs_inner, height=18, width=30, state="disabled",
            font=("Consolas", 8, "bold"), foreground="black", wrap="word", yscrollcommand=sb_cs.set)
        self.status_list.pack(side="left", fill="both", expand=True)
        sb_cs.configure(command=self.status_list.yview)

        # Configure status list tag for active status
        self.status_list.tag_config("active", foreground="#000000", font=("Consolas", 8, "bold"))

        # Status buttons
        cs_frame = ttk.Frame(csf)
        cs_frame.pack(fill="x", padx=0, pady=(8, 0))
        ttk.Button(cs_frame, text="Check", command=self.do_check_status, width=10).pack(
            side="left", padx=(0, 4))
        ttk.Button(cs_frame, text="Clear Fault", command=self.do_clear_fault, width=10).pack(
            side="left")

        # ── Log ───────────────────────────────────────────────────────────
        lf = ttk.LabelFrame(outer, text="Log", padding=6)
        lf.grid(row=2, column=0, sticky="nsew", padx=8, pady=4)
        outer.grid_rowconfigure(2, weight=1)

        self.log_text = tk.Text(
            lf, height=8, width=92, state="disabled",
            font=("Consolas", 9), wrap="word")
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb.set)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        lf.grid_rowconfigure(0, weight=1)
        lf.grid_columnconfigure(0, weight=1)

        # Configure text tags for colors
        self.log_text.tag_config("read_data", foreground="#0066cc", font=("Consolas", 9, "bold"))

        ttk.Button(outer, text="Clear Log", command=self.clear_log).grid(
            row=3, column=0, sticky="e", pady=(2, 0))

    # ================================================================= helpers
    def log(self, msg: str, tag: str = "", newline: bool = True):
        self.log_text.configure(state="normal")
        line_end = "\n" if newline else ""
        if tag:
            self.log_text.insert("end", msg + line_end, tag)
        else:
            self.log_text.insert("end", msg + line_end)
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _get_dev(self) -> int:
        return parse_hex_addr(self.dev_addr_var.get())

    def _get_dev_hex(self) -> str:
        """Get device address as hex string (e.g. 'E0')"""
        return f"{self._get_dev():02X}".lower()

    def _convert_script_format(self, script: str) -> str:
        """Convert simplified script format to standard format.
        X00 00 → w e0 00 00
        D72 01 → r e0 72 01
        """
        dev_hex = self._get_dev_hex()
        lines = []

        for line in script.split('\n'):
            # Strip anything from the first non-standard character onward.
            # Valid script chars are letters, digits, and whitespace; anything
            # else (#, //, ;, *, (, etc.) and everything after it is dropped.
            cut = len(line)
            for i, ch in enumerate(line):
                if not (ch.isalnum() or ch.isspace()):
                    cut = i
                    break
            line = line[:cut]
            line_stripped = line.strip()

            # Skip empty lines and comments (any line starting with a non-alphanumeric symbol)
            if not line_stripped or not line_stripped[0].isalnum():
                lines.append(line_stripped)
                continue

            # Convert X format (write): X<reg> <data> → w <dev> <reg> <data>
            if line_stripped.upper().startswith('X'):
                parts = line_stripped.split()
                if len(parts) >= 2:
                    reg = parts[0][1:]  # Remove 'X'
                    data = ' '.join(parts[1:])
                    line_stripped = f"w {dev_hex} {reg} {data}"

            # Convert D format (read): D<reg> <count> → r <dev> <reg> <count>
            elif line_stripped.upper().startswith('D'):
                parts = line_stripped.split()
                if len(parts) >= 2:
                    reg = parts[0][1:]  # Remove 'D'
                    count = parts[1]
                    line_stripped = f"r {dev_hex} {reg} {count}"

            lines.append(line_stripped)

        return '\n'.join(lines)

    def _ini_path_for(self, name: str) -> str:
        return os.path.join(INI_ROOT, name, f"{name} Trim Config.ini")

    # ======================================== device name / section loading
    def _on_device_name_typed(self, *_):
        """Called on every keystroke — sync, fast (just a file check + small read)."""
        name = self.device_name_var.get().strip()
        self.section_combo["values"] = []
        self._ini_path = None
        if not name:
            return
        path = self._ini_path_for(name)
        if os.path.isfile(path):
            cfg = _make_cfg()
            cfg.read(path, encoding="utf-8")
            sections = cfg.sections()
            self.section_combo["values"] = sections
            self._ini_path = path
            self.log(f"[OK] {path}  ({len(sections)} section(s))")

    def do_load(self):
        """Load INI file for the Device Name."""
        name = self.device_name_var.get().strip()
        if not name:
            messagebox.showwarning("Missing", "Enter a Device Name.")
            return
        path = self._ini_path_for(name)
        if not os.path.isfile(path):
            messagebox.showerror(
                "File Not Found",
                f"No INI file found at:\n{path}"
            )
            return
        try:
            cfg = _make_cfg()
            cfg.read(path, encoding="utf-8")
            sections = cfg.sections()
            self.section_combo["values"] = sections
            self._ini_path = path
            self.log(f"[OK] Loaded {path} ({len(sections)} section(s))")
            if sections:
                self.log(f"     Available sections: {', '.join(sections)}")

            # Also try to load device address from Default Setting.ini
            default_setting_path = os.path.join(INI_ROOT, name, f"{name} Default Setting.ini")
            if os.path.isfile(default_setting_path):
                try:
                    default_cfg = _make_cfg()
                    default_cfg.read(default_setting_path, encoding="utf-8")
                    self.log(f"[OK] Loaded {default_setting_path}")
                    found = False
                    for s in default_cfg.sections():
                        if "IC Address*" in default_cfg[s]:
                            try:
                                addr_str = default_cfg[s]["IC Address*"].strip().strip("\"'")
                                addr_decimal = float(addr_str)
                                dev_addr = int(addr_decimal)
                                self.dev_addr_var.set(f"{dev_addr:02X}")
                                self.log(f"     Device address: {dev_addr:02X}")
                                found = True
                                break
                            except Exception:
                                pass
                except Exception as e:
                    pass
            else:
                self.log(f"[ERR] {default_setting_path} not found")

            # Load Status Register Map
            status_map_path = os.path.join(INI_ROOT, name, f"{name} Status Register Map.txt")
            if os.path.isfile(status_map_path):
                try:
                    self._status_registers = parse_status_register_map(status_map_path)
                    self.log(f"[OK] Loaded {status_map_path} ({len(self._status_registers)} entries)")
                except Exception as e:
                    pass
            else:
                pass

            # Load FC Register Map (for Quick Settings)
            fc_map_path = os.path.join(INI_ROOT, name, f"{name} FC Register Map.txt")
            self._fc_map = []
            self._fc_names = set()
            if os.path.isfile(fc_map_path):
                try:
                    self._fc_map = parse_fc_register_map(fc_map_path)
                    self._fc_names = {e.name for e in self._fc_map}
                    self.log(f"[OK] Loaded {fc_map_path} ({len(self._fc_map)} entries)")
                except Exception as exc:
                    self.log(f"[ERR] FC map parse failed: {exc}")

            # Load [Quick Setting] section from Default Setting.ini into the QS panel
            self._qs_default_setting_path = default_setting_path if os.path.isfile(default_setting_path) else None
            self._qs_load_from_ini(default_setting_path)
            # Re-validate any pre-populated QS rows now that fc_names is loaded
            for r in self.qs_rows:
                r._validate_value()
        except Exception as exc:
            messagebox.showerror("Load Error", str(exc))

    def _on_device_name_change(self, _event=None):
        """Kept for Save/Reset callers; delegates to the typed handler."""
        self._on_device_name_typed()

    def _on_section_selected(self, _event=None):
        section = self.section_var.get()
        if not section or not self._ini_path:
            return
        cfg = _make_cfg()
        cfg.read(self._ini_path, encoding="utf-8")
        if section not in cfg:
            return

        sec  = cfg[section]
        keys = list(sec.keys())[:NUM_ROWS]

        for i, row in enumerate(self.trim_rows):
            if i < len(keys):
                name = keys[i]
                try:
                    f1, f2 = parse_ini_value(sec[name])
                    row.name_var.set(name)
                    row.load_fields(f1, f2)
                except Exception as exc:
                    self.log(f"[ERR] '{name}': {exc}")
                    row.clear_all()
            else:
                row.clear_all()

        self.log(f"[OK] Loaded '{section}'  ({len(keys)} trim(s))")

    # ================================================================= COM scan / auto-connect
    def do_scan_ports(self):
        """Scan for STLink COM port and update status. Does NOT connect."""
        all_ports = get_all_ports_info()
        self.log("[--] Scanning COM ports...")
        for port_info in all_ports:
            self.log(f"    {port_info['device']}: {port_info['description']}")

        port = detect_stlink_port()
        if not port:
            self._detected_port = None
            self.status_var.set("No STLink Found")
            self.status_lbl.config(foreground="#cc0000")
            self.log("[ERR] No STLink Virtual COM port detected")
            if not all_ports:
                self.log("[ERR] No COM ports found at all")
            return

        self._detected_port = port
        self.status_var.set(f"{port} Ready")
        self.status_lbl.config(foreground="#007700")
        self.log(f"[OK] Detected STLink: {port} (will connect on read/write)")

    def _connect_for_operation(self) -> bool:
        """Open COM port for an I2C operation. Returns True on success."""
        if self.board:
            return True
        port = self._detected_port or detect_stlink_port()
        if not port:
            messagebox.showwarning(
                "No STLink",
                "No STLink Virtual COM port detected.\nConnect the STLink and click Rescan.")
            return False
        self._detected_port = port
        try:
            self.board = I2X_AAA(port)
            return True
        except Exception as exc:
            messagebox.showerror("Connection Error", str(exc))
            self.board = None
            self.log(f"[ERR] Connection failed: {exc}")
            return False

    def _disconnect_after_operation(self):
        """Close COM port to release it after an operation."""
        if self.board:
            try:
                self.board.close()
            except Exception:
                pass
            self.board = None

    def _switch_page(self):
        """Switch to the selected page by writing page select commands."""
        page = self.page_var.get().strip()
        if not page or page == "0":
            return  # Page 0 is default, no switch needed

        if not self.board:
            return

        try:
            page_num = int(page)
            dev_hex = f"{self._get_dev():02X}".upper()
            # Write page select sequence
            self.board.i2c_send(f"w {dev_hex} 00 00\nw {dev_hex} 7f 00\nw {dev_hex} 00 0{page_num}")
            self.log(f"[--] Switch to page {page_num}")
        except Exception as exc:
            self.log(f"[ERR] Page switch failed: {exc}")

    # =================================================================== Read
    def do_read(self):
        if self.mode_var.get() == "Quick Settings":
            return self._qs_do_read()
        if not self._connect_for_operation():
            return
        try:
            self._switch_page()
            dev_hex = f"{self._get_dev():02X}".lower()
            errors, count = [], 0
            cmd_num = 0
            for row in self.trim_rows:
                try:
                    f1, f2 = row.get_fields()
                    if f1 is None:
                        continue
                    cmd_num += 1
                    reg1_hex = f"{f1[0]:02X}".lower()
                    byte1, s1, raw1 = _read_reg(self.board, dev_hex.upper(), reg1_hex.upper())
                    val1 = (byte1 >> f1[2]) & fmask(fwidth(f1[1], f1[2]))

                    if f2:
                        reg2_hex = f"{f2[0]:02X}".lower()
                        byte2, s2, raw2 = _read_reg(self.board, dev_hex.upper(), reg2_hex.upper())
                        val2     = (byte2 >> f2[2]) & fmask(fwidth(f2[1], f2[2]))
                        combined = (val1 << fwidth(f2[1], f2[2])) | val2
                        bits_str = f"{f1[1]}:{f1[2]},{f2[1]}:{f2[2]}"
                        self.log(f"[{cmd_num}] read 0x{reg1_hex}=0x{byte1:02x}, 0x{reg2_hex}=0x{byte2:02x} -> [{bits_str}]=", newline=False)
                        self.log(f"{combined}", tag="read_data")
                    else:
                        bits_str = f"{f1[1]}:{f1[2]}"
                        self.log(f"[{cmd_num}] read 0x{reg1_hex}=0x{byte1:02x} -> [{bits_str}]=", newline=False)
                        self.log(f"{val1}", tag="read_data")
                        combined = val1

                    row.val_var.set(str(combined))
                    count += 1
                except Exception as exc:
                    errors.append(str(exc));  self.log(f"[{cmd_num}] error: {exc}")

            if errors:
                messagebox.showerror("Read Error", "\n".join(errors))
            else:
                self.log(f"[OK] Read complete — {count} row(s)")
        finally:
            self._disconnect_after_operation()

    # ================================================================== Write
    def do_write(self):
        if self.mode_var.get() == "Quick Settings":
            return self._qs_do_write()
        if not self._connect_for_operation():
            return
        try:
            self._switch_page()
            dev_hex = f"{self._get_dev():02X}".lower()
            errors, count = [], 0
            cmd_num = 0
            for row in self.trim_rows:
                try:
                    f1, f2 = row.get_fields()
                    if f1 is None:
                        continue
                    val_s = row.val_var.get().strip()
                    if not val_s:
                        continue
                    cmd_num += 1
                    write_val = int(val_s, 0)
                    w1   = fwidth(f1[1], f1[2])
                    w2   = fwidth(f2[1], f2[2]) if f2 else 0
                    maxv = fmask(w1 + w2)
                    if write_val < 0 or write_val > maxv:
                        raise ValueError(
                            f"'{row.name_var.get()}': {write_val} out of [0,{maxv}]")

                    val1 = (write_val >> w2) & fmask(w1) if f2 else write_val
                    val2 = write_val & fmask(w2) if f2 else None

                    reg1_hex = f"{f1[0]:02X}".lower()
                    old_byte1, new_byte1, r1, w1s, raw1 = _rmw(
                        self.board, dev_hex.upper(), reg1_hex.upper(), f1[1], f1[2], val1)

                    self.log(f"[{cmd_num}] read 0x{reg1_hex}=0x{old_byte1:02x}")
                    self.log(f"    write 0x{reg1_hex}[{f1[1]}:{f1[2]}]={val1} -> 0x{reg1_hex}=0x", newline=False)
                    self.log(f"{new_byte1:02x}", tag="read_data")

                    if f2 and val2 is not None:
                        reg2_hex = f"{f2[0]:02X}".lower()
                        old_byte2, new_byte2, r2, w2s, raw2 = _rmw(
                            self.board, dev_hex.upper(), reg2_hex.upper(), f2[1], f2[2], val2)
                        self.log(f"[{cmd_num}] read 0x{reg2_hex}=0x{old_byte2:02x}")
                        self.log(f"    write 0x{reg2_hex}[{f2[1]}:{f2[2]}]={val2} -> 0x{reg2_hex}=0x", newline=False)
                        self.log(f"{new_byte2:02x}", tag="read_data")

                    count += 1
                except Exception as exc:
                    errors.append(str(exc));  self.log(f"[{cmd_num}] error: {exc}")

            if errors:
                messagebox.showerror("Write Error", "\n".join(errors))
            else:
                self.log(f"[OK] Write complete — {count} row(s)")
        finally:
            self._disconnect_after_operation()

    # ================================================================= Export
    def do_export(self):
        if self.mode_var.get() == "Quick Settings":
            return self._qs_do_export()
        if not self._connect_for_operation():
            return
        try:
            dev_hex   = f"{self._get_dev():02X}"
            reg_order: list[str]       = []
            reg_map:   dict[str, int]  = {}
            errors: list[str]          = []

            for row in self.trim_rows:
                try:
                    f1, f2 = row.get_fields()
                    if f1 is None:
                        continue
                    for reg_int in ([f1[0]] + ([f2[0]] if f2 else [])):
                        reg_hex = f"{reg_int:02X}"
                        if reg_hex not in reg_map:
                            byte, s, raw = _read_reg(self.board, dev_hex, reg_hex)
                            self.log(f"[TX] {s}")
                            self.log(f"[RX] {raw}")
                            reg_map[reg_hex] = byte
                            reg_order.append(reg_hex)
                except Exception as exc:
                    errors.append(str(exc));  self.log(f"[ERR] {exc}")

            if errors:
                messagebox.showerror("Export Read Error", "\n".join(errors))
                if not reg_order:
                    return

            dev_lo = dev_hex.lower()
            lines  = [f"w {dev_lo} {r.lower()} {reg_map[r]:02x}" for r in reg_order]
            script = "\n".join(lines)
            self.log(f"[OK] Export — {len(lines)} register(s)")
            self._show_export_popup(script)
        finally:
            self._disconnect_after_operation()

    def _show_export_popup(self, script: str):
        win = tk.Toplevel(self.root)
        win.title("Export Script")
        win.resizable(True, True)
        win.grab_set()

        ttk.Label(win, text="Script  (w  device_addr  reg_addr  full_reg_byte):",
                  font=("Segoe UI", 9, "bold")).pack(
            anchor="w", padx=10, pady=(10, 2))

        txt = tk.Text(win,
                      width=36,
                      height=max(4, len(script.splitlines()) + 2),
                      font=("Consolas", 11))
        txt.pack(fill="both", expand=True, padx=10, pady=(0, 4))
        txt.insert("1.0", script)
        txt.configure(state="disabled")

        bf = ttk.Frame(win)
        bf.pack(fill="x", padx=10, pady=(0, 10))

        def _copy():
            win.clipboard_clear()
            win.clipboard_append(script)
            self.log("[OK] Script copied to clipboard")

        ttk.Button(bf, text="Copy to Clipboard", command=_copy).pack(
            side="left", padx=4)
        ttk.Button(bf, text="Close", command=win.destroy).pack(
            side="right", padx=4)

    # =================================================================== Save
    def do_save(self):
        if self.mode_var.get() == "Quick Settings":
            return self._qs_do_save()
        device_name = self.device_name_var.get().strip()
        if not device_name:
            messagebox.showwarning("Missing", "Enter a Device Name before saving.")
            return
        section = self.section_var.get().strip()
        if not section:
            messagebox.showwarning("Missing", "Enter or select a Trim Section name.")
            return

        ini_path = self._ini_path_for(device_name)
        os.makedirs(os.path.dirname(ini_path), exist_ok=True)

        cfg = _make_cfg()
        if os.path.isfile(ini_path):
            cfg.read(ini_path, encoding="utf-8")

        # Create section if it doesn't exist (preserves order for existing sections)
        if section not in cfg:
            cfg.add_section(section)

        # Update the section values (clear old entries in this section first)
        for key in list(cfg.options(section)):
            cfg.remove_option(section, key)

        for row in self.trim_rows:
            name = row.name_var.get().strip()
            if not name:
                continue
            ini_val = row.to_ini_value()
            if ini_val:
                cfg[section][name] = ini_val

        with open(ini_path, "w", encoding="utf-8") as fh:
            cfg.write(fh)

        self._ini_path = ini_path
        self.log(f"[OK] Saved → {ini_path}  [{section}]")

        # Refresh dropdown
        cfg2 = _make_cfg()
        cfg2.read(ini_path, encoding="utf-8")
        self.section_combo["values"] = cfg2.sections()

    # ================================================================== Reset
    def do_reset(self):
        if self.mode_var.get() == "Quick Settings":
            return self._qs_do_reset()
        for row in self.trim_rows:
            row.clear_all()
        self.section_var.set("")
        self.log("[--] Reset — Quick Trim cleared")

    # ============================================================ Mode switch
    def _on_mode_switch(self, _event=None):
        """Switch between Quick Trim and Quick Settings panels.
        Also disables/enables the Trim Section + Page combos accordingly.
        """
        mode = self.mode_var.get()
        if mode == "Quick Settings":
            self.tf.grid_remove()
            self.qsf.grid()
            self.section_combo.config(state="disabled")
            self.page_combo.config(state="disabled")
            self.log("[--] Mode → Quick Settings")
        else:
            self.qsf.grid_remove()
            self.tf.grid()
            self.section_combo.config(state="normal")
            self.page_combo.config(state="readonly")
            self.log("[--] Mode → Quick Trim")

    # ==================================================== Quick Settings I/O
    def _qs_load_from_ini(self, path: str):
        """Read [Quick Setting] from <Name> Default Setting.ini and populate the QS panel."""
        if not os.path.isfile(path):
            return
        try:
            cfg = _make_cfg()
            cfg.read(path, encoding="utf-8")
            if "Quick Setting" not in cfg:
                self.log("[--] No [Quick Setting] section in Default Setting.ini")
                return
            sec = cfg["Quick Setting"]
            items  = _qs_parse_ini_list(sec.get("Device Setting Items", ""))
            values = _qs_parse_ini_list(sec.get("New Setting Items", ""))
            n = min(len(items), NUM_ROWS)
            for i, row in enumerate(self.qs_rows):
                if i < n:
                    row.name_var.set(items[i])
                    row.value_var.set(values[i] if i < len(values) else "")
                else:
                    row.clear_all()
            self.log(f"[OK] Loaded [Quick Setting] ({n} item(s))")
        except Exception as exc:
            self.log(f"[ERR] [Quick Setting] load failed: {exc}")

    def _qs_do_reset(self):
        for row in self.qs_rows:
            row.clear_all()
        self._qs_clear_current_settings()
        self.log("[--] Reset — Quick Settings cleared")

    def _qs_clear_current_settings(self):
        self.qs_current_text.config(state="normal")
        self.qs_current_text.delete("1.0", "end")
        self.qs_current_text.config(state="disabled")

    def _qs_set_current_settings(self, names: list[str]):
        self.qs_current_text.config(state="normal")
        self.qs_current_text.delete("1.0", "end")
        self.qs_current_text.insert("1.0", "\n".join(names))
        self.qs_current_text.config(state="disabled")

    def _qs_switch_to_page(self, page_num: int):
        """Emit page-select I2C commands for a specific page (used by QS Read/Write)."""
        if not self.board:
            return
        try:
            dev_hex = f"{self._get_dev():02X}".upper()
            self.board.i2c_send(
                f"w {dev_hex} 00 00\nw {dev_hex} 7f 00\nw {dev_hex} 00 {page_num:02X}")
        except Exception as exc:
            self.log(f"[ERR] Page switch failed: {exc}")

    def _qs_do_read(self):
        """Read every (page, reg) pair referenced by FC map, then list matching FC names."""
        if not self._fc_map:
            messagebox.showwarning("No FC Map", "Load a device with an FC Register Map first.")
            return
        if not self._connect_for_operation():
            return
        try:
            dev_hex = f"{self._get_dev():02X}".upper()

            # Collect all unique (page, reg) pairs from the FC map
            reg_addrs: set[tuple[int, int]] = set()
            for e in self._fc_map:
                reg_addrs.add((e.page1, e.reg1))
                if e.has_part2:
                    reg_addrs.add((e.page2, e.reg2))

            # Read each register (grouped by page to minimize page switches)
            reg_vals: dict[tuple[int, int], int] = {}
            for page in sorted({p for p, _ in reg_addrs}):
                self._qs_switch_to_page(page)
                for (p, r) in sorted(reg_addrs):
                    if p != page:
                        continue
                    try:
                        reg_hex = f"{r:02X}"
                        byte, _s, _raw = _read_reg(self.board, dev_hex, reg_hex)
                        reg_vals[(p, r)] = byte
                    except Exception as exc:
                        self.log(f"[ERR] read P{p} 0x{r:02X}: {exc}")

            # For each FC entry, check whether current bits equal the entry's expected value
            matches: list[str] = []
            for e in self._fc_map:
                v1 = reg_vals.get((e.page1, e.reg1))
                if v1 is None:
                    continue
                extracted1 = (v1 >> e.start1) & fmask(e.len1)
                if extracted1 != e.val1:
                    continue
                if e.has_part2:
                    v2 = reg_vals.get((e.page2, e.reg2))
                    if v2 is None:
                        continue
                    extracted2 = (v2 >> e.start2) & fmask(e.len2)
                    if extracted2 != e.val2:
                        continue
                matches.append(e.name)

            self._qs_set_current_settings(matches)
            self.log(f"[OK] QS Read — {len(reg_vals)} reg(s), {len(matches)} setting(s) matched")
        finally:
            self._disconnect_after_operation()

    def _qs_do_write(self):
        """Write each non-empty Setting Value into DUT (read-modify-write)."""
        if not self._fc_map:
            messagebox.showwarning("No FC Map", "Load a device with an FC Register Map first.")
            return
        by_name = {e.name: e for e in self._fc_map}
        # Collect write intents
        intents: list[tuple[QuickSettingRow, FCMapEntry]] = []
        errors: list[str] = []
        for row in self.qs_rows:
            v = row.value_var.get().strip()
            if not v:
                continue
            entry = by_name.get(v)
            if entry is None:
                row.value_entry.config(bg="#ffe6e6")
                errors.append(f"'{v}' not in FC map")
                self.log(f"[ERR] '{v}' not in FC map, skipped")
                continue
            intents.append((row, entry))

        if not intents:
            if errors:
                messagebox.showerror("Write Error", "\n".join(errors))
            else:
                self.log("[--] QS Write — nothing to write")
            return

        if not self._connect_for_operation():
            return
        try:
            dev_hex = f"{self._get_dev():02X}".upper()
            written = 0
            # Group by page to minimize page switches (page1 and page2 may differ)
            for row, e in intents:
                try:
                    self._qs_switch_to_page(e.page1)
                    reg_hex = f"{e.reg1:02X}"
                    old, new, _r, _w, _raw = _rmw(
                        self.board, dev_hex, reg_hex, e.start1 + e.len1 - 1, e.start1, e.val1)
                    self.log(f"[QS] {e.name}: P{e.page1} 0x{reg_hex} [{e.start1 + e.len1 - 1}:{e.start1}]={e.val1} "
                             f"(0x{old:02X} → 0x{new:02X})")
                    if e.has_part2:
                        self._qs_switch_to_page(e.page2)
                        reg_hex2 = f"{e.reg2:02X}"
                        old2, new2, _r2, _w2, _raw2 = _rmw(
                            self.board, dev_hex, reg_hex2, e.start2 + e.len2 - 1, e.start2, e.val2)
                        self.log(f"     part2: P{e.page2} 0x{reg_hex2} [{e.start2 + e.len2 - 1}:{e.start2}]={e.val2} "
                                 f"(0x{old2:02X} → 0x{new2:02X})")
                    written += 1
                except Exception as exc:
                    errors.append(f"{e.name}: {exc}")
                    self.log(f"[ERR] {e.name}: {exc}")
            if errors:
                messagebox.showerror("Write Error", "\n".join(errors))
            else:
                self.log(f"[OK] QS Write — {written} setting(s)")
        finally:
            self._disconnect_after_operation()

    def _qs_do_export(self):
        """Read every (page, reg) referenced by valid Setting Values, export w commands."""
        if not self._fc_map:
            messagebox.showwarning("No FC Map", "Load a device with an FC Register Map first.")
            return
        by_name = {e.name: e for e in self._fc_map}
        # Which registers need to appear in the export
        touched: list[tuple[int, int]] = []
        seen: set[tuple[int, int]] = set()
        for row in self.qs_rows:
            v = row.value_var.get().strip()
            if not v:
                continue
            entry = by_name.get(v)
            if entry is None:
                self.log(f"[ERR] '{v}' not in FC map, skipped for Export")
                continue
            for p, r in ([(entry.page1, entry.reg1)] +
                         ([(entry.page2, entry.reg2)] if entry.has_part2 else [])):
                if (p, r) not in seen:
                    seen.add((p, r))
                    touched.append((p, r))

        if not touched:
            messagebox.showwarning("Nothing to Export", "No valid Setting Values to export.")
            return

        if not self._connect_for_operation():
            return
        try:
            dev_hex = f"{self._get_dev():02X}".upper()
            dev_lo = dev_hex.lower()
            # For each register: read current, apply the RMW mask for every matching entry, output w
            reg_vals: dict[tuple[int, int], int] = {}
            for page in sorted({p for p, _ in touched}):
                self._qs_switch_to_page(page)
                for (p, r) in touched:
                    if p != page:
                        continue
                    try:
                        byte, _s, _raw = _read_reg(self.board, dev_hex, f"{r:02X}")
                        reg_vals[(p, r)] = byte
                    except Exception as exc:
                        self.log(f"[ERR] read P{p} 0x{r:02X}: {exc}")

            # Apply RMW in memory for each intent
            for row in self.qs_rows:
                v = row.value_var.get().strip()
                if not v:
                    continue
                e = by_name.get(v)
                if e is None:
                    continue
                cur1 = reg_vals.get((e.page1, e.reg1))
                if cur1 is not None:
                    mask = fmask(e.len1) << e.start1
                    reg_vals[(e.page1, e.reg1)] = (cur1 & ~mask) | ((e.val1 & fmask(e.len1)) << e.start1)
                if e.has_part2:
                    cur2 = reg_vals.get((e.page2, e.reg2))
                    if cur2 is not None:
                        mask2 = fmask(e.len2) << e.start2
                        reg_vals[(e.page2, e.reg2)] = (cur2 & ~mask2) | ((e.val2 & fmask(e.len2)) << e.start2)

            # Build script (group page switches by page)
            lines: list[str] = []
            for page in sorted({p for p, _ in touched}):
                if page != 0:
                    lines.append(f"w {dev_lo} 00 00")
                    lines.append(f"w {dev_lo} 7f 00")
                    lines.append(f"w {dev_lo} 00 {page:02x}")
                for (p, r) in touched:
                    if p != page:
                        continue
                    lines.append(f"w {dev_lo} {r:02x} {reg_vals[(p, r)]:02x}")
            script = "\n".join(lines)
            self.log(f"[OK] QS Export — {len(touched)} register(s)")
            self._show_export_popup(script)
        finally:
            self._disconnect_after_operation()

    def _qs_do_save(self):
        """Write the current Setting Items + Setting Values back to
        [Quick Setting] section of <Name> Default Setting.ini.
        Preserves the trailing \\0D\\0A sentinel and comma+3-spaces separator.
        """
        name = self.device_name_var.get().strip()
        if not name:
            messagebox.showwarning("Missing", "Enter a Device Name before saving.")
            return
        path = self._qs_default_setting_path or os.path.join(
            INI_ROOT, name, f"{name} Default Setting.ini")
        if not os.path.isfile(path):
            messagebox.showerror("File Not Found",
                                 f"Default Setting.ini not found:\n{path}")
            return

        items: list[str] = []
        values: list[str] = []
        for row in self.qs_rows:
            n = row.name_var.get().strip()
            v = row.value_var.get().strip()
            if not n and not v:
                continue
            items.append(n)
            values.append(v)

        try:
            cfg = _make_cfg()
            cfg.read(path, encoding="utf-8")
            if "Quick Setting" not in cfg:
                cfg.add_section("Quick Setting")
            cfg["Quick Setting"]["Device Setting Items"] = _qs_build_ini_list(items)
            cfg["Quick Setting"]["Device Setting Items_type"] = '"Array of strings"'
            cfg["Quick Setting"]["New Setting Items"] = _qs_build_ini_list(values)
            cfg["Quick Setting"]["New Setting Items_type"] = '"Array of strings"'
            with open(path, "w", encoding="utf-8") as fh:
                cfg.write(fh)
            self.log(f"[OK] QS Saved → {path}  [Quick Setting] ({len(items)} item(s))")
        except Exception as exc:
            messagebox.showerror("Save Error", str(exc))

    # ================================================================= Check Status
    def do_check_status(self):
        """Read registers and display active statuses."""
        if not self._status_registers:
            messagebox.showwarning("No Data", "Status Register Map not loaded.")
            return
        if not self._connect_for_operation():
            return

        dev_hex = f"{self._get_dev():02X}"
        status_output = []
        reg_cache = {}

        try:
            try:
                self.board.i2c_send(f"w {dev_hex} 00 00\nw {dev_hex} 7f 00")
            except Exception as exc:
                self.log(f"[ERR] Page switch failed: {exc}")

            unique_regs = {}
            for item in self._status_registers:
                reg_str = item['reg_addr'].strip()
                reg_int = int(reg_str, 16)
                if reg_int not in unique_regs:
                    unique_regs[reg_int] = f"{reg_int:02X}"

            for reg_int, reg_hex in unique_regs.items():
                byte, _, _ = _read_reg(self.board, dev_hex, reg_hex)
                reg_cache[reg_int] = byte

            for item in self._status_registers:
                reg_str = item['reg_addr'].strip()
                reg_int = int(reg_str, 16)
                bits_str = item['bits']
                expected_value = item['value']
                status_text = item['status']

                byte_val = reg_cache.get(reg_int, 0)

                if ',' in bits_str:
                    bit_list = [int(b.strip()) for b in bits_str.split(',')]
                else:
                    bit_list = [int(bits_str)]

                if len(bit_list) > 1:
                    high = max(bit_list)
                    low = min(bit_list)
                    width = high - low + 1
                    extracted = (byte_val >> low) & ((1 << width) - 1)
                else:
                    bit = bit_list[0]
                    extracted = (byte_val >> bit) & 1

                if extracted == expected_value:
                    status_output.append((status_text, True))

            self.status_list.configure(state="normal")
            self.status_list.delete("1.0", "end")
            for status, is_active in status_output:
                if is_active:
                    self.status_list.insert("end", status + "\n", "active")
            self.status_list.configure(state="disabled")

            self.log("[OK] Check status complete")

        except Exception as exc:
            messagebox.showerror("Status Check Error", str(exc))
            self.log(f"[ERR] Status check failed: {exc}")
        finally:
            self._disconnect_after_operation()

    # ================================================================ Clear Fault
    def do_clear_fault(self):
        """Clear fault by executing clear fault commands."""
        if not self._connect_for_operation():
            return

        dev_hex = self._get_dev_hex()
        try:
            try:
                self.board.i2c_send(f"w {dev_hex} 00 00\nw {dev_hex} 7f 00")
            except Exception as exc:
                self.log(f"[ERR] Page switch failed: {exc}")

            commands = [
                f"w {dev_hex} 00 00",
                f"w {dev_hex} 7f 00",
                f"w {dev_hex} 01 08",
            ]

            self.log("[--] Executing clear fault commands...")
            for i, cmd in enumerate(commands, 1):
                try:
                    self.log(f"[{i}] {cmd} write successful")
                    self.board.i2c_send(cmd)
                except Exception as exc:
                    self.log(f"[ERR] Command failed: {exc}")
                    messagebox.showerror("Clear Fault Error", str(exc))
                    return

            self.log(f"[OK] Clear fault complete")
        finally:
            self._disconnect_after_operation()

    # ================================================================ Script
    def _clear_script(self):
        """Clear script text area"""
        self.script_text.delete("1.0", "end")

    def do_run_script(self):
        """Execute user-written script - pass directly to I2X_AAA"""
        script_text = self.script_text.get("1.0", "end").strip()
        if not script_text:
            messagebox.showwarning("Empty Script", "Enter script commands.")
            return

        if not self._connect_for_operation():
            return

        try:
            converted_script = self._convert_script_format(script_text)
            lines = converted_script.split('\n')
            cmd_num = 0

            for line in lines:
                line = line.strip()

                if not line or not line[0].isalnum():
                    continue

                cmd_num += 1

                if line.upper().startswith('D') and len(line) > 1 and line[1:].isdigit():
                    try:
                        delay_ms = int(line[1:])
                        time.sleep(delay_ms / 1000.0)
                        self.log(f"[{cmd_num}] delay {delay_ms}ms")
                    except Exception as exc:
                        self.log(f"[{cmd_num}] error: {exc}")
                        return
                    continue

                try:
                    results = self.board.i2c_send(line)
                    cmd_upper = line.upper().split()[0] if line else ""

                    if cmd_upper == 'R':
                        parts = line.split()
                        dev_addr = parts[1] if len(parts) > 1 else "??"
                        reg_addr = parts[2] if len(parts) > 2 else "??"
                        self.log(f"[{cmd_num}] r {dev_addr} {reg_addr} read successful")
                        if results and results[0]:
                            hex_values = []
                            for raw in results[0]:
                                value = int(raw[4:6], 16)
                                hex_values.append(f"{value:02X}")
                            self.log(f"{' '.join(hex_values)}", tag="read_data")
                    elif cmd_upper == 'W':
                        parts = line.split()
                        dev_addr = parts[1] if len(parts) > 1 else "??"
                        reg_addr = parts[2] if len(parts) > 2 else "??"
                        val = parts[3] if len(parts) > 3 else "??"
                        self.log(f"[{cmd_num}] w {dev_addr} {reg_addr} {val} write successful")
                    else:
                        self.log(f"[{cmd_num}] {line} ok")

                except Exception as exc:
                    self.log(f"[{cmd_num}] error: {exc}")
                    return
        finally:
            self._disconnect_after_operation()

    def _on_close(self):
        self._disconnect_after_operation()
        self.root.destroy()


# ---------------------------------------------------------------------------
def main():
    root = tk.Tk()
    root.minsize(720, 776)
    TrimGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
