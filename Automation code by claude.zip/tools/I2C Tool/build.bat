@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo  Build: I2C_Tool  (one-file)
echo ============================================================
echo.

REM --- 0. require the repo .venv --------------------------------------------
set "VPY=..\..\.venv\Scripts\python.exe"
if not exist "%VPY%" (
    echo [!] ERROR: .venv not found. Run setup_env.bat at the repo root first.
    pause
    exit /b 1
)

REM --- 1. ensure PyInstaller in the .venv (build-only tool) -----------------
REM Runtime dependencies come from setup_env. PyInstaller is needed ONLY to
REM build an exe, so it is installed here, on demand, into the .venv -- only
REM whoever builds pays for it, not every setup_env user. (The .venv itself
REM must already exist -- checked in step 0 above.)
echo [1] Ensuring PyInstaller in the .venv...
"%VPY%" -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo     Not found -- installing PyInstaller into the .venv...
    "%VPY%" -m pip install pyinstaller
    if errorlevel 1 (
        echo [!] ERROR: failed to install PyInstaller.
        pause
        exit /b 1
    )
)
echo.

REM --- 2. clean previous output --------------------------------------------
if exist "dist"          rmdir /s /q "dist"
if exist "build"         rmdir /s /q "build"
if exist "I2C_Tool.spec" del /q "I2C_Tool.spec"

REM --- 3. build one-file exe -----------------------------------------------
REM  --onefile   -> dist\ holds a single I2C_Tool.exe (no _internal\)
REM  --windowed  -> GUI, no console window
REM  --paths ..\.. -> repo root, so `instruments.*` resolves at build time
echo [2] Running PyInstaller (one-file, this takes a while)...
"%VPY%" -m PyInstaller --noconfirm --clean --onefile --windowed ^
    --name "I2C_Tool" ^
    --paths "..\.." ^
    "I2C_Tool.py"
if errorlevel 1 (
    echo [!] ERROR: PyInstaller build failed.
    pause
    exit /b 1
)
echo.

REM --- 4. clean temp artifacts (keep only dist\I2C_Tool.exe) ---------------
echo [3] Cleaning temp files...
if exist "build"         rmdir /s /q "build"
if exist "__pycache__"   rmdir /s /q "__pycache__"
if exist "I2C_Tool.spec" del /q "I2C_Tool.spec"
echo.

if exist "dist\I2C_Tool.exe" (
    echo ============================================================
    echo  BUILD SUCCESSFUL
    echo  Output: %~dp0dist\I2C_Tool.exe
    echo ============================================================
) else (
    echo ============================================================
    echo  BUILD INCOMPLETE -- check output above
    echo ============================================================
)
echo.
pause
