r"""Thermal Stream Control - TS700 V3.1 one-click controller.

Single-button flow:
    1. Click "SET ALL" -> auto-connect (if not already), apply all settings,
       force flow ON, auto-start monitor.
    2. Monitor polls air+DUT temp at 1 Hz, plots vs elapsed time with the
       setpoint dashed line and accuracy band.
    3. Chamber signals at-temp + soak complete (TECR bit 0 = 1) -> monitor
       auto-stops and connection is auto-released.
    4. "STOP" button aborts mid-run: forces flow OFF, then disconnects.

On launch, a one-shot IDN check is performed on the default GPIB address
so the user knows the chamber is reachable before setting up a run.

Deps: pyvisa (+ NI-VISA runtime), matplotlib, Thermal_Stream.py wrapper.
"""
from __future__ import annotations

import os
import sys
import time
import tkinter as tk
from datetime import datetime
from tkinter import messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure                                    # noqa: E402
from matplotlib.lines import Line2D                                     # noqa: E402
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg         # noqa: E402


def _setup_paths():
    # Frozen: _MEIPASS.  Source: this tool folder + repo root (../.. from
    # this tool folder) so `instruments.*` is importable.
    candidates = []
    if getattr(sys, "frozen", False):
        candidates.append(getattr(sys, "_MEIPASS", ""))
    here = os.path.dirname(os.path.abspath(__file__))
    candidates.append(here)
    candidates.append(os.path.abspath(os.path.join(here, "..", "..")))
    for p in candidates:
        if p and p not in sys.path:
            sys.path.insert(0, p)


_setup_paths()

# Class renamed on the way into the framework (Thermal_Stream -> ATS710);
# aliased here so the rest of this file doesn't need to change.
from instruments.thermal.ats_710 import ATS710 as Thermal_Stream  # noqa: E402


DEFAULTS = {
    "gpib":      "GPIB0::9::INSTR",
    "setpoint":  25.0,
    "soak":      30,
    "accuracy":  1.0,
    "ramp":      0,
    "flow_rate": 10,
    "mode":      "DUT",
    "sensor":    "K",
}

MODE_MAP   = {"Air": 0, "DUT": 1, "Air+DUT": 2}
SENSOR_MAP = {"NON": 0, "T": 1, "K": 2}

POLL_MS      = 1000       # monitor tick interval
MAX_POINTS   = 7200       # 2 h at 1 Hz
VISA_TIMEOUT_MS = 5000    # per-query timeout
COOL_REQUIRED_BELOW = 15  # °C - warn if setpoint below this and compressor off


class ThermalStreamControl:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Thermal Stream Control - TS700 V3.1")
        self.ts: "Thermal_Stream | None" = None
        self.monitoring = False
        self._monitor_after_id = None
        self.t_data:   list[float] = []
        self.air_data: list[float] = []
        self.dut_data: list[float] = []
        self.start_time: float | None = None
        # Cached at Apply time so we don't re-query every tick.
        self._cached_setp = None
        self._cached_acc  = None
        self._cached_soak = None
        # Soak countdown state: timestamp we first entered the in-range band,
        # or None while ramping. Reset on abort/apply/drift.
        self._holding_start_time: float | None = None
        # Once a SCPI query times out, mark it dead so we don't waste
        # 5 s on every subsequent tick waiting for a chamber that doesn't
        # implement that command (e.g. ATS-710 doesn't have ERROR?).
        self._dead_queries: set[str] = set()

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        # On launch: read IDN + current chamber state, repaint manual
        # buttons, then release the connection.
        self.root.after(200, self._check_device)

    # =================================================================== UI
    def _build_ui(self):
        # ------ top: GPIB address + IDN readout ------
        top = ttk.Frame(self.root, padding=(10, 8))
        top.grid(row=0, column=0, sticky="ew")
        self.top_frame = top
        ttk.Label(top, text="GPIB Address:").grid(row=0, column=0, padx=(0, 4))
        self.gpib_var = tk.StringVar(value=DEFAULTS["gpib"])
        ttk.Entry(top, textvariable=self.gpib_var, width=24).grid(
            row=0, column=1, padx=(0, 4))
        ttk.Button(top, text="Check Device",
                   command=self._check_device, width=12).grid(
            row=0, column=2, padx=4)
        self.idn_var = tk.StringVar(value="(checking...)")
        ttk.Label(top, textvariable=self.idn_var, foreground="#666",
                  font=("Segoe UI", 9, "italic")).grid(
            row=0, column=3, padx=(8, 0), sticky="w")

        # ------ middle: settings (left) + monitor (right) ------
        mid = ttk.Frame(self.root, padding=(10, 0))
        mid.grid(row=1, column=0, sticky="nsew")
        self.mid_frame = mid
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)
        mid.grid_columnconfigure(1, weight=1)
        mid.grid_rowconfigure(0, weight=1)

        self._build_settings(mid)
        self._build_monitor(mid)

        # ------ manual controls (full-width row) ------
        self._build_manual_controls()

        # ------ bottom: log ------
        self._build_log()

    def _build_settings(self, parent):
        f = ttk.LabelFrame(parent, text="Settings", padding=10)
        f.grid(row=0, column=0, sticky="nsw", padx=(0, 8))
        self.settings_frame = f

        row = 0

        def add_entry(label, key, unit="", width=10):
            nonlocal row
            ttk.Label(f, text=label).grid(row=row, column=0, sticky="w", pady=3)
            var = tk.StringVar(value=str(DEFAULTS[key]))
            ttk.Entry(f, textvariable=var, width=width).grid(
                row=row, column=1, padx=4, pady=3, sticky="w")
            if unit:
                ttk.Label(f, text=unit, foreground="#666").grid(
                    row=row, column=2, sticky="w")
            row += 1
            return var

        self.setpoint_var  = add_entry("Setpoint:",           "setpoint",  "°C")
        self.soak_var      = add_entry("Soak time:",          "soak",      "s")
        self.accuracy_var  = add_entry("Accuracy (window):",  "accuracy",  "°C")
        self.ramp_var      = add_entry("Ramp:",               "ramp",      "°C/min (0=fastest)")
        self.flow_rate_var = add_entry("Flow rate:",          "flow_rate", "SCFM (4-18)")

        # Mode / sensor / compressor tracked as StringVars so the Manual
        # Controls bar buttons and any external banner (e.g. the TS wrapper)
        # can render them via textvariable. Values are populated in
        # _refresh_manual_states (on connect) and by the individual toggle
        # handlers to stay in sync with the chamber.
        self.mode_var   = tk.StringVar(value=DEFAULTS["mode"])
        self.sensor_var = tk.StringVar(value=DEFAULTS["sensor"])
        self.cool_var   = tk.StringVar(value="?")

        ttk.Separator(f, orient="horizontal").grid(
            row=row, column=0, columnspan=3, sticky="ew", pady=10)
        row += 1

        s = ttk.Style()
        s.configure("Big.TButton",  font=("Segoe UI", 11, "bold"))
        s.configure("Stop.TButton", font=("Segoe UI", 10, "bold"),
                    foreground="#c62828")

        self.set_btn = ttk.Button(
            f, text="Set", command=self._set_all_and_run,
            width=26, style="Big.TButton")
        self.set_btn.grid(row=row, column=0, columnspan=3, pady=4, sticky="ew")
        row += 1

        self.stop_btn = ttk.Button(
            f, text="Abort", command=self._abort,
            width=26, style="Stop.TButton", state="disabled")
        self.stop_btn.grid(row=row, column=0, columnspan=3, pady=4, sticky="ew")

    def _build_monitor(self, parent):
        f = ttk.LabelFrame(parent, text="Monitor", padding=8)
        f.grid(row=0, column=1, sticky="nsew")
        self.monitor_frame = f
        f.grid_rowconfigure(0, weight=1)
        f.grid_columnconfigure(0, weight=1)

        self.fig = Figure(figsize=(7.5, 4.4), dpi=90)
        self.ax = self.fig.add_subplot(111)
        self._init_plot()
        self.canvas = FigureCanvasTkAgg(self.fig, master=f)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew",
                                         pady=(0, 6))

        status = ttk.Frame(f)
        status.grid(row=1, column=0, sticky="ew", pady=4)

        # 3 separate column-frames packed side by side. Each column's
        # internal grid handles its own label/value alignment - so values
        # inside one column align regardless of what's happening in the
        # other columns.
        col1 = ttk.Frame(status)
        col2 = ttk.Frame(status)
        col3 = ttk.Frame(status)
        col1.pack(side="left", padx=(4, 20), anchor="n")
        col2.pack(side="left", padx=(0, 20), anchor="n")
        col3.pack(side="left",              anchor="n")

        self.air_val     = tk.StringVar(value="--")
        self.dut_val     = tk.StringVar(value="--")
        self.set_val     = tk.StringVar(value="--")
        self.tecr_val    = tk.StringVar(value="--")
        self.range_val   = tk.StringVar(value="--")
        self.elapsed_val = tk.StringVar(value="00:00:00")
        self.timeout_val = tk.StringVar(value="--")
        self.err_val     = tk.StringVar(value="--")
        self.state_val   = tk.StringVar(value="idle")

        def add_row(parent, row, label, var, color="#222",
                    lbl_w=10, val_w=14):
            # Both label and value use Consolas monospaced so widths in
            # "chars" translate to identical pixel widths. Labels are
            # left-anchored (all rows start at same X), lbl_w is sized to
            # the longest label in that column so the value sits right
            # after a small uniform gap.
            lbl = tk.Label(parent, text=label, foreground="#666",
                           width=lbl_w, anchor="w",
                           font=("Consolas", 10))
            lbl.grid(row=row, column=0, sticky="w", padx=(0, 6), pady=1)
            val = tk.Label(parent, textvariable=var, foreground=color,
                           anchor="w", width=val_w,
                           font=("Consolas", 10, "bold"))
            val.grid(row=row, column=1, sticky="w", pady=1)
            return val

        # Per-column label widths = longest label in that column + 1.
        # col1: "Error:" (6), col2: "In-Range:" (9), col3: "Elapsed:" (8).
        LW1, LW2, LW3 = 7, 10, 9

        add_row(col1, 0, "Air:",      self.air_val,     "#1e63c9", lbl_w=LW1)
        add_row(col1, 1, "TECR:",     self.tecr_val,               lbl_w=LW1)
        add_row(col1, 2, "Error:",    self.err_val,                lbl_w=LW1)

        add_row(col2, 0, "DUT:",      self.dut_val,     "#c62828", lbl_w=LW2)
        # Handle kept so monitor tick can flip its color True/False.
        self.range_lbl = add_row(col2, 1, "In-Range:", self.range_val,
                                  lbl_w=LW2)
        add_row(col2, 2, "State:",    self.state_val,   "#1e3a5f", lbl_w=LW2)

        add_row(col3, 0, "Set:",      self.set_val,     "#444",    lbl_w=LW3)
        add_row(col3, 1, "Elapsed:",  self.elapsed_val,            lbl_w=LW3)
        add_row(col3, 2, "Timeout:",  self.timeout_val, "#1e3a5f", lbl_w=LW3)

    def _init_plot(self):
        self.ax.clear()
        self.ax.set_xlabel("Elapsed (s)")
        self.ax.set_ylabel("Temperature (°C)")
        self.ax.grid(True, alpha=0.3)
        (self.air_line,) = self.ax.plot(
            [], [], color="#1e63c9", label="Air", linewidth=1.6)
        (self.dut_line,) = self.ax.plot(
            [], [], color="#c62828", label="DUT", linewidth=1.6)
        self.set_line = self.ax.axhline(
            y=0, color="#444", linestyle="--", linewidth=1.2)
        self.set_line.set_visible(False)
        # Legend uses a proxy handle for the setpoint so it always renders the
        # dashed marker, even before the real axhline becomes visible on the
        # first monitor tick.
        setpoint_proxy = Line2D([0], [0], color="#444", linestyle="--",
                                linewidth=1.2, label="Setpoint")
        self.band = None
        self.ax.legend(handles=[self.air_line, self.dut_line, setpoint_proxy],
                       loc="upper right", fontsize=9)
        self.fig.tight_layout()

    # ================================================== manual controls bar
    def _build_manual_controls(self):
        f = ttk.LabelFrame(self.root, text="Manual Controls", padding=8)
        f.grid(row=2, column=0, sticky="ew", padx=10, pady=(4, 0))
        self.manual_frame = f

        # -- Mode section (Air / DUT / Air+DUT) --
        ttk.Label(f, text="Mode:", font=("Segoe UI", 9, "bold")).grid(
            row=0, column=0, sticky="e", padx=(0, 6))
        mf = ttk.Frame(f)
        mf.grid(row=0, column=1, sticky="w", padx=(0, 20))
        self.mode_btns: dict[str, tk.Button] = {}
        for i, m in enumerate(("Air", "DUT", "Air+DUT")):
            b = tk.Button(mf, text=m, width=9,
                          command=lambda x=m: self._set_mode(x))
            b.grid(row=0, column=i, padx=2)
            self.mode_btns[m] = b

        # -- Sensor section (NON / T / K) --
        ttk.Label(f, text="Sensor:", font=("Segoe UI", 9, "bold")).grid(
            row=0, column=2, sticky="e", padx=(0, 6))
        sf = ttk.Frame(f)
        sf.grid(row=0, column=3, sticky="w", padx=(0, 20))
        self.sensor_btns: dict[str, tk.Button] = {}
        for i, s in enumerate(("NON", "T", "K")):
            b = tk.Button(sf, text=s, width=6,
                          command=lambda x=s: self._set_sensor(x))
            b.grid(row=0, column=i, padx=2)
            self.sensor_btns[s] = b

        # -- Independent toggles --
        self.flow_btn = tk.Button(f, text="Flow: ?", width=14,
                                  command=self._toggle_flow)
        self.flow_btn.grid(row=0, column=4, padx=6)
        self.cool_btn = tk.Button(f, text="Compressor: ?", width=16,
                                  command=self._toggle_cool)
        self.cool_btn.grid(row=0, column=5, padx=6)
        self.head_btn = tk.Button(f, text="Head: ?", width=12,
                                  command=self._toggle_head)
        self.head_btn.grid(row=0, column=6, padx=6)

        # Reflect initial state (before connect).
        self._paint_mode_buttons(None)
        self._paint_sensor_buttons(None)
        self._paint_toggle(self.flow_btn, "Flow", None)
        self._paint_toggle(self.cool_btn, "Compressor", None)
        self._paint_toggle(self.head_btn, "Head", None)

    def _paint_mode_buttons(self, active_name):
        for name, btn in self.mode_btns.items():
            if name == active_name:
                btn.configure(relief="sunken", bg="#1e63c9",
                              fg="white", font=("Segoe UI", 9, "bold"))
            else:
                btn.configure(relief="raised", bg="SystemButtonFace",
                              fg="black", font=("Segoe UI", 9))

    def _paint_sensor_buttons(self, active_name):
        for name, btn in self.sensor_btns.items():
            if name == active_name:
                btn.configure(relief="sunken", bg="#1e63c9",
                              fg="white", font=("Segoe UI", 9, "bold"))
            else:
                btn.configure(relief="raised", bg="SystemButtonFace",
                              fg="black", font=("Segoe UI", 9))

    def _paint_toggle(self, btn: tk.Button, label: str, state):
        """state: True (on/down), False (off/up), None (unknown)."""
        if state is None:
            btn.configure(text=f"{label}: ?", bg="SystemButtonFace",
                          fg="black", relief="raised")
            return
        if label == "Head":
            on_word, off_word = "DOWN", "UP"
        else:
            on_word, off_word = "ON", "OFF"
        if state:
            btn.configure(text=f"{label}: {on_word}",
                          bg="#4caf50", fg="white", relief="sunken",
                          font=("Segoe UI", 9, "bold"))
        else:
            btn.configure(text=f"{label}: {off_word}",
                          bg="SystemButtonFace", fg="black",
                          relief="raised", font=("Segoe UI", 9))

    def _refresh_manual_states(self):
        """Read chamber state and repaint every manual-control button."""
        if self.ts is None:
            return
        try:
            mode   = int(self.ts.get_dut_mode())
            sensor = int(self.ts.get_dut_sensor())
            flow   = int(self.ts.get_flow())
            cool   = int(self.ts.get_cool())
            head   = int(self.ts.get_head())
            mode_name   = next((k for k, v in MODE_MAP.items()   if v == mode),   None)
            sensor_name = next((k for k, v in SENSOR_MAP.items() if v == sensor), None)
            if mode_name:
                self.mode_var.set(mode_name)
                self._paint_mode_buttons(mode_name)
            if sensor_name:
                self.sensor_var.set(sensor_name)
                self._paint_sensor_buttons(sensor_name)
            self._paint_toggle(self.flow_btn, "Flow",       bool(flow))
            self._paint_toggle(self.cool_btn, "Compressor", bool(cool))
            self._paint_toggle(self.head_btn, "Head",       bool(head))
            self.cool_var.set("ON" if cool else "OFF")
        except Exception as exc:
            self.log(f"[WARN] state refresh failed: {exc}")

    # -- click handlers --
    def _ensure_flow_off(self):
        """Silently turn flow off if it's on. Repaints the flow button
        from the chamber's actual state afterward."""
        try:
            if bool(int(self.ts.get_flow())):
                self.ts.flow_off()
                self.log("[OK] Flow OFF (auto, required for Mode/Sensor)")
            self._paint_toggle(
                self.flow_btn, "Flow", bool(int(self.ts.get_flow())))
        except Exception as exc:
            self.log(f"[WARN] flow-off precheck failed: {exc}")

    def _set_mode(self, name: str):
        if not self._ensure_connected():
            return
        # Reject if target Mode needs DUT sensor but Sensor is NON.
        if name in ("DUT", "Air+DUT") and self.sensor_var.get() == "NON":
            messagebox.showerror(
                "Sensor Required",
                f"Mode '{name}' needs a DUT thermocouple.\n"
                "Set Sensor to T or K first, then switch Mode.")
            return
        try:
            self._ensure_flow_off()
            self.ts.set_dut_mode(MODE_MAP[name])
            self.mode_var.set(name)
            self._paint_mode_buttons(name)
            self.log(f"[OK] Mode -> {name}")
        except Exception as exc:
            messagebox.showerror("Set Mode", str(exc))
            self.log(f"[ERR] Set mode failed: {exc}")

    def _set_sensor(self, name: str):
        if not self._ensure_connected():
            return
        # Reject NON if current Mode needs a DUT sensor.
        if name == "NON" and self.mode_var.get() in ("DUT", "Air+DUT"):
            messagebox.showerror(
                "Sensor Required",
                f"Mode '{self.mode_var.get()}' needs a DUT thermocouple.\n"
                "Switch Mode to Air first, then set Sensor to NON.")
            return
        try:
            self._ensure_flow_off()
            self.ts.set_dut_sensor(SENSOR_MAP[name])
            self.sensor_var.set(name)
            self._paint_sensor_buttons(name)
            self.log(f"[OK] Sensor -> {name}")
        except Exception as exc:
            messagebox.showerror("Set Sensor", str(exc))
            self.log(f"[ERR] Set sensor failed: {exc}")

    def _toggle_flow(self):
        if not self._ensure_connected():
            return
        try:
            was_on = bool(int(self.ts.get_flow()))
            if was_on:
                # Turning OFF while monitoring means the chamber will
                # stop actively controlling temperature - halt monitor.
                if self.monitoring:
                    self._stop_monitor("flow turned off by user")
                self.ts.flow_off()
                self.log("[OK] Flow OFF")
                self._paint_toggle(self.flow_btn, "Flow", False)
            else:
                self.ts.flow_on()
                self.log("[OK] Flow ON")
                self._paint_toggle(self.flow_btn, "Flow", True)
        except Exception as exc:
            messagebox.showerror("Toggle Flow", str(exc))
            self.log(f"[ERR] Toggle flow failed: {exc}")

    def _toggle_cool(self):
        if not self._ensure_connected():
            return
        try:
            was_on = bool(int(self.ts.get_cool()))
            if was_on:
                self.ts.cool_off()
                self.log("[OK] Compressor OFF")
                self._paint_toggle(self.cool_btn, "Compressor", False)
                self.cool_var.set("OFF")
            else:
                self.ts.cool_on()
                self.log("[OK] Compressor ON")
                self._paint_toggle(self.cool_btn, "Compressor", True)
                self.cool_var.set("ON")
        except Exception as exc:
            messagebox.showerror("Toggle Compressor", str(exc))
            self.log(f"[ERR] Toggle compressor failed: {exc}")

    def _toggle_head(self):
        if not self._ensure_connected():
            return
        try:
            was_down = bool(int(self.ts.get_head()))
            if was_down:
                self.ts.head_up()
                self.log("[OK] Head UP")
                self._paint_toggle(self.head_btn, "Head", False)
            else:
                self.ts.head_down()
                self.log("[OK] Head DOWN")
                self._paint_toggle(self.head_btn, "Head", True)
        except Exception as exc:
            messagebox.showerror("Toggle Head", str(exc))
            self.log(f"[ERR] Toggle head failed: {exc}")

    def _ensure_connected(self) -> bool:
        if self.ts is None:
            if not self._connect():
                return False
            self._refresh_manual_states()
        return True

    def _build_log(self):
        f = ttk.LabelFrame(self.root, text="Log", padding=(6, 4))
        f.grid(row=3, column=0, sticky="nsew", padx=10, pady=(4, 8))
        self.log_frame = f
        f.grid_rowconfigure(0, weight=1)
        f.grid_columnconfigure(0, weight=1)
        self.log_text = tk.Text(f, height=7, wrap="word",
                                font=("Consolas", 9), state="disabled")
        self.log_text.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(f, orient="vertical",
                           command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb.set)
        sb.grid(row=0, column=1, sticky="ns")

    def log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_text.configure(state="normal")
        self.log_text.insert("end", f"[{ts}] {msg}\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    # =========================================================== connection
    def _connect(self) -> bool:
        """Open the chamber. Returns True on success."""
        if self.ts is not None:
            return True
        addr = self.gpib_var.get().strip()
        if not addr:
            messagebox.showwarning("Missing", "Enter a GPIB address.")
            return False
        try:
            self.ts = Thermal_Stream(addr)
            # Bump per-query timeout, add a tiny query delay to let older
            # Temptronic chambers (ATS-710, ATS-810) form the reply, and
            # flush any stale bytes in the GPIB read buffer.
            try:
                self.ts.my_ins.timeout = VISA_TIMEOUT_MS
                self.ts.my_ins.query_delay = 0.05
                self.ts.my_ins.clear()
            except Exception:
                pass
            self.ts.set_remote()
            idn = self.ts.get_idn()
            self.idn_var.set(idn)
            # Fresh connection - give every SCPI query a chance again,
            # then blacklist queries that we know don't exist on this model.
            self._dead_queries.clear()
            self._preblacklist_by_model(idn)
            self.log(f"[OK] Connected: {addr} -> {idn}")
            return True
        except Exception as exc:
            self.ts = None
            self.idn_var.set(f"({addr} not detected)")
            messagebox.showerror("Connect Error", str(exc))
            self.log(f"[ERR] Connect failed: {exc}")
            return False

    def _preblacklist_by_model(self, idn: str):
        """Pre-populate dead_queries for known-incompatible chambers so we
        don't burn a full VISA timeout on the first monitor tick."""
        u = (idn or "").upper()
        # Temptronic ATS-71x / ATS-81x older MCU firmware: no ERROR? query.
        if "ATS-71" in u or "ATS-81" in u:
            self._dead_queries.add("ERROR?")
            self.log("[--] Model does not support ERROR?  - skipped.")

    def _disconnect(self):
        if self.ts is None:
            return
        try:
            self.ts.set_local()
        except Exception:
            pass
        try:
            self.ts.my_ins.close()
        except Exception:
            pass
        self.ts = None
        self.log("[--] Disconnected")

    def _check_device(self):
        """Read IDN + current chamber state, repaint manual buttons.
        If not already connected, briefly open + close the connection."""
        addr = self.gpib_var.get().strip()
        if not addr:
            self.idn_var.set("(no address)")
            return

        keep_open = self.ts is not None
        if not keep_open:
            if not self._connect():
                return
        try:
            self._refresh_manual_states()
        finally:
            if not keep_open:
                self._disconnect()

    # ============================================================= main flow
    def _set_all_and_run(self):
        """Apply numeric settings + start monitor. Mode/Sensor/Flow/
        Compressor/Head are controlled separately from the Manual
        Controls bar."""
        try:
            setp      = float(self.setpoint_var.get())
            soak      = int(self.soak_var.get())
            acc       = float(self.accuracy_var.get())
            ramp      = int(self.ramp_var.get())
            flow_rate = int(self.flow_rate_var.get())
        except Exception as exc:
            messagebox.showerror("Bad Input", f"Cannot parse settings: {exc}")
            return

        if not self._ensure_connected():
            return

        self.state_val.set("applying...")
        self.set_btn.configure(state="disabled")
        self.root.update_idletasks()

        try:
            self.ts.set_soak(soak)
            self.ts.set_accuracy(acc)
            self.ts.set_ramp(ramp)
            self.ts.set_flow_rate(flow_rate)
            self.ts.set_setpoint(setp)   # auto-zone, non-blocking

            # Force flow ON so the chamber actually drives temperature.
            # Idempotent — safe to call even if already on.
            self.ts.flow_on()
            self.log("[OK] Flow ON (auto)")
            self._sync_flow_button()

            self._cached_setp = setp
            self._cached_acc  = acc
            self._cached_soak = soak
            # New run: clear any previous holding countdown state and show
            # the full soak time in the Timeout field before the first tick.
            self._holding_start_time = None
            self.timeout_val.set(f"{soak} s")

            self.log(
                f"[OK] Applied: setpoint={setp} °C, soak={soak} s, "
                f"acc={acc} °C, ramp={ramp}, flow_rate={flow_rate}")
        except Exception as exc:
            self.set_btn.configure(state="normal")
            self.state_val.set("apply failed")
            messagebox.showerror("Apply Error", str(exc))
            self.log(f"[ERR] Apply failed: {exc}")
            return

        self._start_monitor()

    def _abort(self):
        """Emergency stop: halt monitor, force flow OFF, then disconnect."""
        if self.monitoring:
            self._stop_monitor("aborted by user")
        # Force flow OFF while we still have a connection. Idempotent.
        if self.ts is not None:
            try:
                self.ts.flow_off()
                self.log("[OK] Flow OFF (auto on abort)")
                self._sync_flow_button()
            except Exception as exc:
                self.log(f"[WARN] flow-off on abort failed: {exc}")
        self._disconnect()
        self.state_val.set("aborted")
        self.timeout_val.set("--")
        self._holding_start_time = None
        self.set_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")

    def _sync_flow_button(self):
        """Wait for the chamber to settle, then read the flow state and
        repaint the flow button to reflect what the chamber actually reports.
        Called after Start/Abort so the button always matches reality."""
        # A short pause lets the chamber apply the flow setting before we
        # read it back — older TS700 firmware can lag the flow bit by a few
        # tens of milliseconds after a flow_on/flow_off write.
        time.sleep(0.1)
        try:
            is_on = bool(int(self.ts.get_flow()))
        except Exception as exc:
            self.log(f"[WARN] flow readback failed: {exc}")
            return
        self._paint_toggle(self.flow_btn, "Flow", is_on)

    # ============================================================== monitor
    def _start_monitor(self):
        if self.ts is None or self.monitoring:
            return
        self.monitoring = True
        self.start_time = time.time()
        self.t_data.clear()
        self.air_data.clear()
        self.dut_data.clear()
        self.set_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.state_val.set("ramping")
        self.log("[--] Monitor started")
        self._monitor_tick()

    def _stop_monitor(self, reason: str = ""):
        if not self.monitoring:
            return
        self.monitoring = False
        if self._monitor_after_id is not None:
            try:
                self.root.after_cancel(self._monitor_after_id)
            except Exception:
                pass
            self._monitor_after_id = None
        self.set_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        if reason:
            self.log(f"[--] Monitor stopped ({reason})")
        else:
            self.log("[--] Monitor stopped")

    def _monitor_tick(self):
        if not self.monitoring:
            return

        setp = self._cached_setp
        acc  = self._cached_acc
        elapsed = time.time() - self.start_time

        # Query each field independently. If a query has ever timed out
        # this session, skip it entirely so we don't burn 5 s per tick.
        def _q(name, fn, default):
            if name in self._dead_queries:
                return default
            try:
                return fn()
            except Exception as exc:
                self.log(
                    f"[WARN] {name} failed: {exc}. "
                    f"Skipping this query for the rest of the session.")
                self._dead_queries.add(name)
                try:
                    self.ts.my_ins.clear()
                except Exception:
                    pass
                return default

        air_raw  = _q("TMPA?",  self.ts.get_air_temp, None)
        dut_raw  = _q("TMPD?",  self.ts.get_dut_temp, None)
        tecr_raw = _q("TECR?",  self.ts.get_TECR,     None)
        err_raw  = _q("ERROR?", self.ts.get_error,    None)

        # Fall back to last-known values when a query failed this tick.
        air  = float(air_raw)  if air_raw  is not None else (
            self.air_data[-1]  if self.air_data  else float("nan"))
        dut  = float(dut_raw)  if dut_raw  is not None else (
            self.dut_data[-1]  if self.dut_data  else float("nan"))
        tecr = int(tecr_raw)   if tecr_raw is not None else 0
        err  = int(err_raw)    if err_raw  is not None else 0

        self.t_data.append(elapsed)
        self.air_data.append(air)
        self.dut_data.append(dut)
        if len(self.t_data) > MAX_POINTS:
            self.t_data = self.t_data[-MAX_POINTS:]
            self.air_data = self.air_data[-MAX_POINTS:]
            self.dut_data = self.dut_data[-MAX_POINTS:]

        self.air_val.set(f"{air:.2f} °C")
        self.dut_val.set(f"{dut:.2f} °C")
        self.set_val.set(f"{setp:.2f} °C")
        self.tecr_val.set(f"0x{tecr:04X}")
        ctrl_temp = dut if self.mode_var.get() == "DUT" else air
        in_range = abs(ctrl_temp - setp) <= acc
        self.range_val.set("True" if in_range else "False")
        self.range_lbl.configure(
            foreground="#2e7d32" if in_range else "#c62828")
        h, rem = divmod(int(elapsed), 3600)
        m, s = divmod(rem, 60)
        self.elapsed_val.set(f"{h:02d}:{m:02d}:{s:02d}")
        self.err_val.set("OK" if err == 0 else f"{err} (0x{err:04X})")

        # ── ramping / holding state machine + soak-time countdown ──────
        # ramping: not yet in-range (or just drifted out)  → Timeout shows full soak
        # holding: in-range, counting down                 → Timeout shows remaining
        # done:    handled below when TECR bit 0 = 1       → Timeout shows 0
        now = time.time()
        soak = self._cached_soak or 0
        if in_range:
            if self._holding_start_time is None:
                self._holding_start_time = now
                self.state_val.set("holding")
                self.log(f"[--] In-range: holding for {soak} s")
            remaining = max(0.0, soak - (now - self._holding_start_time))
            self.timeout_val.set(f"{remaining:.0f} s")
        else:
            if self._holding_start_time is not None:
                # Drifted out of the accuracy band during hold — reset.
                self._holding_start_time = None
                self.log("[--] Drifted out of range — back to ramping, "
                         f"timeout reset to {soak} s")
            self.state_val.set("ramping")
            self.timeout_val.set(f"{soak} s")

        self.air_line.set_data(self.t_data, self.air_data)
        self.dut_line.set_data(self.t_data, self.dut_data)
        self.set_line.set_ydata([setp, setp])
        self.set_line.set_visible(True)
        if self.band is not None:
            self.band.remove()
        self.band = self.ax.axhspan(setp - acc, setp + acc,
                                    color="#4caf50", alpha=0.10)
        self.ax.relim()
        self.ax.autoscale_view()
        self.canvas.draw_idle()

        if tecr & 1:
            self.log(
                f"[OK] TECR bit 0 set (at-temp + soak complete). "
                f"Air={air:.2f}, DUT={dut:.2f}, Set={setp:.2f}, "
                f"elapsed={self.elapsed_val.get()}")
            self._stop_monitor("at-temp + soak complete")
            self._disconnect()
            self.state_val.set("done")
            self.timeout_val.set("0 s")
            return

        self._monitor_after_id = self.root.after(POLL_MS, self._monitor_tick)

    def _on_close(self):
        self._stop_monitor()
        self._disconnect()
        self.root.destroy()


def main():
    root = tk.Tk()
    root.minsize(1100, 780)
    ThermalStreamControl(root)
    root.mainloop()


if __name__ == "__main__":
    main()
