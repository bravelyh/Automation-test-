@echo off
set "VPYW=%~dp0..\..\.venv\Scripts\pythonw.exe"
if not exist "%VPYW%" (
    echo .venv not found. Run setup_env.bat at the repo root first.
    pause
    exit /b 1
)
start "" "%VPYW%" "%~dp0Thermal_Stream_Control.py"
