r"""Bench_GUI_Client -- TestStand-side client for the Bench Control GUI.

WHAT THIS IS
------------
This module is how TestStand drives the Bench Control GUI (Bench_Control.py).
A TestStand step calls run(); the GUI pops up (auto-launched if it is not
already open), the operator sets things up and clicks STOP, and run() returns
the test-configuration tuple to TestStand.

It is intentionally lightweight -- pure socket + subprocess, NO tkinter /
matplotlib -- so importing it into the TestStand Python interpreter does not
pull in the whole GUI stack.

HOW TESTSTAND USES IT (Python Adapter)
--------------------------------------
    Module   : Bench_GUI_Client.py
    Function : run
    (no input arguments -- the GUI is the source of truth for all config)

RETURN VALUE
------------
run() returns a 6-element tuple, in this exact order. Map each element to
your container:

    index  name                  type    notes
    -----  --------------------  ------  --------------------------------------
      0    device_name           str
      1    device_unit           str
      2    loadbox_mode          int     0 = single channel, 1 = 4-channel series
      3    data_save_folder      str
      4    FC_table_file_path    str
      5    use_thermal_stream    bool    True if the "use_thermal_stream" box is checked

BEHAVIOUR
---------
  * If no GUI is running, one is auto-launched (repo .venv pythonw).
  * run() BLOCKS until the operator clicks STOP, which returns the tuple above.
  * Closing the window (X) instead of STOP raises RuntimeError.
  * If a GUI is already mid-RUN when run() is called, it attaches to that run;
    the next STOP returns here. A second concurrent TS run raises RuntimeError.

Standalone / debug CLI:
    python Bench_GUI_Client.py            # trigger a run, print the tuple
    python Bench_GUI_Client.py --ping     # check whether a GUI is up
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time

IPC_HOST = "127.0.0.1"
IPC_PORT = 52700

_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_HERE, "..", ".."))
_GUI_PATH = os.path.join(_HERE, "Bench_Control.py")
_PYTHONW = os.path.join(_REPO_ROOT, ".venv", "Scripts", "pythonw.exe")
_PYTHON = os.path.join(_REPO_ROOT, ".venv", "Scripts", "python.exe")


# ---------------------------------------------------------------------------
# Low-level socket helpers
# ---------------------------------------------------------------------------
def _send(obj: dict, timeout: float | None):
    """Open a connection, send one JSON line, return the response dict (or None).

    timeout=None means block indefinitely on the read -- used for 'run', where
    the operator may take a long time before pressing STOP.
    """
    with socket.create_connection((IPC_HOST, IPC_PORT), timeout=5.0) as c:
        c.sendall((json.dumps(obj) + "\n").encode("utf-8"))
        c.settimeout(timeout)
        buf = b""
        while b"\n" not in buf:
            chunk = c.recv(4096)
            if not chunk:
                break
            buf += chunk
        if not buf:
            return None
        return json.loads(buf.decode("utf-8", "replace").strip())


def _ping() -> bool:
    try:
        resp = _send({"cmd": "ping"}, timeout=2.0)
        return bool(resp and resp.get("status") == "ok")
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Launch
# ---------------------------------------------------------------------------
def _launch_gui() -> None:
    exe = _PYTHONW if os.path.isfile(_PYTHONW) else _PYTHON
    if not os.path.isfile(exe):
        exe = sys.executable
    flags = 0
    if os.name == "nt":
        # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP -> survives this process.
        flags = 0x00000008 | 0x00000200
    subprocess.Popen([exe, _GUI_PATH], cwd=_HERE, creationflags=flags,
                     close_fds=True)


DEFAULT_LAUNCH_TIMEOUT = 30.0


def _coerce_timeout(v, default: float = DEFAULT_LAUNCH_TIMEOUT) -> float:
    """Accept a number, a numeric string, or empty ('' / None / whitespace).
    Empty -> default. TestStand can't pass a truly empty argument, so an
    empty value is written as "" there and normalised to the default here."""
    if v is None:
        return default
    if isinstance(v, str) and v.strip() == "":
        return default
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _ensure_running(launch_timeout: float = DEFAULT_LAUNCH_TIMEOUT) -> None:
    if _ping():
        return
    _launch_gui()
    deadline = time.time() + launch_timeout
    while time.time() < deadline:
        if _ping():
            return
        time.sleep(0.5)
    raise RuntimeError("Bench Control GUI did not start within "
                       f"{launch_timeout:.0f}s")


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def run(launch_timeout="") -> tuple:
    """Trigger a RUN on the Bench Control GUI and block until STOP.

    launch_timeout: seconds to wait for the GUI to auto-launch. Accepts a
    number, a numeric string, or "" (empty -> default 30 s). In TestStand,
    pass "" to use the default. This bounds only GUI startup, NOT how long the
    operator may take before STOP.

    Returns the 6-element config tuple documented at the top of this module:
        (device_name, device_unit, loadbox_mode, data_save_folder,
         FC_table_file_path, use_thermal_stream)

    Raises RuntimeError on window-close, busy, or communication failure.
    """
    _ensure_running(_coerce_timeout(launch_timeout))
    resp = _send({"cmd": "run"}, timeout=None)   # block until STOP
    if resp is None:
        raise RuntimeError("Bench Control GUI closed the connection unexpectedly")
    status = resp.get("status")
    if status == "stopped":
        result = resp.get("result", [])
        if len(result) != 6:
            raise RuntimeError(f"Unexpected result payload: {result!r}")
        device_name, device_unit, loadbox_mode, data_save_folder, \
            fc_table_file_path, use_thermal_stream = result
        return (str(device_name), str(device_unit), int(loadbox_mode),
                str(data_save_folder), str(fc_table_file_path),
                bool(use_thermal_stream))
    if status == "busy":
        raise RuntimeError(resp.get("message", "GUI busy with another TS run"))
    raise RuntimeError(resp.get("message", "Window closed without STOP"))


# ---------------------------------------------------------------------------
# Debug CLI
# ---------------------------------------------------------------------------
def main() -> int:
    if "--ping" in sys.argv:
        print("running" if _ping() else "not running")
        return 0
    try:
        print(run())
        return 0
    except Exception as exc:
        print(f"ERR {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
