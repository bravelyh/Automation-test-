r"""Bench Control - 4-in-1 manual + TestStand bench GUI.

One window, three tabs:
  1. Power + Loadbox   -- Test Settings + PSU monitor (held during RUN) + Loadbox
  2. I2C               -- Script Execution + Check Status / Clear Fault
  3. Thermal Stream    -- TS700 settings + live monitor + manual controls

Global top bar: RUN / STOP button, status light, use_thermal_stream checkbox.

Two run modes, one codebase:
  * Manual   : `python Bench_Control.py`. Operator clicks RUN -> PSU monitoring
               starts. Other instruments are per-operation (connect, do, release);
               only the PSU is held for the duration of RUN.
  * TestStand: a step calls bench_gui_client.run(). If no GUI is up, it is
               auto-launched. The call blocks until the operator clicks STOP,
               which returns the config tuple:
                 (device_name, device_unit, loadbox_mode, data_save_folder,
                  FC_table_file_path, use_thermal_stream)
               Closing the window (X) instead of STOP returns an error.

Single instance: the first process binds IPC_PORT; a second launch focuses the
existing window and exits. That same port is the TestStand IPC channel.

Config persistence: %LOCALAPPDATA%\AutoBench\gui_config.json. Written on change,
reloaded on startup (crash recovery), deleted on graceful window close.
"""
from __future__ import annotations

import json
import os
import queue
import socket
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure                              # noqa: E402
from matplotlib.lines import Line2D                               # noqa: E402
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg   # noqa: E402


def _setup_paths():
    candidates = []
    if getattr(sys, "frozen", False):
        candidates.append(getattr(sys, "_MEIPASS", ""))
    here = os.path.dirname(os.path.abspath(__file__))
    candidates.append(here)
    candidates.append(os.path.abspath(os.path.join(here, "..", "..")))
    for p in candidates:
        if p and p not in sys.path:
            sys.path.insert(0, p)


_setup_paths()

from instruments.bench import Bench, BENCH_REGISTRY               # noqa: E402
from instruments.loadbox.loadbox_SH import (                      # noqa: E402
    LOAD_MAP,
    detect_loadbox_port,
    format_load,
    list_all_ports,
    resolve_mode0,
    resolve_mode1,
    set_load_per_channel,
)
from instruments.i2x.i2x_aaa import I2X_AAA                       # noqa: E402
from instruments.thermal.ats_710 import ATS710 as Thermal_Stream  # noqa: E402
from serial.tools import list_ports                               # noqa: E402


# ===========================================================================
# Constants
# ===========================================================================
IPC_HOST = "127.0.0.1"
IPC_PORT = 52700

APP_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
                       "AutoBench")
CONFIG_PATH = os.path.join(APP_DIR, "gui_config.json")

INI_ROOT = r"C:\Auto Bench\docs\projects"

# PSU monitor cadence
MONITOR_MS = 100
V_FMT = "{:.3f}"
I_FMT = "{:.3f}"
HP_ROLE = "PVDD"

# Thermal
DEFAULTS = {
    "gpib":      "GPIB0::9::INSTR",
    "setpoint":  25.0,
    "soak":      30,
    "accuracy":  1.0,
    "flow_rate": 10,
    "mode":      "DUT",
    "sensor":    "K",
}
MODE_MAP   = {"Air": 0, "DUT": 1, "Air+DUT": 2}
SENSOR_MAP = {"NON": 0, "T": 1, "K": 2}
POLL_MS         = 1000
MAX_POINTS      = 7200
VISA_TIMEOUT_MS = 5000

NUM_ROWS = 16
ROW_BG   = ["#ffffff", "#f0f4f8"]


def get_ch_roles(gpp_driver_type_name: str) -> list[str]:
    """4 role names for CH1..CH4 based on the 4-CH PSU model."""
    if gpp_driver_type_name == "GwinstekGPP4323":
        return ["Loadbox", "VBAT", "AUX", "DVDD"]
    return ["DVDD", "VBAT", "Loadbox", "AUX"]


# ===========================================================================
# Config persistence
# ===========================================================================
def load_config() -> dict:
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


def save_config(data: dict) -> None:
    try:
        os.makedirs(APP_DIR, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
    except Exception:
        pass


def clear_config() -> None:
    try:
        if os.path.isfile(CONFIG_PATH):
            os.remove(CONFIG_PATH)
    except Exception:
        pass


# ===========================================================================
# I2C helpers (device address + register I/O + script + status map)
# ===========================================================================
import configparser  # noqa: E402


def _make_cfg() -> configparser.RawConfigParser:
    cfg = configparser.RawConfigParser()
    cfg.optionxform = str
    return cfg


def i2c_device_addr(device_name: str) -> str:
    r"""DUT I2C address as uppercase 2-hex string (e.g. 'E0'), read from
    <INI_ROOT>\<name>\<name> Default Setting.ini 'IC Address*'."""
    name = str(device_name).strip()
    if not name:
        raise ValueError("Device Name is empty")
    path = os.path.join(INI_ROOT, name, f"{name} Default Setting.ini")
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Default Setting.ini not found: {path}")
    cfg = _make_cfg()
    cfg.read(path, encoding="utf-8")
    for section in cfg.sections():
        if "IC Address*" in cfg[section]:
            try:
                val = float(cfg[section]["IC Address*"].strip().strip("\"'"))
                return f"{int(val):02X}"
            except Exception:
                pass
    raise ValueError(f"IC Address* not found in: {path}")


def _read_reg_byte(board: I2X_AAA, dev_hex: str, reg_hex: str) -> int:
    results = board.i2c_send(f"R {dev_hex} {reg_hex} 1")
    if not (results and results[0]):
        raise RuntimeError(f"No data for reg 0x{reg_hex}")
    return int(results[0][0][4:6], 16)


def _convert_script(script: str, dev_hex: str) -> str:
    """Convert X/D shorthand to standard w/r commands; drop trailing comments."""
    dev_hex = dev_hex.lower()
    out: list[str] = []
    for raw_line in script.split("\n"):
        cut = len(raw_line)
        for i, ch in enumerate(raw_line):
            if not (ch.isalnum() or ch.isspace()):
                cut = i
                break
        line = raw_line[:cut].strip()
        if not line or not line[0].isalnum():
            out.append(line)
            continue
        upper = line.upper()
        if upper.startswith("X"):
            parts = line.split()
            if len(parts) >= 2:
                line = f"w {dev_hex} {parts[0][1:]} {' '.join(parts[1:])}"
        elif upper.startswith("D"):
            parts = line.split()
            if len(parts) >= 2:
                line = f"r {dev_hex} {parts[0][1:]} {parts[1]}"
        out.append(line)
    return "\n".join(out)


def parse_status_register_map(file_path: str) -> list[dict]:
    """Tab-separated, header row skipped. Columns: reg_addr, bits, value, status."""
    registers: list[dict] = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if line_no == 1:
                continue
            line = line.strip()
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) < 4:
                continue
            try:
                registers.append({
                    "reg_addr": parts[0].strip(),
                    "bits":     parts[1].strip(),
                    "value":    int(parts[2].strip()),
                    "status":   parts[3].strip(),
                })
            except (ValueError, IndexError):
                continue
    return registers


# ===========================================================================
# PSU widgets (ported from Power_Supply_Control)
# ===========================================================================
class ChannelBinding:
    """One logical PSU channel -- wraps driver + optional channel index."""

    def __init__(self, psu, channel=None):
        self.psu = psu
        self.channel = channel

    def _kw(self):
        return {} if self.channel is None else {"channel": self.channel}

    def set_voltage(self, v): self.psu.set_voltage(v, **self._kw())
    def set_current(self, i): self.psu.set_current(i, **self._kw())
    def enable(self, on): self.psu.enable(on, **self._kw())
    def measure_voltage(self): return self.psu.measure_voltage(**self._kw())
    def measure_current(self): return self.psu.measure_current(**self._kw())
    def get_voltage_setpoint(self): return self.psu.get_voltage_setpoint(**self._kw())
    def get_current_setpoint(self): return self.psu.get_current_setpoint(**self._kw())
    def is_enabled(self): return self.psu.is_enabled(**self._kw())


class PSUChannelRow:
    """One PSU row: V set / I set / Output / V meas / I meas."""

    def __init__(self, parent, row, label, gui):
        self.gui = gui
        self.label = label
        self.binding = None
        self._committed_v = ""
        self._committed_i = ""

        self.v_var = tk.StringVar(value="0.00")
        self.i_var = tk.StringVar(value="0.00")
        self.on_var = tk.BooleanVar(value=False)
        self.v_meas_var = tk.StringVar(value="\u2014")
        self.i_meas_var = tk.StringVar(value="\u2014")
        self.role_var = tk.StringVar(value="")

        tk.Label(parent, text=label, width=10, anchor="w",
                 font=("Segoe UI", 9, "bold")).grid(
            row=row, column=0, sticky="w", padx=(4, 4), pady=3)
        tk.Label(parent, textvariable=self.role_var, width=9, anchor="w",
                 font=("Segoe UI", 9), foreground="#666").grid(
            row=row, column=1, sticky="w", padx=(0, 8))

        self.v_entry = ttk.Entry(parent, textvariable=self.v_var, width=8,
                                 font=("Consolas", 10), justify="right")
        self.v_entry.grid(row=row, column=2, padx=2)
        self.v_entry.bind("<Return>",   lambda _e: self._commit_v())
        self.v_entry.bind("<FocusOut>", lambda _e: self._commit_v())

        self.i_entry = ttk.Entry(parent, textvariable=self.i_var, width=8,
                                 font=("Consolas", 10), justify="right")
        self.i_entry.grid(row=row, column=3, padx=2)
        self.i_entry.bind("<Return>",   lambda _e: self._commit_i())
        self.i_entry.bind("<FocusOut>", lambda _e: self._commit_i())

        self.output_btn = tk.Button(parent, text="OFF", width=6, bg="#d0d0d0",
                                    font=("Segoe UI", 9, "bold"),
                                    command=self._toggle_output)
        self.output_btn.grid(row=row, column=4, padx=8)

        tk.Label(parent, textvariable=self.v_meas_var, width=9, anchor="e",
                 font=("Consolas", 10)).grid(row=row, column=5, padx=4)
        tk.Label(parent, text="V", foreground="grey").grid(row=row, column=6, sticky="w")
        tk.Label(parent, textvariable=self.i_meas_var, width=9, anchor="e",
                 font=("Consolas", 10)).grid(row=row, column=7, padx=4)
        tk.Label(parent, text="A", foreground="grey").grid(row=row, column=8, sticky="w")

    def set_role(self, role):
        self.role_var.set(role)

    def set_binding(self, b):
        self.binding = b
        state = "normal" if b is not None else "disabled"
        self.v_entry.configure(state=state)
        self.i_entry.configure(state=state)
        self.output_btn.configure(state=state)
        if b is None:
            self.v_meas_var.set("N/A")
            self.i_meas_var.set("N/A")

    def _apply_output_ui(self, on):
        self.on_var.set(on)
        if on:
            self.output_btn.configure(text="ON", bg="#4caf50", fg="white")
        else:
            self.output_btn.configure(text="OFF", bg="#d0d0d0", fg="black")

    def _toggle_output(self):
        new_state = not self.on_var.get()
        self._apply_output_ui(new_state)
        if not self.gui.running or self.binding is None:
            return
        try:
            self.binding.enable(new_state)
            self.gui.log(f"[SET] {self.label} Output = {'ON' if new_state else 'OFF'}", "ok")
        except Exception as exc:
            self._apply_output_ui(not new_state)
            self.gui.log(f"[ERR] {self.label} enable: {exc}", "err")

    def _commit_v(self):
        txt = self.v_var.get().strip()
        if txt == self._committed_v:
            return
        self._committed_v = txt
        if not self.gui.running or self.binding is None:
            return
        try:
            v = float(txt)
        except ValueError:
            self.gui.log(f"[ERR] {self.label} V invalid: {txt!r}", "err")
            return
        try:
            self.binding.set_voltage(v)
            self.gui.log(f"[SET] {self.label} V = {v}", "ok")
        except Exception as exc:
            self.gui.log(f"[ERR] {self.label} set_voltage: {exc}", "err")

    def _commit_i(self):
        txt = self.i_var.get().strip()
        if txt == self._committed_i:
            return
        self._committed_i = txt
        if not self.gui.running or self.binding is None:
            return
        try:
            i = float(txt)
        except ValueError:
            self.gui.log(f"[ERR] {self.label} I invalid: {txt!r}", "err")
            return
        try:
            self.binding.set_current(i)
            self.gui.log(f"[SET] {self.label} I = {i}", "ok")
        except Exception as exc:
            self.gui.log(f"[ERR] {self.label} set_current: {exc}", "err")

    def sync_from_hw(self):
        if self.binding is None:
            return None
        v = self.binding.get_voltage_setpoint()
        i = self.binding.get_current_setpoint()
        on = self.binding.is_enabled()
        v_str, i_str = V_FMT.format(v), I_FMT.format(i)
        self.v_var.set(v_str)
        self.i_var.set(i_str)
        self._committed_v = v_str
        self._committed_i = i_str
        self._apply_output_ui(on)
        return v, i, on

    def poll(self):
        if self.binding is None:
            return
        try:
            self.v_meas_var.set(V_FMT.format(self.binding.measure_voltage()))
        except Exception:
            self.v_meas_var.set("err")
        try:
            self.i_meas_var.set(I_FMT.format(self.binding.measure_current()))
        except Exception:
            self.i_meas_var.set("err")


def ps_headers(parent, row):
    ttk.Label(parent, text="",       width=10).grid(row=row, column=0)
    ttk.Label(parent, text="Rail",   width=9, anchor="w",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=1)
    ttk.Label(parent, text="V set",  width=8, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=2)
    ttk.Label(parent, text="I set",  width=8, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=3)
    ttk.Label(parent, text="Output", width=6, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=4)
    ttk.Label(parent, text="V meas", width=9, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=5, columnspan=2)
    ttk.Label(parent, text="I meas", width=9, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=7, columnspan=2)


class LoadboxRow:
    """One loadbox CH row: Load / Write cmd / Read value (display only)."""

    def __init__(self, parent, grid_row, ch, idx):
        bg = ROW_BG[idx % 2]
        self.load_var = tk.StringVar(value="")
        self.write_var = tk.StringVar(value="")
        self.read_var = tk.StringVar(value="")

        def cell(col, var):
            tk.Label(parent, textvariable=var, width=12, font=("Consolas", 9),
                     bg=bg, anchor="center", relief="solid", bd=1).grid(
                row=grid_row, column=col, padx=1, pady=1, sticky="ew")

        tk.Label(parent, text=f"CH{ch}", width=6, font=("Segoe UI", 9, "bold"),
                 bg=bg, anchor="center", relief="solid", bd=1).grid(
            row=grid_row, column=0, padx=1, pady=1, sticky="ew")
        cell(1, self.load_var)
        cell(2, self.write_var)
        cell(3, self.read_var)

    def set(self, load_key, write_cmd, read_val):
        self.load_var.set(format_load(load_key))
        self.write_var.set(write_cmd)
        self.read_var.set(read_val)

    def clear(self):
        self.load_var.set("")
        self.write_var.set("")
        self.read_var.set("")


# ===========================================================================
# IPC server (single-instance + TestStand channel)
# ===========================================================================
def _send_json(conn, obj):
    try:
        conn.sendall((json.dumps(obj) + "\n").encode("utf-8"))
    except Exception:
        pass


def _recv_line(conn) -> str:
    buf = b""
    while b"\n" not in buf:
        chunk = conn.recv(4096)
        if not chunk:
            break
        buf += chunk
    return buf.decode("utf-8", "replace").strip()


class Waiter:
    """A pending TS 'run' request awaiting STOP on the main thread."""

    def __init__(self):
        self.event = threading.Event()
        self.result = {"status": "error", "message": "no result"}

    def finish(self, result: dict):
        self.result = result
        self.event.set()


class IPCServer:
    """Localhost TCP server. Binds IPC_PORT (single-instance guard) and relays
    'run'/'focus' commands to the Tk main thread via app.ipc_queue."""

    def __init__(self, app):
        self.app = app
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((IPC_HOST, IPC_PORT))   # raises OSError if already bound
        self.sock.listen(5)
        self._stop = False

    def start(self):
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        while not self._stop:
            try:
                conn, _addr = self.sock.accept()
            except OSError:
                break
            threading.Thread(target=self._handle, args=(conn,), daemon=True).start()

    def _handle(self, conn):
        try:
            line = _recv_line(conn)
            if not line:
                return
            try:
                cmd = json.loads(line)
            except Exception:
                _send_json(conn, {"status": "error", "message": "bad json"})
                return
            action = cmd.get("cmd")
            if action == "ping":
                _send_json(conn, {"status": "ok"})
            elif action == "focus":
                self.app.ipc_queue.put(("focus", None))
                _send_json(conn, {"status": "ok"})
            elif action == "run":
                waiter = Waiter()
                self.app.ipc_queue.put(("run", waiter))
                waiter.event.wait()               # blocks until STOP / close
                _send_json(conn, waiter.result)
            else:
                _send_json(conn, {"status": "error", "message": f"unknown cmd {action!r}"})
        finally:
            try:
                conn.close()
            except Exception:
                pass

    def stop(self):
        self._stop = True
        try:
            self.sock.close()
        except Exception:
            pass



def _detect_stlink_port():
    """Detect the STMicroelectronics STLink Virtual COM port."""
    try:
        for port in list_ports.comports():
            desc = (port.description or "").lower()
            if "stlink" in desc and "virtual com" in desc:
                return port.device
    except Exception:
        pass
    return None


# ===========================================================================
# Main application
# ===========================================================================
class BenchApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Bench Control")

        # run state
        self.running = False
        self.ts_waiter: Waiter | None = None
        self._monitor_after_id = None

        # PSU drivers
        self.bench: Bench | None = None
        self.hp_driver = None
        self.gpp_driver = None

        # I2C / thermal per-op state
        self.board: I2X_AAA | None = None
        self.ts = None
        self._status_registers: list[dict] = []
        self._loaded_dev_hex: str | None = None

        # IPC
        self.ipc_queue: queue.Queue = queue.Queue()
        self.ipc_server: IPCServer | None = None

        # shared config vars
        self.device_name_var = tk.StringVar()
        self.device_unit_var = tk.StringVar()
        self.data_save_folder_var = tk.StringVar()
        self.fc_table_path_var = tk.StringVar()
        self.loadbox_mode_var = tk.StringVar(value="0")
        self.use_thermal_var = tk.BooleanVar(value=False)

        self._build_ui()
        self._load_and_apply_config()
        self._wire_persistence()

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(50, self._detect_ps)
        self.root.after(60, self._refresh_i2c_conn)
        self.root.after(200, lambda: self._thermal_check_device(silent=True))
        self.root.after(50, self._poll_ipc)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        self._build_topbar()          # row 0

        self.nb = ttk.Notebook(self.root)
        self.nb.grid(row=1, column=0, sticky="nsew", padx=8, pady=(4, 4))
        self.tab_power = ttk.Frame(self.nb, padding=8)
        self.tab_i2c = ttk.Frame(self.nb, padding=8)
        self.tab_thermal = ttk.Frame(self.nb, padding=8)
        self.nb.add(self.tab_power, text="  Power + Loadbox  ")
        self.nb.add(self.tab_i2c, text="  I2C  ")
        self.nb.add(self.tab_thermal, text="  Thermal Stream  ")

        self._build_tab_power(self.tab_power)
        self._build_tab_i2c(self.tab_i2c)
        self._build_tab_thermal(self.tab_thermal)

        self._build_log()             # rows 3, 4

    def _build_topbar(self):
        bar = ttk.Frame(self.root, padding=(10, 8))
        bar.grid(row=0, column=0, sticky="ew")

        self.run_btn = tk.Button(bar, text="RUN", width=10, bg="#e0e0e0",
                                 font=("Segoe UI", 11, "bold"),
                                 command=self._toggle_run)
        self.run_btn.pack(side="left")

        self.status_var = tk.StringVar(value="IDLE")
        self.status_lbl = tk.Label(bar, textvariable=self.status_var,
                                   font=("Segoe UI", 10, "bold"),
                                   fg="#666", width=24, anchor="w")
        self.status_lbl.pack(side="left", padx=(12, 0))

    def _build_test_settings(self, parent):
        ts = ttk.LabelFrame(parent, text="Test Settings", padding=8)
        ts.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ts.grid_columnconfigure(5, weight=1)   # flex column

        # Row 0: Device Name + Load | Device Unit | PC/Bench id
        ttk.Label(ts, text="Device Name:").grid(row=0, column=0, sticky="w", pady=3)
        ttk.Entry(ts, textvariable=self.device_name_var, width=14).grid(
            row=0, column=1, sticky="w", padx=(4, 2))
        ttk.Button(ts, text="Load", width=6, command=self._do_load).grid(
            row=0, column=2, sticky="w", padx=(0, 12))
        ttk.Label(ts, text="Device Unit:").grid(row=0, column=3, sticky="w")
        ttk.Entry(ts, textvariable=self.device_unit_var, width=12).grid(
            row=0, column=4, sticky="w", padx=(4, 8))
        self.pcbench_var = tk.StringVar(value="PC: --   Bench: --")
        tk.Label(ts, textvariable=self.pcbench_var, anchor="center",
                 font=("Segoe UI", 9), fg="#0066aa").grid(
            row=0, column=5, columnspan=2, sticky="ew")

        # Row 1: Data Save Folder (entry expands to align with row 0's box)
        ttk.Label(ts, text="Data Save Folder:").grid(row=1, column=0, sticky="w", pady=3)
        ttk.Entry(ts, textvariable=self.data_save_folder_var).grid(
            row=1, column=1, columnspan=5, sticky="ew", padx=4)
        ttk.Button(ts, text="Browse...", width=9,
                   command=self._browse_folder).grid(row=1, column=6, sticky="ew", padx=4)

        # Row 2: FC Table File
        ttk.Label(ts, text="FC Table File:").grid(row=2, column=0, sticky="w", pady=3)
        ttk.Entry(ts, textvariable=self.fc_table_path_var).grid(
            row=2, column=1, columnspan=5, sticky="ew", padx=4)
        ttk.Button(ts, text="Browse...", width=9,
                   command=self._browse_fc).grid(row=2, column=6, sticky="ew", padx=4)

        self._refresh_pcbench()

    def _build_log(self):
        lf = ttk.LabelFrame(self.root, text="Log", padding=6)
        lf.grid(row=2, column=0, sticky="nsew", padx=8, pady=(0, 8))
        self.root.grid_rowconfigure(2, weight=0)
        self.log_text = tk.Text(lf, height=8, state="disabled",
                                font=("Consolas", 9), wrap="word")
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb.set)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        lf.grid_rowconfigure(0, weight=1)
        lf.grid_columnconfigure(0, weight=1)
        self.log_text.tag_config("ok", foreground="#007700")
        self.log_text.tag_config("err", foreground="#cc0000")
        self.log_text.tag_config("data", foreground="#0066cc",
                                 font=("Consolas", 9, "bold"))
        ttk.Button(self.root, text="Clear Log", command=self._clear_log).grid(
            row=3, column=0, sticky="e", padx=8, pady=(0, 6))

    def log(self, msg, tag="", newline=True):
        self.log_text.configure(state="normal")
        end = "\n" if newline else ""
        if tag:
            self.log_text.insert("end", msg + end, tag)
        else:
            self.log_text.insert("end", msg + end)
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    # -------------------------------------------------- config persistence
    def _config_dict(self) -> dict:
        return {
            "device_name": self.device_name_var.get(),
            "device_unit": self.device_unit_var.get(),
            "data_save_folder": self.data_save_folder_var.get(),
            "fc_table_file_path": self.fc_table_path_var.get(),
            "loadbox_mode": self.loadbox_mode_var.get(),
            "use_thermal_stream": bool(self.use_thermal_var.get()),
        }

    def _load_and_apply_config(self):
        data = load_config()
        if not data:
            return
        self.device_name_var.set(data.get("device_name", ""))
        self.device_unit_var.set(data.get("device_unit", ""))
        self.data_save_folder_var.set(data.get("data_save_folder", ""))
        self.fc_table_path_var.set(data.get("fc_table_file_path", ""))
        self.loadbox_mode_var.set(str(data.get("loadbox_mode", "0")))
        self.use_thermal_var.set(bool(data.get("use_thermal_stream", False)))

    def _persist(self, *_):
        save_config(self._config_dict())

    def _wire_persistence(self):
        for var in (self.device_name_var, self.device_unit_var,
                    self.data_save_folder_var, self.fc_table_path_var,
                    self.loadbox_mode_var, self.use_thermal_var):
            var.trace_add("write", self._persist)

    def get_config_tuple(self) -> tuple:
        return (
            self.device_name_var.get().strip(),
            self.device_unit_var.get().strip(),
            int(self.loadbox_mode_var.get() or 0),
            self.data_save_folder_var.get().strip(),
            self.fc_table_path_var.get().strip(),
            bool(self.use_thermal_var.get()),
        )

    # -------------------------------------------------------- IPC handling
    def _poll_ipc(self):
        try:
            while True:
                action, payload = self.ipc_queue.get_nowait()
                if action == "focus":
                    self._on_focus()
                elif action == "run":
                    self._on_ts_run(payload)
        except queue.Empty:
            pass
        self.root.after(50, self._poll_ipc)

    def _on_focus(self):
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass

    def _on_ts_run(self, waiter: Waiter):
        if self.ts_waiter is not None:
            waiter.finish({"status": "busy",
                           "message": "A TestStand run is already waiting for STOP"})
            return
        self.ts_waiter = waiter
        self.log("[TS] TestStand run requested", "ok")
        if not self.running:
            self._start_run()
        self._update_status()

    # ------------------------------------------------------- run/stop
    def _toggle_run(self):
        if self.running:
            self._stop_run("user")
        else:
            self._start_run()

    def _update_status(self):
        if self.running and self.ts_waiter is not None:
            self.status_var.set("RUNNING - TS waiting")
            self.status_lbl.config(fg="#0066aa")
        elif self.running:
            self.status_var.set("RUNNING")
            self.status_lbl.config(fg="#007700")
        else:
            self.status_var.set("IDLE")
            self.status_lbl.config(fg="#666")

    def _start_run(self):
        # Fresh PSU discovery each RUN (there is no Rescan button -- STOP then
        # RUN re-detects). Then one-shot detect of the non-held instruments.
        self._rescan_ps_silent()
        self._snapshot_devices()
        # Open + monitor PSU (the only held instrument).
        try:
            if self.hp_driver is not None:
                self.hp_driver.open()
            if self.gpp_driver is not None:
                self.gpp_driver.open()
        except Exception as exc:
            self.log(f"[ERR] PSU open failed: {exc}", "err")
            self._close_ps_drivers()
            return
        for row in (self.hp_row, *self.ch_rows):
            if row.binding is None:
                continue
            try:
                v, i, on = row.sync_from_hw()
                self.log(f"[SYNC] {row.label}: V={v:.3f} I={i:.3f} "
                         f"Output={'ON' if on else 'OFF'}")
            except Exception as exc:
                self.log(f"[ERR] {row.label} sync: {exc}", "err")
        self.running = True
        self.run_btn.configure(text="STOP", bg="#4caf50", fg="white")
        self._update_status()
        self.log("[OK] RUN started - PSU monitoring active", "ok")
        self._monitor_tick()

    def _stop_run(self, reason="user"):
        if not self.running:
            # still allow STOP to resolve a pending TS waiter
            self._resolve_ts_waiter()
            return
        self.running = False
        if self._monitor_after_id is not None:
            try:
                self.root.after_cancel(self._monitor_after_id)
            except Exception:
                pass
            self._monitor_after_id = None
        self.run_btn.configure(text="RUN", bg="#e0e0e0", fg="black")
        self._close_ps_drivers()
        self.log(f"[--] STOP ({reason}); PSU outputs left as-is")
        self._resolve_ts_waiter()
        self._update_status()

    def _resolve_ts_waiter(self):
        if self.ts_waiter is not None:
            cfg = self.get_config_tuple()
            self.ts_waiter.finish({"status": "stopped", "result": list(cfg)})
            self.log(f"[TS] returned {cfg}", "ok")
            self.ts_waiter = None

    def _monitor_tick(self):
        if not self.running:
            return
        self.hp_row.poll()
        for r in self.ch_rows:
            r.poll()
        self._monitor_after_id = self.root.after(MONITOR_MS, self._monitor_tick)

    def _close_ps_drivers(self):
        for d in (self.hp_driver, self.gpp_driver):
            if d is None:
                continue
            try:
                d.close()
            except Exception:
                pass

    def _snapshot_devices(self):
        self.log("[--] Detecting instruments (snapshot, not held)...")
        try:
            lb = detect_loadbox_port()
            self.log(f"    Loadbox: {lb}" if lb else "    Loadbox: not found")
        except Exception:
            pass
        try:
            stl = _detect_stlink_port()
            self.log(f"    STLink : {stl}" if stl else "    STLink : not found")
        except Exception:
            pass
        try:
            self._refresh_i2c_conn()
        except Exception:
            pass

    def _rescan_ps_silent(self):
        """Clear discovery cache and re-detect PSU without touching run state."""
        self._close_ps_drivers()
        self.hp_driver = None
        self.gpp_driver = None
        try:
            from instruments import discovery
            discovery.clear_cache()
        except Exception:
            pass
        self.bench = None
        self._detect_ps()

    # ---------------------------------------------------------- close
    def _on_close(self):
        if self.ts_waiter is not None:
            self.ts_waiter.finish({"status": "error",
                                   "message": "Window closed without STOP"})
            self.ts_waiter = None
        if self.running:
            self._stop_run("window closed")
        try:
            self._thermal_disconnect()
        except Exception:
            pass
        if self.ipc_server is not None:
            self.ipc_server.stop()
        clear_config()
        self.root.destroy()

    # ---------------------------------------------------------- PSU detect
    def _detect_ps(self):
        try:
            self.bench = Bench()
        except Exception as exc:
            self.log(f"[ERR] Bench(): {exc}", "err")
            self.hp_header.configure(text="Bench init failed", foreground="#cc0000")
            self.gpp_header.configure(text="Bench init failed", foreground="#cc0000")
            self.hp_row.set_binding(None)
            for r in self.ch_rows:
                r.set_binding(None)
            return

        self.hp_row.set_role(HP_ROLE)
        try:
            self.hp_driver = self.bench.psu_high_power
            self.hp_header.configure(
                text=f"{type(self.hp_driver).__name__}  @  {self.hp_driver.addr}",
                foreground="#0066aa")
            self.hp_row.set_binding(ChannelBinding(self.hp_driver))
            self.log(f"[OK] psu_high_power = {type(self.hp_driver).__name__} "
                     f"@ {self.hp_driver.addr} (rail: {HP_ROLE})", "ok")
        except Exception as exc:
            self.hp_header.configure(text="NOT DETECTED", foreground="#cc0000")
            self.hp_row.set_binding(None)
            self.log(f"[--] psu_high_power not available: {str(exc).splitlines()[0]}")

        try:
            self.gpp_driver = self.bench.psu_4ch
            gpp_type = type(self.gpp_driver).__name__
            self.gpp_header.configure(
                text=f"{gpp_type}  @  {self.gpp_driver.addr}", foreground="#0066aa")
            roles = get_ch_roles(gpp_type)
            for i, r in enumerate(self.ch_rows):
                r.set_binding(ChannelBinding(self.gpp_driver, channel=i + 1))
                r.set_role(roles[i])
            self.log(f"[OK] psu_4ch = {gpp_type} @ {self.gpp_driver.addr}", "ok")
        except Exception as exc:
            self.gpp_header.configure(text="NOT DETECTED", foreground="#cc0000")
            for r in self.ch_rows:
                r.set_binding(None)
                r.set_role("")
            self.log(f"[--] psu_4ch not available: {str(exc).splitlines()[0]}")

    def _rescan_ps(self):
        if self.running:
            self._stop_run("rescan")
        self._close_ps_drivers()
        self.hp_driver = None
        self.gpp_driver = None
        self.hp_row.set_binding(None)
        for r in self.ch_rows:
            r.set_binding(None)
        self.log("[--] Rescanning PSU...")
        try:
            from instruments import discovery
            discovery.clear_cache()
        except Exception:
            pass
        self.bench = None
        self._detect_ps()

    # ================================================= TAB 1: Power + Loadbox
    def _build_tab_power(self, parent):
        parent.grid_columnconfigure(0, weight=1)

        # --- Test Settings (shared config; lives on this tab) ---
        self._build_test_settings(parent)   # row 0

        # --- Power supplies ---
        hp = ttk.LabelFrame(parent, text="High Power", padding=8)
        hp.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        self.hp_header = ttk.Label(hp, text="(detecting...)", foreground="#666",
                                   font=("Segoe UI", 9))
        self.hp_header.grid(row=0, column=0, columnspan=9, sticky="w", pady=(0, 4))
        ps_headers(hp, row=1)
        self.hp_row = PSUChannelRow(hp, row=2, label="High Power", gui=self)

        gpp = ttk.LabelFrame(parent, text="4-Channel", padding=8)
        gpp.grid(row=2, column=0, sticky="ew", pady=(0, 6))
        self.gpp_header = ttk.Label(gpp, text="(detecting...)", foreground="#666",
                                    font=("Segoe UI", 9))
        self.gpp_header.grid(row=0, column=0, columnspan=9, sticky="w", pady=(0, 4))
        ps_headers(gpp, row=1)
        self.ch_rows = []
        for i in range(4):
            self.ch_rows.append(PSUChannelRow(gpp, row=2 + i, label=f"CH{i+1}", gui=self))

        # --- Loadbox (single control row; no per-channel readback table) ---
        lb = ttk.LabelFrame(parent, text="Loadbox", padding=8)
        lb.grid(row=3, column=0, sticky="ew")
        ctrl = ttk.Frame(lb)
        ctrl.pack(fill="x")
        ttk.Label(ctrl, text="loadbox_mode:").pack(side="left")
        ttk.Combobox(ctrl, textvariable=self.loadbox_mode_var, values=["0", "1"],
                     width=4, state="readonly").pack(side="left", padx=(3, 12))
        ttk.Label(ctrl, text="Load:").pack(side="left", padx=(0, 2))
        self.load_var = tk.StringVar()
        e = ttk.Entry(ctrl, textvariable=self.load_var, width=12)
        e.pack(side="left")
        e.bind("<Return>", lambda _ev: self._loadbox_set())
        ttk.Button(ctrl, text="Set", width=8,
                   command=self._loadbox_set).pack(side="left", padx=(8, 12))
        ttk.Label(ctrl, text="mode 0 = single channel,  mode 1 = 4-channel series",
                  foreground="grey", font=("Segoe UI", 8)).pack(side="left")
        self.lb_rows = []   # no readback table; set_load_per_channel logs results

    def _browse_folder(self):
        d = filedialog.askdirectory(title="Select Data Save Folder")
        if d:
            self.data_save_folder_var.set(d)

    def _browse_fc(self):
        f = filedialog.askopenfilename(
            title="Select FC Table File",
            filetypes=[("All files", "*.*"), ("Excel", "*.xlsx *.xls"),
                       ("Text/CSV", "*.txt *.csv")])
        if f:
            self.fc_table_path_var.set(f)

    # ----------------------------------------------- Load (I2C addr + status)
    def _do_load(self):
        """Load the device's I2C address + Status Register Map from
        <INI_ROOT>\\<device_name>\\ (like the old I2C tool's Load)."""
        name = self.device_name_var.get().strip()
        if not name:
            messagebox.showwarning("Missing", "Enter a Device Name first.")
            return
        # I2C address
        try:
            self._loaded_dev_hex = i2c_device_addr(name)
            self.log(f"[OK] {name}: I2C addr = 0x{self._loaded_dev_hex}", "ok")
        except Exception as exc:
            self._loaded_dev_hex = None
            self.log(f"[ERR] {exc}", "err")
            messagebox.showerror("Load", str(exc))
        # Status Register Map
        map_path = os.path.join(INI_ROOT, name, f"{name} Status Register Map.txt")
        if os.path.isfile(map_path):
            try:
                self._status_registers = parse_status_register_map(map_path)
                self.log(f"[OK] Loaded status map ({len(self._status_registers)} entries)", "ok")
            except Exception as exc:
                self.log(f"[ERR] status map parse failed: {exc}", "err")
        else:
            self._status_registers = []
            self.log(f"[--] No Status Register Map at {map_path}")
        self._refresh_i2c_conn()

    # -------------------------------------------------------- loadbox set
    def _loadbox_set(self):
        mode = self.loadbox_mode_var.get().strip()
        load = self.load_var.get().strip()
        if not load:
            messagebox.showwarning("Missing Load", "Enter a Load value.")
            return
        try:
            if mode == "0":
                labels = resolve_mode0(load)
            else:
                labels = resolve_mode1(load)
            codes = [LOAD_MAP[k] for k in labels]
            self.log(f"[--] Loadbox mode {mode}, load='{load}' -> {labels}")
        except (ValueError, KeyError) as exc:
            self.log(f"[ERR] {exc}", "err")
            messagebox.showerror("Invalid Load", str(exc))
            return
        port = detect_loadbox_port()
        if not port:
            self.log("[ERR] No loadbox port detected", "err")
            messagebox.showwarning("No Loadbox", "No Prolific USB-Serial port detected.")
            return
        try:
            results = set_load_per_channel(port, codes, labels, self.log)
        except Exception as exc:
            self.log(f"[ERR] loadbox set failed: {exc}", "err")
            messagebox.showerror("Set Failed", str(exc))
            return
        for r, row in zip(results, self.lb_rows):
            row.set(r["load"], r["write"], r["read"])
        responded = sum(1 for r in results if r["read"])
        self.log(f"[OK] Loadbox set complete. {responded}/4 responded.", "ok")

    # =============================================================== I2C helpers
    def _i2c_connect(self) -> bool:
        if self.board:
            return True
        port = _detect_stlink_port()
        if not port:
            messagebox.showwarning("No STLink",
                                   "No STLink Virtual COM port detected.")
            self.log("[ERR] No STLink Virtual COM port detected", "err")
            return False
        try:
            self.board = I2X_AAA(port)
            return True
        except Exception as exc:
            self.board = None
            messagebox.showerror("Connection Error", str(exc))
            self.log(f"[ERR] I2C connect failed: {exc}", "err")
            return False

    def _i2c_disconnect(self):
        if self.board:
            try:
                self.board.close()
            except Exception:
                pass
            self.board = None

    def _i2c_dev_hex(self) -> str:
        if self._loaded_dev_hex:
            return self._loaded_dev_hex.upper()
        return i2c_device_addr(self.device_name_var.get()).upper()

    def _refresh_i2c_conn(self):
        """Update the I2C tab's connection line: STLink COM port + I2C addr."""
        port = _detect_stlink_port()
        addr = f"0x{self._loaded_dev_hex}" if self._loaded_dev_hex else "--"
        self.i2c_conn_var.set(
            f"STLink: {port or 'not found'}    |    I2C addr: {addr}")

    def _refresh_pcbench(self):
        """Show this machine's PC ID (hostname) + mapped Bench ID."""
        try:
            pc_id = socket.gethostname()
        except Exception:
            pc_id = "?"
        bench_id = BENCH_REGISTRY.get(pc_id, {}).get("bench_id", "?")
        self.pcbench_var.set(f"PC: {pc_id}   Bench: {bench_id}")

    # ===================================================== TAB 2: I2C
    def _build_tab_i2c(self, parent):
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_columnconfigure(1, weight=0)
        parent.grid_rowconfigure(1, weight=1)

        self.i2c_conn_var = tk.StringVar(value="STLink: --    |    I2C addr: --")
        ttk.Label(parent, textvariable=self.i2c_conn_var,
                  font=("Consolas", 9, "bold"), foreground="#0066aa").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))

        sf = ttk.LabelFrame(parent, text="Script Execution", padding=6)
        sf.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        sf_inner = ttk.Frame(sf)
        sf_inner.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(sf_inner, orient="vertical")
        sb.pack(side="right", fill="y")
        self.script_text = tk.Text(sf_inner, height=18, width=40, wrap="word",
                                   font=("Consolas", 9), yscrollcommand=sb.set)
        self.script_text.pack(side="left", fill="both", expand=True)
        sb.configure(command=self.script_text.yview)
        bf = ttk.Frame(sf)
        bf.pack(fill="x", pady=(8, 0))
        ttk.Button(bf, text="Run", width=10,
                   command=self._i2c_run_script).pack(side="left", padx=(0, 4))
        ttk.Button(bf, text="Clear", width=10,
                   command=lambda: self.script_text.delete("1.0", "end")).pack(side="left")

        csf = ttk.LabelFrame(parent, text="Check Status", padding=6)
        csf.grid(row=1, column=1, sticky="nsew")
        cs_inner = ttk.Frame(csf)
        cs_inner.pack(fill="both", expand=True)
        sb2 = ttk.Scrollbar(cs_inner, orient="vertical")
        sb2.pack(side="right", fill="y")
        self.status_list = tk.Text(cs_inner, height=18, width=30, state="disabled",
                                   font=("Consolas", 8, "bold"), wrap="word",
                                   yscrollcommand=sb2.set)
        self.status_list.pack(side="left", fill="both", expand=True)
        sb2.configure(command=self.status_list.yview)
        self.status_list.tag_config("active", foreground="#000000")
        cf = ttk.Frame(csf)
        cf.pack(fill="x", pady=(8, 0))
        ttk.Button(cf, text="Check", width=10,
                   command=self._i2c_check_status).pack(side="left", padx=(0, 4))
        ttk.Button(cf, text="Clear Fault", width=10,
                   command=self._i2c_clear_fault).pack(side="left")

    def _i2c_run_script(self):
        script = self.script_text.get("1.0", "end").strip()
        if not script:
            messagebox.showwarning("Empty Script", "Enter script commands.")
            return
        try:
            dev_hex = self._i2c_dev_hex()
        except Exception as exc:
            messagebox.showerror("Device Address", str(exc))
            self.log(f"[ERR] {exc}", "err")
            return
        if not self._i2c_connect():
            return
        try:
            converted = _convert_script(script, dev_hex)
            cmd_num = 0
            for line in converted.split("\n"):
                line = line.strip()
                if not line or not line[0].isalnum():
                    continue
                cmd_num += 1
                if line.upper().startswith("D") and len(line) > 1 and line[1:].isdigit():
                    time.sleep(int(line[1:]) / 1000.0)
                    self.log(f"[{cmd_num}] delay {line[1:]}ms")
                    continue
                try:
                    results = self.board.i2c_send(line)
                    parts = line.split()
                    up = parts[0].upper() if parts else ""
                    if up == "R":
                        self.log(f"[{cmd_num}] r {parts[1]} {parts[2]} read ok")
                        if results and results[0]:
                            vals = " ".join(f"{int(r[4:6],16):02X}" for r in results[0])
                            self.log(vals, "data")
                    elif up == "W":
                        self.log(f"[{cmd_num}] w {parts[1]} {parts[2]} {parts[3]} write ok")
                    else:
                        self.log(f"[{cmd_num}] {line} ok")
                except Exception as exc:
                    self.log(f"[{cmd_num}] error: {exc}", "err")
                    return
            self.log(f"[OK] Script complete ({cmd_num} cmd)", "ok")
        finally:
            self._i2c_disconnect()

    def _i2c_check_status(self):
        name = self.device_name_var.get().strip()
        if not name:
            messagebox.showwarning("Missing", "Enter a Device Name first.")
            return
        path = os.path.join(INI_ROOT, name, f"{name} Status Register Map.txt")
        if not os.path.isfile(path):
            messagebox.showerror("Not Found", f"Status Register Map not found:\n{path}")
            return
        self._status_registers = parse_status_register_map(path)
        if not self._status_registers:
            messagebox.showwarning("No Data", "No entries in status register map.")
            return
        try:
            dev_hex = self._i2c_dev_hex()
        except Exception as exc:
            messagebox.showerror("Device Address", str(exc))
            return
        if not self._i2c_connect():
            return
        try:
            try:
                self.board.i2c_send(f"w {dev_hex} 00 00\nw {dev_hex} 7f 00")
            except Exception as exc:
                self.log(f"[ERR] page switch: {exc}", "err")
            reg_cache = {}
            for item in self._status_registers:
                reg_int = int(item["reg_addr"].strip(), 16)
                if reg_int not in reg_cache:
                    reg_cache[reg_int] = _read_reg_byte(self.board, dev_hex, f"{reg_int:02X}")
            active = []
            for item in self._status_registers:
                reg_int = int(item["reg_addr"].strip(), 16)
                byte_val = reg_cache.get(reg_int, 0)
                bits = item["bits"]
                if "," in bits:
                    bl = [int(b.strip()) for b in bits.split(",")]
                    hi, lo = max(bl), min(bl)
                    extracted = (byte_val >> lo) & ((1 << (hi - lo + 1)) - 1)
                else:
                    extracted = (byte_val >> int(bits)) & 1
                if extracted == item["value"]:
                    active.append(item["status"])
            self.status_list.configure(state="normal")
            self.status_list.delete("1.0", "end")
            for s in active:
                self.status_list.insert("end", s + "\n", "active")
            self.status_list.configure(state="disabled")
            self.log(f"[OK] Check status complete ({len(active)} active)", "ok")
        except Exception as exc:
            messagebox.showerror("Status Check Error", str(exc))
            self.log(f"[ERR] status check: {exc}", "err")
        finally:
            self._i2c_disconnect()

    def _i2c_clear_fault(self):
        try:
            dev_hex = self._i2c_dev_hex().lower()
        except Exception as exc:
            messagebox.showerror("Device Address", str(exc))
            return
        if not self._i2c_connect():
            return
        try:
            for i, cmd in enumerate((f"w {dev_hex} 00 00", f"w {dev_hex} 7f 00",
                                     f"w {dev_hex} 01 08"), 1):
                self.board.i2c_send(cmd)
                self.log(f"[{i}] {cmd} write ok")
            self.log("[OK] Clear fault complete", "ok")
        except Exception as exc:
            messagebox.showerror("Clear Fault Error", str(exc))
            self.log(f"[ERR] clear fault: {exc}", "err")
        finally:
            self._i2c_disconnect()

    # ===================================================== TAB 3: Thermal Stream
    def _build_tab_thermal(self, parent):
        # runtime state
        self.thermal_monitoring = False
        self._thermal_after_id = None
        self.t_data = []
        self.air_data = []
        self.dut_data = []
        self.thermal_start_time = None
        self._cached_setp = None
        self._cached_acc = None
        self._cached_soak = None
        self._holding_start_time = None
        self._dead_queries = set()

        parent.grid_columnconfigure(1, weight=1)   # monitor column expands
        parent.grid_rowconfigure(1, weight=1)      # settings + monitor row

        # ---- top: use_thermal_stream (prominent) + GPIB + IDN ----
        top = ttk.Frame(parent)
        top.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        tk.Checkbutton(top, text="use_thermal_stream",
                       variable=self.use_thermal_var,
                       font=("Segoe UI", 10, "bold"), fg="#0066aa").pack(
            side="left", padx=(0, 16))
        ttk.Label(top, text="GPIB:").pack(side="left")
        self.gpib_var = tk.StringVar(value=DEFAULTS["gpib"])
        ttk.Entry(top, textvariable=self.gpib_var, width=18).pack(side="left", padx=(3, 6))
        self.idn_var = tk.StringVar(value="(not connected)")
        ttk.Label(top, textvariable=self.idn_var, foreground="#666",
                  font=("Segoe UI", 9, "italic")).pack(side="left")

        # ---- Settings (left of monitor; size unchanged) ----
        sf = ttk.LabelFrame(parent, text="Settings", padding=8)
        sf.grid(row=1, column=0, sticky="nsw", padx=(0, 8))

        def add_entry(r, label, key, unit):
            ttk.Label(sf, text=label).grid(row=r, column=0, sticky="w", pady=3)
            var = tk.StringVar(value=str(DEFAULTS[key]))
            ttk.Entry(sf, textvariable=var, width=8).grid(
                row=r, column=1, padx=4, pady=3, sticky="w")
            ttk.Label(sf, text=unit, foreground="#666").grid(
                row=r, column=2, sticky="w")
            return var

        self.setpoint_var  = add_entry(0, "Setpoint:", "setpoint", "\u00b0C")
        self.soak_var      = add_entry(1, "Soak:",     "soak",     "s")
        self.accuracy_var  = add_entry(2, "Accuracy:", "accuracy", "\u00b0C")
        self.flow_rate_var = add_entry(3, "Flow rate:", "flow_rate", "SCFM")

        self.t_mode_var   = tk.StringVar(value=DEFAULTS["mode"])
        self.t_sensor_var = tk.StringVar(value=DEFAULTS["sensor"])
        self.cool_var     = tk.StringVar(value="?")

        ttk.Separator(sf, orient="horizontal").grid(
            row=4, column=0, columnspan=3, sticky="ew", pady=10)
        s = ttk.Style()
        s.configure("Big.TButton", font=("Segoe UI", 11, "bold"))
        s.configure("Stop.TButton", font=("Segoe UI", 10, "bold"), foreground="#c62828")
        self.t_set_btn = ttk.Button(sf, text="Set", style="Big.TButton",
                                    command=self._thermal_set_all_and_run)
        self.t_set_btn.grid(row=5, column=0, columnspan=3, sticky="ew", pady=4)
        self.t_stop_btn = ttk.Button(sf, text="Abort", style="Stop.TButton",
                                     state="disabled", command=self._thermal_abort)
        self.t_stop_btn.grid(row=6, column=0, columnspan=3, sticky="ew", pady=4)

        # ---- monitor (right of settings; width compressed) ----
        mf = ttk.LabelFrame(parent, text="Monitor", padding=6)
        mf.grid(row=1, column=1, sticky="nsew")
        mf.grid_rowconfigure(0, weight=1)
        mf.grid_columnconfigure(0, weight=1)
        self.fig = Figure(figsize=(3.8, 2.6), dpi=90, constrained_layout=True)
        self.ax = self.fig.add_subplot(111)
        self._thermal_init_plot()
        self.canvas = FigureCanvasTkAgg(self.fig, master=mf)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew", pady=(0, 6))

        st = ttk.Frame(mf)
        st.grid(row=1, column=0, sticky="ew")
        self.air_val = tk.StringVar(value="--")
        self.dut_val = tk.StringVar(value="--")
        self.set_val = tk.StringVar(value="--")
        self.tecr_val = tk.StringVar(value="--")
        self.range_val = tk.StringVar(value="--")
        self.elapsed_val = tk.StringVar(value="00:00:00")
        self.timeout_val = tk.StringVar(value="--")
        self.err_val = tk.StringVar(value="--")
        self.state_val = tk.StringVar(value="idle")

        def rd(parent, r, label, var, color="#222"):
            tk.Label(parent, text=label, foreground="#666", width=9, anchor="w",
                     font=("Consolas", 9)).grid(row=r, column=0, sticky="w", padx=(0, 4))
            lbl = tk.Label(parent, textvariable=var, foreground=color, anchor="w",
                           width=13, font=("Consolas", 9, "bold"))
            lbl.grid(row=r, column=1, sticky="w")
            return lbl

        c1 = ttk.Frame(st); c1.pack(side="left", padx=(4, 16), anchor="n")
        c2 = ttk.Frame(st); c2.pack(side="left", anchor="n")
        rd(c1, 0, "Air:", self.air_val, "#1e63c9")
        rd(c1, 1, "DUT:", self.dut_val, "#c62828")
        rd(c1, 2, "Set:", self.set_val, "#444")
        rd(c1, 3, "TECR:", self.tecr_val)
        self.range_lbl = rd(c2, 0, "In-Range:", self.range_val)
        rd(c2, 1, "State:", self.state_val, "#1e3a5f")
        rd(c2, 2, "Elapsed:", self.elapsed_val)
        rd(c2, 3, "Timeout:", self.timeout_val, "#1e3a5f")

        # ---- manual controls (below monitor, single row) ----
        self._build_thermal_manual(parent)

    def _thermal_init_plot(self):
        self.ax.clear()
        self.ax.set_xlabel("Elapsed (s)")
        self.ax.set_ylabel("Temp (\u00b0C)")
        self.ax.grid(True, alpha=0.3)
        (self.air_line,) = self.ax.plot([], [], color="#1e63c9", label="Air", linewidth=1.6)
        (self.dut_line,) = self.ax.plot([], [], color="#c62828", label="DUT", linewidth=1.6)
        self.set_line = self.ax.axhline(y=0, color="#444", linestyle="--", linewidth=1.2)
        self.set_line.set_visible(False)
        proxy = Line2D([0], [0], color="#444", linestyle="--", linewidth=1.2, label="Setpoint")
        self.band = None
        self.ax.legend(handles=[self.air_line, self.dut_line, proxy],
                       loc="upper right", fontsize=8)

    def _build_thermal_manual(self, parent):
        f = ttk.LabelFrame(parent, text="Manual Controls", padding=8)
        f.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        # Single row. Air+DUT (mode) and NON (sensor) are intentionally omitted.
        ttk.Label(f, text="Mode:", font=("Segoe UI", 9, "bold")).grid(
            row=0, column=0, sticky="e", padx=(0, 4))
        mf = ttk.Frame(f); mf.grid(row=0, column=1, sticky="w", padx=(0, 12))
        self.mode_btns = {}
        for i, m in enumerate(("Air", "DUT")):
            b = tk.Button(mf, text=m, width=6, command=lambda x=m: self._thermal_set_mode(x))
            b.grid(row=0, column=i, padx=2)
            self.mode_btns[m] = b
        ttk.Label(f, text="Sensor:", font=("Segoe UI", 9, "bold")).grid(
            row=0, column=2, sticky="e", padx=(0, 4))
        sfr = ttk.Frame(f); sfr.grid(row=0, column=3, sticky="w", padx=(0, 12))
        self.sensor_btns = {}
        for i, sname in enumerate(("T", "K")):
            b = tk.Button(sfr, text=sname, width=5,
                          command=lambda x=sname: self._thermal_set_sensor(x))
            b.grid(row=0, column=i, padx=2)
            self.sensor_btns[sname] = b
        self.flow_btn = tk.Button(f, text="Flow: ?", width=12,
                                  command=self._thermal_toggle_flow)
        self.flow_btn.grid(row=0, column=4, padx=4)
        self.cool_btn = tk.Button(f, text="Compressor: ?", width=15,
                                  command=self._thermal_toggle_cool)
        self.cool_btn.grid(row=0, column=5, padx=4)
        self.head_btn = tk.Button(f, text="Head: ?", width=10,
                                  command=self._thermal_toggle_head)
        self.head_btn.grid(row=0, column=6, padx=4)
        self._thermal_paint_mode(None)
        self._thermal_paint_sensor(None)
        self._thermal_paint_toggle(self.flow_btn, "Flow", None)
        self._thermal_paint_toggle(self.cool_btn, "Compressor", None)
        self._thermal_paint_toggle(self.head_btn, "Head", None)

    def _thermal_paint_mode(self, active):
        for name, btn in self.mode_btns.items():
            if name == active:
                btn.configure(relief="sunken", bg="#1e63c9", fg="white",
                              font=("Segoe UI", 9, "bold"))
            else:
                btn.configure(relief="raised", bg="SystemButtonFace", fg="black",
                              font=("Segoe UI", 9))

    def _thermal_paint_sensor(self, active):
        for name, btn in self.sensor_btns.items():
            if name == active:
                btn.configure(relief="sunken", bg="#1e63c9", fg="white",
                              font=("Segoe UI", 9, "bold"))
            else:
                btn.configure(relief="raised", bg="SystemButtonFace", fg="black",
                              font=("Segoe UI", 9))

    def _thermal_paint_toggle(self, btn, label, state):
        if state is None:
            btn.configure(text=f"{label}: ?", bg="SystemButtonFace", fg="black",
                          relief="raised")
            return
        on_word, off_word = ("DOWN", "UP") if label == "Head" else ("ON", "OFF")
        if state:
            btn.configure(text=f"{label}: {on_word}", bg="#4caf50", fg="white",
                          relief="sunken", font=("Segoe UI", 9, "bold"))
        else:
            btn.configure(text=f"{label}: {off_word}", bg="SystemButtonFace",
                          fg="black", relief="raised", font=("Segoe UI", 9))

    def _thermal_refresh_manual(self):
        if self.ts is None:
            return
        try:
            mode = int(self.ts.get_dut_mode())
            sensor = int(self.ts.get_dut_sensor())
            flow = int(self.ts.get_flow())
            cool = int(self.ts.get_cool())
            head = int(self.ts.get_head())
            mode_name = next((k for k, v in MODE_MAP.items() if v == mode), None)
            sensor_name = next((k for k, v in SENSOR_MAP.items() if v == sensor), None)
            if mode_name:
                self.t_mode_var.set(mode_name)
                self._thermal_paint_mode(mode_name)
            if sensor_name:
                self.t_sensor_var.set(sensor_name)
                self._thermal_paint_sensor(sensor_name)
            self._thermal_paint_toggle(self.flow_btn, "Flow", bool(flow))
            self._thermal_paint_toggle(self.cool_btn, "Compressor", bool(cool))
            self._thermal_paint_toggle(self.head_btn, "Head", bool(head))
            self.cool_var.set("ON" if cool else "OFF")
        except Exception as exc:
            self.log(f"[WARN] thermal state refresh failed: {exc}")

    def _thermal_ensure_connected(self) -> bool:
        if self.ts is None:
            if not self._thermal_connect():
                return False
            self._thermal_refresh_manual()
        return True

    def _thermal_ensure_flow_off(self):
        try:
            if bool(int(self.ts.get_flow())):
                self.ts.flow_off()
                self.log("[OK] Flow OFF (auto, required for Mode/Sensor)")
            self._thermal_paint_toggle(self.flow_btn, "Flow", bool(int(self.ts.get_flow())))
        except Exception as exc:
            self.log(f"[WARN] flow-off precheck failed: {exc}")

    def _thermal_set_mode(self, name):
        if not self._thermal_ensure_connected():
            return
        if name in ("DUT", "Air+DUT") and self.t_sensor_var.get() == "NON":
            messagebox.showerror("Sensor Required",
                                 f"Mode '{name}' needs a DUT thermocouple.")
            return
        try:
            self._thermal_ensure_flow_off()
            self.ts.set_dut_mode(MODE_MAP[name])
            self.t_mode_var.set(name)
            self._thermal_paint_mode(name)
            self.log(f"[OK] Mode -> {name}")
        except Exception as exc:
            messagebox.showerror("Set Mode", str(exc))

    def _thermal_set_sensor(self, name):
        if not self._thermal_ensure_connected():
            return
        if name == "NON" and self.t_mode_var.get() in ("DUT", "Air+DUT"):
            messagebox.showerror("Sensor Required",
                                 f"Mode '{self.t_mode_var.get()}' needs a DUT thermocouple.")
            return
        try:
            self._thermal_ensure_flow_off()
            self.ts.set_dut_sensor(SENSOR_MAP[name])
            self.t_sensor_var.set(name)
            self._thermal_paint_sensor(name)
            self.log(f"[OK] Sensor -> {name}")
        except Exception as exc:
            messagebox.showerror("Set Sensor", str(exc))

    def _thermal_toggle_flow(self):
        if not self._thermal_ensure_connected():
            return
        try:
            if bool(int(self.ts.get_flow())):
                if self.thermal_monitoring:
                    self._thermal_stop_monitor("flow turned off by user")
                self.ts.flow_off()
                self.log("[OK] Flow OFF")
                self._thermal_paint_toggle(self.flow_btn, "Flow", False)
            else:
                self.ts.flow_on()
                self.log("[OK] Flow ON")
                self._thermal_paint_toggle(self.flow_btn, "Flow", True)
        except Exception as exc:
            messagebox.showerror("Toggle Flow", str(exc))

    def _thermal_toggle_cool(self):
        if not self._thermal_ensure_connected():
            return
        try:
            if bool(int(self.ts.get_cool())):
                self.ts.cool_off()
                self.log("[OK] Compressor OFF")
                self._thermal_paint_toggle(self.cool_btn, "Compressor", False)
                self.cool_var.set("OFF")
            else:
                self.ts.cool_on()
                self.log("[OK] Compressor ON")
                self._thermal_paint_toggle(self.cool_btn, "Compressor", True)
                self.cool_var.set("ON")
        except Exception as exc:
            messagebox.showerror("Toggle Compressor", str(exc))

    def _thermal_toggle_head(self):
        if not self._thermal_ensure_connected():
            return
        try:
            if bool(int(self.ts.get_head())):
                self.ts.head_up()
                self.log("[OK] Head UP")
                self._thermal_paint_toggle(self.head_btn, "Head", False)
            else:
                self.ts.head_down()
                self.log("[OK] Head DOWN")
                self._thermal_paint_toggle(self.head_btn, "Head", True)
        except Exception as exc:
            messagebox.showerror("Toggle Head", str(exc))

    # ---------------------------------------------- thermal connection
    def _thermal_connect(self, silent: bool = False) -> bool:
        if self.ts is not None:
            return True
        addr = self.gpib_var.get().strip()
        if not addr:
            if not silent:
                messagebox.showwarning("Missing", "Enter a GPIB address.")
            return False
        try:
            self.ts = Thermal_Stream(addr)
            try:
                self.ts.my_ins.timeout = VISA_TIMEOUT_MS
                self.ts.my_ins.query_delay = 0.05
                self.ts.my_ins.clear()
            except Exception:
                pass
            self.ts.set_remote()
            idn = self.ts.get_idn()
            self.idn_var.set(idn)
            self._dead_queries.clear()
            self._thermal_preblacklist(idn)
            self.log(f"[OK] Thermal connected: {addr} -> {idn}", "ok")
            return True
        except Exception as exc:
            self.ts = None
            self.idn_var.set(f"({addr} not detected)")
            if not silent:
                messagebox.showerror("Connect Error", str(exc))
            self.log(f"[ERR] Thermal connect failed: {exc}", "err")
            return False

    def _thermal_preblacklist(self, idn):
        u = (idn or "").upper()
        if "ATS-71" in u or "ATS-81" in u:
            self._dead_queries.add("ERROR?")
            self.log("[--] Model does not support ERROR? - skipped.")

    def _thermal_disconnect(self):
        if self.ts is None:
            return
        try:
            self.ts.set_local()
        except Exception:
            pass
        try:
            self.ts.my_ins.close()
        except Exception:
            pass
        self.ts = None
        self.log("[--] Thermal disconnected")

    def _thermal_check_device(self, silent: bool = False):
        """Read IDN + current chamber state, then release (per-op, not held).
        silent=True suppresses error dialogs -- used for the startup probe so a
        missing chamber doesn't pop a dialog, just shows '(not detected)'."""
        addr = self.gpib_var.get().strip()
        if not addr:
            self.idn_var.set("(no address)")
            return
        keep = self.ts is not None
        if not keep:
            if not self._thermal_connect(silent=silent):
                return
        try:
            self._thermal_refresh_manual()
        finally:
            if not keep:
                self._thermal_disconnect()

    def _thermal_sync_flow_button(self):
        time.sleep(0.1)
        try:
            is_on = bool(int(self.ts.get_flow()))
        except Exception as exc:
            self.log(f"[WARN] flow readback failed: {exc}")
            return
        self._thermal_paint_toggle(self.flow_btn, "Flow", is_on)

    # ---------------------------------------------- thermal set + monitor
    def _thermal_set_all_and_run(self):
        try:
            setp = float(self.setpoint_var.get())
            soak = int(self.soak_var.get())
            acc = float(self.accuracy_var.get())
            flow_rate = int(self.flow_rate_var.get())
        except Exception as exc:
            messagebox.showerror("Bad Input", f"Cannot parse settings: {exc}")
            return
        if not self._thermal_ensure_connected():
            return
        self.state_val.set("applying...")
        self.t_set_btn.configure(state="disabled")
        self.root.update_idletasks()
        try:
            self.ts.set_soak(soak)
            self.ts.set_accuracy(acc)
            self.ts.set_flow_rate(flow_rate)
            self.ts.set_setpoint(setp)
            self.ts.flow_on()
            self.log("[OK] Flow ON (auto)")
            self._thermal_sync_flow_button()
            self._cached_setp = setp
            self._cached_acc = acc
            self._cached_soak = soak
            self._holding_start_time = None
            self.timeout_val.set(f"{soak} s")
            self.log(f"[OK] Applied: setpoint={setp} soak={soak} acc={acc} flow={flow_rate}")
        except Exception as exc:
            self.t_set_btn.configure(state="normal")
            self.state_val.set("apply failed")
            messagebox.showerror("Apply Error", str(exc))
            return
        self._thermal_start_monitor()

    def _thermal_abort(self):
        if self.thermal_monitoring:
            self._thermal_stop_monitor("aborted by user")
        if self.ts is not None:
            try:
                self.ts.flow_off()
                self.log("[OK] Flow OFF (auto on abort)")
                self._thermal_sync_flow_button()
            except Exception as exc:
                self.log(f"[WARN] flow-off on abort failed: {exc}")
        self._thermal_disconnect()
        self.state_val.set("aborted")
        self.timeout_val.set("--")
        self._holding_start_time = None
        self.t_set_btn.configure(state="normal")
        self.t_stop_btn.configure(state="disabled")

    def _thermal_start_monitor(self):
        if self.ts is None or self.thermal_monitoring:
            return
        self.thermal_monitoring = True
        self.thermal_start_time = time.time()
        self.t_data.clear()
        self.air_data.clear()
        self.dut_data.clear()
        self.t_set_btn.configure(state="disabled")
        self.t_stop_btn.configure(state="normal")
        self.state_val.set("ramping")
        self.log("[--] Thermal monitor started")
        self._thermal_monitor_tick()

    def _thermal_stop_monitor(self, reason=""):
        if not self.thermal_monitoring:
            return
        self.thermal_monitoring = False
        if self._thermal_after_id is not None:
            try:
                self.root.after_cancel(self._thermal_after_id)
            except Exception:
                pass
            self._thermal_after_id = None
        self.t_set_btn.configure(state="normal")
        self.t_stop_btn.configure(state="disabled")
        self.log(f"[--] Thermal monitor stopped ({reason})" if reason
                 else "[--] Thermal monitor stopped")

    def _thermal_monitor_tick(self):
        if not self.thermal_monitoring:
            return
        setp = self._cached_setp
        acc = self._cached_acc
        elapsed = time.time() - self.thermal_start_time

        def _q(name, fn, default):
            if name in self._dead_queries:
                return default
            try:
                return fn()
            except Exception as exc:
                self.log(f"[WARN] {name} failed: {exc}. Skipping for session.")
                self._dead_queries.add(name)
                try:
                    self.ts.my_ins.clear()
                except Exception:
                    pass
                return default

        air_raw = _q("TMPA?", self.ts.get_air_temp, None)
        dut_raw = _q("TMPD?", self.ts.get_dut_temp, None)
        tecr_raw = _q("TECR?", self.ts.get_TECR, None)
        err_raw = _q("ERROR?", self.ts.get_error, None)

        air = float(air_raw) if air_raw is not None else (
            self.air_data[-1] if self.air_data else float("nan"))
        dut = float(dut_raw) if dut_raw is not None else (
            self.dut_data[-1] if self.dut_data else float("nan"))
        tecr = int(tecr_raw) if tecr_raw is not None else 0
        err = int(err_raw) if err_raw is not None else 0

        self.t_data.append(elapsed)
        self.air_data.append(air)
        self.dut_data.append(dut)
        if len(self.t_data) > MAX_POINTS:
            self.t_data = self.t_data[-MAX_POINTS:]
            self.air_data = self.air_data[-MAX_POINTS:]
            self.dut_data = self.dut_data[-MAX_POINTS:]

        self.air_val.set(f"{air:.2f} \u00b0C")
        self.dut_val.set(f"{dut:.2f} \u00b0C")
        self.set_val.set(f"{setp:.2f} \u00b0C")
        self.tecr_val.set(f"0x{tecr:04X}")
        ctrl_temp = dut if self.t_mode_var.get() == "DUT" else air
        in_range = abs(ctrl_temp - setp) <= acc
        self.range_val.set("True" if in_range else "False")
        self.range_lbl.configure(foreground="#2e7d32" if in_range else "#c62828")
        h, rem = divmod(int(elapsed), 3600)
        m, sec = divmod(rem, 60)
        self.elapsed_val.set(f"{h:02d}:{m:02d}:{sec:02d}")
        self.err_val.set("OK" if err == 0 else f"{err} (0x{err:04X})")

        now = time.time()
        soak = self._cached_soak or 0
        if in_range:
            if self._holding_start_time is None:
                self._holding_start_time = now
                self.state_val.set("holding")
                self.log(f"[--] In-range: holding for {soak} s")
            remaining = max(0.0, soak - (now - self._holding_start_time))
            self.timeout_val.set(f"{remaining:.0f} s")
        else:
            if self._holding_start_time is not None:
                self._holding_start_time = None
                self.log(f"[--] Drifted out of range - reset to {soak} s")
            self.state_val.set("ramping")
            self.timeout_val.set(f"{soak} s")

        self.air_line.set_data(self.t_data, self.air_data)
        self.dut_line.set_data(self.t_data, self.dut_data)
        self.set_line.set_ydata([setp, setp])
        self.set_line.set_visible(True)
        if self.band is not None:
            self.band.remove()
        self.band = self.ax.axhspan(setp - acc, setp + acc, color="#4caf50", alpha=0.10)
        self.ax.relim()
        self.ax.autoscale_view()
        self.canvas.draw_idle()

        if tecr & 1:
            self.log(f"[OK] TECR bit 0 set (at-temp + soak complete). "
                     f"Air={air:.2f} DUT={dut:.2f} Set={setp:.2f}")
            self._thermal_stop_monitor("at-temp + soak complete")
            self._thermal_disconnect()
            self.state_val.set("done")
            self.timeout_val.set("0 s")
            return
        self._thermal_after_id = self.root.after(POLL_MS, self._thermal_monitor_tick)


# ===========================================================================
# Single-instance helpers + entry point
# ===========================================================================
def _client_send(obj: dict, timeout: float = 1.0):
    """Send one JSON command to a running instance; return response dict or None."""
    try:
        with socket.create_connection((IPC_HOST, IPC_PORT), timeout=timeout) as c:
            c.sendall((json.dumps(obj) + "\n").encode("utf-8"))
            c.settimeout(timeout)
            buf = b""
            while b"\n" not in buf:
                chunk = c.recv(4096)
                if not chunk:
                    break
                buf += chunk
            if not buf:
                return None
            return json.loads(buf.decode("utf-8", "replace").strip())
    except Exception:
        return None


def _instance_running() -> bool:
    resp = _client_send({"cmd": "ping"})
    return bool(resp and resp.get("status") == "ok")


def main():
    if _instance_running():
        _client_send({"cmd": "focus"})
        print("Bench Control already running - focused existing window.")
        return

    root = tk.Tk()
    root.minsize(700, 560)
    app = BenchApp(root)
    try:
        app.ipc_server = IPCServer(app)
        app.ipc_server.start()
    except OSError:
        # Lost a startup race: another instance bound the port first.
        _client_send({"cmd": "focus"})
        root.destroy()
        return
    root.mainloop()


if __name__ == "__main__":
    main()
