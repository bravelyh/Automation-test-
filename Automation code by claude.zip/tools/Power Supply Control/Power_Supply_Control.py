"""Power Supply Control GUI.

Controls the two PSUs on the bench (auto-discovered):
  * High Power (Chroma 62012P-80-60, single channel)
  * 4-Channel  (GW Instek GPP-4323, 4 channels)

Layout: 5 rows total, top section is HP + bottom section is CH1..CH4.
Each row: V setpoint, I setpoint, Output toggle, V measured, I measured.

Run/Stop semantics:
  * Run OFF -> setpoint edits do NOT push to hardware; no monitoring.
  * Run ON  -> monitor polls all channels every MONITOR_MS ms; setpoint
               edits push to hardware on Enter / focus-out.
  * Toggling Run OFF stops monitoring but does NOT change output state.

Missing hardware handling:
  * If a PSU is not detected, that section is greyed out; the other
    section continues to work.
"""
from __future__ import annotations

import os
import sys
import tkinter as tk
from tkinter import ttk


def _setup_paths():
    candidates = []
    if getattr(sys, "frozen", False):
        candidates.append(getattr(sys, "_MEIPASS", ""))
    here = os.path.dirname(os.path.abspath(__file__))
    candidates.append(here)
    candidates.append(os.path.abspath(os.path.join(here, "..", "..")))
    for p in candidates:
        if p and p not in sys.path:
            sys.path.insert(0, p)


_setup_paths()
from instruments.bench import Bench  # noqa: E402


MONITOR_MS = 100
V_FMT = "{:.3f}"
I_FMT = "{:.3f}"

# Role mapping (which DUT rail each channel powers).
# HP is always PVDD regardless of which 4-CH supply is installed.
HP_ROLE = "PVDD"


def get_ch_roles(gpp_driver_type_name: str) -> list[str]:
    """Return the 4 role names for CH1..CH4 based on the 4-CH PSU model.

    Special case: GW Instek GPP-4323 has a different pin-out (Loadbox on
    CH1, DVDD on CH4). Any other 4-CH model gets the default mapping.
    Add more special cases here as new 4-CH PSUs are integrated.
    """
    if gpp_driver_type_name == "GwinstekGPP4323":
        # CH1        CH2      CH3    CH4
        return ["Loadbox", "VBAT", "AUX", "DVDD"]
    # default    CH1     CH2      CH3        CH4
    return ["DVDD", "VBAT", "Loadbox", "AUX"]


# ---------------------------------------------------------------------------
# ChannelBinding — hides multi-channel vs single-channel PSU differences
# ---------------------------------------------------------------------------
class ChannelBinding:
    """One logical channel — wraps the underlying driver + optional channel index."""

    def __init__(self, psu, channel: int | None = None):
        self.psu = psu
        self.channel = channel

    def _kw(self):
        return {} if self.channel is None else {"channel": self.channel}

    def set_voltage(self, v: float) -> None:
        self.psu.set_voltage(v, **self._kw())

    def set_current(self, i: float) -> None:
        self.psu.set_current(i, **self._kw())

    def enable(self, on: bool) -> None:
        self.psu.enable(on, **self._kw())

    def measure_voltage(self) -> float:
        return self.psu.measure_voltage(**self._kw())

    def measure_current(self) -> float:
        return self.psu.measure_current(**self._kw())

    def get_voltage_setpoint(self) -> float:
        return self.psu.get_voltage_setpoint(**self._kw())

    def get_current_setpoint(self) -> float:
        return self.psu.get_current_setpoint(**self._kw())

    def is_enabled(self) -> bool:
        return self.psu.is_enabled(**self._kw())


# ---------------------------------------------------------------------------
# One row of the UI (V set / I set / Output / V meas / I meas)
# ---------------------------------------------------------------------------
class ChannelRow:
    def __init__(self, parent: tk.Widget, row: int, label: str,
                 gui: "PSUControlGUI"):
        self.gui = gui
        self.label = label
        self.binding: ChannelBinding | None = None   # set by gui.set_binding()

        # Cached committed values so blur-after-enter doesn't re-push.
        self._committed_v: str = ""
        self._committed_i: str = ""

        self.v_var  = tk.StringVar(value="0.00")
        self.i_var  = tk.StringVar(value="0.00")
        self.on_var = tk.BooleanVar(value=False)
        self.v_meas_var = tk.StringVar(value="—")
        self.i_meas_var = tk.StringVar(value="—")
        self.role_var   = tk.StringVar(value="")   # e.g. "PVDD", "DVDD", set later

        # Col 0 -- channel identity (bold)
        tk.Label(parent, text=label, width=10, anchor="w",
                 font=("Segoe UI", 9, "bold")).grid(
            row=row, column=0, sticky="w", padx=(4, 4), pady=3)

        # Col 1 -- role (grey, updated after HW detection)
        tk.Label(parent, textvariable=self.role_var, width=9, anchor="w",
                 font=("Segoe UI", 9), foreground="#666").grid(
            row=row, column=1, sticky="w", padx=(0, 8))

        self.v_entry = ttk.Entry(parent, textvariable=self.v_var, width=8,
                                 font=("Consolas", 10), justify="right")
        self.v_entry.grid(row=row, column=2, padx=2)
        self.v_entry.bind("<Return>",   lambda _e: self._commit_v())
        self.v_entry.bind("<FocusOut>", lambda _e: self._commit_v())

        self.i_entry = ttk.Entry(parent, textvariable=self.i_var, width=8,
                                 font=("Consolas", 10), justify="right")
        self.i_entry.grid(row=row, column=3, padx=2)
        self.i_entry.bind("<Return>",   lambda _e: self._commit_i())
        self.i_entry.bind("<FocusOut>", lambda _e: self._commit_i())

        self.output_btn = tk.Button(
            parent, text="OFF", width=6, bg="#d0d0d0",
            font=("Segoe UI", 9, "bold"),
            command=self._toggle_output)
        self.output_btn.grid(row=row, column=4, padx=8)

        tk.Label(parent, textvariable=self.v_meas_var, width=9, anchor="e",
                 font=("Consolas", 10)).grid(row=row, column=5, padx=4)
        tk.Label(parent, text="V", foreground="grey").grid(row=row, column=6, sticky="w")

        tk.Label(parent, textvariable=self.i_meas_var, width=9, anchor="e",
                 font=("Consolas", 10)).grid(row=row, column=7, padx=4)
        tk.Label(parent, text="A", foreground="grey").grid(row=row, column=8, sticky="w")

    # ---------------------------------------------------------------- state
    def set_role(self, role: str) -> None:
        """Show what DUT rail this channel powers (e.g. 'PVDD', 'DVDD')."""
        self.role_var.set(role)

    def set_binding(self, b: ChannelBinding | None) -> None:
        self.binding = b
        state = "normal" if b is not None else "disabled"
        self.v_entry.configure(state=state)
        self.i_entry.configure(state=state)
        self.output_btn.configure(state=state)
        if b is None:
            self.v_meas_var.set("N/A")
            self.i_meas_var.set("N/A")

    def _toggle_output(self) -> None:
        # UI-side toggle first (immediate visual feedback), then push if Run
        new_state = not self.on_var.get()
        self._apply_output_ui(new_state)
        if not self.gui.running or self.binding is None:
            return
        try:
            self.binding.enable(new_state)
            self.gui.log(f"[SET] {self.label} Output = {'ON' if new_state else 'OFF'}",
                         tag="ok")
        except Exception as exc:
            self._apply_output_ui(not new_state)  # revert
            self.gui.log(f"[ERR] {self.label} enable({new_state}): {exc}", tag="err")

    def _apply_output_ui(self, on: bool) -> None:
        self.on_var.set(on)
        if on:
            self.output_btn.configure(text="ON",  bg="#4caf50", fg="white")
        else:
            self.output_btn.configure(text="OFF", bg="#d0d0d0", fg="black")

    # ---------------------------------------------------------------- commit
    def _commit_v(self) -> None:
        txt = self.v_var.get().strip()
        if txt == self._committed_v:
            return
        self._committed_v = txt
        if not self.gui.running or self.binding is None:
            return
        try:
            v = float(txt)
        except ValueError:
            self.gui.log(f"[ERR] {self.label} V: invalid value {txt!r}", tag="err")
            return
        try:
            self.binding.set_voltage(v)
            self.gui.log(f"[SET] {self.label} V = {v}", tag="ok")
        except Exception as exc:
            self.gui.log(f"[ERR] {self.label} set_voltage({v}): {exc}", tag="err")

    def _commit_i(self) -> None:
        txt = self.i_var.get().strip()
        if txt == self._committed_i:
            return
        self._committed_i = txt
        if not self.gui.running or self.binding is None:
            return
        try:
            i = float(txt)
        except ValueError:
            self.gui.log(f"[ERR] {self.label} I: invalid value {txt!r}", tag="err")
            return
        try:
            self.binding.set_current(i)
            self.gui.log(f"[SET] {self.label} I = {i}", tag="ok")
        except Exception as exc:
            self.gui.log(f"[ERR] {self.label} set_current({i}): {exc}", tag="err")

    # ---------------------------------------------------------------- sync
    def sync_from_hw(self) -> tuple[float, float, bool] | None:
        """Read Vset / Iset / output-state from hardware and mirror to GUI.
        Returns (v, i, on) on success, None on failure. Called on Run start.
        """
        if self.binding is None:
            return None
        v = self.binding.get_voltage_setpoint()
        i = self.binding.get_current_setpoint()
        on = self.binding.is_enabled()
        v_str = V_FMT.format(v)
        i_str = I_FMT.format(i)
        self.v_var.set(v_str)
        self.i_var.set(i_str)
        # Prime the "last committed" cache so FocusOut on unchanged values
        # doesn't re-push what we just read.
        self._committed_v = v_str
        self._committed_i = i_str
        self._apply_output_ui(on)
        return v, i, on

    # ---------------------------------------------------------------- monitor
    def poll(self) -> None:
        if self.binding is None:
            return
        try:
            v = self.binding.measure_voltage()
            self.v_meas_var.set(V_FMT.format(v))
        except Exception:
            self.v_meas_var.set("err")
        try:
            i = self.binding.measure_current()
            self.i_meas_var.set(I_FMT.format(i))
        except Exception:
            self.i_meas_var.set("err")


# ---------------------------------------------------------------------------
# Main GUI
# ---------------------------------------------------------------------------
class PSUControlGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Power Supply Control")
        self.running = False
        self._monitor_after_id: str | None = None

        self.bench: Bench | None = None
        self.hp_driver = None
        self.gpp_driver = None

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        # Do detection on the first mainloop tick so the window shows first.
        self.root.after(50, self._detect_and_bind)

    # ------------------------------------------------------------------- UI
    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=10)
        outer.grid(sticky="nsew")
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        # ── Top: Run / Rescan ─────────────────────────────────────
        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 8))

        self.run_btn = tk.Button(top, text="Run", width=10, bg="#e0e0e0",
                                  font=("Segoe UI", 10, "bold"),
                                  command=self._toggle_run)
        self.run_btn.pack(side="left")

        ttk.Button(top, text="Rescan", command=self._rescan, width=10).pack(
            side="left", padx=(6, 0))

        self.status_var = tk.StringVar(value="Idle")
        ttk.Label(top, textvariable=self.status_var, foreground="#666",
                  font=("Segoe UI", 9)).pack(side="right")

        # ── High Power section ────────────────────────────────────
        hp_frame = ttk.LabelFrame(outer, text="High Power", padding=8)
        hp_frame.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        self.hp_header = ttk.Label(hp_frame, text="(detecting…)",
                                    foreground="#666", font=("Segoe UI", 9))
        self.hp_header.grid(row=0, column=0, columnspan=8, sticky="w",
                             pady=(0, 4))

        _headers(hp_frame, row=1)
        self.hp_row = ChannelRow(hp_frame, row=2, label="High Power", gui=self)

        # ── 4-Channel section ─────────────────────────────────────
        gpp_frame = ttk.LabelFrame(outer, text="4-Channel", padding=8)
        gpp_frame.grid(row=2, column=0, sticky="ew", pady=(0, 6))
        self.gpp_header = ttk.Label(gpp_frame, text="(detecting…)",
                                     foreground="#666", font=("Segoe UI", 9))
        self.gpp_header.grid(row=0, column=0, columnspan=8, sticky="w",
                              pady=(0, 4))

        _headers(gpp_frame, row=1)
        self.ch_rows: list[ChannelRow] = []
        for i in range(4):
            r = ChannelRow(gpp_frame, row=2 + i, label=f"CH{i+1}", gui=self)
            self.ch_rows.append(r)

        # ── Log ───────────────────────────────────────────────────
        # Fixed 5-line log — don't give this row any grid weight or it
        # will absorb every unused pixel of the window.
        lf = ttk.LabelFrame(outer, text="Log", padding=6)
        lf.grid(row=3, column=0, sticky="ew", pady=(4, 0))

        self.log_text = tk.Text(lf, height=5, state="disabled",
                                 font=("Consolas", 9), wrap="word")
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb.set)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        lf.grid_rowconfigure(0, weight=1)
        lf.grid_columnconfigure(0, weight=1)
        self.log_text.tag_config("ok",   foreground="#007700")
        self.log_text.tag_config("err",  foreground="#cc0000")
        self.log_text.tag_config("info", foreground="#333333")

    # ---------------------------------------------------------------- helpers
    def log(self, msg: str, tag: str = "info") -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", msg + "\n", tag)
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    # ---------------------------------------------------------------- detect
    def _detect_and_bind(self) -> None:
        """Create a Bench, try to get both PSUs, wire up rows accordingly."""
        try:
            self.bench = Bench()
        except Exception as exc:
            self.log(f"[ERR] Bench(): {exc}", tag="err")
            self.hp_header.configure(text="Bench init failed", foreground="#cc0000")
            self.gpp_header.configure(text="Bench init failed", foreground="#cc0000")
            self.hp_row.set_binding(None)
            for r in self.ch_rows:
                r.set_binding(None)
            return

        # High Power
        self.hp_row.set_role(HP_ROLE)   # always PVDD
        try:
            self.hp_driver = self.bench.psu_high_power
            self.hp_header.configure(
                text=f"{type(self.hp_driver).__name__}  @  {self.hp_driver.addr}",
                foreground="#0066aa")
            self.hp_row.set_binding(ChannelBinding(self.hp_driver))
            self.log(f"[OK] psu_high_power = {type(self.hp_driver).__name__} "
                     f"@ {self.hp_driver.addr}  (rail: {HP_ROLE})", tag="ok")
        except Exception as exc:
            self.hp_header.configure(text="NOT DETECTED", foreground="#cc0000")
            self.hp_row.set_binding(None)
            self.log(f"[--] psu_high_power not available: {str(exc).splitlines()[0]}")

        # 4-Channel
        try:
            self.gpp_driver = self.bench.psu_4ch
            gpp_type = type(self.gpp_driver).__name__
            self.gpp_header.configure(
                text=f"{gpp_type}  @  {self.gpp_driver.addr}",
                foreground="#0066aa")
            ch_roles = get_ch_roles(gpp_type)
            for i, r in enumerate(self.ch_rows):
                r.set_binding(ChannelBinding(self.gpp_driver, channel=i + 1))
                r.set_role(ch_roles[i])
            self.log(f"[OK] psu_4ch = {gpp_type} @ {self.gpp_driver.addr}  "
                     f"(rails: {', '.join(f'CH{i+1}={r}' for i,r in enumerate(ch_roles))})",
                     tag="ok")
        except Exception as exc:
            self.gpp_header.configure(text="NOT DETECTED", foreground="#cc0000")
            for r in self.ch_rows:
                r.set_binding(None)
                r.set_role("")
            self.log(f"[--] psu_4ch not available: {str(exc).splitlines()[0]}")

    def _rescan(self) -> None:
        """Drop drivers, force a fresh discovery, re-bind."""
        self._stop_run(reason="rescan")
        # Close whatever we may have opened
        self._close_drivers()
        self.hp_driver = None
        self.gpp_driver = None
        self.hp_row.set_binding(None)
        for r in self.ch_rows:
            r.set_binding(None)
        self.log("[--] Rescanning...")
        # Fresh Bench + fresh scan
        from instruments import discovery
        discovery.clear_cache()
        self._detect_and_bind()

    # ---------------------------------------------------------------- run
    def _toggle_run(self) -> None:
        if self.running:
            self._stop_run()
        else:
            self._start_run()

    def _start_run(self) -> None:
        # Open every available PSU
        try:
            if self.hp_driver is not None:
                self.hp_driver.open()
            if self.gpp_driver is not None:
                self.gpp_driver.open()
        except Exception as exc:
            self.log(f"[ERR] open failed: {exc}", tag="err")
            self._close_drivers()
            return

        # Read current state from every available channel and mirror into GUI.
        # This gives the user a live snapshot before edits kick in.
        for row in (self.hp_row, *self.ch_rows):
            if row.binding is None:
                continue
            try:
                v, i, on = row.sync_from_hw()
                self.log(f"[SYNC] {row.label}: V={v:.3f} I={i:.3f} "
                         f"Output={'ON' if on else 'OFF'}", tag="info")
            except Exception as exc:
                self.log(f"[ERR] {row.label} sync from HW: {exc}", tag="err")

        self.running = True
        self.run_btn.configure(text="Stop", bg="#4caf50", fg="white")
        self.status_var.set("Running — monitoring @ 100 ms")
        self.log("[OK] Run started; monitoring active", tag="ok")
        self._monitor_tick()

    def _stop_run(self, reason: str = "user") -> None:
        if not self.running:
            return
        self.running = False
        if self._monitor_after_id is not None:
            try:
                self.root.after_cancel(self._monitor_after_id)
            except Exception:
                pass
            self._monitor_after_id = None
        self.run_btn.configure(text="Run", bg="#e0e0e0", fg="black")
        self.status_var.set("Idle")
        self._close_drivers()
        self.log(f"[--] Run stopped ({reason}); outputs left as-is")

    def _close_drivers(self) -> None:
        for d in (self.hp_driver, self.gpp_driver):
            if d is None:
                continue
            try:
                d.close()
            except Exception:
                pass

    def _monitor_tick(self) -> None:
        if not self.running:
            return
        self.hp_row.poll()
        for r in self.ch_rows:
            r.poll()
        self._monitor_after_id = self.root.after(MONITOR_MS, self._monitor_tick)

    # ---------------------------------------------------------------- close
    def _on_close(self) -> None:
        self._stop_run(reason="window closed")
        self.root.destroy()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _headers(parent: tk.Widget, row: int) -> None:
    ttk.Label(parent, text="",       width=10).grid(row=row, column=0)
    ttk.Label(parent, text="Rail",   width=9,  anchor="w",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=1)
    ttk.Label(parent, text="V set",  width=8, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=2)
    ttk.Label(parent, text="I set",  width=8, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=3)
    ttk.Label(parent, text="Output", width=6, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=4)
    ttk.Label(parent, text="V meas", width=9, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=5, columnspan=2)
    ttk.Label(parent, text="I meas", width=9, anchor="center",
              font=("Segoe UI", 9, "bold")).grid(row=row, column=7, columnspan=2)


def main():
    root = tk.Tk()
    root.minsize(720, 480)
    PSUControlGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
