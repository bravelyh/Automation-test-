"""Bus scanner: identify the PC, enumerate every COM port and VISA resource.

Returns a normalized dict:

  {
      "pc_id": "DT4CE210CTM1",          # this machine's hostname
      "com": [
          {"address": "COM3", "description": "GPP Serial (COM3)",
           "manufacturer": "GWInstek", "hwid": "...", "serial_number": "..."},
          ...
      ],
      "visa": [
          {"address": "GPIB0::28::INSTR", "model": "62012P-80-60",
           "manufacturer": "CHROMA", "serial": "01.20", "idn": "<raw>"},
          ...
      ],
  }

`pc_id` is the local hostname; `bench.py`'s BENCH_REGISTRY maps it to a
bench id + AP type (see there). COM/VISA are the hardware buses matched
against CATALOG.

For VISA entries the IDN is parsed as `MANUFACTURER,MODEL,SERIAL,FIRMWARE`
(comma-separated) and the middle field becomes `model` — this is what the
catalog matches against.

Result is cached in `_CACHE`; `scan_all(force_refresh=True)` (or
`clear_cache()`) forces a rescan. In TestStand's persistent Python
interpreter the scan runs at most once per user session.
"""
from __future__ import annotations

import socket
from typing import Any


_CACHE: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# PC identity — hostname
# ---------------------------------------------------------------------------
def scan_pc_id() -> str:
    """The local machine's hostname (PC ID), e.g. 'DT4CE210CTM1'.

    This is the key bench.py's BENCH_REGISTRY uses to resolve the physical
    bench id and AP type. Returns '' if the hostname can't be read.
    """
    try:
        return socket.gethostname().strip()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# COM (serial) ports — pyserial
# ---------------------------------------------------------------------------
def scan_com() -> list[dict]:
    from serial.tools import list_ports
    out: list[dict] = []
    try:
        for p in list_ports.comports():
            out.append({
                "address":       p.device,
                "description":   p.description  or "",
                "manufacturer":  p.manufacturer or "",
                "hwid":          p.hwid         or "",
                "serial_number": (p.serial_number or "").strip(),
            })
    except Exception:
        pass
    return out


# ---------------------------------------------------------------------------
# VISA resources — pyvisa (GPIB / USB only)
#
# TCPIP and ASRL resources are intentionally skipped:
#   * TCPIP — list_resources() returns every LXI/VXI-11 instrument on the
#     subnet (the whole company's networked gear), and probing each with
#     *IDN? is slow and intrusive. LAN instruments must be addressed manually
#     by IP instead (e.g. build "TCPIP0::10.85.29.232::inst0::INSTR" and pass
#     it to the driver directly).
#   * ASRL — these are COM ports surfaced through VISA (ASRL3 == COM3); they
#     are already enumerated by scan_com() via pyserial, so listing them here
#     too is redundant and confusing.
# ---------------------------------------------------------------------------
# VISA address prefixes skipped during auto-discovery (case-insensitive).
SKIP_VISA_PREFIXES = ("TCPIP", "ASRL")


def _parse_idn(idn: str) -> tuple[str, str, str, str]:
    """`MANUFACTURER,MODEL,SERIAL,FIRMWARE` -> (mfr, model, serial, fw).

    Extra/missing commas are tolerated; missing fields come back as ''.
    """
    parts = [p.strip() for p in idn.split(",")]
    parts += [""] * (4 - len(parts))
    return parts[0], parts[1], parts[2], parts[3]


def scan_visa(idn_probe_timeout_ms: int = 500) -> list[dict]:
    try:
        import pyvisa
    except ImportError:
        return []
    try:
        rm = pyvisa.ResourceManager()
        resources = rm.list_resources()
    except Exception:
        return []

    out: list[dict] = []
    for res in resources:
        if res.upper().startswith(SKIP_VISA_PREFIXES):
            continue          # skip TCPIP (manual IP) and ASRL (== COM ports)
        entry: dict[str, Any] = {
            "address": res, "idn": "", "manufacturer": "", "model": "",
            "serial": "", "firmware": "",
        }
        try:
            inst = rm.open_resource(res)
            inst.timeout = idn_probe_timeout_ms
            inst.write("*IDN?")
            entry["idn"] = inst.read().strip()
            inst.close()
        except Exception:
            entry["idn"] = ""
        if entry["idn"]:
            (entry["manufacturer"], entry["model"],
             entry["serial"], entry["firmware"]) = _parse_idn(entry["idn"])
        out.append(entry)
    return out


# ---------------------------------------------------------------------------
# Unified scan + cache
# ---------------------------------------------------------------------------
def scan_all(force_refresh: bool = False) -> dict:
    """Cached scan of both buses. Call once, use everywhere."""
    global _CACHE
    if _CACHE is None or force_refresh:
        _CACHE = {
            "pc_id": scan_pc_id(),
            "com":   scan_com(),
            "visa":  scan_visa(),
        }
    return _CACHE


def clear_cache() -> None:
    """Force the next scan_all() to actually scan."""
    global _CACHE
    _CACHE = None
