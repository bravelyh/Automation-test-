"""AP2722 — Audio Precision AP2722. Bench mode only.

Placeholder: no AP2722 is present on this bench yet. When one arrives,
implement the APBase bench-mode contract here (the AP2722 has no sequence
mode, so nothing mode-specific to add). Until then this class is abstract
and cannot be instantiated.
"""
from __future__ import annotations

from instruments.ap.ap_base import APBase


class AP2722(APBase, ap_type="AP2722"):
    def __init__(self, addr: str = "", mode: str = "bench") -> None:
        # Bench-only device. Accepts `mode` for a uniform AP(...) signature
        # but supports only "bench".
        if mode != "bench":
            raise ValueError(f"AP2722 is bench-only; mode={mode!r} not supported")
        self.addr = addr
        self.mode = mode
        self._apx = None

    # TODO: implement the APBase bench-mode methods (open, close, get_idn,
    # open_project, sample_rate, set_digital_generator, turn_on/off_generator,
    # load_file, start_measurement[_non_blocking], save_graph, clear_data,
    # append/not_append_graph_data, set_x_axis_range, get_meter_reading,
    # export_data) when the unit is available.
