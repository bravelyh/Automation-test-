"""APx555 — Audio Precision APx555 controlled via .NET API (pythonnet).

Implements the APBase bench-mode contract, plus APx555-only extras:
the input switcher and Sequence mode. Only the APx555 has a Sequence mode
(the AP2722 is bench-only), so those methods live here, not in the base.

The APx500 host application is a Windows singleton: the first attach may
take ~10 s to spawn the UI, later ones snap to the running instance. There
is no bus to scan — the "address" is the API DLL path, a machine-wide
constant. Set APX500_API_DIR to override the DLL location.

Usage:
    ap = APx555()                       # bench mode (default)
    ap.open()
    ap.set_digital_generator(level=-20, frequency=1000)
    ap.turn_on_generator()
    ap.close()

    seq = APx555(mode="sequence")       # sequence mode
    seq.open()
    seq.sequence_sample_rate(48000)
    seq.show_measurement(signal_path, measurement)
    seq.close()
"""
from __future__ import annotations

import os

from instruments.ap.ap_base import APBase


APX_DIR_DEFAULT = r"C:\Program Files\Audio Precision\APx500 8.0\API"

# mode name -> APxOperatingMode enum attribute.
_OPERATING_MODES: dict[str, str] = {
    "bench":    "BenchMode",
    "sequence": "SequenceMode",
}


class APx555(APBase, ap_type="APx555"):
    def __init__(self, addr: str = "", mode: str = "bench") -> None:
        """`addr` is accepted for a uniform signature but ignored (no bus
        address). `mode`: "bench" (default) or "sequence".
        """
        if mode not in _OPERATING_MODES:
            raise ValueError(
                f"unknown AP mode {mode!r}; expected one of "
                f"{sorted(_OPERATING_MODES)}")
        self.addr = addr
        self.mode = mode
        self._apx = None  # lazy; call open() to attach

    # ---- lifecycle -------------------------------------------------------
    def open(self) -> None:
        import clr  # pythonnet
        api_dir = os.environ.get("APX500_API_DIR", APX_DIR_DEFAULT)
        clr.AddReference(os.path.join(api_dir, "AudioPrecision.API.dll"))
        clr.AddReference(os.path.join(api_dir, "AudioPrecision.API2.dll"))
        from AudioPrecision.API import APx500_Application, APxOperatingMode
        op = getattr(APxOperatingMode, _OPERATING_MODES[self.mode])
        self._apx = APx500_Application(op)
        self._apx.Visible = True

    def close(self) -> None:
        # APx500 is a Windows singleton owned by the host; we don't shut it
        # down when a Python client detaches. Just drop our reference.
        self._apx = None

    @property
    def app(self):
        """The underlying AudioPrecision.API.APx500_Application object.
        Raises if open() was never called.
        """
        if self._apx is None:
            raise RuntimeError("APx555 not opened; call open() first")
        return self._apx

    @property
    def generator(self):
        """Shortcut to `.app.BenchMode.Generator`."""
        return self.app.BenchMode.Generator

    @property
    def setup(self):
        """Shortcut to `.app.BenchMode.Setup`."""
        return self.app.BenchMode.Setup

    def get_idn(self) -> str:
        try:
            return f"APx500 {self.app.ApplicationVersion}"
        except Exception:
            return "APx500"

    def open_project(self, project_path: str) -> None:
        self.app.OpenProject(project_path)

    # ---- signal path -----------------------------------------------------
    def sample_rate(self, rate) -> None:
        self.app.BenchMode.Setup.SerialDigitalTransmitter.SampleRate.Value = rate

    # ---- input -----------------------------------------------------------
    def set_analog_balance_input(
        self,
        channels: int | None = None,
        auto_range: bool | None = None,
        fixed_range: float | None = None,
        channel: int | None = None,
    ) -> None:
        from AudioPrecision.API import (
            AnalogConnectorType,
            InputChannelIndex,
            SingleInputChannelIndex,
        )
        analog_in = self.app.BenchMode.Setup.AnalogInput

        if channels is not None:
            channels = int(channels)
            analog_in.ChannelCount = channels
            # channels=1 -> pick which physical channel (channel is conditional).
            if channels == 1:
                sel = int(channel) if channel is not None else 1
                analog_in.SingleInputChannel = getattr(SingleInputChannelIndex, f"Ch{sel}")
                active = [sel]
            else:
                active = list(range(1, channels + 1))
            for n in active:
                analog_in.SetConnectorType(
                    getattr(InputChannelIndex, f"Ch{n}"), AnalogConnectorType.Balanced)
        elif channel is not None:
            # channels not given, but a single-channel selection was: apply it.
            # Harmless (no effect) if the instrument is in 2-channel mode.
            analog_in.SingleInputChannel = getattr(
                SingleInputChannelIndex, f"Ch{int(channel)}")

        if auto_range is not None or fixed_range is not None:
            ranges = self.app.BenchMode.AnalogInputRanges
            if auto_range is not None:
                ranges.AutoRange = bool(auto_range)
            # fixed_range is conditional: it only takes effect when auto range
            # is off. Setting it while auto range is on is harmless (stored,
            # used once auto range is turned off) -> never an error.
            if fixed_range is not None:
                ranges.TrackFirstChannel = True             # apply Ch1 to all
                ranges.SetValue(InputChannelIndex.Ch1, float(fixed_range))

    @staticmethod
    def _enum(enum_type, name, what):
        """Resolve an APx enum member by name, with a helpful error."""
        try:
            return getattr(enum_type, str(name))
        except AttributeError:
            from System import Enum
            valid = ", ".join(Enum.GetNames(enum_type))
            raise ValueError(f"invalid {what} {name!r}; valid: {valid}")

    def setup_filters(
        self,
        high_pass: str | None = None,
        low_pass: str | None = None,
        weighting: str | None = None,
        bandwidth: str | None = None,
        hpf_frequency: float | None = None,
    ) -> None:
        from AudioPrecision.API import (
            AdcBandwidth,
            HighpassFilterMode,
            LowpassFilterModeAnalog,
            SignalPathWeightingFilterType,
        )
        setup = self.app.BenchMode.Setup

        if high_pass is not None:
            setup.HighpassFilter = self._enum(
                HighpassFilterMode, high_pass, "high_pass")
        # hpf_frequency is conditional: it only takes effect for the tunable
        # high-pass filters (Butterworth/Elliptic). Setting it otherwise is
        # harmless (stored, used once such a filter is selected).
        if hpf_frequency is not None:
            setup.HighpassFilterFrequency = float(hpf_frequency)

        if low_pass is not None:
            setup.LowpassFilterAnalog = self._enum(
                LowpassFilterModeAnalog, low_pass, "low_pass")
        # bandwidth is conditional: it only takes effect when the LPF is the
        # ADC passband. Setting it otherwise is harmless.
        if bandwidth is not None:
            setup.LowpassFilterAnalogBandwidth = self._enum(
                AdcBandwidth, bandwidth, "bandwidth")

        if weighting is not None:
            setup.WeightingFilter = self._enum(
                SignalPathWeightingFilterType, weighting, "weighting")

    # ---- generator -------------------------------------------------------
    def set_digital_generator(
        self,
        waveform: str | None = None,
        level: float | None = None,
        offset: float | None = None,
        auto_on: bool | None = None,
        turn_on: bool | None = None,
        frequency: float | None = None,
        shape: str | None = None,
        music_path: str | None = None,
    ) -> None:
        from AudioPrecision.API import NoiseShape, OutputChannelIndex
        gen = self.app.BenchMode.Generator

        # ---- waveform selection --------------------------------------------
        # "Sine"/"Noise" are the generator's built-in waveform names. "music"
        # is our facade for playing a file: it has no built-in name, so we load
        # the file (which also selects it) instead of setting gen.Waveform.
        if waveform is not None:
            if waveform.lower() == "music":
                # music_path is conditional: it only takes effect here, when
                # waveform="music". Loading the file also selects it.
                if music_path is not None:
                    gen.LoadWaveformFile(music_path, replaceIfExists=False)
            else:
                gen.Waveform = waveform

        # ---- common: levels ------------------------------------------------
        if level is not None or offset is not None:
            gen.Levels.TrackFirstChannel = True             # apply Ch1 to all
            if level is not None:
                gen.Levels.Unit = "dBFS"
                gen.Levels.SetValue(OutputChannelIndex.Ch1, level)
            if offset is not None:
                gen.Levels.OffsetUnit = "D"
                gen.Levels.SetOffsetValue(OutputChannelIndex.Ch1, offset)

        # ---- sine-specific: frequency (harmless if not a sine) -------------
        if frequency is not None:
            gen.Frequency.Value = frequency

        # ---- noise-specific: shape (harmless if not noise) -----------------
        if shape is not None:
            gen.NoiseShape = self._enum(NoiseShape, shape, "shape")

        # ---- common: auto-on, then output on/off ---------------------------
        if auto_on is not None:
            gen.AutoOn = bool(auto_on)
        # turn_on last: finish configuring, then switch the output.
        if turn_on is not None:
            gen.On = bool(turn_on)

    def turn_on_generator(self) -> None:
        self.app.BenchMode.Generator.On = True

    def turn_off_generator(self) -> None:
        self.app.BenchMode.Generator.On = False

    def load_file(self, file_path: str) -> None:
        self.app.BenchMode.Generator.LoadWaveformFile(
            file_path, replaceIfExists=False)

    # ---- measurements ----------------------------------------------------
    def start_measurement(self, measurement) -> None:
        measurement.Start()
        while measurement.IsStarted:
            pass

    def start_measurement_non_blocking(self, measurement) -> None:
        measurement.Start()

    def save_graph(self, file_path: str, measurement, tag_list=None) -> None:
        from AudioPrecision.API import GraphImageType
        tag = "_" + "_".join(str(c) for c in tag_list) if tag_list else ""
        for i in range(measurement.Graphs.Count):
            graph = measurement.Graphs[i]
            filename = f"{file_path}\\{graph.Name}{tag}.png"
            graph.Show()
            graph.Save(filename, GraphImageType.PNG)

    def clear_data(self, measurement) -> None:
        measurement.ClearData()

    def append_graph_data(self, measurement) -> None:
        measurement.Append = True

    def not_append_graph_data(self, measurement) -> None:
        measurement.Append = False

    def set_x_axis_range(self, result, x_axis_min, x_axis_max) -> None:
        result.XAxis.Minimum = x_axis_min
        result.XAxis.Maximum = x_axis_max

    def get_meter_reading(self, meter_type, unit) -> list:
        return list(self.app.BenchMode.Meters.GetReadings(meter_type, unit))

    def export_data(
        self,
        file_path: str,
        measurement,
        measurement_name: str,
        tag_list=None,
        number_of_points=None,
        append_if_exist: bool = False,
    ) -> None:
        from AudioPrecision.API import NumberOfGraphPoints
        if number_of_points is None:
            number_of_points = NumberOfGraphPoints.GraphPointsAllPoints
        tag = "_" + "_".join(str(c) for c in tag_list) if tag_list else ""
        filename = f"{file_path}\\{measurement_name}{tag}.csv"
        measurement.ExportData(filename, number_of_points, append_if_exist)

    # ---- input switcher (APx555-specific) --------------------------------
    def enable_input_switcher(self, enabled: bool = True) -> None:
        """Enable or disable the input switcher (`UseInputSwitcher`)."""
        self.setup.UseInputSwitcher = enabled

    def set_input_switcher(
        self,
        cha: int | None = None,
        chb: int | None = None,
        addr: int = 0,
    ) -> None:
        """Route CHA and/or CHB on the switcher at `addr` (default 0 = Switcher0).

        cha / chb: DUT port number 1-12, or 0 to disconnect (None = leave unchanged).
        Does not change the UseInputSwitcher enable state — call
        enable_input_switcher() separately.
        """
        from AudioPrecision.API import SwitcherAddress, SwitcherChannelSelection

        sw_addr = getattr(SwitcherAddress, f"Switcher{addr}")
        cfg = self.setup.InputSwitcherConfiguration

        def _ch_sel(port: int) -> SwitcherChannelSelection:
            return (SwitcherChannelSelection.None_ if port == 0
                    else getattr(SwitcherChannelSelection, f"Ch{port}"))

        if cha is not None:
            cfg.SetChannelA(sw_addr, _ch_sel(cha))
        if chb is not None:
            cfg.SetChannelB(sw_addr, _ch_sel(chb))

    # ---- sequence-mode only (APx555 exclusive) ---------------------------
    def _require_sequence(self) -> None:
        if self.mode != "sequence":
            raise RuntimeError(
                f"this method requires mode='sequence'; this APx555 was "
                f"opened in {self.mode!r} mode")

    def sequence_sample_rate(self, rate) -> None:
        """Set the transmitter sample rate via SignalPathSetup (sequence mode)."""
        self._require_sequence()
        self.app.SignalPathSetup.SerialDigitalTransmitter.SampleRate.Value = rate

    def start_measurement_sequence(self, measurement) -> None:
        """Start a measurement without blocking on IsStarted (sequence mode)."""
        self._require_sequence()
        measurement.Start()

    def show_measurement(self, signal_path, measurement) -> None:
        """Bring a measurement in a signal path to the foreground (sequence mode)."""
        self._require_sequence()
        self.app.ShowMeasurement(signal_path, measurement)
