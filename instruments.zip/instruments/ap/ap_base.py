"""APBase — category-level interface every Audio Precision driver honours.

Contract only, like psu_base.py: this file names the shared *bench-mode*
methods every AP analyzer supports; the concrete code lives in the driver
(apx555.py, ap2722.py). Bench mode is the common denominator, so every
bench-mode method is declared here. Sequence mode is APx555-only, so those
methods are declared on APx555, not here.

There is no bus to scan: the "address" is the API DLL path, a machine-wide
constant. Do not instantiate a driver directly — go through the Bench
facade, which resolves this bench's `ap_type` to its driver and returns an
object exposing this base-layer interface:

    bench = Bench()
    ap = bench.ap(mode="bench")     # or bench.ap("sequence") on an APx555
    ap.open()
    ap.set_digital_generator(level=-20, frequency=1000)
    ap.turn_on_generator()
    ap.close()

Each driver registers itself by passing `ap_type=` in its class statement
(`class APx555(APBase, ap_type="APx555")`), so the resolver never imports a
specific driver — importing the package (which pulls the drivers in) is
enough. `Bench.ap` looks the driver up in APBase._registry.
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class APBase(ABC):
    # driver registry: ap_type string -> driver class (see __init_subclass__)
    _registry: dict[str, type["APBase"]] = {}

    def __init_subclass__(cls, ap_type: str | None = None, **kwargs) -> None:
        super().__init_subclass__(**kwargs)
        if ap_type is not None:
            APBase._registry[ap_type] = cls

    # ---- lifecycle -------------------------------------------------------
    @abstractmethod
    def open(self) -> None:
        """Load the API DLLs and attach to the APx500 host."""

    @abstractmethod
    def close(self) -> None:
        """Detach from the host (drop the reference)."""

    @abstractmethod
    def get_idn(self) -> str:
        """Return a best-effort identity string for logging."""

    @abstractmethod
    def open_project(self, project_path: str) -> None:
        """Open an APx project file."""

    # ---- signal path -----------------------------------------------------
    @abstractmethod
    def sample_rate(self, rate) -> None:
        """Set the serial-digital transmitter sample rate (bench mode)."""

    # ---- input -----------------------------------------------------------
    @abstractmethod
    def set_analog_balance_input(
        self,
        channels: int | None = None,
        auto_range: bool | None = None,
        fixed_range: float | None = None,
        channel: int | None = None,
    ) -> None:
        """Configure the analog balanced input (connector = analog balanced).

        Every parameter is optional: pass only what you want to change; anything
        left as None keeps the instrument's current setting — never an error.
        Parameters marked (conditional) only take effect under their condition;
        supplying one when the condition doesn't hold is silently ignored.

          channels    number of input channels (1 or 2).
          auto_range  True = auto range; False = use a fixed range.
          fixed_range (conditional) input-range value in the current unit; takes
                      effect only when auto_range is off.
          channel     (conditional) which physical channel (1 or 2) to use;
                      takes effect only in single-channel mode (channels=1).
        """

    @abstractmethod
    def setup_filters(
        self,
        high_pass: str | None = None,
        low_pass: str | None = None,
        weighting: str | None = None,
        bandwidth: str | None = None,
        hpf_frequency: float | None = None,
    ) -> None:
        """Configure the bench-mode input filters (values are APx enum names).

        Every parameter is optional: pass only what you want to change; anything
        left as None keeps the instrument's current setting — never an error.
        Parameters marked (conditional) only take effect under their condition;
        supplying one when the condition doesn't hold is silently ignored.

          high_pass  HighpassFilterMode: DC, AC, Butterworth, Elliptic, JitterAes3
          low_pass   LowpassFilterModeAnalog: AdcPassband, LpAes17_20k,
                     LpAes17_40k, Butterworth, Elliptic
          weighting  SignalPathWeightingFilterType: wt_None, wt_A, wt_B, wt_C,
                     wt_Ccir, wt_Dolby2k, wt_Ccitt, wt_CMessage, wt_Deemph50us,
                     wt_Deemph75us, wt_Deemph50usA, wt_Deemph75usA
          bandwidth      (conditional) AdcBandwidth (bw20k, bw45k, bw90k,
                         bw250k, ...); takes effect only when
                         low_pass='AdcPassband'.
          hpf_frequency  (conditional) high-pass corner frequency in Hz (e.g.
                         20); takes effect only when high_pass is 'Butterworth'
                         or 'Elliptic'.
        """

    # ---- generator -------------------------------------------------------
    @abstractmethod
    def set_digital_generator(
        self,
        waveform: str | None = None,
        level: float | None = None,
        offset: float | None = None,
        auto_on: bool | None = None,
        turn_on: bool | None = None,
        frequency: float | None = None,
        shape: str | None = None,
        music_path: str | None = None,
    ) -> None:
        """Configure the bench-mode digital generator.

        Every parameter is optional: pass only what you want to change; anything
        left as None keeps the generator's current setting — never an error.
        Parameters marked (conditional) only apply to one waveform; supplying
        one that doesn't apply is silently ignored.

          waveform    'Sine', 'Noise', or 'music' (play a file, see music_path).
          level       output level in dBFS.
          offset      DC offset (unit 'D').
          auto_on     AutoOn flag — turn on automatically when a measurement
                      starts (True/False).
          turn_on     turn the output on/off now (True/False).
          frequency   (conditional) tone frequency in Hz; applies to 'Sine'.
          shape       (conditional) noise algorithm — 'White', 'Pink', ...;
                      applies to 'Noise'.
          music_path  (conditional) path to a waveform file to load and play;
                      applies only when waveform='music'.
        """

    @abstractmethod
    def turn_on_generator(self) -> None:
        """Turn the generator output on."""

    @abstractmethod
    def turn_off_generator(self) -> None:
        """Turn the generator output off."""

    @abstractmethod
    def load_file(self, file_path: str) -> None:
        """Load a waveform file into the generator."""

    # ---- measurements ----------------------------------------------------
    @abstractmethod
    def start_measurement(self, measurement) -> None:
        """Start a measurement and block until it finishes."""

    @abstractmethod
    def start_measurement_non_blocking(self, measurement) -> None:
        """Start a measurement without waiting for it to finish."""

    @abstractmethod
    def save_graph(self, file_path: str, measurement, tag_list=None) -> None:
        """Save every graph of a measurement as a PNG."""

    @abstractmethod
    def clear_data(self, measurement) -> None:
        """Clear a measurement's data."""

    @abstractmethod
    def append_graph_data(self, measurement) -> None:
        """Set a measurement to append subsequent runs."""

    @abstractmethod
    def not_append_graph_data(self, measurement) -> None:
        """Set a measurement to overwrite instead of append."""

    @abstractmethod
    def set_x_axis_range(self, result, x_axis_min, x_axis_max) -> None:
        """Set a result graph's X-axis min/max."""

    @abstractmethod
    def get_meter_reading(self, meter_type, unit) -> list:
        """Read the bench-mode meters for `meter_type` in `unit`."""

    @abstractmethod
    def export_data(
        self,
        file_path: str,
        measurement,
        measurement_name: str,
        tag_list=None,
        number_of_points=None,
        append_if_exist: bool = False,
    ) -> None:
        """Export a measurement's data to CSV."""

    # ---- context-manager sugar ------------------------------------------
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
