"""Shanghai (SH) 4-channel resistive loadbox — Prolific USB-Serial transport.

Loadbox drivers are split by *site*, not by model: this is the SH-site box;
other regions get their own instruments/loadbox/loadbox_<SITE>.py driver.

The module-level constants and helper functions are kept verbatim so existing
tool code (and the Set_Load CLI) can keep importing them from here.

Programming model:
    * The physical hardware is stateless — each channel is set with a
      one-shot 4-char command `PC<ch><code>`. There is no persistent
      "connected" state, so the historical helper `set_load_per_channel`
      opens the port for one round-trip and closes it.
    * The `Loadbox_SH` class wraps that helper: `__init__(addr)` just stores
      the port, `.set_load_per_channel(codes, labels)` does one open /
      write-all-channels / close cycle.
"""
from __future__ import annotations

import time
from itertools import combinations_with_replacement
from pathlib import Path

import serial
from serial.tools import list_ports

from instruments.loadbox.loadbox_base import LoadboxBase


# Per-bench calibration tables. Each file records the *actual measured*
# resistance of that bench's loadbox — the nominal "Set Value" is the commanded
# load, the CHx columns are what the channel really is. Measurements (e.g.
# power) must use these real ohms, not nominal.
# Data lives under docs/ (instruments/ is code-only); absolute path per the
# fixed repo location (README rule: the repo is at C:\Auto Bench).
_MAPPING_DIR = Path(r"C:\Auto Bench\docs\bench loadbox mapping")


# key -> device code. Keys are the accepted --load strings in range 0 mode,
# and also the per-channel values selected by the series distributor.
LOAD_MAP: dict[str, int] = {
    "0":   0,
    "0.5": 1,
    "1":   2,
    "2":   3,
    "3":   4,
    "4":   5,
    "5":   6,
    "6":   7,
    "8":   8,
    "off": 9,
}

# Numeric per-channel values available for series-mode distribution.
# 'off' is intentionally excluded — series mode is about real ohm values.
CHANNEL_VALUES: list[float] = [0, 0.5, 1, 2, 3, 4, 5, 6, 8]

# Valid single-digit keys for mode-0 per-channel input (e.g. "2234").
PER_CHANNEL_KEYS: set[str] = {"1", "2", "3", "4", "5", "6", "8"}


# ---------------------------------------------------------------------------
# COM port detection (kept for legacy tool code; the Bench facade uses
# instruments.discovery.scan_all() instead)
# ---------------------------------------------------------------------------
def list_all_ports() -> list[dict]:
    """Return a list of dicts describing every COM port."""
    ports = []
    try:
        for p in list_ports.comports():
            ports.append({
                "device":       p.device,
                "description":  p.description  or "",
                "manufacturer": p.manufacturer or "",
                "hwid":         p.hwid         or "",
            })
    except Exception:
        pass
    return ports


def detect_loadbox_port() -> str | None:
    """Auto-detect the Prolific USB-Serial bridge used by the loadbox."""
    try:
        for port in list_ports.comports():
            desc  = (port.description or "").lower()
            manuf = (port.manufacturer or "").lower()
            if "prolific" in desc or "prolific" in manuf:
                return port.device
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Per-bench calibration table (actual measured resistance)
# ---------------------------------------------------------------------------
def load_bench_values(bench_id: str) -> dict[str, list[float]]:
    """Actual measured resistance (ohm) of a bench's loadbox, per channel.

    Reads ``bench_loadbox_mapping/Bench_#<bench_id>_Loadbox_Value.txt`` and
    returns ``{set_value: [ch1, ch2, ch3, ch4]}`` keyed by the nominal load
    string ('1', '2', ..., '8'). Use this for calculations that need real
    ohms (e.g. power) instead of the nominal commanded value.
    """
    path = _MAPPING_DIR / f"Bench_#{bench_id}_Loadbox_Value.txt"
    if not path.exists():
        available = sorted(
            p.stem.replace("Bench_#", "").replace("_Loadbox_Value", "")
            for p in _MAPPING_DIR.glob("Bench_#*_Loadbox_Value.txt"))
        raise FileNotFoundError(
            f"no loadbox calibration for bench {bench_id!r} at {path}. "
            f"Available benches: {', '.join(available) or '(none)'}")

    table: dict[str, list[float]] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        cells = [c.strip() for c in line.split("\t") if c.strip() != ""]
        if not cells:
            continue
        set_value = cells[0]
        try:
            float(set_value)          # skips the "Set Value" header row
        except ValueError:
            continue
        chans = [float(c) for c in cells[1:5]]   # ignore any trailing columns
        if len(chans) == 4:
            table[set_value] = chans
    return table


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------
def _decode_response(data: bytes) -> str:
    if not data:
        return ""
    try:
        text = data.decode("ascii").strip()
        if text and all(32 <= ord(c) < 127 for c in text):
            return text
    except Exception:
        pass
    return data.hex()


def _load_key(v: float) -> str:
    if v == int(v):
        return str(int(v))
    return f"{v:g}"


def format_load(key: str) -> str:
    """Render a load label: '3' -> '3ohm', 'off' -> 'off'."""
    return "off" if key == "off" else f"{key}ohm"


# ---------------------------------------------------------------------------
# Series-mode distribution
# ---------------------------------------------------------------------------
def distribute_series(target: float) -> list[float]:
    """4 channel values from CHANNEL_VALUES summing to `target`, as even as
    possible. Tie-break: min spread, then min variance. Descending."""
    best: list[float] | None = None
    best_key: tuple[float, float] | None = None
    for combo in combinations_with_replacement(CHANNEL_VALUES, 4):
        if abs(sum(combo) - target) > 1e-9:
            continue
        a, b, c, d = combo
        spread = d - a
        mean = (a + b + c + d) / 4.0
        var = (a - mean) ** 2 + (b - mean) ** 2 + (c - mean) ** 2 + (d - mean) ** 2
        key = (spread, var)
        if best_key is None or key < best_key:
            best = list(combo)
            best_key = key
    if best is None:
        raise ValueError(
            f"load {target} ohm cannot be composed from 4 channels using "
            f"per-channel values {CHANNEL_VALUES}")
    return sorted(best, reverse=True)


def parse_series_target(load_arg: str) -> float:
    try:
        target = float(load_arg)
    except ValueError:
        raise ValueError(
            f"--load '{load_arg}' must be numeric when --load-range=1")
    if target < 0 or target > 32:
        raise ValueError(f"load {target} out of range [0, 32] ohm")
    doubled = target * 2.0
    if abs(doubled - round(doubled)) > 1e-9:
        raise ValueError(f"load {target} must be a multiple of 0.5 ohm")
    return target


def parse_uniform_load(load_arg: str) -> str:
    key = load_arg.strip().lower()
    if key not in LOAD_MAP:
        valid = ", ".join(LOAD_MAP.keys())
        raise ValueError(f"load '{load_arg}' invalid for uniform mode. Valid: {valid}")
    return key


def parse_per_channel_load(load_arg: str) -> list[str]:
    s = load_arg.strip()
    if len(s) != 4:
        raise ValueError(
            f"per-channel load '{load_arg}' must be exactly 4 digits")
    keys: list[str] = []
    for i, ch in enumerate(s, start=1):
        if ch not in PER_CHANNEL_KEYS:
            valid = ", ".join(sorted(PER_CHANNEL_KEYS))
            raise ValueError(
                f"per-channel load '{load_arg}' CH{i}='{ch}' invalid. "
                f"Each digit must be one of: {valid}")
        keys.append(ch)
    return keys


def resolve_mode0(load_arg: str) -> list[str]:
    """Mode-0 --load into 4 LOAD_MAP keys (uniform or per-channel)."""
    if len(load_arg.strip()) == 4:
        return parse_per_channel_load(load_arg)
    key = parse_uniform_load(load_arg)
    return [key] * 4


def resolve_mode1(load_arg: str) -> list[str]:
    """Mode-1 (series) --load into 4 LOAD_MAP keys (descending)."""
    target = parse_series_target(load_arg)
    values = distribute_series(target)
    return [_load_key(v) for v in values]


# ---------------------------------------------------------------------------
# Serial I/O — one open/write/close cycle
# ---------------------------------------------------------------------------
def set_load_per_channel(port: str,
                         codes: list[int],
                         labels: list[str],
                         log=None) -> list[dict]:
    """Write per-channel codes to CH1..CH4 on `port`, return results.

    Args:
        port:   COM port device string, e.g. 'COM12'.
        codes:  4 device codes (0..9), one per channel in CH1..CH4 order.
        labels: 4 LOAD_MAP keys ('0', '0.5', ..., 'off') for display.
        log:    Optional callable(msg: str) for diagnostic output.

    Returns list of 4 dicts: {"ch", "load", "write", "read"}.
    """
    def _log(msg: str) -> None:
        if log is not None:
            log(msg)

    _log(f"[dbg] pyserial v{serial.__version__}")
    _log(f"[dbg] opening {port}")
    instr = serial.Serial(
        port, baudrate=9600, bytesize=8, parity="N",
        stopbits=1, timeout=0.5)
    _log(f"[dbg] opened {port}, baud=9600, read_timeout=500ms")

    results: list[dict] = []
    try:
        for i, (code, label) in enumerate(zip(codes, labels), start=1):
            cmd = f"PC{i}{code}"
            _log(f"[CH{i}] load={format_load(label)} code={code} write {cmd}")
            instr.write(cmd.encode("ascii"))
            instr.flush()
            time.sleep(0.1)
            data = instr.read(5)
            if data:
                val = _decode_response(data)
                _log(f"[CH{i}] read {data!r} -> {val}")
            else:
                val = ""
                _log(f"[CH{i}] no read response (timeout)")
            results.append({"ch": i, "load": label, "write": cmd, "read": val})
    finally:
        try:
            instr.close()
        except Exception:
            pass
    return results


# ---------------------------------------------------------------------------
# Class wrapper (for Bench facade / auto-discovery)
# ---------------------------------------------------------------------------
class Loadbox_SH(LoadboxBase):
    """Bench-facade-friendly wrapper around `set_load_per_channel`.

    Stateless internally: each `set_load_per_channel` call does its own
    open/write/close. `close()` is a no-op provided to satisfy the
    LoadboxBase context-manager protocol.
    """

    def __init__(self, addr: str) -> None:
        self.addr = addr

    def close(self) -> None:
        pass  # no persistent connection to close

    def set_load_per_channel(
        self,
        codes: list[int],
        labels: list[str],
        log=None,
    ) -> list[dict]:
        return set_load_per_channel(self.addr, codes, labels, log=log)
