"""LoadboxBase — minimal shared interface for 4-channel resistive loadboxes.

Kept tiny. The current inventory has exactly one physical device (a custom
board on a Prolific USB-Serial bridge). When a second model appears, this
class documents the contract every driver must honour.
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class LoadboxBase(ABC):
    @abstractmethod
    def close(self) -> None:
        """Close the underlying connection."""

    @abstractmethod
    def set_load_per_channel(
        self,
        codes: list[int],
        labels: list[str],
    ) -> list[dict]:
        """Set CH1..CH4 to the given per-channel device codes and return
        a list of {"ch", "load", "write", "read"} dicts describing each
        commanded channel.
        """

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
