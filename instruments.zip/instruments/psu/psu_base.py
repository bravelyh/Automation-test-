"""PSUBase — minimal category-level interface every PSU driver should honour.

Kept intentionally small. Extend only when a capability is shared by two or
more concrete drivers; single-driver features live on the concrete class.

Channel argument:
  * Single-channel supplies ignore `channel` (accept None).
  * Multi-channel supplies must be given a valid channel; raising on None
    is the driver's responsibility.
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class PSUBase(ABC):
    # ---- connection ------------------------------------------------------
    @abstractmethod
    def open(self) -> None:
        """Open the underlying connection."""

    @abstractmethod
    def close(self) -> None:
        """Close the underlying connection."""

    @abstractmethod
    def identify(self) -> str:
        """Return *IDN? response."""

    @abstractmethod
    def reset(self) -> None:
        """Reset the instrument to power-on defaults."""

    # ---- setpoints -------------------------------------------------------
    @abstractmethod
    def set_voltage(self, voltage: float, channel: int | None = None) -> None:
        """Program output voltage setpoint (V)."""

    @abstractmethod
    def set_current(self, current: float, channel: int | None = None) -> None:
        """Program current limit / setpoint (A)."""

    @abstractmethod
    def get_voltage_setpoint(self, channel: int | None = None) -> float:
        """Read back the programmed voltage setpoint (V)."""

    @abstractmethod
    def get_current_setpoint(self, channel: int | None = None) -> float:
        """Read back the programmed current setpoint (A)."""

    # ---- output enable ---------------------------------------------------
    @abstractmethod
    def enable(self, on: bool, channel: int | None = None) -> None:
        """Turn the output on/off."""

    @abstractmethod
    def is_enabled(self, channel: int | None = None) -> bool:
        """Query whether the output is on."""

    # ---- measurements ----------------------------------------------------
    @abstractmethod
    def measure_voltage(self, channel: int | None = None) -> float:
        """Measure actual output voltage (V)."""

    @abstractmethod
    def measure_current(self, channel: int | None = None) -> float:
        """Measure actual output current (A)."""

    @abstractmethod
    def measure_power(self, channel: int | None = None) -> float:
        """Measure actual output power (W)."""

    # ---- context-manager sugar ------------------------------------------
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
