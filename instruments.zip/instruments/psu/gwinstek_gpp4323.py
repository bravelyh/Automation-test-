"""GW Instek GPP-4323 — 4-channel bench DC supply.

Transport: RS-232 (USB Virtual COM Port). Default baud 115200, 8N1, no
flow control. The instrument accepts SCPI over the serial link exactly
like the GPIB/LAN interfaces.

Reference: GPP-Series User Manual (REVG, 2024-05-06), commands section
starting p.115. Only the source/measure/output commands used by test
code are implemented here; OVP/OCP, sequence, delay, monitor, trigger
and status subsystems are intentionally out of scope for now.

Channel numbering follows the manual: 1..4 for CH1..CH4.
"""
from __future__ import annotations

import serial

from instruments.psu.psu_base import PSUBase


DEFAULT_BAUD = 115200
DEFAULT_TIMEOUT_S = 1.0
NUM_CHANNELS = 4
TERM = "\n"  # SCPI line terminator for both write and read


def _check_channel(channel: int | None) -> int:
    if channel is None:
        raise ValueError("GPP-4323 requires a channel (1..4)")
    if channel not in (1, 2, 3, 4):
        raise ValueError(
            f"invalid channel {channel!r}, expected 1..{NUM_CHANNELS}")
    return channel


class GwinstekGPP4323(PSUBase):
    def __init__(self, addr: str, baud: int = DEFAULT_BAUD,
                 timeout_s: float = DEFAULT_TIMEOUT_S) -> None:
        # addr is a COM port string, e.g. "COM3"
        self.addr = addr
        self.baud = baud
        self.timeout_s = timeout_s
        self._ser: serial.Serial | None = None

    # ---- low-level transport --------------------------------------------
    def open(self) -> None:
        self._ser = serial.Serial(
            self.addr, baudrate=self.baud, bytesize=8, parity="N",
            stopbits=1, timeout=self.timeout_s)

    def close(self) -> None:
        if self._ser is not None:
            try:
                self._ser.close()
            except Exception:
                pass
            self._ser = None

    def _write(self, cmd: str) -> None:
        if self._ser is None:
            raise RuntimeError("port is not open — call open() first")
        self._ser.write((cmd + TERM).encode("ascii"))
        self._ser.flush()

    def _query(self, cmd: str) -> str:
        self._write(cmd)
        assert self._ser is not None
        line = self._ser.readline()
        return line.decode("ascii", errors="replace").strip()

    # ---- identification --------------------------------------------------
    def identify(self) -> str:
        return self._query("*IDN?")

    def reset(self) -> None:
        self._write("*RST")

    # ---- setpoints -------------------------------------------------------
    def set_voltage(self, voltage: float, channel: int | None = None) -> None:
        """Manual p.133 — `:SOURce[1|2|3|4]:VOLTage <NRf>`."""
        ch = _check_channel(channel)
        self._write(f":SOURce{ch}:VOLTage {float(voltage):g}")

    def set_current(self, current: float, channel: int | None = None) -> None:
        """Manual p.132 — `:SOURce[1|2|3|4]:CURRent <NRf>`."""
        ch = _check_channel(channel)
        self._write(f":SOURce{ch}:CURRent {float(current):g}")

    def get_voltage_setpoint(self, channel: int | None = None) -> float:
        """Manual p.134 — `:SOURce[1|2|3|4]:VOLTage?`."""
        ch = _check_channel(channel)
        return float(self._query(f":SOURce{ch}:VOLTage?"))

    def get_current_setpoint(self, channel: int | None = None) -> float:
        """Manual p.132 — `:SOURce[1|2|3|4]:CURRent?`."""
        ch = _check_channel(channel)
        return float(self._query(f":SOURce{ch}:CURRent?"))

    # ---- output enable ---------------------------------------------------
    def enable(self, on: bool, channel: int | None = None) -> None:
        """Manual p.128 — `:OUTPut[1|2|3|4][:STATe] <b>`."""
        ch = _check_channel(channel)
        self._write(f":OUTPut{ch}:STATe {'ON' if on else 'OFF'}")

    def is_enabled(self, channel: int | None = None) -> bool:
        """Manual p.128 — `:OUTPut[1|2|3|4][:STATe]?` (returns 0/1)."""
        ch = _check_channel(channel)
        return self._query(f":OUTPut{ch}:STATe?").strip() in ("1", "ON")

    def all_outputs(self, on: bool) -> None:
        """Manual p.128 — `:ALLOUTON` / `:ALLOUTOFF`. Bench-wide switch."""
        self._write(":ALLOUTON" if on else ":ALLOUTOFF")

    # ---- measurements ----------------------------------------------------
    def measure_voltage(self, channel: int | None = None) -> float:
        """Manual p.124 — `:MEASure[1|2|3|4]:VOLTage[:DC]?`."""
        ch = _check_channel(channel)
        return float(self._query(f":MEASure{ch}:VOLTage?"))

    def measure_current(self, channel: int | None = None) -> float:
        """Manual p.124 — `:MEASure[1|2|3|4]:CURRent[:DC]?`."""
        ch = _check_channel(channel)
        return float(self._query(f":MEASure{ch}:CURRent?"))

    def measure_power(self, channel: int | None = None) -> float:
        """Manual p.124 — `:MEASure[1|2|3|4]:POWEr[:DC]?`."""
        ch = _check_channel(channel)
        return float(self._query(f":MEASure{ch}:POWEr?"))

    def measure_all(self, channel: int | None = None) -> tuple[float, float, float]:
        """Manual p.124 — `:MEASure[1|2|3|4]:ALL?`. Returns (V, I, P)."""
        ch = _check_channel(channel)
        resp = self._query(f":MEASure{ch}:ALL?")
        # Response is comma-separated V,I,P
        parts = [p.strip() for p in resp.split(",")]
        if len(parts) < 3:
            raise ValueError(f"unexpected :MEAS:ALL? response: {resp!r}")
        return float(parts[0]), float(parts[1]), float(parts[2])
