"""Chroma 62012P-80-60 — 1200W / 80V / 60A single-channel programmable DC supply.

Transport: GPIB (via pyvisa). Also accepts USBTMC / RS-232 / LXI resource
strings that pyvisa recognises.

SCPI reference: python-ivi driver `chroma/chroma62000p.py` (Alex Forencich,
methods tagged "Tested on Chroma 62012P-80-60; working") and sigrok wiki
(scpi-pps). Key non-standard bits worth flagging:

  * Output enable uses `CONF:OUTP {ON|OFF}` — NOT the more common
    `OUTP:STAT` — and the query returns the literal strings `"ON"` /
    `"OFF"` rather than `0` / `1`.
  * Actual readback uses `FETC:VOLT?` / `FETC:CURR?` — NOT `MEAS:...?`.
    Power is not directly queryable; we return V*I as a convenience.
  * `SOUR:CURR` is the CC-mode threshold. There is a separate hard cap
    `SOUR:CURR:LIM:HIGH` if you want to protect against runaway CV->CC
    excursions.

Single-channel driver: the `channel` argument is accepted (matches
PSUBase signature) but ignored.
"""
from __future__ import annotations

import pyvisa

from instruments.psu.psu_base import PSUBase


# 62012P-80-60 spec envelope (from datasheet / python-ivi output_spec)
V_MAX_NOMINAL = 80.0
I_MAX_NOMINAL = 60.0
OVP_MAX = 88.0        # ~110% of V nominal
OCP_MAX = 66.0        # ~110% of I nominal
SLEW_MIN = 0.001      # V/ms
SLEW_MAX = 10.0       # V/ms  (for the 80-60 range)


class Chroma62012P(PSUBase):
    def __init__(self, addr: str) -> None:
        self.addr = addr
        self._rm: pyvisa.ResourceManager | None = None
        self._inst: pyvisa.resources.MessageBasedResource | None = None

    # ---- transport -------------------------------------------------------
    def open(self) -> None:
        self._rm = pyvisa.ResourceManager()
        self._inst = self._rm.open_resource(self.addr)

    def close(self) -> None:
        if self._inst is not None:
            try:
                self._inst.close()
            except Exception:
                pass
            self._inst = None

    def _write(self, cmd: str) -> None:
        if self._inst is None:
            raise RuntimeError("instrument not open — call open() first")
        self._inst.write(cmd)

    def _query(self, cmd: str) -> str:
        if self._inst is None:
            raise RuntimeError("instrument not open — call open() first")
        return self._inst.query(cmd).strip()

    # ---- identification --------------------------------------------------
    def identify(self) -> str:
        return self._query("*IDN?")

    def reset(self) -> None:
        self._write("*RST")

    # ---- setpoints -------------------------------------------------------
    def set_voltage(self, voltage: float, channel: int | None = None) -> None:
        v = float(voltage)
        if v < 0 or v > V_MAX_NOMINAL:
            raise ValueError(f"voltage {v} out of [0, {V_MAX_NOMINAL}] V")
        self._write(f"SOUR:VOLT {v:.2f}")

    def set_current(self, current: float, channel: int | None = None) -> None:
        i = float(current)
        if i < 0 or i > I_MAX_NOMINAL:
            raise ValueError(f"current {i} out of [0, {I_MAX_NOMINAL}] A")
        self._write(f"SOUR:CURR {i:.2f}")

    def get_voltage_setpoint(self, channel: int | None = None) -> float:
        return float(self._query("SOUR:VOLT?"))

    def get_current_setpoint(self, channel: int | None = None) -> float:
        return float(self._query("SOUR:CURR?"))

    # ---- output enable ---------------------------------------------------
    def enable(self, on: bool, channel: int | None = None) -> None:
        self._write(f"CONF:OUTP {'ON' if on else 'OFF'}")

    def is_enabled(self, channel: int | None = None) -> bool:
        return self._query("CONF:OUTP?").upper() == "ON"

    # ---- measurements ----------------------------------------------------
    def measure_voltage(self, channel: int | None = None) -> float:
        return float(self._query("FETC:VOLT?"))

    def measure_current(self, channel: int | None = None) -> float:
        return float(self._query("FETC:CURR?"))

    def measure_power(self, channel: int | None = None) -> float:
        return float(self._query("FETC:POW?"))

    # ---- protection & dynamics (Chroma-specific extras) ------------------
    def set_ovp(self, voltage: float) -> None:
        """Set over-voltage protection trip level (V)."""
        v = float(voltage)
        if v < 0 or v > OVP_MAX:
            raise ValueError(f"OVP {v} out of [0, {OVP_MAX}] V")
        self._write(f"SOUR:VOLT:PROT:HIGH {v:.1f}")

    def get_ovp(self) -> float:
        return float(self._query("SOUR:VOLT:PROT:HIGH?"))

    def set_ocp(self, current: float) -> None:
        """Set over-current protection trip level (A)."""
        i = float(current)
        if i < 0 or i > OCP_MAX:
            raise ValueError(f"OCP {i} out of [0, {OCP_MAX}] A")
        self._write(f"SOUR:CURR:PROT:HIGH {i:.1f}")

    def set_current_limit_hard(self, current: float) -> None:
        """Set the hard current-limit cap that clamps SOUR:CURR programming.

        Different from set_current(): this caps how high the CC threshold
        can go, protecting against runaway settings. Manual p.155.
        """
        self._write(f"SOUR:CURR:LIMIT:HIGH {float(current):.2f}")

    def set_slew_rate(self, v_per_ms: float) -> None:
        """Set output voltage slew rate in V/ms (0.001 .. 10 for 80-60 unit)."""
        s = float(v_per_ms)
        if s < SLEW_MIN or s > SLEW_MAX:
            raise ValueError(
                f"slew rate {s} out of [{SLEW_MIN}, {SLEW_MAX}] V/ms")
        self._write(f"SOUR:VOLT:SLEW {s:.3f}")

    def get_slew_rate(self) -> float:
        return float(self._query("SOUR:VOLT:SLEW?"))
