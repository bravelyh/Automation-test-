"""Power-supply drivers.

Each concrete driver lives in its own file and subclasses PSUBase. Register
the driver class in CATALOG in instruments/bench.py so auto-discovery can
match and instantiate it.
"""
