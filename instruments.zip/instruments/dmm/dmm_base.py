"""DMMBase — minimum contract every DMM driver should satisfy.

Placeholder; no concrete drivers yet. Common bench tasks a DMM does:
DCV / ACV / DCI / ACI / R / freq / range control.
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class DMMBase(ABC):
    @abstractmethod
    def close(self) -> None:
        """Close the underlying connection."""

    @abstractmethod
    def get_idn(self) -> str:
        """Return the DMM's identification string."""

    @abstractmethod
    def measure_dc_voltage(self) -> float:
        """Measure DC voltage in V."""

    @abstractmethod
    def measure_dc_current(self) -> float:
        """Measure DC current in A."""

    @abstractmethod
    def measure_resistance(self) -> float:
        """Measure resistance in Ω."""

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
