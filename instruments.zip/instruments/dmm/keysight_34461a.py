"""Keysight 34461A 6½-digit DMM — VISA transport.

Skeleton. SCPI commands filled in when needed by an actual test.
"""
from __future__ import annotations

import pyvisa

from instruments.dmm.dmm_base import DMMBase


class Keysight34461A(DMMBase):
    def __init__(self, addr: str) -> None:
        self.addr = addr
        self._rm: pyvisa.ResourceManager | None = None
        self._inst: pyvisa.resources.MessageBasedResource | None = None

    def open(self) -> None:
        self._rm = pyvisa.ResourceManager()
        self._inst = self._rm.open_resource(self.addr)

    def close(self) -> None:
        if self._inst is not None:
            try:
                self._inst.close()
            except Exception:
                pass
            self._inst = None

    def _query(self, cmd: str) -> str:
        if self._inst is None:
            raise RuntimeError("Keysight34461A not open; call open() first")
        return self._inst.query(cmd).strip()

    def get_idn(self) -> str:
        return self._query("*IDN?")

    def measure_dc_voltage(self) -> float:
        return float(self._query("MEASure:VOLTage:DC?"))

    def measure_dc_current(self) -> float:
        return float(self._query("MEASure:CURRent:DC?"))

    def measure_resistance(self) -> float:
        return float(self._query("MEASure:RESistance?"))
