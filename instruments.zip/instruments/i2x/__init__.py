"""I2X-AAA — 3-in-1 protocol bridge board (I2C + I2S + GPIO over UART).

Public API:
    from instruments.i2x.i2x_aaa import I2X_AAA
"""
