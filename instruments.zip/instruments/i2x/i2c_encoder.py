"""I2C command encoder / response parser for the I2X-AAA board.

Pure functions — no I/O, no state. The I2X_AAA driver calls `encode()`
to turn a user-facing script into a UART command string (plus the
expected response length), sends it, then feeds the reply to `parse()`.

Frame layout
------------
Command written to UART:
    i2c_flag(1) | cmd_length(4) | <segment 1> | <segment 2> | ...

Each segment (write or read):
    data_number(1) | wr(1) | device_addr(2) | reg_addr(2) | reg_data(N*2) | delay(4)

Response bytes:
  * Every segment yields an 8-char error code.
  * Read segments additionally yield N * 6-char data groups
    (device_addr(2) + reg_addr(2) + data(2) per byte read).

Script syntax (input to encode())
---------------------------------
    w <DEV_ADDR> <REG_ADDR> <DATA1> [DATA2 ...]      # write
    r <DEV_ADDR> <REG_ADDR> <N>                      # read N bytes (1..9)
    D<ms>                                             # optional delay after
                                                     # the previous op (0..9999)
"""
from __future__ import annotations


CMD_HEADER_LENGTH = 5              # i2c_flag(1) + cmd_length(4)
SEGMENT_READ_DATA_UNIT_LEN = 6     # dev_addr(2) + reg_addr(2) + data(2)
SEGMENT_ERROR_CODE_LEN = 8         # 8-char ascii error code

ERROR_CODES = {
    "00000000": "No error",
    "00000001": "BERR error",
    "00000002": "ARLO error",
    "00000004": "AF error",
    "00000008": "OVR error",
    "00000010": "DMA transfer error",
    "00000020": "Timeout Error",
    "00000040": "Size Management error",
    "00000080": "DMA Parameter Error",
    "00000200": "Wrong start Error",
}


def encode(script: str) -> tuple[str, int, list[dict]]:
    """Compile an I2C script into (cmd_string, expected_response_bytes, segments).

    Returns:
      cmd_string:   the ASCII UART frame to write.
      expected_len: number of bytes to read back from the UART.
      segments:     internal segment list (needed by parse()).
    """
    segments = _parse_script(script)
    cmd = _build_command(segments)
    expected_len = _expected_response_length(segments)
    return cmd, expected_len, segments


def parse(response: bytes, segments: list[dict]) -> list[list[str]]:
    """Parse the UART reply. Raises RuntimeError on any non-zero error code.

    Returns a list of read results (one entry per `r` segment). Each entry
    is a list of 6-char ASCII groups: `<dev_addr(2)><reg_addr(2)><data(2)>`.
    """
    results: list[list[str]] = []
    error_codes: list[str] = []
    pos = 0
    for seg in segments:
        error_code = response[pos:pos + SEGMENT_ERROR_CODE_LEN].decode(errors="ignore")
        error_codes.append(error_code)
        pos += SEGMENT_ERROR_CODE_LEN
        if seg["wr"] == "1":
            n = int(seg["data_number"])
            read_data: list[str] = []
            for _ in range(n):
                data = response[pos:pos + SEGMENT_READ_DATA_UNIT_LEN].decode(errors="ignore")
                read_data.append(data)
                pos += SEGMENT_READ_DATA_UNIT_LEN
            results.append(read_data)

    for i, code in enumerate(error_codes):
        code_hex = code.strip().upper().zfill(8)
        if code_hex == "00000000":
            continue
        seg = segments[i]
        if seg["wr"] == "0":
            line_str = f"w {seg['device_addr']} {seg['reg_addr']} {seg['reg_data']}"
        else:
            line_str = (f"r {seg['device_addr']} {seg['reg_addr']} "
                        f"{seg['data_number'].zfill(2)}")
        msg = ERROR_CODES.get(code_hex, "Unknown error")
        raise RuntimeError(f"I2C error on line '{line_str}': {msg} (code {code_hex})")

    return results


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------
def _parse_script(script: str) -> list[dict]:
    segments: list[dict] = []
    lines = script.splitlines()
    idx = 0
    while idx < len(lines):
        line = lines[idx].strip().upper()
        if not line:
            idx += 1
            continue
        parts = line.split()

        # Look-ahead for optional delay `Dxxxx` on the next line
        delay = "0000"
        next_idx = idx + 1
        if next_idx < len(lines):
            next_line = lines[next_idx].strip().upper().replace(" ", "")
            if next_line.startswith("D") and next_line[1:].isdigit():
                delay_val = next_line[1:]
                if 0 <= int(delay_val) <= 9999:
                    delay = f"{int(delay_val):04d}"
                    idx += 1

        if parts[0] == "W" and len(parts) >= 4:
            data_number = len(parts) - 3
            wr = "0"
            device_addr = parts[1]
            reg_addr = parts[2]
            reg_data = "".join(parts[3:])
            segments.append({
                "data_number": f"{data_number}",
                "wr": wr,
                "device_addr": device_addr,
                "reg_addr": reg_addr,
                "reg_data": reg_data,
                "delay": delay,
            })
        elif parts[0] == "R" and len(parts) == 4:
            if not parts[3].isdigit():
                raise ValueError(
                    f"Error in line {idx+1}: '{line}' - data number "
                    "must be a decimal integer (1~9)")
            data_number = int(parts[3])
            if data_number < 1 or data_number > 9:
                raise ValueError(
                    f"Error in line {idx+1}: '{line}' - data number "
                    "must be between 1 and 9")
            wr = "1"
            device_addr = parts[1]
            reg_addr = parts[2]
            reg_data = "00" * data_number
            segments.append({
                "data_number": f"{data_number}",
                "wr": wr,
                "device_addr": device_addr,
                "reg_addr": reg_addr,
                "reg_data": reg_data,
                "delay": delay,
            })
        else:
            raise ValueError(
                f"Error in line {idx+1}: '{line}' - format should be "
                "'w <DEV_ADDR> <REG_ADDR> <DATA...>' or "
                "'r <DEV_ADDR> <REG_ADDR> <DATA_NUM>'"
            )
        idx += 1
    return segments


def _build_command(segments: list[dict]) -> str:
    i2c_flag = "1"
    cmd_body = ""
    for seg in segments:
        cmd_body += (
            f"{seg['data_number']}{seg['wr']}{seg['device_addr']}"
            f"{seg['reg_addr']}{seg['reg_data']}{seg['delay']}"
        )
    cmd_length = f"{len(cmd_body) + CMD_HEADER_LENGTH:04d}"
    return f"{i2c_flag}{cmd_length}{cmd_body}"


def _expected_response_length(segments: list[dict]) -> int:
    expected = 0
    for seg in segments:
        expected += SEGMENT_ERROR_CODE_LEN
        if seg["wr"] == "1":
            expected += int(seg["data_number"]) * SEGMENT_READ_DATA_UNIT_LEN
    return expected
