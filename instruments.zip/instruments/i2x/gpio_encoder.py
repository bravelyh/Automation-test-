"""GPIO command encoder for the I2X-AAA board — pure function, no I/O.

Frame layout
------------
    flag(1) | length(4) | <segment 1> | <segment 2> | ...

Each per-GPIO segment (6 chars):
    gpio_letter(1) | on_off(1) | delay(4)

Fields:
  flag         = "3" (GPIO mode)
  length       = total command length, 4-digit decimal
  gpio_letter  = "A" / "B" / "C" (what the MCU firmware expects on the wire)
  on_off       = "1" on, "0" off
  delay        = 4-digit decimal, = delay_ms + 1 (protocol quirk)

External API uses `gpio1` / `gpio2` / `gpio3` — mapped to A/B/C internally.
"""
from __future__ import annotations


FLAG = "3"
HEADER_LEN = 5      # flag(1) + length(4)
SEGMENT_LEN = 6     # gpio_letter(1) + on_off(1) + delay(4)

# gpioN kwarg -> letter written to the MCU
GPIO_LETTERS: dict[str, str] = {"gpio1": "A", "gpio2": "B", "gpio3": "C"}


def encode(
    gpio1: tuple[bool, int] | None = None,
    gpio2: tuple[bool, int] | None = None,
    gpio3: tuple[bool, int] | None = None,
) -> str:
    """Build the GPIO command frame.

    Args:
        gpio1 / gpio2 / gpio3:
            Each is `(on: bool, delay_ms: int)` or None to skip that GPIO.
            delay_ms range 0..9998 (field is delay_ms + 1, must fit 4 digits).
            At least one GPIO must be non-None.

    Example:
        encode(gpio1=(True, 10), gpio2=(False, 10), gpio3=(True, 10))
          -> "30023A10011B00011C10011"
        encode(gpio1=(True, 10))
          -> "30011A10011"
    """
    segments = []
    for kwarg_name, spec in (("gpio1", gpio1), ("gpio2", gpio2), ("gpio3", gpio3)):
        if spec is None:
            continue
        on_off, delay_ms = spec
        if not (0 <= int(delay_ms) <= 9998):
            raise ValueError(
                f"{kwarg_name} delay_ms {delay_ms} out of [0, 9998]")
        letter  = GPIO_LETTERS[kwarg_name]
        state   = "1" if on_off else "0"
        delay_f = f"{int(delay_ms) + 1:04d}"
        segments.append(f"{letter}{state}{delay_f}")

    if not segments:
        raise ValueError("gpio_encoder.encode: no GPIO specified "
                         "(pass at least one of gpio1/gpio2/gpio3)")

    body = "".join(segments)
    total_len = HEADER_LEN + len(body)
    return f"{FLAG}{total_len:04d}{body}"
