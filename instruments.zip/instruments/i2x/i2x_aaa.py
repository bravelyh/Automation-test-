"""I2X-AAA — 3-in-1 protocol bridge (I2C / I2S / GPIO) over UART.

The board is a custom MCU. The PC connects via its STLink Virtual COM
Port and speaks an ASCII framing protocol; the MCU translates each frame
into I2C bus transactions, I2S register writes, or GPIO toggles.

Public API — three flat methods, each self-contained (open → write →
[read] → close). I2C returns the parsed read results; I2S and GPIO are
fire-and-forget.

    board = I2X_AAA("COM14")
    results = board.i2c_send("w E0 03 22\\nD100\\nr E0 05 1")
    board.i2s_send(sample_rate=48000, ...)      # when spec lands
    board.gpio_send(pin=3, level=True)          # when spec lands

Transport is pyserial (raw serial to the STLink VCP, e.g. `"COM14"`).
Baud 115200, 20 s read timeout to allow scripts with long inline delays.
"""
from __future__ import annotations

import serial

from instruments.i2x import i2c_encoder, i2s_encoder, gpio_encoder


BAUD = 115200
READ_TIMEOUT_MS = 20000


class I2X_AAA:
    def __init__(self, addr: str) -> None:
        # `__init__` does NOT open the port. Each public method opens/closes
        # its own connection so callers don't have to manage state.
        self.addr = addr

    def open(self) -> None:
        """No-op — I2X_AAA auto-opens the port for every send/receive.
        Provided for API compatibility with drivers that hold a persistent
        connection (Chroma62012P, TS700, ...)."""

    def close(self) -> None:
        """No-op — see open()."""

    # ---- protocol methods -----------------------------------------------
    def i2c_send(self, script: str) -> list[list[str]]:
        """Compile+send an I2C script, read the reply, return parsed results.

        Raises RuntimeError on any per-segment I2C error code.
        """
        cmd, expected_len, segments = i2c_encoder.encode(script)
        response = self._write_and_read(cmd, expected_len)
        return i2c_encoder.parse(response, segments)

    def i2s_send(
        self,
        *,
        word_length: int,
        sample_rate: int,
        amplitude_dbfs: float,
        frequency: int,
    ) -> None:
        """Configure the I2S generator. All args keyword-only.

        word_length:    24 or 32 (bits).
        sample_rate:    Hz (e.g. 48000, 96000).
        amplitude_dbfs: dBFS, must be <= 0.
        frequency:      tone frequency in Hz.
        """
        cmd = i2s_encoder.encode(
            word_length=word_length,
            sample_rate=sample_rate,
            amplitude_dbfs=amplitude_dbfs,
            frequency=frequency,
        )
        self._write(cmd)

    def gpio_send(
        self,
        gpio1: tuple[bool, int] | None = None,
        gpio2: tuple[bool, int] | None = None,
        gpio3: tuple[bool, int] | None = None,
    ) -> None:
        """Set GPIO 1/2/3 on the board (encoded as A/B/C on the wire).
        Each arg is (on: bool, delay_ms: int) or None to skip that GPIO."""
        cmd = gpio_encoder.encode(gpio1=gpio1, gpio2=gpio2, gpio3=gpio3)
        self._write(cmd)

    # ---- low-level UART (open + write [+ read] + close) ----------------
    def _open(self) -> serial.Serial:
        return serial.Serial(
            self.addr, baudrate=BAUD, bytesize=8, parity="N",
            stopbits=1, timeout=READ_TIMEOUT_MS / 1000.0)

    def _write(self, cmd: str) -> None:
        inst = self._open()
        try:
            inst.write(cmd.encode("ascii"))
            inst.flush()
        finally:
            try:
                inst.close()
            except Exception:
                pass

    def _write_and_read(self, cmd: str, expected_len: int) -> bytes:
        inst = self._open()
        try:
            inst.write(cmd.encode("ascii"))
            inst.flush()
            return inst.read(expected_len)
        finally:
            try:
                inst.close()
            except Exception:
                pass
