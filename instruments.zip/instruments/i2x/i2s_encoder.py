"""I2S command encoder for the I2X-AAA board — pure function, no I/O.

Frame layout (fixed 21 chars)
-----------------------------
    flag(1) | length(4) | word_length(2) | sample_rate(5) | amplitude(4) | frequency(5)

Fields:
  flag         = "2" (I2S mode)
  length       = "0021" (total length, always 21)
  word_length  = "24" or "32"
  sample_rate  = 5-digit sample rate in Hz (e.g. "48000", "96000")
  amplitude    = 4-digit level, dBFS -> 10000-FS scale (see below)
  frequency    = 5-digit tone frequency in Hz (e.g. "00020", "01000", "10000")

Amplitude encoding
------------------
  Input is dBFS (must be <= 0). Encoded as `round(10^(dBFS/20) * 10000)`
  clamped to the 4-digit field maximum 9999.
      0 dBFS   -> 9999   (would compute to 10000, clamped)
    -20 dBFS   -> 1000
    -40 dBFS   -> 0100
    -60 dBFS   -> 0010
"""
from __future__ import annotations


FLAG = "2"
TOTAL_LEN = 21   # header(5) + fields(2+5+4+5)


def encode(
    *,
    word_length: int,
    sample_rate: int,
    amplitude_dbfs: float,
    frequency: int,
) -> str:
    """Build the I2S command frame.

    Args (all keyword-only):
        word_length:     24 or 32 (bits per sample).
        sample_rate:     Hz, 0..99999 (fits the 5-digit field).
        amplitude_dbfs:  dBFS, must be <= 0.
        frequency:       tone frequency in Hz, 0..99999.
    """
    if word_length not in (24, 32):
        raise ValueError(f"word_length {word_length} invalid (expected 24 or 32)")
    if not (0 <= int(sample_rate) <= 99999):
        raise ValueError(f"sample_rate {sample_rate} out of [0, 99999] Hz")
    if amplitude_dbfs > 0:
        raise ValueError(
            f"amplitude_dbfs {amplitude_dbfs} must be <= 0 (positive dBFS "
            "not allowed)")
    if not (0 <= int(frequency) <= 99999):
        raise ValueError(f"frequency {frequency} out of [0, 99999] Hz")

    wl_field   = f"{int(word_length):02d}"
    sr_field   = f"{int(sample_rate):05d}"
    amp_field  = f"{_dbfs_to_field(amplitude_dbfs):04d}"
    freq_field = f"{int(frequency):05d}"

    return f"{FLAG}{TOTAL_LEN:04d}{wl_field}{sr_field}{amp_field}{freq_field}"


def _dbfs_to_field(dbfs: float) -> int:
    """dBFS -> 4-digit field value (linear amplitude * 10000, capped at 9999)."""
    linear = 10 ** (float(dbfs) / 20.0)
    field  = round(linear * 10000)
    return min(field, 9999)
