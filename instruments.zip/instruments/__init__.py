"""Bench_Automation instruments package — hardware abstraction layer.

Top-level entry: `Bench` in `bench.py`. Callers normally do:

    from instruments.bench import Bench
    bench = Bench()
    bench.psu_high_power.set_voltage(12.0)
"""
