"""ScopeBase — minimum contract every oscilloscope driver should satisfy.

Placeholder; no concrete drivers yet. Typical bench operations:
per-channel vertical setup, timebase, trigger, waveform fetch, screenshot.
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class ScopeBase(ABC):
    @abstractmethod
    def close(self) -> None:
        """Close the underlying connection."""

    @abstractmethod
    def get_idn(self) -> str:
        """Return the scope's identification string."""

    @abstractmethod
    def set_channel_scale(self, channel: int, volts_per_div: float) -> None:
        """Set vertical scale (V/div) on a channel."""

    @abstractmethod
    def set_timebase(self, seconds_per_div: float) -> None:
        """Set horizontal scale (s/div)."""

    @abstractmethod
    def capture_waveform(self, channel: int) -> tuple[list[float], list[float]]:
        """Fetch the (time, voltage) samples currently on-screen."""

    @abstractmethod
    def save_screenshot(self, path: str) -> None:
        """Save a PNG screenshot of the scope display to `path`."""

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
