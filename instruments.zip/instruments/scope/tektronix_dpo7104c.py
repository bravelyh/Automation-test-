"""Tektronix DPO7104C — 1 GHz, 4-channel digital phosphor oscilloscope.

Skeleton driver over VISA. The DPO7xxx family shares SCPI with older
Tek scopes (DPO/MSO4000, TDS series). Fill in commands per test needs.
"""
from __future__ import annotations

import pyvisa

from instruments.scope.scope_base import ScopeBase


class TekDPO7104C(ScopeBase):
    def __init__(self, addr: str) -> None:
        self.addr = addr
        self._rm: pyvisa.ResourceManager | None = None
        self._inst: pyvisa.resources.MessageBasedResource | None = None

    def open(self) -> None:
        self._rm = pyvisa.ResourceManager()
        self._inst = self._rm.open_resource(self.addr)

    def close(self) -> None:
        if self._inst is not None:
            try:
                self._inst.close()
            except Exception:
                pass
            self._inst = None

    def _write(self, cmd: str) -> None:
        if self._inst is None:
            raise RuntimeError("TekDPO7104C not open; call open() first")
        self._inst.write(cmd)

    def _query(self, cmd: str) -> str:
        if self._inst is None:
            raise RuntimeError("TekDPO7104C not open; call open() first")
        return self._inst.query(cmd).strip()

    def get_idn(self) -> str:
        return self._query("*IDN?")

    def set_channel_scale(self, channel: int, volts_per_div: float) -> None:
        self._write(f"CH{channel}:SCALE {float(volts_per_div):g}")

    def set_timebase(self, seconds_per_div: float) -> None:
        self._write(f"HORizontal:SCAle {float(seconds_per_div):g}")

    def capture_waveform(self, channel: int) -> tuple[list[float], list[float]]:
        raise NotImplementedError

    def save_screenshot(self, path: str) -> None:
        raise NotImplementedError
