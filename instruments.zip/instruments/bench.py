"""Bench facade — auto-discovery of instruments on the local machine.

The CATALOG below is the entire configuration: for each instrument
category, one entry per known model (driver class + identifying keyword).
`Bench` is the thin orchestration layer: on attribute access it scans
buses, matches the keyword, instantiates the driver, and caches.

Usage:
    from instruments.bench import Bench
    bench = Bench()                            # trivial; no config lookup
    bench.psu_high_power.set_voltage(12)       # 1st access: scan + match + open
    bench.dmm.measure_dc_voltage()             # 2nd access: reuses cached scan

Rules of the framework:
  * At most one instrument per category on any bench.
  * If none match at access time -> AttributeError-ish RuntimeError with
    a helpful diagnostic listing what was scanned vs. what was expected.
  * Matching is a case-insensitive substring check: COM ports look at
    `description`, VISA resources look at the `model` field of their
    *IDN? reply. Keywords must be distinctive enough that only one
    column matches (a model number or unique product string works well).

Add a new physical instrument:
  1. Write the driver class under instruments/<category>/<name>.py
  2. Import it below.
  3. Append one dict {"class": ..., "keyword": ...} to CATALOG[<category>].

Add a new category (rare):
  1. Create instruments/<newcat>/ with a base + at least one driver.
  2. Import the driver here and add a new CATALOG key + entry list.
"""
from __future__ import annotations

from typing import Any

from instruments import discovery
from instruments.psu.chroma_62012p          import Chroma62012P
from instruments.psu.gwinstek_gpp4323       import GwinstekGPP4323
from instruments.dmm.keysight_34461a        import Keysight34461A
from instruments.thermal.ats_710            import ATS710
from instruments.i2x.i2x_aaa                import I2X_AAA
from instruments.loadbox.loadbox_SH         import Loadbox_SH
from instruments.scope.tektronix_dpo7104c   import TekDPO7104C


# ---------------------------------------------------------------------------
# Catalog (single source of truth)
# ---------------------------------------------------------------------------
CATALOG: dict[str, list[dict]] = {
    "psu_high_power": [{"class": Chroma62012P,    "keyword": "62012P-80-60"}],
    "psu_4ch":        [{"class": GwinstekGPP4323, "keyword": "GPP Serial"}],
    "dmm":            [{"class": Keysight34461A,  "keyword": "34461A"}],
    "thermal":        [{"class": ATS710,          "keyword": "ATS-710"}],
    "i2x":            [{"class": I2X_AAA,          "keyword": "STLink Virtual COM"}],
    "loadbox":        [{"class": Loadbox_SH,      "keyword": "Prolific"}],
    "oscilloscope":   [{"class": TekDPO7104C,     "keyword": "DPO7104C"}],
}


# ---------------------------------------------------------------------------
# Bench registry (PC ID -> physical bench identity)
# ---------------------------------------------------------------------------
# The CATALOG above matches *hardware buses* (COM/VISA). This table matches
# the *machine itself*: hostname (PC ID) -> bench id + AP type. The bench id
# selects the loadbox calibration file in loadbox/bench_loadbox_mapping/; the
# AP type says which Audio Precision analyzer this bench drives.
#
# Add a bench: run `hostname` on it and append one row. `bench_id` must have a
# matching Bench_#<bench_id>_Loadbox_Value.txt (mappings exist for benches
# 1-6, 8, 9, A17, B17, C17, C18).
BENCH_REGISTRY: dict[str, dict[str, str]] = {
    #  PC ID (hostname)   bench_id   ap_type
    "DT4CE210CTM1": {"bench_id": "8", "ap_type": "APx555"},
    "DTGM0MPKJ9": {"bench_id": "4", "ap_type": "APx2722"}
}


# ---------------------------------------------------------------------------
# Bench facade
# ---------------------------------------------------------------------------
class Bench:
    def categories(self) -> list[str]:
        """Every category the framework knows about."""
        return sorted(CATALOG)

    def rescan(self) -> None:
        """Force a fresh bus scan on the next attribute access."""
        discovery.clear_cache()

    # -- Bench identity (PC ID -> bench id + AP type) --------------------
    @property
    def pc_id(self) -> str:
        """This machine's hostname (PC ID), from the bus scan."""
        return discovery.scan_all()["pc_id"]

    def _registry_row(self) -> dict[str, str]:
        row = BENCH_REGISTRY.get(self.pc_id)
        if row is None:
            known = ", ".join(sorted(BENCH_REGISTRY)) or "(none)"
            raise RuntimeError(
                f"PC ID {self.pc_id!r} is not in BENCH_REGISTRY. Add a row "
                f"mapping it to a bench_id + ap_type. Registered PC IDs: {known}.")
        return row

    @property
    def bench_id(self) -> str:
        """This bench's id (e.g. '8'), resolved from the PC ID."""
        return self._registry_row()["bench_id"]

    @property
    def ap_type(self) -> str:
        """Audio Precision analyzer type on this bench (e.g. 'APx555')."""
        return self._registry_row()["ap_type"]

    # -- Loadbox calibration (actual measured resistance) ----------------
    def loadbox_values(self) -> dict[str, list[float]]:
        """This bench's loadbox calibration: {set_value: [ch1..ch4]} ohms.

        Actual measured resistance, keyed by nominal load ('1'..'8').
        """
        from instruments.loadbox.loadbox_SH import load_bench_values
        return load_bench_values(self.bench_id)

    def loadbox_resistance(self, labels: list[str]) -> list[float]:
        """Actual ohms for CH1..CH4 given their commanded load labels.

        `labels` are the per-channel load keys ('1'..'8') used by the
        loadbox. Returns the real measured resistance of each physical
        channel at that setting — use for power/current calculations.
        """
        table = self.loadbox_values()
        out: list[float] = []
        for ch, label in enumerate(labels, start=1):
            row = table.get(str(label))
            if row is None:
                valid = ", ".join(sorted(table)) or "(none)"
                raise KeyError(
                    f"no calibrated resistance for load {label!r} on bench "
                    f"{self.bench_id} (CH{ch}). Calibrated loads: {valid}.")
            out.append(row[ch - 1])
        return out

    # -- Audio Precision analyzer ----------------------------------------
    def ap(self, mode: str = "bench"):
        """Instantiate this bench's Audio Precision analyzer.

        Resolves `ap_type` (from the PC ID) to its registered driver and
        returns an instance in the requested `mode` ("bench", or "sequence"
        for the APx555). Unlike the bus-scanned categories this is a factory,
        not a cached attribute — the `mode` argument makes each call distinct;
        call it once and hold the result.
        """
        from instruments.ap import APBase   # importing the package registers drivers
        driver_cls = APBase._registry.get(self.ap_type)
        if driver_cls is None:
            known = ", ".join(sorted(APBase._registry)) or "(none)"
            raise RuntimeError(
                f"no AP driver registered for ap_type {self.ap_type!r}. "
                f"Known: {known}.")
        return driver_cls(mode=mode)

    # -- Oscilloscope (auto-discover, or manual LAN IP) ------------------
    def scope(self, ip: str | None = None):
        """This bench's oscilloscope.

        `ip=None` (default): auto-discover on GPIB/USB via CATALOG.
        `ip="10.85.29.232"`: address it over LAN — pass only the IP and the
        VISA wrapper `TCPIP0::<ip>::inst0::INSTR` is filled in for you (a full
        `TCPIP0::...` / `GPIB...` resource string is also accepted as-is).

        LAN scopes are not auto-discovered (the bus scan skips TCPIP), so pass
        an IP for those. Raises if no IP is given and none is found on the bus.
        """
        entries = CATALOG["oscilloscope"]
        if ip is not None:
            ip = str(ip).strip()
            addr = ip if "::" in ip else f"TCPIP0::{ip}::inst0::INSTR"
            return entries[0]["class"](addr)
        scan = discovery.scan_all()
        for entry in entries:
            addr = _find_match(scan, entry)
            if addr is not None:
                return entry["class"](addr)
        raise RuntimeError(
            "no oscilloscope found on GPIB/USB. If it is connected over LAN, "
            "pass its IP, e.g. bench.scope('10.85.29.232').")

    def __getattr__(self, category: str) -> Any:
        # __getattr__ only fires for names not already in self.__dict__.
        if category not in CATALOG:
            known = ", ".join(sorted(CATALOG))
            raise AttributeError(
                f"unknown category {category!r}. Known: {known}")

        entries = CATALOG[category]
        scan = discovery.scan_all()
        for entry in entries:
            addr = _find_match(scan, entry)
            if addr is not None:
                instance = entry["class"](addr)
                self.__dict__[category] = instance
                return instance

        raise RuntimeError(_no_match_message(category, entries, scan))


# ---------------------------------------------------------------------------
# Matcher
# ---------------------------------------------------------------------------
def _find_match(scan: dict, entry: dict) -> str | None:
    """Return the first matching device's address, or None.

    Checks COM port descriptions first, then VISA `model` fields. Well-
    chosen keywords hit only one column, so the order doesn't matter --
    it's just a short-circuit.
    """
    keyword = entry["keyword"].lower()
    for p in scan["com"]:
        if keyword in (p["description"] or "").lower():
            return p["address"]
    for r in scan["visa"]:
        if keyword in (r["model"] or "").lower():
            return r["address"]
    return None


def _no_match_message(category: str, entries: list[dict], scan: dict) -> str:
    tried = ", ".join(repr(e["keyword"]) for e in entries)
    coms  = ", ".join(f"{p['address']}={p['description']!r}" for p in scan["com"])  or "(none)"
    visas = ", ".join(f"{r['address']}=model:{r['model']!r}"  for r in scan["visa"]) or "(none)"
    return (
        f"no device found for category {category!r}. "
        f"Tried keywords: {tried}. "
        f"Scanned COM ports: {coms}. "
        f"Scanned VISA models: {visas}."
    )
