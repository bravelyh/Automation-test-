"""ThermalBase — minimal shared interface for thermal-forcing instruments.

Deliberately tiny. Only the operations that every thermal device is likely
to expose. Model-specific extras (cycle mode, cool control, DUT sensor)
live on the concrete class.
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class ThermalBase(ABC):
    @abstractmethod
    def close(self) -> None:
        """Close the underlying connection."""

    @abstractmethod
    def get_idn(self) -> str:
        """Return the instrument's identification string."""

    @abstractmethod
    def set_temp(self, temp: float) -> None:
        """Program a setpoint and block until the DUT reaches it."""

    @abstractmethod
    def get_temp(self) -> float:
        """Read the current air or DUT temperature (whichever is active)."""

    @abstractmethod
    def flow_on(self) -> None:
        """Turn the air flow on."""

    @abstractmethod
    def flow_off(self) -> None:
        """Turn the air flow off."""

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
