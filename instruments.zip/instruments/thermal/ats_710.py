"""TEMPTRONIC ATS-710 Thermal Stream — VISA-based remote control.

Ported from tools/Thermal Stream Control/Thermal_Stream.py (class renamed
from `Thermal_Stream` to `ATS710`; behavior unchanged).

Reference: TS700 远程控制命令V3.1 (Temptronic thermal stream command set; ATS-710 is protocol-compatible with the TS700 family). All command
letters uppercase; set commands use `CMD value`, queries use `CMD?`.

The transport is VISA — typically a USB-TMC or GPIB link. The Bench
facade discovers this instrument via its `*IDN?` response — model field `"ATS-710"`.
"""
from __future__ import annotations

import time

import pyvisa as pv

from instruments.thermal.thermal_base import ThermalBase


class ATS710(ThermalBase):

    rm = pv.ResourceManager()

    def __init__(self, addr: str) -> None:
        self.addr = addr
        self.my_ins = self.rm.open_resource(addr)
        self.my_ins.write_termination = None

    # ---- transport helpers ----------------------------------------------
    def _write(self, cmd: str) -> None:
        self.my_ins.write(cmd)

    def _query(self, cmd: str) -> str:
        self.my_ins.write(cmd)
        return self.my_ins.read().strip()

    def close(self) -> None:
        try:
            self.my_ins.close()
        except Exception:
            pass

    # ---- identity / local-remote ----------------------------------------
    def get_idn(self) -> str:
        return self._query("*IDN?")

    def set_local(self) -> None:
        """%GL - switch to local, release manual-UI lock."""
        self._write("%GL")

    def set_remote(self) -> None:
        """%RM - switch to remote, locks manual UI. Call first in scripts."""
        self._write("%RM")

    # ---- compressor -----------------------------------------------------
    def cool_on(self) -> None:
        self._write("COOL 1")

    def cool_off(self) -> None:
        """Stops compressor. Cold testing unavailable until re-enabled."""
        self._write("COOL 0")

    def get_cool(self) -> int:
        return int(self._query("COOL?"))

    # ---- temperature control mode --------------------------------------
    def set_dut_mode(self, mode: int) -> None:
        """DUTM - 0=Air (default), 1=DUT, 2=Air with DUT displayed.
        Flow must be OFF when sending this command.
        """
        assert mode in (0, 1, 2)
        self._write(f"DUTM {mode}")

    def get_dut_mode(self) -> int:
        return int(self._query("DUTM?"))

    # ---- DUT sensor type -----------------------------------------------
    def set_dut_sensor(self, sensor: int) -> None:
        """DSNS - 0=NON, 1=T-type TC, 2=K-type TC."""
        assert sensor in (0, 1, 2)
        self._write(f"DSNS {sensor}")

    def get_dut_sensor(self) -> int:
        return int(self._query("DSNS?"))

    # ---- flow -----------------------------------------------------------
    def flow_on(self) -> None:
        self._write("FLOW 1")

    def flow_off(self) -> None:
        self._write("FLOW 0")

    def get_flow(self) -> int:
        return int(self._query("FLOW?"))

    def get_flow_actual(self) -> float:
        """FLRE? - measured flow in SCFM (1 SCFM = 28.3 L/min)."""
        return float(self._query("FLRE?"))

    def set_flow_rate(self, scfm: float) -> None:
        """FLWM - target flow in SCFM. Valid range 4-18."""
        self._write(f"FLWM {scfm}")

    def get_flow_rate(self) -> float:
        return float(self._query("FLWM?"))

    # ---- head -----------------------------------------------------------
    def head_down(self) -> None:
        """HEAD 1 - lower head onto DUT."""
        self._write("HEAD 1")

    def head_up(self) -> None:
        """HEAD 0 - raise head."""
        self._write("HEAD 0")

    def get_head(self) -> int:
        return int(self._query("HEAD?"))

    def head_lock(self) -> None:
        """HDLK 1 - lock head in current up/down position."""
        self._write("HDLK 1")

    def head_unlock(self) -> None:
        self._write("HDLK 0")

    def get_head_lock(self) -> int:
        return int(self._query("HDLK?"))

    # ---- temperature limits --------------------------------------------
    def set_low_limit(self, temp: float) -> None:
        """LLIM - low temp limit in °C. Valid -99 to 25."""
        self._write(f"LLIM {temp}")

    def get_low_limit(self) -> float:
        return float(self._query("LLIM?"))

    def set_high_limit(self, temp: float) -> None:
        """ULIM - high temp limit in °C. Valid 25 to 225."""
        self._write(f"ULIM {temp}")

    def get_high_limit(self) -> float:
        return float(self._query("ULIM?"))

    # ---- ramp -----------------------------------------------------------
    def set_ramp(self, rate: float) -> None:
        """RAMP - ramp rate in °C/min. 0-9999. 0 disables ramp (fastest)."""
        self._write(f"RAMP {rate}")

    def get_ramp(self) -> float:
        return float(self._query("RAMP?"))

    # ---- setpoint / zone -----------------------------------------------
    def set_setpoint(self, temp: float) -> None:
        """Auto-pick zone. Rule (empirical, matches how the chamber actually
        cools rather than the manual's nominal zone ranges):
          - temp >  35  -> zone 0 (high, heater path)
          - temp <  15  -> zone 2 (low, compressor path — required to cool
                                    below ambient even for 0-14 °C setpoints)
          - otherwise   -> zone 1 (ambient, no active cooling)
        Preserves WNDW across zone changes (device resets it on SETN).
        """
        if temp > 35:
            zone = 0
        elif temp < 15:
            zone = 2
        else:
            zone = 1
        current_zone = int(self._query("SETN?"))
        if zone != current_zone:
            wndw = float(self._query("WNDW?"))
            self._write(f"SETN {zone}")
            self._write(f"WNDW {wndw}")
        else:
            self._write(f"SETN {zone}")
        self._write(f"SETP {temp}")

    def set_zone(self, zone: int) -> None:
        """SETN - 0=high, 1=ambient, 2=low. Cycle UI: 1-20 selects program step."""
        self._write(f"SETN {zone}")

    def get_zone(self) -> int:
        return int(self._query("SETN?"))

    def get_setpoint(self) -> float:
        return float(self._query("SETP?"))

    # ---- temperature readback ------------------------------------------
    def get_air_temp(self) -> float:
        """TMPA? - nozzle/air temperature."""
        return float(self._query("TMPA?"))

    def get_dut_temp(self) -> float:
        """TMPD? - DUT thermocouple temperature."""
        return float(self._query("TMPD?"))

    def get_temp(self) -> float:
        """TEMP? - air temp in Air mode, DUT temp in DUT mode."""
        return float(self._query("TEMP?"))

    # ---- window / soak -------------------------------------------------
    def set_accuracy(self, accuracy: float) -> None:
        """WNDW - temperature window in °C, 0.1-9.9."""
        self._write(f"WNDW {accuracy}")

    def get_accuracy(self) -> float:
        return float(self._query("WNDW?"))

    def set_soak(self, soak_time: int) -> None:
        """SOAK - hold time in seconds, 1-9999."""
        self._write(f"SOAK {soak_time}")

    def get_soak(self) -> int:
        return int(self._query("SOAK?"))

    # ---- cycle mode ----------------------------------------------------
    def set_cycle_count(self, n: int) -> None:
        """CYCC - cycle count, 1-9999."""
        self._write(f"CYCC {n}")

    def get_cycle_count(self) -> int:
        return int(self._query("CYCC?"))

    def cycle_start(self) -> None:
        self._write("CYCL 1")

    def cycle_stop(self) -> None:
        self._write("CYCL 0")

    def get_cycle(self) -> int:
        return int(self._query("CYCL?"))

    # ---- status --------------------------------------------------------
    def get_TECR(self) -> float:
        """TECR? - bit 0 = at temp + soak done, bit 1 = not at temp."""
        return float(self._query("TECR?"))

    def at_temperature(self) -> bool:
        """True when TECR bit 0 is set (at setpoint and soak elapsed)."""
        return bool(int(self.get_TECR()) & 1)

    def get_aux_status(self) -> int:
        """AUXC? - status bitfield.
          bit 6: 1=manual UI, 0=cycle UI
          bit 5: 1=flow on, 0=flow off
          bit 4: 1=DUT control, 0=Air control
          bit 3: 1=heat-only, 0=heat/cool
          bit 2: 1=head up, 0=head down
        """
        return int(self._query("AUXC?"))

    def get_error(self) -> int:
        """ERROR? - alarm bitfield. 0 = no alarms.
          bit 11: temp-controller comm fault
          bit 10: PLC comm fault
          bit  9: air over-temp
          bit  8: compressor overload
          bit  7: compressor high-pressure
          bit  6: compressor low-pressure
          bit  5: supply air pressure low
          bit  4: compressor discharge TC broken
          bit  3: compressor discharge over-temp
          bit  2: DUT TC not connected / broken
          bit  1: air TC broken
          bit  0: supply flow too low
        """
        return int(self._query("ERROR?"))

    # ---- high-level convenience ----------------------------------------
    def set_temp(self, temp: float, timeout: float | None = None) -> None:
        """Set setpoint, turn flow on, block until at-temperature + soak done."""
        self.set_setpoint(temp)
        self.flow_on()
        start = time.time()
        while not self.at_temperature():
            if timeout and time.time() - start > timeout:
                raise TimeoutError(f"Did not reach {temp} C within {timeout} s")
            time.sleep(1)
